package com.example

import android.content.Context
import androidx.test.core.app.ApplicationProvider
import com.example.data.model.ServiceCategory
import com.example.data.repository.AkinhubRepository
import com.example.ui.viewmodel.AkinhubViewModel
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertTrue
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [36])
class ExampleRobolectricTest {

  @Test
  fun `read string from context`() {
    val context = ApplicationProvider.getApplicationContext<Context>()
    val appName = context.getString(R.string.app_name)
    assertEquals("AKINHUB", appName)
  }

  @Test
  fun `verify repository initial services`() {
    val repository = AkinhubRepository()
    val services = repository.services.value
    assertTrue(services.isNotEmpty())
    assertTrue(services.any { it.id == "pan_new" })
    assertTrue(services.any { it.id == "adre_job_apply" })
    assertTrue(services.any { it.id == "apdcl_bill" })
  }

  @Test
  fun `verify age calculation logic`() {
    val viewModel = AkinhubViewModel()
    viewModel.calculateAge(2000, 8, 15, 2026, 8, 15)
    val result = viewModel.uiState.value.ageResult
    assertNotNull(result)
    assertEquals(26, result?.years)
    assertEquals(0, result?.months)
    assertEquals(0, result?.days)
    assertTrue(result?.eligibleExams?.isNotEmpty() == true)
  }

  @Test
  fun `verify electricity bill calculation logic`() {
    val viewModel = AkinhubViewModel()
    viewModel.calculateElectricityBill(100.0)
    val bill = viewModel.uiState.value.billResult
    assertNotNull(bill)
    // 100 * 5.40 = 540 + 60 (fixed) = 600 + 5% (30) = 630.0
    assertEquals(630.0, bill?.totalEstimatedBill ?: 0.0, 0.01)
  }
}
