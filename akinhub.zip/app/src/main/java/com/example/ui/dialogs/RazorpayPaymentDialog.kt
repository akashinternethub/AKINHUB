package com.example.ui.dialogs

import android.annotation.SuppressLint
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.webkit.JavascriptInterface
import android.webkit.WebSettings
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.Toast
import androidx.compose.animation.*
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.compose.ui.window.Dialog
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.ui.window.DialogProperties
import com.example.ui.components.ContactHelper
import com.example.ui.theme.AkinAmberAccent
import com.example.ui.theme.AkinGreenSuccess
import com.example.ui.theme.AkinNavyDark

class PaymentJsBridge(
    private val onComplete: (paymentId: String) -> Unit
) {
    @JavascriptInterface
    fun onPaymentSuccess(paymentId: String) {
        onComplete(paymentId)
    }

    @JavascriptInterface
    fun onPaymentFailure(error: String) {
        // failed callback
    }
}

@SuppressLint("SetJavaScriptEnabled")
@Composable
fun RazorpayPaymentDialog(
    itemName: String = "AI Tool HD Download (No Watermark)",
    amountRs: Int = 10,
    paymentButtonId: String = "pl_TSU7RSYHOBTThn",
    onPaymentSuccess: () -> Unit,
    onPaymentCancelledOrFailed: () -> Unit,
    onDismiss: () -> Unit
) {
    val context = LocalContext.current
    var isPaymentSuccessDetected by remember { mutableStateOf(false) }

    // Official Razorpay HTML embed with event listener bridge
    val razorpayHtml = """
        <!DOCTYPE html>
        <html>
        <head>
            <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no">
            <style>
                * { box-sizing: border-box; margin: 0; padding: 0; }
                body {
                    font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif;
                    background-color: #0B132B;
                    color: #FFFFFF;
                    display: flex;
                    flex-direction: column;
                    align-items: center;
                    justify-content: flex-start;
                    padding: 16px 12px;
                    min-height: 100vh;
                    text-align: center;
                }
                .title { font-size: 13px; font-weight: 700; color: #F59E0B; margin-bottom: 4px; letter-spacing: 0.3px; }
                .amount-tag { font-size: 28px; font-weight: 900; color: #10B981; margin-bottom: 6px; letter-spacing: 0.5px; }
                .desc { font-size: 11.5px; color: #94A3B8; margin-bottom: 16px; max-width: 320px; line-height: 1.4; }
                #razorpay-form { margin: 8px auto; display: flex; justify-content: center; width: 100%; min-height: 120px; }
                .upi-note { font-size: 11px; color: #38BDF8; margin-top: 14px; font-weight: 600; }
                .secure-badge { font-size: 10px; color: #64748B; margin-top: 6px; }
            </style>
        </head>
        <body>
            <div class="title">Akash Internet Hub • Razorpay Pay</div>
            <div class="amount-tag">₹$amountRs.00</div>
            <div class="desc">$itemName</div>
            <form id="razorpay-form">
                <script src="https://checkout.razorpay.com/v1/payment-button.js" data-payment_button_id="$paymentButtonId" async> </script>
            </form>
            <div class="upi-note">🔒 Pay with GPay / PhonePe / Paytm / Any UPI App</div>
            <div class="secure-badge">100% Encrypted & Safe Razorpay Gateway</div>
            <script>
                window.addEventListener('message', function(e) {
                    if (e.data && (e.data.event === 'payment.success' || e.data.razorpay_payment_id)) {
                        if (window.AndroidBridge) {
                            window.AndroidBridge.onPaymentSuccess(e.data.payment_id || e.data.razorpay_payment_id || 'RZP_SUCCESS');
                        }
                    }
                });
            </script>
        </body>
        </html>
    """.trimIndent()

    val handleDismissOrCancel = {
        if (!isPaymentSuccessDetected) {
            onPaymentCancelledOrFailed()
        }
        onDismiss()
    }

    Dialog(
        onDismissRequest = handleDismissOrCancel,
        properties = DialogProperties(dismissOnClickOutside = false, usePlatformDefaultWidth = false)
    ) {
        Card(
            modifier = Modifier
                .fillMaxWidth(0.98f)
                .heightIn(min = 540.dp, max = 740.dp)
                .wrapContentHeight()
                .testTag("razorpay_payment_dialog"),
            shape = RoundedCornerShape(22.dp),
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
            elevation = CardDefaults.cardElevation(defaultElevation = 10.dp)
        ) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .verticalScroll(rememberScrollState())
                    .padding(16.dp),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                // Header
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Surface(
                            shape = CircleShape,
                            color = AkinGreenSuccess.copy(alpha = 0.15f),
                            modifier = Modifier.size(38.dp)
                        ) {
                            Box(contentAlignment = Alignment.Center) {
                                Icon(
                                    imageVector = Icons.Default.Lock,
                                    contentDescription = "Secure Payment",
                                    tint = AkinGreenSuccess,
                                    modifier = Modifier.size(20.dp)
                                )
                            }
                        }
                        Spacer(modifier = Modifier.width(10.dp))
                        Column {
                            Text(
                                text = "Akash Hub Pay Gateway",
                                fontSize = 16.sp,
                                fontWeight = FontWeight.Bold,
                                color = MaterialTheme.colorScheme.onSurface
                            )
                            Text(
                                text = "Official Razorpay Checkout • ₹$amountRs",
                                fontSize = 11.sp,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                    }

                    IconButton(
                        onClick = handleDismissOrCancel,
                        modifier = Modifier.testTag("close_payment_dialog_button")
                    ) {
                        Icon(Icons.Default.Close, contentDescription = "Close")
                    }
                }

                Spacer(modifier = Modifier.height(12.dp))

                // Item description box
                Surface(
                    shape = RoundedCornerShape(12.dp),
                    color = MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.35f),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(modifier = Modifier.padding(12.dp)) {
                        Text(
                            text = itemName,
                            fontSize = 13.sp,
                            fontWeight = FontWeight.Bold,
                            color = MaterialTheme.colorScheme.onPrimaryContainer
                        )
                        Spacer(modifier = Modifier.height(4.dp))
                        Text(
                            text = "👉 Niche diye gaye Razorpay 'Pay Now' button par click karke ₹$amountRs ka payment karein. Payment successful hone par HD Download button turant unlock ho jayega.",
                            fontSize = 11.sp,
                            color = MaterialTheme.colorScheme.onPrimaryContainer.copy(alpha = 0.9f),
                            lineHeight = 15.sp
                        )
                    }
                }

                Spacer(modifier = Modifier.height(14.dp))

                // Razorpay Button WebView Container - EXPANDED LARGE HEIGHT (420dp) TO PREVENT OVERLAPPING
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(420.dp)
                        .clip(RoundedCornerShape(14.dp))
                        .background(Color(0xFF0B132B))
                        .border(1.dp, Color(0xFF1E293B), RoundedCornerShape(14.dp))
                        .padding(6.dp)
                ) {
                    AndroidView(
                        factory = { ctx ->
                            WebView(ctx).apply {
                                settings.javaScriptEnabled = true
                                settings.domStorageEnabled = true
                                settings.loadWithOverviewMode = true
                                settings.useWideViewPort = true
                                settings.javaScriptCanOpenWindowsAutomatically = true
                                settings.setSupportMultipleWindows(true)
                                settings.cacheMode = WebSettings.LOAD_NO_CACHE

                                addJavascriptInterface(
                                    PaymentJsBridge { paymentId ->
                                        (ctx as? android.app.Activity)?.runOnUiThread {
                                            isPaymentSuccessDetected = true
                                            Toast.makeText(
                                                ctx,
                                                "🎉 Payment of ₹$amountRs Successful! (ID: $paymentId)",
                                                Toast.LENGTH_LONG
                                            ).show()
                                            onPaymentSuccess()
                                            onDismiss()
                                        }
                                    },
                                    "AndroidBridge"
                                )

                                webViewClient = object : WebViewClient() {
                                    override fun shouldOverrideUrlLoading(view: WebView?, url: String?): Boolean {
                                        if (url != null) {
                                            if (url.contains("payment-success") || url.contains("status=success")) {
                                                isPaymentSuccessDetected = true
                                                Toast.makeText(ctx, "🎉 Payment Successful! Unlocking HD File...", Toast.LENGTH_LONG).show()
                                                onPaymentSuccess()
                                                onDismiss()
                                                return true
                                            }
                                            if (url.startsWith("upi://") || url.startsWith("tez://") || url.startsWith("phonepe://") || url.startsWith("paytmmp://")) {
                                                try {
                                                    val intent = Intent(Intent.ACTION_VIEW, Uri.parse(url))
                                                    ctx.startActivity(intent)
                                                    return true
                                                } catch (e: Exception) {
                                                    Toast.makeText(ctx, "Opening UPI payment app...", Toast.LENGTH_SHORT).show()
                                                }
                                            }
                                        }
                                        return false
                                    }
                                }
                                loadDataWithBaseURL("https://checkout.razorpay.com", razorpayHtml, "text/html", "UTF-8", null)
                            }
                        },
                        modifier = Modifier.fillMaxSize()
                    )
                }

                // CRITICAL REQUIREMENT: "I Have Paid" button is HIDDEN by default.
                // It ONLY becomes visible AFTER the payment is verified / detected successful!
                AnimatedVisibility(
                    visible = isPaymentSuccessDetected,
                    enter = fadeIn() + expandVertically()
                ) {
                    Column {
                        Spacer(modifier = Modifier.height(14.dp))
                        Button(
                            onClick = {
                                onPaymentSuccess()
                                onDismiss()
                            },
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(48.dp)
                                .testTag("verify_paid_download_button"),
                            shape = RoundedCornerShape(12.dp),
                            colors = ButtonDefaults.buttonColors(containerColor = AkinGreenSuccess)
                        ) {
                            Icon(Icons.Default.DownloadDone, contentDescription = "Paid", modifier = Modifier.size(20.dp))
                            Spacer(modifier = Modifier.width(6.dp))
                            Text("✨ Payment Verified! Click to Download Clean HD File", fontSize = 12.sp, fontWeight = FontWeight.Bold)
                        }
                    }
                }

                Spacer(modifier = Modifier.height(10.dp))

                Text(
                    text = "Button ID: $paymentButtonId • 100% Verified SSL Razorpay Gateway",
                    fontSize = 9.sp,
                    color = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.7f),
                    textAlign = TextAlign.Center
                )
            }
        }
    }
}

/**
 * POPUP NOTIFICATION DIALOG when payment is cancelled, skipped, or not completed by user.
 * Displays user warning and direct WhatsApp Support contact for Akash Internet Hub.
 */
@Composable
fun PaymentIncompletePopupDialog(
    itemName: String,
    amountRs: Int,
    onRetryPayment: () -> Unit,
    onDismiss: () -> Unit
) {
    val context = LocalContext.current

    Dialog(
        onDismissRequest = onDismiss,
        properties = DialogProperties(dismissOnClickOutside = true, usePlatformDefaultWidth = false)
    ) {
        Card(
            modifier = Modifier
                .fillMaxWidth(0.92f)
                .wrapContentHeight()
                .testTag("payment_incomplete_popup_dialog"),
            shape = RoundedCornerShape(20.dp),
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
            elevation = CardDefaults.cardElevation(defaultElevation = 8.dp)
        ) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(20.dp),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                // Warning badge icon
                Surface(
                    shape = CircleShape,
                    color = AkinAmberAccent.copy(alpha = 0.2f),
                    modifier = Modifier.size(54.dp)
                ) {
                    Box(contentAlignment = Alignment.Center) {
                        Icon(
                            imageVector = Icons.Default.WarningAmber,
                            contentDescription = "Warning",
                            tint = Color(0xFFD97706),
                            modifier = Modifier.size(32.dp)
                        )
                    }
                }

                Spacer(modifier = Modifier.height(12.dp))

                Text(
                    text = "⚠️ Apne Payment Nehi Kiya ...!",
                    fontSize = 17.sp,
                    fontWeight = FontWeight.ExtraBold,
                    color = MaterialTheme.colorScheme.onSurface,
                    textAlign = TextAlign.Center
                )

                Spacer(modifier = Modifier.height(6.dp))

                Text(
                    text = "Aapne \"$itemName\" (₹$amountRs) ka payment complete nahi kiya hai ya cancel kar diya hai. HD (Without Watermark) file download karne ke liye payment jaruri hai.",
                    fontSize = 12.sp,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    textAlign = TextAlign.Center,
                    lineHeight = 16.sp
                )

                Spacer(modifier = Modifier.height(14.dp))

                // WhatsApp Support Assistance Card
                Surface(
                    shape = RoundedCornerShape(12.dp),
                    color = Color(0xFF25D366).copy(alpha = 0.12f),
                    border = CardDefaults.outlinedCardBorder().copy(brush = Brush.linearGradient(listOf(Color(0xFF25D366), Color(0xFF128C7E))), width = 1.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(modifier = Modifier.padding(12.dp)) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(Icons.Default.SupportAgent, contentDescription = "Support", tint = Color(0xFF166534), modifier = Modifier.size(18.dp))
                            Spacer(modifier = Modifier.width(6.dp))
                            Text(
                                text = "Paise Cut Gaye Ya Koi Problem Hai?",
                                fontSize = 12.sp,
                                fontWeight = FontWeight.Bold,
                                color = Color(0xFF166534)
                            )
                        }
                        Spacer(modifier = Modifier.height(4.dp))
                        Text(
                            text = "Agar aapke account se balance deduct ho gaya hai, to turant Akash Hub WhatsApp Support par sampark karein. Hum manual verify karke aapko HD file bhej denge.",
                            fontSize = 10.5.sp,
                            color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.85f),
                            lineHeight = 14.sp
                        )
                    }
                }

                Spacer(modifier = Modifier.height(16.dp))

                // Action 1: Contact WhatsApp Support
                Button(
                    onClick = {
                        ContactHelper.openWhatsApp(
                            context,
                            "Namaste Akash Internet Hub, Maine ₹$amountRs ka payment kiya tha for \"$itemName\" par file unlock nahi hui. Kripya verification karke HD file provide karein."
                        )
                        onDismiss()
                    },
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(46.dp)
                        .testTag("whatsapp_support_payment_button"),
                    shape = RoundedCornerShape(10.dp),
                    colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF25D366), contentColor = Color.White)
                ) {
                    Icon(Icons.Default.Chat, contentDescription = "WhatsApp", tint = Color.White, modifier = Modifier.size(18.dp))
                    Spacer(modifier = Modifier.width(8.dp))
                    Text("WhatsApp Support par Sampark Karein", fontSize = 12.sp, fontWeight = FontWeight.Bold)
                }

                Spacer(modifier = Modifier.height(8.dp))

                // Action 2: Retry Payment
                Button(
                    onClick = onRetryPayment,
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(44.dp)
                        .testTag("retry_payment_button"),
                    shape = RoundedCornerShape(10.dp),
                    colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.primary)
                ) {
                    Icon(Icons.Default.Refresh, contentDescription = "Retry", modifier = Modifier.size(18.dp))
                    Spacer(modifier = Modifier.width(6.dp))
                    Text("Dobara Pay Karein (Retry)", fontSize = 12.sp, fontWeight = FontWeight.Bold)
                }

                Spacer(modifier = Modifier.height(6.dp))

                // Action 3: Dismiss
                TextButton(
                    onClick = onDismiss,
                    modifier = Modifier.testTag("dismiss_incomplete_popup_button")
                ) {
                    Text("Theek Hai / Close", fontSize = 11.5.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                }
            }
        }
    }
}
