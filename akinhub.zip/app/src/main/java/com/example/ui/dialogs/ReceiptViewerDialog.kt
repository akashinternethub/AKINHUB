package com.example.ui.dialogs

import android.content.Intent
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import com.example.data.model.HubInfo
import com.example.data.model.ServiceApplication
import com.example.ui.theme.AkinAmberAccent
import com.example.ui.theme.AkinBluePrimary
import com.example.ui.theme.AkinGreenSuccess
import com.example.ui.theme.AkinNavyDark

@Composable
fun ReceiptViewerDialog(
    application: ServiceApplication,
    hubInfo: HubInfo = HubInfo(),
    onDismiss: () -> Unit
) {
    val context = LocalContext.current

    Dialog(
        onDismissRequest = onDismiss,
        properties = DialogProperties(usePlatformDefaultWidth = false)
    ) {
        Card(
            modifier = Modifier
                .fillMaxWidth(0.92f)
                .fillMaxHeight(0.90f)
                .testTag("receipt_viewer_dialog"),
            shape = RoundedCornerShape(20.dp),
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
        ) {
            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(18.dp)
            ) {
                // Top Action Bar
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = "Official e-Acknowledgement",
                        fontSize = 15.sp,
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.primary
                    )
                    IconButton(onClick = onDismiss) {
                        Icon(Icons.Default.Close, contentDescription = "Close")
                    }
                }

                HorizontalDivider(modifier = Modifier.padding(vertical = 8.dp))

                // Printable Slip Container
                Card(
                    modifier = Modifier
                        .weight(1f)
                        .fillMaxWidth()
                        .verticalScroll(rememberScrollState()),
                    shape = RoundedCornerShape(12.dp),
                    colors = CardDefaults.cardColors(containerColor = Color(0xFFFCFDFE)),
                    border = CardDefaults.outlinedCardBorder()
                ) {
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(16.dp),
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        // Hub Header
                        Text(
                            text = hubInfo.receiptHeader.ifBlank { "AKASH INTERNET HUB" },
                            fontSize = 17.sp,
                            fontWeight = FontWeight.Black,
                            color = AkinNavyDark,
                            letterSpacing = 1.sp,
                            textAlign = TextAlign.Center
                        )
                        Text(
                            text = hubInfo.receiptSubHeader.ifBlank { "Common Services Center & Cyber Portal" },
                            fontSize = 11.sp,
                            fontWeight = FontWeight.SemiBold,
                            color = AkinBluePrimary,
                            textAlign = TextAlign.Center
                        )
                        Text(
                            text = hubInfo.receiptAddress.ifBlank { hubInfo.address },
                            fontSize = 10.sp,
                            color = Color(0xFF64748B),
                            textAlign = TextAlign.Center
                        )
                        Text(
                            text = "Helpline: ${hubInfo.phone} • Email: ${hubInfo.receiptEmail}",
                            fontSize = 9.5.sp,
                            color = Color(0xFF64748B),
                            textAlign = TextAlign.Center
                        )

                        Spacer(modifier = Modifier.height(10.dp))
                        HorizontalDivider(thickness = 1.dp, color = Color(0xFFCBD5E1))
                        Spacer(modifier = Modifier.height(10.dp))

                        // Receipt Tag
                        Surface(
                            shape = RoundedCornerShape(6.dp),
                            color = Color(0xFFF1F5F9)
                        ) {
                            Text(
                                text = "ACKNOWLEDGEMENT & PAYMENT RECEIPT",
                                fontSize = 11.sp,
                                fontWeight = FontWeight.Bold,
                                color = Color(0xFF334155),
                                modifier = Modifier.padding(horizontal = 10.dp, vertical = 4.dp)
                            )
                        }

                        Spacer(modifier = Modifier.height(14.dp))

                        // Details Table
                        ReceiptItemRow("Token / App ID:", application.id, isHighlight = true)
                        ReceiptItemRow("Portal Ref No:", application.trackingRefNumber)
                        ReceiptItemRow("Date & Time:", application.dateSubmitted)
                        ReceiptItemRow("Service Applied:", application.serviceTitle)
                        ReceiptItemRow("Applicant Name:", application.applicantName)
                        ReceiptItemRow("Contact Mobile:", application.phone)
                        ReceiptItemRow("Email ID:", application.email)
                        ReceiptItemRow("Status:", application.status.title)
                        ReceiptItemRow("Fee Collected:", application.totalPaid, isHighlight = true)
                        ReceiptItemRow("Payment Mode:", "CASH / UPI VERIFIED")

                        if (application.remark.isNotBlank()) {
                            ReceiptItemRow("Remark:", application.remark)
                        }

                        if (application.uploadedDocuments.isNotEmpty()) {
                            Spacer(modifier = Modifier.height(8.dp))
                            Text(
                                text = "Documents Attached:",
                                fontSize = 11.sp,
                                fontWeight = FontWeight.Bold,
                                modifier = Modifier.fillMaxWidth()
                            )
                            application.uploadedDocuments.forEach { doc ->
                                Text(
                                    text = "• $doc",
                                    fontSize = 10.sp,
                                    color = Color(0xFF475569),
                                    modifier = Modifier.fillMaxWidth()
                                )
                            }
                        }

                        Spacer(modifier = Modifier.height(10.dp))
                        Text(
                            text = hubInfo.receiptCustomNote,
                            fontSize = 9.sp,
                            color = Color(0xFF64748B),
                            textAlign = TextAlign.Center,
                            modifier = Modifier.padding(horizontal = 8.dp)
                        )

                        Spacer(modifier = Modifier.height(14.dp))
                        HorizontalDivider(thickness = 1.dp, color = Color(0xFFCBD5E1))
                        Spacer(modifier = Modifier.height(10.dp))

                        // Seal & Barcode Simulator
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Column {
                                Text(
                                    text = "||||| ||||||| |||| |||||| ||||||",
                                    fontFamily = FontFamily.Monospace,
                                    fontSize = 14.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = Color(0xFF1E293B)
                                )
                                Text(
                                    text = "*${application.id}*",
                                    fontSize = 9.sp,
                                    fontFamily = FontFamily.Monospace,
                                    color = Color(0xFF64748B)
                                )
                            }

                            Surface(
                                shape = RoundedCornerShape(8.dp),
                                color = AkinGreenSuccess.copy(alpha = 0.15f),
                                border = CardDefaults.outlinedCardBorder().copy(brush = androidx.compose.ui.graphics.SolidColor(AkinGreenSuccess))
                            ) {
                                Text(
                                    text = hubInfo.receiptSealText.ifBlank { "AKASH HUB\nDIGITALLY VERIFIED" },
                                    fontSize = 9.sp,
                                    fontWeight = FontWeight.ExtraBold,
                                    color = Color(0xFF047857),
                                    textAlign = TextAlign.Center,
                                    modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp),
                                    lineHeight = 11.sp
                                )
                            }
                        }
                    }
                }

                Spacer(modifier = Modifier.height(12.dp))

                // Actions
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    OutlinedButton(
                        onClick = {
                            val shareText = """
                                *${hubInfo.receiptHeader}*
                                Receipt / Token: ${application.id}
                                Service: ${application.serviceTitle}
                                Applicant: ${application.applicantName}
                                Status: ${application.status.title}
                                Total Fee: ${application.totalPaid}
                                Date: ${application.dateSubmitted}
                                Location: ${hubInfo.receiptAddress}
                                Contact: ${hubInfo.phone}
                            """.trimIndent()
                            val sendIntent = Intent().apply {
                                action = Intent.ACTION_SEND
                                putExtra(Intent.EXTRA_TEXT, shareText)
                                type = "text/plain"
                            }
                            context.startActivity(Intent.createChooser(sendIntent, "Share Receipt Slip"))
                        },
                        modifier = Modifier
                            .weight(1f)
                            .height(44.dp)
                            .testTag("share_receipt_button"),
                        shape = RoundedCornerShape(10.dp)
                    ) {
                        Icon(Icons.Default.Share, contentDescription = "Share", modifier = Modifier.size(16.dp))
                        Spacer(modifier = Modifier.width(6.dp))
                        Text("Share Slip", fontSize = 12.sp)
                    }

                    Button(
                        onClick = onDismiss,
                        modifier = Modifier
                            .weight(1f)
                            .height(44.dp)
                            .testTag("done_receipt_button"),
                        shape = RoundedCornerShape(10.dp)
                    ) {
                        Text("Done", fontSize = 12.sp, fontWeight = FontWeight.Bold)
                    }
                }
            }
        }
    }
}

@Composable
fun ReceiptItemRow(
    label: String,
    value: String,
    isHighlight: Boolean = false
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 3.dp),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        Text(
            text = label,
            fontSize = 11.sp,
            color = Color(0xFF64748B),
            fontWeight = FontWeight.Medium
        )
        Text(
            text = value,
            fontSize = 11.sp,
            fontWeight = if (isHighlight) FontWeight.ExtraBold else FontWeight.SemiBold,
            color = if (isHighlight) AkinNavyDark else Color(0xFF0F172A),
            textAlign = TextAlign.End
        )
    }
}
