package com.example.ui.components

import androidx.compose.animation.*
import androidx.compose.animation.core.*
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material.icons.filled.GraphicEq
import androidx.compose.material.icons.filled.Mic
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.scale
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.theme.AkinAmberAccent

@Composable
fun FloatingVoiceHelpButton(
    onClick: () -> Unit,
    isSpeakingOrListening: Boolean = false,
    isCompact: Boolean = false,
    modifier: Modifier = Modifier
) {
    val infiniteTransition = rememberInfiniteTransition(label = "pulse_glow")
    val pulseScale by infiniteTransition.animateFloat(
        initialValue = 1f,
        targetValue = if (isSpeakingOrListening) 1.15f else 1.06f,
        animationSpec = infiniteRepeatable(
            animation = tween(durationMillis = if (isSpeakingOrListening) 600 else 1400, easing = FastOutSlowInEasing),
            repeatMode = RepeatMode.Reverse
        ),
        label = "pulse_scale"
    )

    val auraAlpha by infiniteTransition.animateFloat(
        initialValue = 0.2f,
        targetValue = 0.6f,
        animationSpec = infiniteRepeatable(
            animation = tween(durationMillis = 1000, easing = LinearEasing),
            repeatMode = RepeatMode.Reverse
        ),
        label = "aura_alpha"
    )

    Box(
        modifier = modifier
            .padding(bottom = 12.dp, end = 16.dp)
            .testTag("floating_voice_help_container"),
        contentAlignment = Alignment.Center
    ) {
        // Glowing Aura Ring
        Box(
            modifier = Modifier
                .size(if (isCompact) 52.dp else 62.dp)
                .scale(pulseScale)
                .clip(CircleShape)
                .background(
                    Brush.radialGradient(
                        colors = listOf(
                            AkinAmberAccent.copy(alpha = auraAlpha),
                            Color(0xFF2563EB).copy(alpha = 0.12f),
                            Color.Transparent
                        )
                    )
                )
        )

        // Main Action Button (Morphs between Compact Circle & Full Pill)
        Surface(
            modifier = Modifier
                .shadow(8.dp, if (isCompact) CircleShape else RoundedCornerShape(28.dp))
                .clip(if (isCompact) CircleShape else RoundedCornerShape(28.dp))
                .clickable { onClick() }
                .animateContentSize(animationSpec = spring(dampingRatio = Spring.DampingRatioMediumBouncy, stiffness = Spring.StiffnessMedium))
                .testTag("floating_voice_help_button"),
            color = Color(0xFF0F172A),
            shape = if (isCompact) CircleShape else RoundedCornerShape(28.dp)
        ) {
            Row(
                modifier = Modifier
                    .background(
                        Brush.horizontalGradient(
                            colors = listOf(
                                Color(0xFF0F172A),
                                Color(0xFF1E293B),
                                Color(0xFF1E1B4B)
                            )
                        )
                    )
                    .padding(
                        horizontal = if (isCompact) 10.dp else 14.dp,
                        vertical = if (isCompact) 10.dp else 10.dp
                    ),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                // Animated Mic / Sound wave icon container
                Surface(
                    shape = CircleShape,
                    color = if (isSpeakingOrListening) Color(0xFFEF4444) else AkinAmberAccent,
                    modifier = Modifier.size(if (isCompact) 32.dp else 32.dp)
                ) {
                    Box(contentAlignment = Alignment.Center) {
                        Icon(
                            imageVector = if (isSpeakingOrListening) Icons.Default.GraphicEq else Icons.Default.Mic,
                            contentDescription = "Voice Assistant",
                            tint = Color(0xFF0F172A),
                            modifier = Modifier.size(18.dp)
                        )
                    }
                }

                // If expanded, show the text details
                AnimatedVisibility(
                    visible = !isCompact,
                    enter = fadeIn() + expandHorizontally(),
                    exit = fadeOut() + shrinkHorizontally()
                ) {
                    Column(modifier = Modifier.padding(end = 4.dp)) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Text(
                                text = "AI Voice Help",
                                fontSize = 12.sp,
                                fontWeight = FontWeight.ExtraBold,
                                color = Color.White
                            )
                            Spacer(modifier = Modifier.width(3.dp))
                            Icon(
                                imageVector = Icons.Default.AutoAwesome,
                                contentDescription = null,
                                tint = AkinAmberAccent,
                                modifier = Modifier.size(11.dp)
                            )
                        }
                        Text(
                            text = "Hindi • Eng • বাংলা • অসমীয়া",
                            fontSize = 9.5.sp,
                            fontWeight = FontWeight.Medium,
                            color = Color(0xFF94A3B8)
                        )
                    }
                }
            }
        }
    }
}

