package com.example.ui.screens.tools

import android.content.Context
import android.widget.Toast
import androidx.compose.animation.core.*
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.theme.AkinAmberAccent
import com.example.ui.theme.AkinGreenSuccess
import com.example.ui.theme.AkinNavyDark

@Composable
fun AiMediaGeneratorTool(
    isPaid: Boolean = false,
    onTriggerPayment: (toolName: String) -> Unit,
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    var mediaMode by remember { mutableStateOf(0) } // 0: AI Prompt to Photo, 1: AI Prompt to Video

    // Photo Generation States
    var imagePrompt by remember { mutableStateOf("Professional Indian youth candidate formal passport portrait in dark navy suit with clean studio background") }
    var selectedStyle by remember { mutableStateOf("Ultra Realistic 8K") }
    var isGeneratingImage by remember { mutableStateOf(false) }

    // Video Generation States
    var videoPrompt by remember { mutableStateOf("Cinematic motion slow-motion zoom into digital cyber hub with glowing fiber optic internet lights and modern computers") }
    var videoMotionEffect by remember { mutableStateOf("Cinematic Slow Pan & Zoom") }
    var isGeneratingVideo by remember { mutableStateOf(false) }
    var isPlayingPreview by remember { mutableStateOf(true) }

    val styles = listOf("Ultra Realistic 8K", "Govt ID Portrait", "Digital Art", "Studio Cinematic", "Vintage Retro")
    val motionEffects = listOf("Cinematic Slow Pan & Zoom", "Dynamic 3D Orbit", "Portrait Face Motion", "Speed Burst")

    // Video animation loop
    val infiniteTransition = rememberInfiniteTransition(label = "video_motion")
    val motionOffset by infiniteTransition.animateFloat(
        initialValue = -10f,
        targetValue = 10f,
        animationSpec = infiniteRepeatable(
            animation = tween(2400, easing = LinearEasing),
            repeatMode = RepeatMode.Reverse
        ),
        label = "motion"
    )
    val motionScale by infiniteTransition.animateFloat(
        initialValue = 1.0f,
        targetValue = 1.08f,
        animationSpec = infiniteRepeatable(
            animation = tween(2400, easing = FastOutSlowInEasing),
            repeatMode = RepeatMode.Reverse
        ),
        label = "scale"
    )

    Card(
        modifier = modifier
            .fillMaxWidth()
            .testTag("ai_media_generator_card"),
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
    ) {
        Column(modifier = Modifier.padding(16.dp)) {
            Text(
                text = "AI Generative Studio (Photo & Video)",
                fontSize = 15.sp,
                fontWeight = FontWeight.Bold,
                color = MaterialTheme.colorScheme.onSurface
            )
            Text(
                text = "Create ultra-realistic photos and animated AI videos directly from text prompts",
                fontSize = 11.sp,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )

            Spacer(modifier = Modifier.height(14.dp))

            // Switcher
            TabRow(
                selectedTabIndex = mediaMode,
                containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f),
                modifier = Modifier.clip(RoundedCornerShape(12.dp))
            ) {
                Tab(
                    selected = mediaMode == 0,
                    onClick = { mediaMode = 0 },
                    text = { Text("✨ AI Prompt to Photo", fontSize = 12.sp, fontWeight = if (mediaMode == 0) FontWeight.Bold else FontWeight.Normal) }
                )
                Tab(
                    selected = mediaMode == 1,
                    onClick = { mediaMode = 1 },
                    text = { Text("🎬 AI Prompt to Video", fontSize = 12.sp, fontWeight = if (mediaMode == 1) FontWeight.Bold else FontWeight.Normal) }
                )
            }

            Spacer(modifier = Modifier.height(14.dp))

            // MODE 0: AI TEXT TO PHOTO
            if (mediaMode == 0) {
                Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    Text("Describe Your Image Prompt:", fontSize = 12.sp, fontWeight = FontWeight.SemiBold)
                    OutlinedTextField(
                        value = imagePrompt,
                        onValueChange = { imagePrompt = it },
                        modifier = Modifier.fillMaxWidth(),
                        minLines = 2,
                        maxLines = 4,
                        shape = RoundedCornerShape(10.dp)
                    )

                    Text("Select Artistic Style:", fontSize = 12.sp, fontWeight = FontWeight.SemiBold)
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        styles.take(3).forEach { st ->
                            val isSel = selectedStyle == st
                            Surface(
                                shape = RoundedCornerShape(8.dp),
                                color = if (isSel) MaterialTheme.colorScheme.primaryContainer else MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f),
                                modifier = Modifier
                                    .weight(1f)
                                    .clickable { selectedStyle = st }
                            ) {
                                Text(
                                    text = st,
                                    fontSize = 10.sp,
                                    fontWeight = if (isSel) FontWeight.Bold else FontWeight.Normal,
                                    textAlign = TextAlign.Center,
                                    modifier = Modifier.padding(vertical = 6.dp)
                                )
                            }
                        }
                    }

                    // Photo Result Preview Box
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(180.dp)
                            .background(Color(0xFF0F172A), RoundedCornerShape(12.dp))
                            .border(1.dp, Color(0xFF334155), RoundedCornerShape(12.dp)),
                        contentAlignment = Alignment.Center
                    ) {
                        Column(
                            horizontalAlignment = Alignment.CenterHorizontally,
                            verticalArrangement = Arrangement.Center
                        ) {
                            Surface(
                                shape = CircleShape,
                                color = AkinAmberAccent.copy(alpha = 0.2f),
                                modifier = Modifier.size(60.dp)
                            ) {
                                Box(contentAlignment = Alignment.Center) {
                                    Icon(
                                        imageVector = Icons.Default.AutoAwesome,
                                        contentDescription = "AI Gen",
                                        tint = AkinAmberAccent,
                                        modifier = Modifier.size(32.dp)
                                    )
                                }
                            }
                            Spacer(modifier = Modifier.height(8.dp))
                            Text(
                                text = "Generated 4K Visual ($selectedStyle)",
                                fontSize = 12.sp,
                                fontWeight = FontWeight.Bold,
                                color = Color.White
                            )
                            Spacer(modifier = Modifier.height(2.dp))
                            Text(
                                text = "\"${imagePrompt.take(45)}...\"",
                                fontSize = 10.sp,
                                color = Color(0xFF94A3B8),
                                textAlign = TextAlign.Center,
                                modifier = Modifier.padding(horizontal = 16.dp)
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(4.dp))
                    DualDownloadActionButtons(
                        toolTitle = "AI Generated Image ($selectedStyle)",
                        isPaid = isPaid,
                        onFreeDownload = {
                            Toast.makeText(context, "Image saved with watermark: 'Downloaded From Akash Internet Hub'", Toast.LENGTH_LONG).show()
                        },
                        onPayDownload = {
                            onTriggerPayment("AI 4K Image Generation (No Watermark)")
                        },
                        onUnlockedDownload = {
                            Toast.makeText(context, "📥 Clean 4K AI Ultra-HD Image Downloaded (No Watermark)!", Toast.LENGTH_LONG).show()
                        }
                    )
                }
            }

            // MODE 1: AI PROMPT TO VIDEO
            if (mediaMode == 1) {
                Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    Text("Describe Video Scene Prompt:", fontSize = 12.sp, fontWeight = FontWeight.SemiBold)
                    OutlinedTextField(
                        value = videoPrompt,
                        onValueChange = { videoPrompt = it },
                        modifier = Modifier.fillMaxWidth(),
                        minLines = 2,
                        maxLines = 4,
                        shape = RoundedCornerShape(10.dp)
                    )

                    Text("AI Motion & Camera Dynamic:", fontSize = 12.sp, fontWeight = FontWeight.SemiBold)
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        motionEffects.take(2).forEach { m ->
                            val isSel = videoMotionEffect == m
                            Surface(
                                shape = RoundedCornerShape(8.dp),
                                color = if (isSel) MaterialTheme.colorScheme.primaryContainer else MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f),
                                modifier = Modifier
                                    .weight(1f)
                                    .clickable { videoMotionEffect = m }
                            ) {
                                Text(
                                    text = m,
                                    fontSize = 10.sp,
                                    fontWeight = if (isSel) FontWeight.Bold else FontWeight.Normal,
                                    textAlign = TextAlign.Center,
                                    modifier = Modifier.padding(vertical = 6.dp)
                                )
                            }
                        }
                    }

                    // Video Player Preview Box
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(180.dp)
                            .background(Color(0xFF020617), RoundedCornerShape(12.dp))
                            .border(1.dp, Color(0xFF1E293B), RoundedCornerShape(12.dp)),
                        contentAlignment = Alignment.Center
                    ) {
                        Column(
                            modifier = Modifier
                                .graphicsLayer {
                                    translationX = motionOffset
                                    scaleX = motionScale
                                    scaleY = motionScale
                                },
                            horizontalAlignment = Alignment.CenterHorizontally
                        ) {
                            Surface(
                                shape = CircleShape,
                                color = Color(0xFF3B82F6).copy(alpha = 0.3f),
                                modifier = Modifier.size(54.dp)
                            ) {
                                Box(contentAlignment = Alignment.Center) {
                                    Icon(
                                        imageVector = Icons.Default.PlayCircleFilled,
                                        contentDescription = "Playing",
                                        tint = Color(0xFF60A5FA),
                                        modifier = Modifier.size(36.dp)
                                    )
                                }
                            }
                            Spacer(modifier = Modifier.height(8.dp))
                            Text(
                                text = "AI Video Generation • 1080p MP4",
                                fontSize = 12.sp,
                                fontWeight = FontWeight.Bold,
                                color = Color.White
                            )
                            Text(
                                text = "$videoMotionEffect • 60 FPS Smooth",
                                fontSize = 10.sp,
                                color = Color(0xFF94A3B8)
                            )
                        }

                        // Watermark preview in bottom right of player
                        Surface(
                            shape = RoundedCornerShape(4.dp),
                            color = Color.Black.copy(alpha = 0.7f),
                            modifier = Modifier
                                .align(Alignment.BottomEnd)
                                .padding(8.dp)
                        ) {
                            Text(
                                text = "Free Mode: Watermarked",
                                fontSize = 8.sp,
                                color = Color.Yellow,
                                modifier = Modifier.padding(horizontal = 4.dp, vertical = 2.dp)
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(4.dp))
                    DualDownloadActionButtons(
                        toolTitle = "AI Video Generation ($videoMotionEffect)",
                        isPaid = isPaid,
                        onFreeDownload = {
                            Toast.makeText(context, "Video saved with watermark: 'Downloaded From Akash Internet Hub'", Toast.LENGTH_LONG).show()
                        },
                        onPayDownload = {
                            onTriggerPayment("AI Video Clip 1080p HD (No Watermark)")
                        },
                        onUnlockedDownload = {
                            Toast.makeText(context, "📥 Clean 1080p AI Video Downloaded (No Watermark)!", Toast.LENGTH_LONG).show()
                        }
                    )
                }
            }
        }
    }
}
