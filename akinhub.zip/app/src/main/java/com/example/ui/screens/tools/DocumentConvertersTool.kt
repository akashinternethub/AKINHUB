package com.example.ui.screens.tools

import android.content.Context
import android.widget.Toast
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.theme.AkinAmberAccent
import com.example.ui.theme.AkinGreenSuccess
import com.example.ui.theme.AkinNavyDark

@Composable
fun DocumentConvertersTool(
    isPaid: Boolean = false,
    onTriggerPayment: (toolName: String) -> Unit,
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    var selectedTab by remember { mutableStateOf(0) } // 0: JPG to PDF, 1: PDF to JPG, 2: TXT to JPG, 3: Edit JPG Text

    // Converter States
    var sampleDocName by remember { mutableStateOf("Assam_Marksheet_Doc.jpg") }
    var textInputForJpg by remember { mutableStateOf("Akash Internet Hub Notice\nAdmit card release date for ADRE Grade III.\nPlease carry original photo ID proof and 2 passport photos to examination center.") }
    var ocrTargetText by remember { mutableStateOf("OLD DATE: 10/08/2026") }
    var ocrReplacementText by remember { mutableStateOf("NEW DATE: 25/08/2026") }
    var isConverted by remember { mutableStateOf(true) }

    Card(
        modifier = modifier
            .fillMaxWidth()
            .testTag("document_converters_card"),
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
    ) {
        Column(modifier = Modifier.padding(16.dp)) {
            Text(
                text = "AI Document & Format Studio",
                fontSize = 15.sp,
                fontWeight = FontWeight.Bold,
                color = MaterialTheme.colorScheme.onSurface
            )
            Text(
                text = "Convert, extract, format and edit image text with AI OCR",
                fontSize = 11.sp,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )

            Spacer(modifier = Modifier.height(14.dp))

            // Sub tabs
            ScrollableTabRow(
                selectedTabIndex = selectedTab,
                edgePadding = 0.dp,
                containerColor = Color.Transparent,
                divider = {}
            ) {
                Tab(
                    selected = selectedTab == 0,
                    onClick = { selectedTab = 0 },
                    text = { Text("📄 JPG to PDF", fontSize = 11.sp, fontWeight = if (selectedTab == 0) FontWeight.Bold else FontWeight.Normal) }
                )
                Tab(
                    selected = selectedTab == 1,
                    onClick = { selectedTab = 1 },
                    text = { Text("🖼️ PDF to JPG", fontSize = 11.sp, fontWeight = if (selectedTab == 1) FontWeight.Bold else FontWeight.Normal) }
                )
                Tab(
                    selected = selectedTab == 2,
                    onClick = { selectedTab = 2 },
                    text = { Text("📝 TXT to JPG", fontSize = 11.sp, fontWeight = if (selectedTab == 2) FontWeight.Bold else FontWeight.Normal) }
                )
                Tab(
                    selected = selectedTab == 3,
                    onClick = { selectedTab = 3 },
                    text = { Text("✏️ Edit JPG Text", fontSize = 11.sp, fontWeight = if (selectedTab == 3) FontWeight.Bold else FontWeight.Normal) }
                )
            }

            Spacer(modifier = Modifier.height(14.dp))

            // TAB 0: JPG TO PDF
            if (selectedTab == 0) {
                Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    Surface(
                        shape = RoundedCornerShape(10.dp),
                        color = Color(0xFFF8FAFC),
                        border = CardDefaults.outlinedCardBorder(),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Row(
                            modifier = Modifier.padding(12.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Icon(Icons.Default.Image, contentDescription = "JPG", tint = MaterialTheme.colorScheme.primary, modifier = Modifier.size(28.dp))
                            Spacer(modifier = Modifier.width(10.dp))
                            Column(modifier = Modifier.weight(1f)) {
                                Text("Uploaded Image: $sampleDocName", fontSize = 12.sp, fontWeight = FontWeight.Bold)
                                Text("High resolution 300 DPI • Ready to convert into PDF", fontSize = 10.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                            }
                            Icon(Icons.Default.CheckCircle, contentDescription = "Ready", tint = AkinGreenSuccess, modifier = Modifier.size(18.dp))
                        }
                    }

                    // PDF Output Preview Box
                    Surface(
                        shape = RoundedCornerShape(10.dp),
                        color = MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.4f),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Column(modifier = Modifier.padding(12.dp)) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Icon(Icons.Default.PictureAsPdf, contentDescription = "PDF", tint = Color(0xFFDC2626), modifier = Modifier.size(20.dp))
                                Spacer(modifier = Modifier.width(6.dp))
                                Text("Generated Output: ${sampleDocName.replace(".jpg", ".pdf")}", fontSize = 12.sp, fontWeight = FontWeight.Bold)
                            }
                            Spacer(modifier = Modifier.height(4.dp))
                            Text("Standard A4 printable document page with sharp vector text & imagery.", fontSize = 10.sp)
                        }
                    }

                    Spacer(modifier = Modifier.height(6.dp))
                    DualDownloadActionButtons(
                        toolTitle = "Converted PDF Document",
                        isPaid = isPaid,
                        onFreeDownload = {
                            Toast.makeText(context, "PDF saved with watermark: 'Downloaded From Akash Internet Hub'", Toast.LENGTH_LONG).show()
                        },
                        onPayDownload = {
                            onTriggerPayment("JPG to PDF HD Document (No Watermark)")
                        },
                        onUnlockedDownload = {
                            Toast.makeText(context, "📥 Clean HD Vector PDF Downloaded (No Watermark)!", Toast.LENGTH_LONG).show()
                        }
                    )
                }
            }

            // TAB 1: PDF TO JPG
            if (selectedTab == 1) {
                Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    Surface(
                        shape = RoundedCornerShape(10.dp),
                        color = Color(0xFFF8FAFC),
                        border = CardDefaults.outlinedCardBorder(),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Row(
                            modifier = Modifier.padding(12.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Icon(Icons.Default.PictureAsPdf, contentDescription = "PDF", tint = Color(0xFFDC2626), modifier = Modifier.size(28.dp))
                            Spacer(modifier = Modifier.width(10.dp))
                            Column(modifier = Modifier.weight(1f)) {
                                Text("Document: Application_Acknowledgment.pdf", fontSize = 12.sp, fontWeight = FontWeight.Bold)
                                Text("AI Page Extractor • 1 Page detected", fontSize = 10.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                            }
                            Icon(Icons.Default.CheckCircle, contentDescription = "Extracted", tint = AkinGreenSuccess, modifier = Modifier.size(18.dp))
                        }
                    }

                    // Extracted JPG Preview Box
                    Surface(
                        shape = RoundedCornerShape(10.dp),
                        color = MaterialTheme.colorScheme.secondaryContainer.copy(alpha = 0.4f),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Column(modifier = Modifier.padding(12.dp)) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Icon(Icons.Default.Image, contentDescription = "JPG", tint = MaterialTheme.colorScheme.primary, modifier = Modifier.size(20.dp))
                                Spacer(modifier = Modifier.width(6.dp))
                                Text("Extracted Output: Page_1_UltraHD.jpg", fontSize = 12.sp, fontWeight = FontWeight.Bold)
                            }
                            Spacer(modifier = Modifier.height(4.dp))
                            Text("Crystal clear 2400 × 3300 pixel JPG image ready for mobile & portal upload.", fontSize = 10.sp)
                        }
                    }

                    Spacer(modifier = Modifier.height(6.dp))
                    DualDownloadActionButtons(
                        toolTitle = "Extracted JPG Image",
                        isPaid = isPaid,
                        onFreeDownload = {
                            Toast.makeText(context, "JPG saved with watermark: 'Downloaded From Akash Internet Hub'", Toast.LENGTH_LONG).show()
                        },
                        onPayDownload = {
                            onTriggerPayment("PDF to JPG Ultra-HD Extraction (No Watermark)")
                        },
                        onUnlockedDownload = {
                            Toast.makeText(context, "📥 Clean Ultra-HD JPG Image Downloaded (No Watermark)!", Toast.LENGTH_LONG).show()
                        }
                    )
                }
            }

            // TAB 2: TXT TO JPG
            if (selectedTab == 2) {
                Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    Text("Enter Text to Render as Image:", fontSize = 12.sp, fontWeight = FontWeight.SemiBold)
                    OutlinedTextField(
                        value = textInputForJpg,
                        onValueChange = { textInputForJpg = it },
                        modifier = Modifier.fillMaxWidth(),
                        minLines = 3,
                        maxLines = 5,
                        shape = RoundedCornerShape(10.dp)
                    )

                    // Card Image Preview
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(130.dp)
                            .background(Color(0xFF0F172A), RoundedCornerShape(10.dp))
                            .border(1.dp, Color(0xFF334155), RoundedCornerShape(10.dp))
                            .padding(12.dp)
                    ) {
                        Column {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Surface(shape = RoundedCornerShape(4.dp), color = AkinAmberAccent) {
                                    Text("OFFICIAL NOTICE", fontSize = 8.sp, fontWeight = FontWeight.Black, color = AkinNavyDark, modifier = Modifier.padding(horizontal = 4.dp, vertical = 2.dp))
                                }
                                Spacer(modifier = Modifier.width(6.dp))
                                Text("Akash Internet Hub", fontSize = 9.sp, color = Color.White, fontWeight = FontWeight.Bold)
                            }
                            Spacer(modifier = Modifier.height(6.dp))
                            Text(
                                text = textInputForJpg,
                                fontSize = 10.sp,
                                color = Color(0xFFF1F5F9),
                                lineHeight = 13.sp,
                                maxLines = 4
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(6.dp))
                    DualDownloadActionButtons(
                        toolTitle = "Rendered Notice JPG Image",
                        isPaid = isPaid,
                        onFreeDownload = {
                            Toast.makeText(context, "Image saved with watermark: 'Downloaded From Akash Internet Hub'", Toast.LENGTH_LONG).show()
                        },
                        onPayDownload = {
                            onTriggerPayment("TXT to JPG High-Res Notice Card (No Watermark)")
                        },
                        onUnlockedDownload = {
                            Toast.makeText(context, "📥 Clean High-Res Notice JPG Downloaded (No Watermark)!", Toast.LENGTH_LONG).show()
                        }
                    )
                }
            }

            // TAB 3: EDIT JPG IMAGE TEXT (AI OCR & REPLACER)
            if (selectedTab == 3) {
                Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    Text("AI Image Text Detection & Replacement:", fontSize = 12.sp, fontWeight = FontWeight.SemiBold)
                    OutlinedTextField(
                        value = ocrTargetText,
                        onValueChange = { ocrTargetText = it },
                        label = { Text("Original Text to Replace") },
                        modifier = Modifier.fillMaxWidth(),
                        singleLine = true,
                        shape = RoundedCornerShape(10.dp)
                    )
                    OutlinedTextField(
                        value = ocrReplacementText,
                        onValueChange = { ocrReplacementText = it },
                        label = { Text("New Replacement Text (AI Font Match)") },
                        modifier = Modifier.fillMaxWidth(),
                        singleLine = true,
                        shape = RoundedCornerShape(10.dp)
                    )

                    Surface(
                        shape = RoundedCornerShape(10.dp),
                        color = AkinGreenSuccess.copy(alpha = 0.1f),
                        border = androidx.compose.foundation.BorderStroke(1.dp, AkinGreenSuccess.copy(alpha = 0.4f)),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Row(
                            modifier = Modifier.padding(10.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Icon(Icons.Default.AutoFixHigh, contentDescription = "AI Font Match", tint = AkinGreenSuccess, modifier = Modifier.size(20.dp))
                            Spacer(modifier = Modifier.width(8.dp))
                            Text("AI text replacement matches background texture, grain & typography seamlessly.", fontSize = 10.sp)
                        }
                    }

                    Spacer(modifier = Modifier.height(6.dp))
                    DualDownloadActionButtons(
                        toolTitle = "AI Edited JPG Image",
                        isPaid = isPaid,
                        onFreeDownload = {
                            Toast.makeText(context, "Saved with watermark: 'Downloaded From Akash Internet Hub'", Toast.LENGTH_LONG).show()
                        },
                        onPayDownload = {
                            onTriggerPayment("AI Edited JPG Image (HD No Watermark)")
                        },
                        onUnlockedDownload = {
                            Toast.makeText(context, "📥 Clean AI Edited High-Res Image Downloaded (No Watermark)!", Toast.LENGTH_LONG).show()
                        }
                    )
                }
            }
        }
    }
}
