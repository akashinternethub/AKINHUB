package com.example.ui.screens.tools

import android.content.Context
import android.net.Uri
import android.widget.Toast
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.*
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import coil.compose.AsyncImage
import com.example.ui.theme.AkinAmberAccent
import com.example.ui.theme.AkinGreenSuccess
import com.example.ui.theme.AkinNavyDark

@Composable
fun DocumentConvertersTool(
    isPaid: Boolean = false,
    onTriggerPayment: (toolName: String) -> Unit,
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    var selectedTab by remember { mutableStateOf(0) } // 0: JPG to PDF, 1: PDF to JPG, 2: TXT to JPG, 3: Edit JPG Text

    // Converter States
    var jpgToPdfUri by remember { mutableStateOf<Uri?>(null) }
    var pdfToJpgUri by remember { mutableStateOf<Uri?>(null) }
    var txtToJpgUri by remember { mutableStateOf<Uri?>(null) }
    var editJpgUri by remember { mutableStateOf<Uri?>(null) }

    var textInputForJpg by remember { mutableStateOf("Akash Internet Hub Notice\nAdmit card release date for ADRE Grade III.\nPlease carry original photo ID proof and 2 passport photos to examination center.") }
    var ocrTargetText by remember { mutableStateOf("OLD DATE: 10/08/2026") }
    var ocrReplacementText by remember { mutableStateOf("NEW DATE: 25/08/2026") }
    var overlayTextPosition by remember { mutableStateOf(0) } // 0: Center, 1: Top, 2: Bottom

    // Pickers
    val jpgToPdfPicker = rememberLauncherForActivityResult(ActivityResultContracts.GetContent()) { uri ->
        if (uri != null) {
            jpgToPdfUri = uri
            Toast.makeText(context, "📸 JPG Image Selected for PDF Conversion!", Toast.LENGTH_SHORT).show()
        }
    }

    val pdfToJpgPicker = rememberLauncherForActivityResult(ActivityResultContracts.GetContent()) { uri ->
        if (uri != null) {
            pdfToJpgUri = uri
            Toast.makeText(context, "📄 Document Selected for JPG Extraction!", Toast.LENGTH_SHORT).show()
        }
    }

    val editJpgPicker = rememberLauncherForActivityResult(ActivityResultContracts.GetContent()) { uri ->
        if (uri != null) {
            editJpgUri = uri
            Toast.makeText(context, "📸 Photo Selected for Text Editing!", Toast.LENGTH_SHORT).show()
        }
    }

    Card(
        modifier = modifier
            .fillMaxWidth()
            .testTag("document_converters_card"),
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
    ) {
        Column(modifier = Modifier.padding(16.dp)) {
            Text(
                text = "AI Document & Format Studio",
                fontSize = 15.sp,
                fontWeight = FontWeight.Bold,
                color = MaterialTheme.colorScheme.onSurface
            )
            Text(
                text = "Upload document, convert formats and edit text with live preview",
                fontSize = 11.sp,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )

            Spacer(modifier = Modifier.height(14.dp))

            // Sub tabs
            ScrollableTabRow(
                selectedTabIndex = selectedTab,
                edgePadding = 0.dp,
                containerColor = Color.Transparent,
                divider = {}
            ) {
                Tab(
                    selected = selectedTab == 0,
                    onClick = { selectedTab = 0 },
                    text = { Text("📄 JPG to PDF", fontSize = 11.sp, fontWeight = if (selectedTab == 0) FontWeight.Bold else FontWeight.Normal) }
                )
                Tab(
                    selected = selectedTab == 1,
                    onClick = { selectedTab = 1 },
                    text = { Text("🖼️ PDF to JPG", fontSize = 11.sp, fontWeight = if (selectedTab == 1) FontWeight.Bold else FontWeight.Normal) }
                )
                Tab(
                    selected = selectedTab == 2,
                    onClick = { selectedTab = 2 },
                    text = { Text("📝 TXT to JPG", fontSize = 11.sp, fontWeight = if (selectedTab == 2) FontWeight.Bold else FontWeight.Normal) }
                )
                Tab(
                    selected = selectedTab == 3,
                    onClick = { selectedTab = 3 },
                    text = { Text("✏️ Edit JPG Text", fontSize = 11.sp, fontWeight = if (selectedTab == 3) FontWeight.Bold else FontWeight.Normal) }
                )
            }

            Spacer(modifier = Modifier.height(14.dp))

            // TAB 0: JPG TO PDF
            if (selectedTab == 0) {
                Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
                    // Upload Button
                    Surface(
                        shape = RoundedCornerShape(10.dp),
                        color = if (jpgToPdfUri != null) AkinGreenSuccess.copy(alpha = 0.1f) else Color(0xFFF8FAFC),
                        border = CardDefaults.outlinedCardBorder(),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Row(
                            modifier = Modifier.padding(12.dp),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.weight(1f)) {
                                Icon(Icons.Default.Image, contentDescription = "JPG", tint = MaterialTheme.colorScheme.primary, modifier = Modifier.size(28.dp))
                                Spacer(modifier = Modifier.width(10.dp))
                                Column {
                                    Text(if (jpgToPdfUri != null) "JPG Selected ✓" else "Upload JPG / Photo", fontSize = 12.sp, fontWeight = FontWeight.Bold)
                                    Text("High resolution 300 DPI • Ready for PDF", fontSize = 10.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                                }
                            }
                            Button(
                                onClick = { jpgToPdfPicker.launch("image/*") },
                                shape = RoundedCornerShape(8.dp),
                                contentPadding = PaddingValues(horizontal = 10.dp, vertical = 6.dp)
                            ) {
                                Text(if (jpgToPdfUri != null) "Badlein" else "📁 Browse Photo", fontSize = 10.sp)
                            }
                        }
                    }

                    // Live PDF Preview Canvas
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(170.dp)
                            .background(Color(0xFFE2E8F0), RoundedCornerShape(10.dp))
                            .border(1.dp, Color(0xFFCBD5E1), RoundedCornerShape(10.dp)),
                        contentAlignment = Alignment.Center
                    ) {
                        Card(
                            modifier = Modifier
                                .width(120.dp)
                                .height(150.dp),
                            colors = CardDefaults.cardColors(containerColor = Color.White),
                            shape = RoundedCornerShape(4.dp),
                            elevation = CardDefaults.cardElevation(defaultElevation = 3.dp)
                        ) {
                            Column(
                                modifier = Modifier
                                    .fillMaxSize()
                                    .padding(6.dp),
                                horizontalAlignment = Alignment.CenterHorizontally,
                                verticalArrangement = Arrangement.SpaceBetween
                            ) {
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    Icon(Icons.Default.PictureAsPdf, contentDescription = "PDF", tint = Color(0xFFDC2626), modifier = Modifier.size(12.dp))
                                    Spacer(modifier = Modifier.width(4.dp))
                                    Text("A4 PDF DOCUMENT", fontSize = 6.5.sp, fontWeight = FontWeight.Bold)
                                }

                                if (jpgToPdfUri != null) {
                                    AsyncImage(
                                        model = jpgToPdfUri,
                                        contentDescription = "PDF Page Content",
                                        contentScale = ContentScale.Fit,
                                        modifier = Modifier
                                            .fillMaxWidth()
                                            .height(100.dp)
                                            .clip(RoundedCornerShape(2.dp))
                                    )
                                } else {
                                    Box(
                                        modifier = Modifier
                                            .fillMaxWidth()
                                            .height(100.dp)
                                            .background(Color(0xFFF1F5F9)),
                                        contentAlignment = Alignment.Center
                                    ) {
                                        Text("Page 1 Preview", fontSize = 8.sp, color = Color.Gray)
                                    }
                                }

                                Text("Akash Internet Hub", fontSize = 6.sp, color = Color.Gray)
                            }
                        }
                    }

                    Spacer(modifier = Modifier.height(4.dp))
                    DualDownloadActionButtons(
                        toolTitle = "Converted PDF Document",
                        isPaid = isPaid,
                        onFreeDownload = {
                            Toast.makeText(context, "PDF saved with watermark: 'Downloaded From Akash Internet Hub'", Toast.LENGTH_LONG).show()
                        },
                        onPayDownload = {
                            onTriggerPayment("JPG to PDF HD Document (No Watermark)")
                        },
                        onUnlockedDownload = {
                            Toast.makeText(context, "📥 Clean HD Vector PDF Downloaded (No Watermark)!", Toast.LENGTH_LONG).show()
                        }
                    )
                }
            }

            // TAB 1: PDF TO JPG
            if (selectedTab == 1) {
                Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
                    // Upload Button
                    Surface(
                        shape = RoundedCornerShape(10.dp),
                        color = if (pdfToJpgUri != null) AkinGreenSuccess.copy(alpha = 0.1f) else Color(0xFFF8FAFC),
                        border = CardDefaults.outlinedCardBorder(),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Row(
                            modifier = Modifier.padding(12.dp),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.weight(1f)) {
                                Icon(Icons.Default.PictureAsPdf, contentDescription = "PDF", tint = Color(0xFFDC2626), modifier = Modifier.size(28.dp))
                                Spacer(modifier = Modifier.width(10.dp))
                                Column {
                                    Text(if (pdfToJpgUri != null) "Document Selected ✓" else "Upload PDF / Document", fontSize = 12.sp, fontWeight = FontWeight.Bold)
                                    Text("Extract 300 DPI High-Res JPG pages", fontSize = 10.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                                }
                            }
                            Button(
                                onClick = { pdfToJpgPicker.launch("*/*") },
                                shape = RoundedCornerShape(8.dp),
                                contentPadding = PaddingValues(horizontal = 10.dp, vertical = 6.dp)
                            ) {
                                Text(if (pdfToJpgUri != null) "Badlein" else "📁 Browse File", fontSize = 10.sp)
                            }
                        }
                    }

                    // Extracted JPG Live Preview Box
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(170.dp)
                            .background(Color(0xFFE2E8F0), RoundedCornerShape(10.dp))
                            .border(1.dp, Color(0xFFCBD5E1), RoundedCornerShape(10.dp)),
                        contentAlignment = Alignment.Center
                    ) {
                        if (pdfToJpgUri != null) {
                            AsyncImage(
                                model = pdfToJpgUri,
                                contentDescription = "Extracted JPG Preview",
                                contentScale = ContentScale.Fit,
                                modifier = Modifier
                                    .fillMaxSize(0.9f)
                                    .clip(RoundedCornerShape(6.dp))
                            )
                        } else {
                            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                                Icon(Icons.Default.Image, contentDescription = "JPG", tint = MaterialTheme.colorScheme.primary, modifier = Modifier.size(36.dp))
                                Spacer(modifier = Modifier.height(6.dp))
                                Text("Page 1 Extracted (300 DPI 2400×3300 px)", fontSize = 11.sp, fontWeight = FontWeight.Bold)
                                Text("Crystal clear high-resolution JPG output ready", fontSize = 9.sp, color = Color.DarkGray)
                            }
                        }
                    }

                    Spacer(modifier = Modifier.height(4.dp))
                    DualDownloadActionButtons(
                        toolTitle = "Extracted JPG Image",
                        isPaid = isPaid,
                        onFreeDownload = {
                            Toast.makeText(context, "JPG saved with watermark: 'Downloaded From Akash Internet Hub'", Toast.LENGTH_LONG).show()
                        },
                        onPayDownload = {
                            onTriggerPayment("PDF to JPG Ultra-HD Extraction (No Watermark)")
                        },
                        onUnlockedDownload = {
                            Toast.makeText(context, "📥 Clean Ultra-HD JPG Image Downloaded (No Watermark)!", Toast.LENGTH_LONG).show()
                        }
                    )
                }
            }

            // TAB 2: TXT TO JPG
            if (selectedTab == 2) {
                Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    Text("Enter Text or Notice to Render as Image:", fontSize = 12.sp, fontWeight = FontWeight.SemiBold)
                    OutlinedTextField(
                        value = textInputForJpg,
                        onValueChange = { textInputForJpg = it },
                        modifier = Modifier.fillMaxWidth(),
                        minLines = 3,
                        maxLines = 4,
                        shape = RoundedCornerShape(10.dp)
                    )

                    // Card Image Live Preview
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(140.dp)
                            .background(Color(0xFF0F172A), RoundedCornerShape(10.dp))
                            .border(1.dp, Color(0xFF334155), RoundedCornerShape(10.dp))
                            .padding(12.dp)
                    ) {
                        Column {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Surface(shape = RoundedCornerShape(4.dp), color = AkinAmberAccent) {
                                    Text("OFFICIAL NOTICE", fontSize = 8.sp, fontWeight = FontWeight.Black, color = AkinNavyDark, modifier = Modifier.padding(horizontal = 4.dp, vertical = 2.dp))
                                }
                                Spacer(modifier = Modifier.width(6.dp))
                                Text("Akash Internet Hub", fontSize = 9.sp, color = Color.White, fontWeight = FontWeight.Bold)
                            }
                            Spacer(modifier = Modifier.height(6.dp))
                            Text(
                                text = textInputForJpg,
                                fontSize = 10.sp,
                                color = Color(0xFFF1F5F9),
                                lineHeight = 13.sp,
                                maxLines = 4
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(4.dp))
                    DualDownloadActionButtons(
                        toolTitle = "Rendered Notice JPG Image",
                        isPaid = isPaid,
                        onFreeDownload = {
                            Toast.makeText(context, "Image saved with watermark: 'Downloaded From Akash Internet Hub'", Toast.LENGTH_LONG).show()
                        },
                        onPayDownload = {
                            onTriggerPayment("TXT to JPG High-Res Notice Card (No Watermark)")
                        },
                        onUnlockedDownload = {
                            Toast.makeText(context, "📥 Clean High-Res Notice JPG Downloaded (No Watermark)!", Toast.LENGTH_LONG).show()
                        }
                    )
                }
            }

            // TAB 3: EDIT JPG IMAGE TEXT (AI OCR & REPLACER)
            if (selectedTab == 3) {
                Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    // Upload Image to Edit
                    Surface(
                        shape = RoundedCornerShape(10.dp),
                        color = if (editJpgUri != null) AkinGreenSuccess.copy(alpha = 0.1f) else Color(0xFFF8FAFC),
                        border = CardDefaults.outlinedCardBorder(),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Row(
                            modifier = Modifier.padding(10.dp),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.weight(1f)) {
                                Icon(Icons.Default.AddPhotoAlternate, contentDescription = "Edit Image", tint = MaterialTheme.colorScheme.primary, modifier = Modifier.size(24.dp))
                                Spacer(modifier = Modifier.width(8.dp))
                                Column {
                                    Text(if (editJpgUri != null) "Photo Ready to Edit ✓" else "Upload Photo to Edit Text", fontSize = 12.sp, fontWeight = FontWeight.Bold)
                                    Text("AI OCR Text Replacer & Stamp", fontSize = 10.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                                }
                            }
                            Button(
                                onClick = { editJpgPicker.launch("image/*") },
                                shape = RoundedCornerShape(8.dp),
                                contentPadding = PaddingValues(horizontal = 8.dp, vertical = 4.dp)
                            ) {
                                Text(if (editJpgUri != null) "Badlein" else "📁 Browse", fontSize = 10.sp)
                            }
                        }
                    }

                    // Live preview of image with text replacement overlay
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(140.dp)
                            .background(Color(0xFF1E293B), RoundedCornerShape(10.dp))
                            .border(1.dp, Color(0xFF334155), RoundedCornerShape(10.dp)),
                        contentAlignment = Alignment.Center
                    ) {
                        if (editJpgUri != null) {
                            AsyncImage(
                                model = editJpgUri,
                                contentDescription = "User Image",
                                contentScale = ContentScale.Crop,
                                modifier = Modifier.fillMaxSize()
                            )
                        } else {
                            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                                Icon(Icons.Default.Description, contentDescription = "Doc", tint = Color.LightGray, modifier = Modifier.size(32.dp))
                                Text("Upload image to see live text replacement", fontSize = 10.sp, color = Color.LightGray)
                            }
                        }

                        // Overlay replacement stamp
                        Surface(
                            shape = RoundedCornerShape(4.dp),
                            color = Color.Black.copy(alpha = 0.8f),
                            modifier = Modifier
                                .align(Alignment.BottomCenter)
                                .padding(8.dp)
                        ) {
                            Text(
                                text = "AI Replaced: $ocrReplacementText",
                                fontSize = 10.sp,
                                fontWeight = FontWeight.Bold,
                                color = AkinAmberAccent,
                                modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                            )
                        }
                    }

                    Text("AI Image Text Detection & Replacement:", fontSize = 12.sp, fontWeight = FontWeight.SemiBold)
                    OutlinedTextField(
                        value = ocrTargetText,
                        onValueChange = { ocrTargetText = it },
                        label = { Text("Original Text to Replace") },
                        modifier = Modifier.fillMaxWidth(),
                        singleLine = true,
                        shape = RoundedCornerShape(10.dp)
                    )
                    OutlinedTextField(
                        value = ocrReplacementText,
                        onValueChange = { ocrReplacementText = it },
                        label = { Text("New Replacement Text (AI Font Match)") },
                        modifier = Modifier.fillMaxWidth(),
                        singleLine = true,
                        shape = RoundedCornerShape(10.dp)
                    )

                    Spacer(modifier = Modifier.height(4.dp))
                    DualDownloadActionButtons(
                        toolTitle = "AI Edited JPG Image",
                        isPaid = isPaid,
                        onFreeDownload = {
                            Toast.makeText(context, "Saved with watermark: 'Downloaded From Akash Internet Hub'", Toast.LENGTH_LONG).show()
                        },
                        onPayDownload = {
                            onTriggerPayment("AI Edited JPG Image (HD No Watermark)")
                        },
                        onUnlockedDownload = {
                            Toast.makeText(context, "📥 Clean AI Edited High-Res Image Downloaded (No Watermark)!", Toast.LENGTH_LONG).show()
                        }
                    )
                }
            }
        }
    }
}
