package com.example.ui.screens.tools

import android.widget.Toast
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.blur
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.rotate
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.theme.AkinAmberAccent
import com.example.ui.theme.AkinGreenSuccess
import com.example.ui.theme.AkinNavyDark

@Composable
fun AiResumeBuilderTool(
    isPaid: Boolean = false,
    onTriggerPayment: (itemName: String, amount: Int, buttonId: String) -> Unit,
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current

    // Resume Data Fields
    var fullName by remember { mutableStateOf("Bikash Nath") }
    var jobRole by remember { mutableStateOf("Computer Operator / Cyber Specialist") }
    var phone by remember { mutableStateOf("+91 98540 88765") }
    var email by remember { mutableStateOf("bikash.nath2026@gmail.com") }
    var address by remember { mutableStateOf("Geramari Part-II, Dhubri, Assam - 783339") }
    var careerObjective by remember { mutableStateOf("Dedicated and hardworking professional seeking a challenging position in an esteemed organization where I can utilize my computer applications, document processing, and administrative skills to contribute effectively.") }
    
    // Education & Skills
    var educationDegree by remember { mutableStateOf("Bachelor of Arts (B.A) - Gauhati University (2024)") }
    var educationHs by remember { mutableStateOf("Higher Secondary (H.S) - AHSEC Assam (2021)") }
    var educationHslc by remember { mutableStateOf("HSLC (10th) - SEBA Assam (2019)") }
    var technicalSkills by remember { mutableStateOf("MS Office (Word, Excel, PPT), Tally Prime, ADRE Online Portals, Fast English & Assamese Typing (40 WPM), Photoshop DTP") }
    var experienceText by remember { mutableStateOf("1.5 Years as Senior Counter Associate at Digital Cyber Center (Online Form Fillup, Sewa Setu, NSDL PAN, APDCL Billing)") }
    var languagesKnown by remember { mutableStateOf("Assamese (Fluent), Hindi (Fluent), English (Working)") }

    var isPhotoUploaded by remember { mutableStateOf(true) }
    var isSimulatingScreenshotProtection by remember { mutableStateOf(false) }

    Card(
        modifier = modifier
            .fillMaxWidth()
            .testTag("ai_resume_builder_card"),
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
    ) {
        Column(modifier = Modifier.padding(16.dp)) {
            // Header
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text(
                            text = "AI CV & Resume Builder",
                            fontSize = 16.sp,
                            fontWeight = FontWeight.Bold,
                            color = MaterialTheme.colorScheme.onSurface
                        )
                        Spacer(modifier = Modifier.width(6.dp))
                        Surface(
                            shape = RoundedCornerShape(4.dp),
                            color = AkinAmberAccent
                        ) {
                            Text(
                                text = "PRO PDF",
                                fontSize = 9.sp,
                                fontWeight = FontWeight.Bold,
                                color = Color.Black,
                                modifier = Modifier.padding(horizontal = 5.dp, vertical = 2.dp)
                            )
                        }
                    }
                    Text(
                        text = "Instant job-ready Curriculum Vitae for Govt & Private Jobs",
                        fontSize = 11.sp,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }

                // Screenshot Blur simulation toggle
                IconButton(
                    onClick = {
                        isSimulatingScreenshotProtection = !isSimulatingScreenshotProtection
                        Toast.makeText(
                            context,
                            if (isSimulatingScreenshotProtection) "🔒 Screenshot Protection Enabled (Preview Protected)" else "Preview Normal",
                            Toast.LENGTH_SHORT
                        ).show()
                    }
                ) {
                    Icon(
                        imageVector = if (isSimulatingScreenshotProtection) Icons.Default.Security else Icons.Default.Visibility,
                        contentDescription = "Protection Mode",
                        tint = if (isSimulatingScreenshotProtection) AkinAmberAccent else MaterialTheme.colorScheme.primary
                    )
                }
            }

            Spacer(modifier = Modifier.height(12.dp))

            // Step 1: Input Form Accordion
            Text("1. Fill Details & Upload Credentials", fontSize = 13.sp, fontWeight = FontWeight.Bold)
            Spacer(modifier = Modifier.height(6.dp))

            OutlinedTextField(
                value = fullName,
                onValueChange = { fullName = it },
                label = { Text("Full Name") },
                modifier = Modifier.fillMaxWidth(),
                singleLine = true
            )
            Spacer(modifier = Modifier.height(6.dp))

            OutlinedTextField(
                value = jobRole,
                onValueChange = { jobRole = it },
                label = { Text("Target Job Title / Role") },
                modifier = Modifier.fillMaxWidth(),
                singleLine = true
            )
            Spacer(modifier = Modifier.height(6.dp))

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                OutlinedTextField(
                    value = phone,
                    onValueChange = { phone = it },
                    label = { Text("Phone Number") },
                    modifier = Modifier.weight(1f),
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Phone),
                    singleLine = true
                )
                OutlinedTextField(
                    value = email,
                    onValueChange = { email = it },
                    label = { Text("Email Address") },
                    modifier = Modifier.weight(1f),
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Email),
                    singleLine = true
                )
            }
            Spacer(modifier = Modifier.height(6.dp))

            OutlinedTextField(
                value = address,
                onValueChange = { address = it },
                label = { Text("Permanent Address (Village/Town, District, Assam)") },
                modifier = Modifier.fillMaxWidth(),
                singleLine = true
            )
            Spacer(modifier = Modifier.height(6.dp))

            OutlinedTextField(
                value = careerObjective,
                onValueChange = { careerObjective = it },
                label = { Text("Career Objective / Summary") },
                modifier = Modifier.fillMaxWidth(),
                maxLines = 3
            )
            Spacer(modifier = Modifier.height(6.dp))

            OutlinedTextField(
                value = educationDegree,
                onValueChange = { educationDegree = it },
                label = { Text("Highest Qualification (Degree/Diploma)") },
                modifier = Modifier.fillMaxWidth(),
                singleLine = true
            )
            Spacer(modifier = Modifier.height(6.dp))

            OutlinedTextField(
                value = technicalSkills,
                onValueChange = { technicalSkills = it },
                label = { Text("Technical & Computer Skills") },
                modifier = Modifier.fillMaxWidth(),
                singleLine = true
            )
            Spacer(modifier = Modifier.height(6.dp))

            OutlinedTextField(
                value = experienceText,
                onValueChange = { experienceText = it },
                label = { Text("Work Experience / Past Roles") },
                modifier = Modifier.fillMaxWidth(),
                singleLine = true
            )
            Spacer(modifier = Modifier.height(6.dp))

            OutlinedTextField(
                value = languagesKnown,
                onValueChange = { languagesKnown = it },
                label = { Text("Languages Known") },
                modifier = Modifier.fillMaxWidth(),
                singleLine = true
            )

            Spacer(modifier = Modifier.height(10.dp))

            // Photo Upload Simulation
            Surface(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(10.dp))
                    .clickable {
                        isPhotoUploaded = !isPhotoUploaded
                        Toast.makeText(context, if (isPhotoUploaded) "Passport Photo Attached!" else "Photo Removed", Toast.LENGTH_SHORT).show()
                    },
                color = if (isPhotoUploaded) MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.5f) else MaterialTheme.colorScheme.surfaceVariant
            ) {
                Row(
                    modifier = Modifier.padding(12.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Icon(
                        imageVector = if (isPhotoUploaded) Icons.Default.CheckCircle else Icons.Default.AddPhotoAlternate,
                        contentDescription = "Photo Upload",
                        tint = if (isPhotoUploaded) AkinGreenSuccess else MaterialTheme.colorScheme.primary
                    )
                    Spacer(modifier = Modifier.width(10.dp))
                    Column {
                        Text(
                            text = if (isPhotoUploaded) "Passport Photo Uploaded (passport_photo.jpg)" else "Click to Upload Passport Photo",
                            fontSize = 12.sp,
                            fontWeight = FontWeight.Bold
                        )
                        Text(
                            text = "Auto-formatted with standard white background in CV",
                            fontSize = 10.sp,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.height(18.dp))

            // Step 2: Live CV Document Preview with Watermark & Anti-Screenshot protection
            Text("2. Live Document Preview", fontSize = 13.sp, fontWeight = FontWeight.Bold)
            Spacer(modifier = Modifier.height(6.dp))

            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .wrapContentHeight()
                    .clip(RoundedCornerShape(12.dp))
                    .background(Color.White)
                    .border(1.dp, Color(0xFFCBD5E1), RoundedCornerShape(12.dp))
                    .padding(14.dp)
            ) {
                // Main CV Body
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .then(if (isSimulatingScreenshotProtection) Modifier.blur(12.dp) else Modifier)
                ) {
                    // CV Top Header
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column(modifier = Modifier.weight(1f)) {
                            Text(
                                text = fullName.ifBlank { "YOUR FULL NAME" }.uppercase(),
                                fontSize = 16.sp,
                                fontWeight = FontWeight.ExtraBold,
                                color = Color(0xFF0F172A)
                            )
                            Text(
                                text = jobRole.ifBlank { "Professional Role" },
                                fontSize = 11.sp,
                                fontWeight = FontWeight.Bold,
                                color = Color(0xFF1E3A8A)
                            )
                            Spacer(modifier = Modifier.height(4.dp))
                            Text(
                                text = "📞 $phone  |  ✉️ $email",
                                fontSize = 9.sp,
                                color = Color(0xFF475569)
                            )
                            Text(
                                text = "📍 $address",
                                fontSize = 9.sp,
                                color = Color(0xFF475569)
                            )
                        }

                        if (isPhotoUploaded) {
                            Surface(
                                modifier = Modifier
                                    .size(54.dp)
                                    .border(1.dp, Color(0xFF94A3B8), RoundedCornerShape(6.dp))
                                    .clip(RoundedCornerShape(6.dp)),
                                color = Color(0xFFE2E8F0)
                            ) {
                                Box(contentAlignment = Alignment.Center) {
                                    Icon(Icons.Default.Person, contentDescription = "Photo", tint = Color(0xFF475569), modifier = Modifier.size(36.dp))
                                }
                            }
                        }
                    }

                    HorizontalDivider(modifier = Modifier.padding(vertical = 8.dp), color = Color(0xFF1E3A8A), thickness = 2.dp)

                    // Objective
                    Text("OBJECTIVE", fontSize = 11.sp, fontWeight = FontWeight.ExtraBold, color = Color(0xFF1E3A8A))
                    Text(text = careerObjective, fontSize = 9.5.sp, color = Color(0xFF1E293B), lineHeight = 13.sp)

                    Spacer(modifier = Modifier.height(8.dp))

                    // Education
                    Text("EDUCATION & QUALIFICATIONS", fontSize = 11.sp, fontWeight = FontWeight.ExtraBold, color = Color(0xFF1E3A8A))
                    Text(text = "• $educationDegree", fontSize = 9.5.sp, color = Color(0xFF1E293B))
                    Text(text = "• $educationHs", fontSize = 9.5.sp, color = Color(0xFF1E293B))
                    Text(text = "• $educationHslc", fontSize = 9.5.sp, color = Color(0xFF1E293B))

                    Spacer(modifier = Modifier.height(8.dp))

                    // Experience
                    Text("WORK EXPERIENCE", fontSize = 11.sp, fontWeight = FontWeight.ExtraBold, color = Color(0xFF1E3A8A))
                    Text(text = "• $experienceText", fontSize = 9.5.sp, color = Color(0xFF1E293B))

                    Spacer(modifier = Modifier.height(8.dp))

                    // Skills & Languages
                    Text("KEY SKILLS & LANGUAGES", fontSize = 11.sp, fontWeight = FontWeight.ExtraBold, color = Color(0xFF1E3A8A))
                    Text(text = "• Skills: $technicalSkills", fontSize = 9.5.sp, color = Color(0xFF1E293B))
                    Text(text = "• Languages: $languagesKnown", fontSize = 9.5.sp, color = Color(0xFF1E293B))

                    Spacer(modifier = Modifier.height(8.dp))

                    // Declaration
                    Text("DECLARATION", fontSize = 10.sp, fontWeight = FontWeight.Bold, color = Color(0xFF475569))
                    Text("I hereby declare that all the information provided above is true and authentic to the best of my knowledge.", fontSize = 8.5.sp, color = Color(0xFF64748B))

                    Spacer(modifier = Modifier.height(6.dp))
                    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                        Text("Place: Dhubri, Assam", fontSize = 8.5.sp, color = Color(0xFF64748B))
                        Text("(${fullName.ifBlank { "Applicant Signature" }})", fontSize = 8.5.sp, fontWeight = FontWeight.Bold, color = Color(0xFF1E293B))
                    }
                }

                // Security & Watermark Overlays
                Box(
                    modifier = Modifier.matchParentSize(),
                    contentAlignment = Alignment.Center
                ) {
                    Text(
                        text = "PREVIEW ONLY\nAKASH INTERNET HUB\nDO NOT SCREENSHOT",
                        color = Color.Red.copy(alpha = 0.18f),
                        fontSize = 18.sp,
                        fontWeight = FontWeight.Black,
                        textAlign = TextAlign.Center,
                        lineHeight = 22.sp,
                        modifier = Modifier.rotate(-28f)
                    )
                }

                if (isSimulatingScreenshotProtection) {
                    Box(
                        modifier = Modifier
                            .matchParentSize()
                            .background(Color.Black.copy(alpha = 0.65f)),
                        contentAlignment = Alignment.Center
                    ) {
                        Column(horizontalAlignment = Alignment.CenterHorizontally) {
                            Icon(Icons.Default.Security, contentDescription = "Protected", tint = AkinAmberAccent, modifier = Modifier.size(36.dp))
                            Spacer(modifier = Modifier.height(4.dp))
                            Text(
                                text = "SCREENSHOT PROTECTED",
                                color = Color.White,
                                fontWeight = FontWeight.Bold,
                                fontSize = 13.sp
                            )
                            Text(
                                text = "Download original PDF via buttons below",
                                color = Color.White.copy(alpha = 0.8f),
                                fontSize = 10.sp
                            )
                        }
                    }
                }
            }

            Spacer(modifier = Modifier.height(16.dp))

            // Step 3: Two Clear Download Buttons
            // Button 1: Free Download With Watermark
            OutlinedButton(
                onClick = {
                    Toast.makeText(
                        context,
                        "📥 Free CV Downloaded with Watermark: 'Downloaded From Akash Internet Hub'",
                        Toast.LENGTH_LONG
                    ).show()
                },
                modifier = Modifier
                    .fillMaxWidth()
                    .height(46.dp)
                    .testTag("free_cv_download_button"),
                shape = RoundedCornerShape(10.dp)
            ) {
                Icon(Icons.Default.Download, contentDescription = "Free Download", modifier = Modifier.size(18.dp))
                Spacer(modifier = Modifier.width(6.dp))
                Text(
                    text = "Free Download (With Watermark)",
                    fontSize = 12.sp,
                    fontWeight = FontWeight.SemiBold
                )
            }

            Spacer(modifier = Modifier.height(10.dp))

            if (isPaid) {
                // Unlocked Clean PDF Button
                Button(
                    onClick = {
                        Toast.makeText(
                            context,
                            "📥 Clean High-Resolution CV / Resume PDF Downloaded (Without Watermark)!",
                            Toast.LENGTH_LONG
                        ).show()
                    },
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(48.dp)
                        .testTag("download_unlocked_cv_button"),
                    shape = RoundedCornerShape(10.dp),
                    colors = ButtonDefaults.buttonColors(containerColor = AkinGreenSuccess, contentColor = Color.White)
                ) {
                    Icon(Icons.Default.DownloadDone, contentDescription = "Download Clean PDF", modifier = Modifier.size(20.dp))
                    Spacer(modifier = Modifier.width(8.dp))
                    Column(horizontalAlignment = Alignment.Start) {
                        Text(
                            text = "✨ Download Clean CV PDF (Unlocked)",
                            fontSize = 13.sp,
                            fontWeight = FontWeight.Bold,
                            color = Color.White
                        )
                        Text(
                            text = "100% Watermark Free • Vector Print Ready PDF",
                            fontSize = 9.sp,
                            color = Color.White.copy(alpha = 0.9f)
                        )
                    }
                }
            } else {
                // Button 2: Pay ₹150 & Get Clean PDF
                Button(
                    onClick = {
                        onTriggerPayment(
                            "Professional CV / Resume Clean PDF (Without Watermark)",
                            150,
                            "pl_TSYk8HTVZ5jbAb"
                        )
                    },
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(48.dp)
                        .testTag("pay_cv_clean_pdf_button"),
                    shape = RoundedCornerShape(10.dp),
                    colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.primary)
                ) {
                    Icon(Icons.Default.PictureAsPdf, contentDescription = "Pay PDF", modifier = Modifier.size(18.dp))
                    Spacer(modifier = Modifier.width(8.dp))
                    Column(horizontalAlignment = Alignment.Start) {
                        Text(
                            text = "Pay ₹150 & Get Clean PDF (No Watermark)",
                            fontSize = 13.sp,
                            fontWeight = FontWeight.Bold
                        )
                        Text(
                            text = "Razorpay Checkout • High-Resolution Vector Print",
                            fontSize = 9.sp,
                            color = Color.White.copy(alpha = 0.85f)
                        )
                    }
                }
            }
        }
    }
}
