package com.example.ui.screens.tools

import android.net.Uri
import android.widget.Toast
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.blur
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.rotate
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import coil.compose.AsyncImage
import com.example.data.model.HubInfo
import com.example.ui.dialogs.FileDownloadProgressDialog
import com.example.ui.theme.AkinAmberAccent
import com.example.ui.theme.AkinGreenSuccess
import com.example.ui.theme.AkinNavyDark
import com.example.utils.DocumentExportHelper
import com.example.utils.MonetagHelper
import kotlinx.coroutines.launch
import java.io.File

@Composable
fun AiResumeBuilderTool(
    hubInfo: HubInfo = HubInfo(),
    isPaid: Boolean = false,
    onTriggerPayment: (itemName: String, amount: Int, buttonId: String) -> Unit,
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    val coroutineScope = rememberCoroutineScope()

    // Resume Data Fields (Default Name: Akash Internet Hub, Default Phone: +91 7002134700)
    var fullName by remember { mutableStateOf("Akash Internet Hub") }
    var jobRole by remember { mutableStateOf("Computer Operator / Cyber Specialist") }
    var phone by remember { mutableStateOf("+91 7002134700") }
    var email by remember { mutableStateOf("akashinternethub@gmail.com") }
    var address by remember { mutableStateOf("Near Saba Petrol Pump, Geramari Part-II, Dhubri, Assam - 783339") }
    var careerObjective by remember { mutableStateOf("Dedicated and hardworking professional seeking a challenging position in an esteemed organization where I can utilize my computer applications, document processing, and administrative skills to contribute effectively.") }
    
    // Education & Skills
    var educationDegree by remember { mutableStateOf("Bachelor of Arts (B.A) - Gauhati University (2024)") }
    var educationHs by remember { mutableStateOf("Higher Secondary (H.S) - AHSEC Assam (2021)") }
    var educationHslc by remember { mutableStateOf("HSLC (10th) - SEBA Assam (2019)") }
    var technicalSkills by remember { mutableStateOf("MS Office (Word, Excel, PPT), Tally Prime, ADRE Online Portals, Fast English & Assamese Typing (40 WPM), Photoshop DTP") }
    var experienceText by remember { mutableStateOf("1.5 Years as Senior Counter Associate at Digital Cyber Center (Online Form Fillup, Sewa Setu, NSDL PAN, APDCL Billing)") }
    var languagesKnown by remember { mutableStateOf("Assamese (Fluent), Hindi (Fluent), English (Working)") }

    // User Photo Upload
    var selectedPhotoUri by remember { mutableStateOf<Uri?>(null) }
    val photoPickerLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.GetContent()
    ) { uri: Uri? ->
        if (uri != null) {
            selectedPhotoUri = uri
            Toast.makeText(context, "📸 Passport photo attached to Resume!", Toast.LENGTH_SHORT).show()
        }
    }

    var isSimulatingScreenshotProtection by remember { mutableStateOf(false) }

    // Download Engine State
    var isDownloading by remember { mutableStateOf(false) }
    var progressMessage by remember { mutableStateOf("") }
    var downloadedFile by remember { mutableStateOf<File?>(null) }

    // Progress Dialog
    FileDownloadProgressDialog(
        isDownloading = isDownloading,
        progressMessage = progressMessage,
        downloadedFile = downloadedFile,
        onDismiss = {
            isDownloading = false
            downloadedFile = null
            progressMessage = ""
        }
    )

    Card(
        modifier = modifier
            .fillMaxWidth()
            .testTag("ai_resume_builder_card"),
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
    ) {
        Column(modifier = Modifier.padding(16.dp)) {
            // Header
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text(
                            text = "AI CV & Resume Builder",
                            fontSize = 16.sp,
                            fontWeight = FontWeight.Bold,
                            color = MaterialTheme.colorScheme.onSurface
                        )
                        Spacer(modifier = Modifier.width(6.dp))
                        Surface(
                            shape = RoundedCornerShape(4.dp),
                            color = AkinAmberAccent
                        ) {
                            Text(
                                text = "PRO PDF",
                                fontSize = 9.sp,
                                fontWeight = FontWeight.Bold,
                                color = Color.Black,
                                modifier = Modifier.padding(horizontal = 5.dp, vertical = 2.dp)
                            )
                        }
                    }
                    Text(
                        text = "Instant job-ready Curriculum Vitae for Govt & Private Jobs",
                        fontSize = 11.sp,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }

                // Screenshot Blur simulation toggle
                IconButton(
                    onClick = {
                        isSimulatingScreenshotProtection = !isSimulatingScreenshotProtection
                        Toast.makeText(
                            context,
                            if (isSimulatingScreenshotProtection) "🔒 Screenshot Protection Enabled (Preview Protected)" else "Preview Normal",
                            Toast.LENGTH_SHORT
                        ).show()
                    }
                ) {
                    Icon(
                        imageVector = if (isSimulatingScreenshotProtection) Icons.Default.Security else Icons.Default.Visibility,
                        contentDescription = "Protection Mode",
                        tint = if (isSimulatingScreenshotProtection) AkinAmberAccent else MaterialTheme.colorScheme.primary
                    )
                }
            }

            Spacer(modifier = Modifier.height(12.dp))

            // Photo Upload Section
            Card(
                modifier = Modifier.fillMaxWidth(),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.45f)),
                shape = RoundedCornerShape(12.dp),
                border = BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.6f))
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(12.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Box(
                        modifier = Modifier
                            .size(68.dp, 80.dp)
                            .clip(RoundedCornerShape(8.dp))
                            .border(1.5.dp, if (selectedPhotoUri != null) AkinGreenSuccess else MaterialTheme.colorScheme.primary, RoundedCornerShape(8.dp))
                            .background(Color.White)
                            .clickable { photoPickerLauncher.launch("image/*") },
                        contentAlignment = Alignment.Center
                    ) {
                        if (selectedPhotoUri != null) {
                            AsyncImage(
                                model = selectedPhotoUri,
                                contentDescription = "Passport Photo",
                                contentScale = ContentScale.Crop,
                                modifier = Modifier.fillMaxSize()
                            )
                        } else {
                            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                                Icon(
                                    imageVector = Icons.Default.AddPhotoAlternate,
                                    contentDescription = "Add Photo",
                                    tint = MaterialTheme.colorScheme.primary,
                                    modifier = Modifier.size(26.dp)
                                )
                                Spacer(modifier = Modifier.height(2.dp))
                                Text("Upload", fontSize = 9.sp, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.primary)
                            }
                        }
                    }

                    Spacer(modifier = Modifier.width(12.dp))

                    Column(modifier = Modifier.weight(1f)) {
                        Text(
                            text = if (selectedPhotoUri != null) "✅ Passport Photo Attached" else "📷 Upload Candidate Photo (Optional)",
                            fontSize = 12.5.sp,
                            fontWeight = FontWeight.Bold,
                            color = MaterialTheme.colorScheme.onSurface
                        )
                        Text(
                            text = "Photo will be cleanly embedded in the generated Resume PDF",
                            fontSize = 10.5.sp,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                        Spacer(modifier = Modifier.height(6.dp))
                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            Button(
                                onClick = { photoPickerLauncher.launch("image/*") },
                                shape = RoundedCornerShape(8.dp),
                                contentPadding = PaddingValues(horizontal = 12.dp, vertical = 4.dp),
                                modifier = Modifier.height(32.dp)
                            ) {
                                Icon(Icons.Default.CloudUpload, contentDescription = null, modifier = Modifier.size(13.dp))
                                Spacer(modifier = Modifier.width(4.dp))
                                Text(if (selectedPhotoUri != null) "Change" else "Choose Photo", fontSize = 11.sp)
                            }
                            if (selectedPhotoUri != null) {
                                OutlinedButton(
                                    onClick = { selectedPhotoUri = null },
                                    shape = RoundedCornerShape(8.dp),
                                    contentPadding = PaddingValues(horizontal = 8.dp, vertical = 4.dp),
                                    modifier = Modifier.height(32.dp)
                                ) {
                                    Icon(Icons.Default.Delete, contentDescription = "Remove", tint = Color(0xFFDC2626), modifier = Modifier.size(13.dp))
                                    Spacer(modifier = Modifier.width(2.dp))
                                    Text("Remove", fontSize = 10.5.sp, color = Color(0xFFDC2626))
                                }
                            }
                        }
                    }
                }
            }

            Spacer(modifier = Modifier.height(12.dp))

            // Step 1: Input Form Accordion
            Text("1. Fill Details & Educational Background", fontSize = 13.sp, fontWeight = FontWeight.Bold)
            Spacer(modifier = Modifier.height(6.dp))

            OutlinedTextField(
                value = fullName,
                onValueChange = { fullName = it },
                label = { Text("Full Name (Default: Akash Internet Hub)") },
                modifier = Modifier.fillMaxWidth(),
                singleLine = true
            )
            Spacer(modifier = Modifier.height(6.dp))

            OutlinedTextField(
                value = jobRole,
                onValueChange = { jobRole = it },
                label = { Text("Target Job Title / Role") },
                modifier = Modifier.fillMaxWidth(),
                singleLine = true
            )
            Spacer(modifier = Modifier.height(6.dp))

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                OutlinedTextField(
                    value = phone,
                    onValueChange = { phone = it },
                    label = { Text("Phone Number") },
                    modifier = Modifier.weight(1f),
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Phone),
                    singleLine = true
                )
                OutlinedTextField(
                    value = email,
                    onValueChange = { email = it },
                    label = { Text("Email Address") },
                    modifier = Modifier.weight(1f),
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Email),
                    singleLine = true
                )
            }
            Spacer(modifier = Modifier.height(6.dp))

            OutlinedTextField(
                value = address,
                onValueChange = { address = it },
                label = { Text("Complete Address") },
                modifier = Modifier.fillMaxWidth(),
                singleLine = true
            )
            Spacer(modifier = Modifier.height(6.dp))

            OutlinedTextField(
                value = careerObjective,
                onValueChange = { careerObjective = it },
                label = { Text("Career Objective") },
                modifier = Modifier.fillMaxWidth(),
                maxLines = 3
            )

            Spacer(modifier = Modifier.height(10.dp))

            Text("Education Qualifications:", fontSize = 12.sp, fontWeight = FontWeight.SemiBold)
            Spacer(modifier = Modifier.height(4.dp))
            OutlinedTextField(
                value = educationDegree,
                onValueChange = { educationDegree = it },
                label = { Text("Highest Degree / Diploma") },
                modifier = Modifier.fillMaxWidth(),
                singleLine = true
            )
            Spacer(modifier = Modifier.height(4.dp))
            OutlinedTextField(
                value = educationHs,
                onValueChange = { educationHs = it },
                label = { Text("Class 12th / H.S") },
                modifier = Modifier.fillMaxWidth(),
                singleLine = true
            )
            Spacer(modifier = Modifier.height(4.dp))
            OutlinedTextField(
                value = educationHslc,
                onValueChange = { educationHslc = it },
                label = { Text("Class 10th / HSLC") },
                modifier = Modifier.fillMaxWidth(),
                singleLine = true
            )

            Spacer(modifier = Modifier.height(10.dp))

            Text("Skills & Experience:", fontSize = 12.sp, fontWeight = FontWeight.SemiBold)
            Spacer(modifier = Modifier.height(4.dp))
            OutlinedTextField(
                value = technicalSkills,
                onValueChange = { technicalSkills = it },
                label = { Text("Technical Skills") },
                modifier = Modifier.fillMaxWidth()
            )
            Spacer(modifier = Modifier.height(4.dp))
            OutlinedTextField(
                value = experienceText,
                onValueChange = { experienceText = it },
                label = { Text("Work Experience") },
                modifier = Modifier.fillMaxWidth()
            )
            Spacer(modifier = Modifier.height(4.dp))
            OutlinedTextField(
                value = languagesKnown,
                onValueChange = { languagesKnown = it },
                label = { Text("Languages Known") },
                modifier = Modifier.fillMaxWidth(),
                singleLine = true
            )

            Spacer(modifier = Modifier.height(14.dp))

            // Step 2: Live CV Document Preview with Watermark / Blur Protection
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text("2. Live Document Preview", fontSize = 13.sp, fontWeight = FontWeight.Bold)
                Text(
                    text = if (isPaid) "✅ Unlocked High-Res" else "🔒 Watermarked Preview",
                    fontSize = 11.sp,
                    fontWeight = FontWeight.Bold,
                    color = if (isPaid) AkinGreenSuccess else AkinAmberAccent
                )
            }
            Spacer(modifier = Modifier.height(6.dp))

            // Paper Preview Container (A4 Aspect Ratio)
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(340.dp)
                    .clip(RoundedCornerShape(8.dp))
                    .border(1.dp, Color(0xFFCBD5E1), RoundedCornerShape(8.dp))
                    .background(Color.White)
            ) {
                Column(
                    modifier = Modifier
                        .fillMaxSize()
                        .padding(12.dp)
                        .then(if (isSimulatingScreenshotProtection) Modifier.blur(14.dp) else Modifier)
                ) {
                    // Header Bar
                    Surface(
                        color = AkinNavyDark,
                        shape = RoundedCornerShape(4.dp),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Row(
                            modifier = Modifier.padding(8.dp),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Column(modifier = Modifier.weight(1f)) {
                                Text(
                                    text = fullName.ifBlank { "Akash Internet Hub" },
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 13.sp,
                                    color = Color.White
                                )
                                Text(
                                    text = jobRole,
                                    fontSize = 9.sp,
                                    color = AkinAmberAccent,
                                    fontWeight = FontWeight.SemiBold
                                )
                                Text(
                                    text = "📞 $phone | ✉️ $email",
                                    fontSize = 7.5.sp,
                                    color = Color.White.copy(alpha = 0.8f)
                                )
                            }
                            Surface(
                                shape = RoundedCornerShape(6.dp),
                                color = AkinAmberAccent,
                                modifier = Modifier.size(38.dp, 44.dp)
                            ) {
                                if (selectedPhotoUri != null) {
                                    AsyncImage(
                                        model = selectedPhotoUri,
                                        contentDescription = "Candidate Photo",
                                        contentScale = ContentScale.Crop,
                                        modifier = Modifier.fillMaxSize()
                                    )
                                } else {
                                    Box(contentAlignment = Alignment.Center) {
                                        Icon(Icons.Default.Person, contentDescription = "User", tint = AkinNavyDark, modifier = Modifier.size(24.dp))
                                    }
                                }
                            }
                        }
                    }

                    Spacer(modifier = Modifier.height(6.dp))

                    // Objective
                    Text("CAREER OBJECTIVE", fontSize = 8.5.sp, fontWeight = FontWeight.Bold, color = AkinNavyDark)
                    Text(
                        text = careerObjective,
                        fontSize = 7.5.sp,
                        color = Color(0xFF334155),
                        maxLines = 2,
                        lineHeight = 10.sp
                    )

                    Spacer(modifier = Modifier.height(4.dp))

                    // Education
                    Text("EDUCATION", fontSize = 8.5.sp, fontWeight = FontWeight.Bold, color = AkinNavyDark)
                    Text("• $educationDegree", fontSize = 7.sp, color = Color(0xFF334155))
                    Text("• $educationHs", fontSize = 7.sp, color = Color(0xFF334155))
                    Text("• $educationHslc", fontSize = 7.sp, color = Color(0xFF334155))

                    Spacer(modifier = Modifier.height(4.dp))

                    // Skills
                    Text("TECHNICAL SKILLS", fontSize = 8.5.sp, fontWeight = FontWeight.Bold, color = AkinNavyDark)
                    Text(technicalSkills, fontSize = 7.sp, color = Color(0xFF334155), maxLines = 2)

                    Spacer(modifier = Modifier.height(4.dp))

                    // Experience
                    Text("EXPERIENCE", fontSize = 8.5.sp, fontWeight = FontWeight.Bold, color = AkinNavyDark)
                    Text(experienceText, fontSize = 7.sp, color = Color(0xFF334155), maxLines = 2)
                }

                // Center Watermark Overlay (If Free / Not Paid)
                if (!isPaid) {
                    Text(
                        text = hubInfo.watermarkText.ifBlank { "Downloaded From Akash Internet Hub" },
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold,
                        color = Color.Black.copy(alpha = 0.16f),
                        modifier = Modifier
                            .align(Alignment.Center)
                            .rotate(-28f)
                    )
                }

                if (isSimulatingScreenshotProtection) {
                    Box(
                        modifier = Modifier
                            .matchParentSize()
                            .background(Color.Black.copy(alpha = 0.65f)),
                        contentAlignment = Alignment.Center
                    ) {
                        Column(horizontalAlignment = Alignment.CenterHorizontally) {
                            Icon(Icons.Default.Security, contentDescription = "Protected", tint = AkinAmberAccent, modifier = Modifier.size(36.dp))
                            Spacer(modifier = Modifier.height(4.dp))
                            Text(
                                text = "SCREENSHOT PROTECTED",
                                color = Color.White,
                                fontWeight = FontWeight.Bold,
                                fontSize = 13.sp
                            )
                            Text(
                                text = "Download original PDF via buttons below",
                                color = Color.White.copy(alpha = 0.8f),
                                fontSize = 10.sp
                            )
                        }
                    }
                }
            }

            Spacer(modifier = Modifier.height(16.dp))

            // Step 3: Two Clear Download Buttons with REAL Loading Animations & File Saving
            // Button 1: Free Download With Watermark
            OutlinedButton(
                onClick = {
                    MonetagHelper.openMonetagAd(context)
                    coroutineScope.launch {
                        isDownloading = true
                        downloadedFile = null
                        progressMessage = "Generating Free CV PDF..."
                        val file = DocumentExportHelper.generateAndSaveResumePdf(
                            context = context,
                            fullName = fullName,
                            jobRole = jobRole,
                            phone = phone,
                            email = email,
                            address = address,
                            careerObjective = careerObjective,
                            educationDegree = educationDegree,
                            educationHs = educationHs,
                            educationHslc = educationHslc,
                            technicalSkills = technicalSkills,
                            experienceText = experienceText,
                            languagesKnown = languagesKnown,
                            photoUri = selectedPhotoUri,
                            isWatermarked = true,
                            watermarkText = hubInfo.watermarkText,
                            onProgressUpdate = { msg -> progressMessage = msg }
                        )
                        downloadedFile = file
                    }
                },
                modifier = Modifier
                    .fillMaxWidth()
                    .height(46.dp)
                    .testTag("free_cv_download_button"),
                shape = RoundedCornerShape(10.dp)
            ) {
                Icon(Icons.Default.Download, contentDescription = "Free Download", modifier = Modifier.size(18.dp))
                Spacer(modifier = Modifier.width(6.dp))
                Text(
                    text = hubInfo.freeDownloadButtonText.ifBlank { "Free Download (With Watermark)" },
                    fontSize = 12.sp,
                    fontWeight = FontWeight.SemiBold
                )
            }

            Spacer(modifier = Modifier.height(10.dp))

            if (isPaid) {
                // Unlocked Clean PDF Button with Real Loading Animation & File Saving
                Button(
                    onClick = {
                        MonetagHelper.openMonetagAd(context)
                        coroutineScope.launch {
                            isDownloading = true
                            downloadedFile = null
                            progressMessage = "Generating High-Resolution Clean CV..."
                            val file = DocumentExportHelper.generateAndSaveResumePdf(
                                context = context,
                                fullName = fullName,
                                jobRole = jobRole,
                                phone = phone,
                                email = email,
                                address = address,
                                careerObjective = careerObjective,
                                educationDegree = educationDegree,
                                educationHs = educationHs,
                                educationHslc = educationHslc,
                                technicalSkills = technicalSkills,
                                experienceText = experienceText,
                                languagesKnown = languagesKnown,
                                photoUri = selectedPhotoUri,
                                isWatermarked = false,
                                watermarkText = hubInfo.watermarkText,
                                onProgressUpdate = { msg -> progressMessage = msg }
                            )
                            downloadedFile = file
                        }
                    },
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(48.dp)
                        .testTag("download_unlocked_cv_button"),
                    shape = RoundedCornerShape(10.dp),
                    colors = ButtonDefaults.buttonColors(containerColor = AkinGreenSuccess, contentColor = Color.White)
                ) {
                    Icon(Icons.Default.DownloadDone, contentDescription = "Download Clean PDF", modifier = Modifier.size(20.dp))
                    Spacer(modifier = Modifier.width(8.dp))
                    Column(horizontalAlignment = Alignment.Start) {
                        Text(
                            text = hubInfo.unlockedButtonText.ifBlank { "✨ Download Clean CV PDF (Unlocked)" },
                            fontSize = 13.sp,
                            fontWeight = FontWeight.Bold,
                            color = Color.White
                        )
                        Text(
                            text = "100% Watermark Free • Vector Print Ready PDF",
                            fontSize = 9.sp,
                            color = Color.White.copy(alpha = 0.9f)
                        )
                    }
                }
            } else {
                // Button 2: Pay & Get Clean PDF
                val priceInt = hubInfo.hdPriceText.toIntOrNull() ?: 150
                Button(
                    onClick = {
                        onTriggerPayment(
                            "Professional CV / Resume Clean PDF (Without Watermark)",
                            priceInt,
                            "pl_TSYk8HTVZ5jbAb"
                        )
                    },
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(48.dp)
                        .testTag("pay_cv_clean_pdf_button"),
                    shape = RoundedCornerShape(10.dp),
                    colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.primary)
                ) {
                    Icon(Icons.Default.PictureAsPdf, contentDescription = "Pay PDF", modifier = Modifier.size(18.dp))
                    Spacer(modifier = Modifier.width(8.dp))
                    Column(horizontalAlignment = Alignment.Start) {
                        Text(
                            text = hubInfo.payHdButtonText.ifBlank { "Pay ₹$priceInt & Get Clean PDF (No Watermark)" },
                            fontSize = 13.sp,
                            fontWeight = FontWeight.Bold
                        )
                        Text(
                            text = "Razorpay Checkout • High-Resolution Vector Print",
                            fontSize = 9.sp,
                            color = Color.White.copy(alpha = 0.85f)
                        )
                    }
                }
            }
        }
    }
}
