package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.ApplicationStatus
import com.example.data.model.PrintOrder
import com.example.data.model.ServiceApplication
import com.example.ui.components.ContactHelper
import com.example.ui.theme.AkinAmberAccent
import com.example.ui.theme.AkinBlueLight
import com.example.ui.theme.AkinGreenSuccess

@Composable
fun TrackerScreen(
    applications: List<ServiceApplication>,
    printOrders: List<PrintOrder>,
    searchQuery: String,
    onSearchQueryChange: (String) -> Unit,
    onViewReceipt: (ServiceApplication) -> Unit,
    onBookNewService: () -> Unit,
    onBookNewPrint: () -> Unit,
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    var selectedSection by remember { mutableStateOf(0) } // 0: Applications, 1: Print Orders

    val filteredApplications = applications.filter { app ->
        searchQuery.isBlank() ||
                app.id.contains(searchQuery, ignoreCase = true) ||
                app.applicantName.contains(searchQuery, ignoreCase = true) ||
                app.serviceTitle.contains(searchQuery, ignoreCase = true) ||
                app.trackingRefNumber.contains(searchQuery, ignoreCase = true)
    }

    val filteredPrintOrders = printOrders.filter { order ->
        searchQuery.isBlank() ||
                order.id.contains(searchQuery, ignoreCase = true) ||
                order.title.contains(searchQuery, ignoreCase = true) ||
                order.customerName.contains(searchQuery, ignoreCase = true)
    }

    LazyColumn(
        modifier = modifier
            .fillMaxSize()
            .testTag("tracker_screen_list"),
        contentPadding = PaddingValues(start = 16.dp, end = 16.dp, top = 16.dp, bottom = 90.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        item {
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("tracker_header_card"),
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.primaryContainer)
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = "Live Status & Receipts",
                            fontSize = 17.sp,
                            fontWeight = FontWeight.Bold,
                            color = MaterialTheme.colorScheme.onPrimaryContainer
                        )
                        Surface(
                            shape = RoundedCornerShape(8.dp),
                            color = MaterialTheme.colorScheme.surface
                        ) {
                            Text(
                                text = "Akash Hub Tracker",
                                fontSize = 11.sp,
                                fontWeight = FontWeight.SemiBold,
                                color = MaterialTheme.colorScheme.primary,
                                modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                            )
                        }
                    }
                    Spacer(modifier = Modifier.height(6.dp))
                    Text(
                        text = "Track your online application status, download computerized acknowledgement receipts, and follow up directly on WhatsApp.",
                        fontSize = 12.sp,
                        color = MaterialTheme.colorScheme.onPrimaryContainer.copy(alpha = 0.85f),
                        lineHeight = 16.sp
                    )
                }
            }
        }

        // Search Input
        item {
            OutlinedTextField(
                value = searchQuery,
                onValueChange = onSearchQueryChange,
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("tracker_search_input"),
                placeholder = { Text("Search by App ID (e.g. AKN-2026-8941) or Name") },
                leadingIcon = { Icon(Icons.Default.Search, contentDescription = "Search") },
                trailingIcon = {
                    if (searchQuery.isNotEmpty()) {
                        IconButton(onClick = { onSearchQueryChange("") }) {
                            Icon(Icons.Default.Close, contentDescription = "Clear")
                        }
                    }
                },
                singleLine = true,
                shape = RoundedCornerShape(14.dp)
            )
        }

        // Section Toggle: Applications vs Print Orders
        item {
            TabRow(
                selectedTabIndex = selectedSection,
                containerColor = Color.Transparent,
                divider = {}
            ) {
                Tab(
                    selected = selectedSection == 0,
                    onClick = { selectedSection = 0 },
                    text = {
                        Text(
                            text = "Govt & e-Services (${filteredApplications.size})",
                            fontSize = 13.sp,
                            fontWeight = if (selectedSection == 0) FontWeight.Bold else FontWeight.Normal
                        )
                    }
                )
                Tab(
                    selected = selectedSection == 1,
                    onClick = { selectedSection = 1 },
                    text = {
                        Text(
                            text = "Print & Xerox (${filteredPrintOrders.size})",
                            fontSize = 13.sp,
                            fontWeight = if (selectedSection == 1) FontWeight.Bold else FontWeight.Normal
                        )
                    }
                )
            }
        }

        if (selectedSection == 0) {
            if (filteredApplications.isEmpty()) {
                item {
                    EmptyTrackerCard(
                        title = "No Applications Found",
                        subtitle = "Submit an e-Service request or PAN/Voter/ADRE form to track here.",
                        buttonText = "Explore Services",
                        onAction = onBookNewService
                    )
                }
            } else {
                items(filteredApplications) { app ->
                    ApplicationTrackerCard(
                        app = app,
                        onViewReceipt = { onViewReceipt(app) },
                        onWhatsAppFollowUp = {
                            ContactHelper.openWhatsApp(
                                context,
                                "Hello Akash Internet Hub, I want to check status of Application ID: ${app.id} (${app.serviceTitle}) for ${app.applicantName}."
                            )
                        }
                    )
                }
            }
        } else {
            if (filteredPrintOrders.isEmpty()) {
                item {
                    EmptyTrackerCard(
                        title = "No Print Orders Found",
                        subtitle = "Book your document Xerox, photo print or PVC smart card printing online.",
                        buttonText = "Order Print / Xerox",
                        onAction = onBookNewPrint
                    )
                }
            } else {
                items(filteredPrintOrders) { order ->
                    PrintOrderCard(
                        order = order,
                        onWhatsAppFollowUp = {
                            ContactHelper.openWhatsApp(
                                context,
                                "Hello Akash Internet Hub, checking status of Print Order #${order.id} for ${order.customerName}."
                            )
                        }
                    )
                }
            }
        }
    }
}

@Composable
fun ApplicationTrackerCard(
    app: ServiceApplication,
    onViewReceipt: () -> Unit,
    onWhatsAppFollowUp: () -> Unit,
    modifier: Modifier = Modifier
) {
    Card(
        modifier = modifier
            .fillMaxWidth()
            .testTag("app_tracker_card_${app.id}"),
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
    ) {
        Column(modifier = Modifier.padding(16.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column {
                    Text(
                        text = app.id,
                        fontSize = 15.sp,
                        fontWeight = FontWeight.ExtraBold,
                        color = MaterialTheme.colorScheme.primary
                    )
                    Text(
                        text = app.dateSubmitted,
                        fontSize = 11.sp,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }

                Surface(
                    shape = RoundedCornerShape(8.dp),
                    color = when (app.status) {
                        ApplicationStatus.COMPLETED_READY -> AkinGreenSuccess.copy(alpha = 0.2f)
                        ApplicationStatus.PROCESSING_AT_HUB -> MaterialTheme.colorScheme.primaryContainer
                        ApplicationStatus.DOCUMENT_VERIFIED -> MaterialTheme.colorScheme.secondaryContainer
                        ApplicationStatus.SUBMITTED -> MaterialTheme.colorScheme.surfaceVariant
                        ApplicationStatus.ACTION_REQUIRED -> MaterialTheme.colorScheme.errorContainer
                    }
                ) {
                    Text(
                        text = app.status.title,
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold,
                        color = when (app.status) {
                            ApplicationStatus.COMPLETED_READY -> Color(0xFF047857)
                            ApplicationStatus.PROCESSING_AT_HUB -> MaterialTheme.colorScheme.primary
                            ApplicationStatus.DOCUMENT_VERIFIED -> MaterialTheme.colorScheme.onSecondaryContainer
                            ApplicationStatus.SUBMITTED -> MaterialTheme.colorScheme.onSurfaceVariant
                            ApplicationStatus.ACTION_REQUIRED -> MaterialTheme.colorScheme.error
                        },
                        modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                    )
                }
            }

            Spacer(modifier = Modifier.height(10.dp))

            Text(
                text = app.serviceTitle,
                fontSize = 16.sp,
                fontWeight = FontWeight.Bold,
                color = MaterialTheme.colorScheme.onSurface
            )

            Text(
                text = "Applicant: ${app.applicantName} • ${app.phone}",
                fontSize = 12.sp,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )

            Spacer(modifier = Modifier.height(12.dp))

            // Step Progress Indicator
            StatusProgressStepper(currentStep = app.status.stepNumber)

            Spacer(modifier = Modifier.height(10.dp))

            if (app.remark.isNotBlank()) {
                Surface(
                    shape = RoundedCornerShape(8.dp),
                    color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Row(
                        modifier = Modifier.padding(8.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Icon(
                            imageVector = Icons.Default.Info,
                            contentDescription = "Remark",
                            tint = MaterialTheme.colorScheme.primary,
                            modifier = Modifier.size(16.dp)
                        )
                        Spacer(modifier = Modifier.width(6.dp))
                        Text(
                            text = app.remark,
                            fontSize = 11.sp,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                }
                Spacer(modifier = Modifier.height(10.dp))
            }

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                OutlinedButton(
                    onClick = onWhatsAppFollowUp,
                    modifier = Modifier
                        .weight(1f)
                        .height(36.dp)
                        .testTag("tracker_whatsapp_btn_${app.id}"),
                    shape = RoundedCornerShape(8.dp)
                ) {
                    Icon(
                        imageVector = Icons.Default.Chat,
                        contentDescription = "Chat",
                        modifier = Modifier.size(14.dp)
                    )
                    Spacer(modifier = Modifier.width(4.dp))
                    Text("Chat Support", fontSize = 11.sp)
                }

                Button(
                    onClick = onViewReceipt,
                    modifier = Modifier
                        .weight(1.2f)
                        .height(36.dp)
                        .testTag("tracker_receipt_btn_${app.id}"),
                    shape = RoundedCornerShape(8.dp)
                ) {
                    Icon(
                        imageVector = Icons.Default.ReceiptLong,
                        contentDescription = "Receipt",
                        modifier = Modifier.size(14.dp)
                    )
                    Spacer(modifier = Modifier.width(4.dp))
                    Text("View Slip / Receipt", fontSize = 11.sp, fontWeight = FontWeight.Bold)
                }
            }
        }
    }
}

@Composable
fun StatusProgressStepper(currentStep: Int, modifier: Modifier = Modifier) {
    val steps = listOf("Received", "Verified", "Processing", "Ready")

    Row(
        modifier = modifier.fillMaxWidth(),
        verticalAlignment = Alignment.CenterVertically
    ) {
        steps.forEachIndexed { index, stepLabel ->
            val stepNum = index + 1
            val isDone = stepNum <= currentStep
            val isCurrent = stepNum == currentStep

            Column(
                horizontalAlignment = Alignment.CenterHorizontally,
                modifier = Modifier.weight(1f)
            ) {
                Box(
                    modifier = Modifier
                        .size(22.dp)
                        .background(
                            if (isDone) AkinGreenSuccess else MaterialTheme.colorScheme.surfaceVariant,
                            CircleShape
                        ),
                    contentAlignment = Alignment.Center
                ) {
                    if (isDone) {
                        Icon(
                            imageVector = Icons.Default.Check,
                            contentDescription = "Done",
                            tint = Color.White,
                            modifier = Modifier.size(14.dp)
                        )
                    } else {
                        Text(
                            text = "$stepNum",
                            fontSize = 10.sp,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                }
                Spacer(modifier = Modifier.height(2.dp))
                Text(
                    text = stepLabel,
                    fontSize = 9.sp,
                    fontWeight = if (isCurrent) FontWeight.Bold else FontWeight.Normal,
                    color = if (isDone) MaterialTheme.colorScheme.onSurface else MaterialTheme.colorScheme.outline
                )
            }

            if (index < steps.size - 1) {
                Box(
                    modifier = Modifier
                        .weight(0.5f)
                        .height(2.dp)
                        .background(
                            if (stepNum < currentStep) AkinGreenSuccess else MaterialTheme.colorScheme.surfaceVariant
                        )
                )
            }
        }
    }
}

@Composable
fun PrintOrderCard(
    order: PrintOrder,
    onWhatsAppFollowUp: () -> Unit,
    modifier: Modifier = Modifier
) {
    Card(
        modifier = modifier
            .fillMaxWidth()
            .testTag("print_order_card_${order.id}"),
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
    ) {
        Column(modifier = Modifier.padding(16.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column {
                    Text(
                        text = "#${order.id}",
                        fontSize = 15.sp,
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.primary
                    )
                    Text(
                        text = order.orderDate,
                        fontSize = 11.sp,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }

                Surface(
                    shape = RoundedCornerShape(8.dp),
                    color = MaterialTheme.colorScheme.secondaryContainer
                ) {
                    Text(
                        text = order.status,
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.onSecondaryContainer,
                        modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                    )
                }
            }

            Spacer(modifier = Modifier.height(8.dp))

            Text(
                text = order.title,
                fontSize = 15.sp,
                fontWeight = FontWeight.Bold
            )

            Text(
                text = "${order.printType} • ${order.pages} Pages × ${order.copies} Copies ${if (order.isLaminated) "• Glossy Laminated" else ""}",
                fontSize = 12.sp,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )

            Spacer(modifier = Modifier.height(10.dp))

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = "Total Amount: ₹${"%.2f".format(order.totalCost)}",
                    fontSize = 14.sp,
                    fontWeight = FontWeight.ExtraBold,
                    color = MaterialTheme.colorScheme.primary
                )

                OutlinedButton(
                    onClick = onWhatsAppFollowUp,
                    modifier = Modifier.height(34.dp),
                    shape = RoundedCornerShape(8.dp)
                ) {
                    Icon(
                        imageVector = Icons.Default.Chat,
                        contentDescription = "WhatsApp",
                        modifier = Modifier.size(14.dp)
                    )
                    Spacer(modifier = Modifier.width(4.dp))
                    Text("Pickup Inquiry", fontSize = 11.sp)
                }
            }
        }
    }
}

@Composable
fun EmptyTrackerCard(
    title: String,
    subtitle: String,
    buttonText: String,
    onAction: () -> Unit,
    modifier: Modifier = Modifier
) {
    Card(
        modifier = modifier
            .fillMaxWidth()
            .padding(vertical = 12.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f)),
        shape = RoundedCornerShape(16.dp)
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(24.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Icon(
                imageVector = Icons.Default.AssignmentLate,
                contentDescription = "Empty",
                tint = MaterialTheme.colorScheme.outline,
                modifier = Modifier.size(48.dp)
            )
            Spacer(modifier = Modifier.height(10.dp))
            Text(
                text = title,
                fontSize = 15.sp,
                fontWeight = FontWeight.Bold
            )
            Spacer(modifier = Modifier.height(4.dp))
            Text(
                text = subtitle,
                fontSize = 12.sp,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
            Spacer(modifier = Modifier.height(14.dp))
            Button(
                onClick = onAction,
                shape = RoundedCornerShape(10.dp)
            ) {
                Text(text = buttonText, fontSize = 12.sp)
            }
        }
    }
}
