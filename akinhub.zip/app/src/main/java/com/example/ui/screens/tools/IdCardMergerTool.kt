package com.example.ui.screens.tools

import android.content.Context
import android.net.Uri
import android.widget.Toast
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.*
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import coil.compose.AsyncImage
import com.example.ui.theme.AkinAmberAccent
import com.example.ui.theme.AkinGreenSuccess
import com.example.ui.theme.AkinNavyDark

@Composable
fun IdCardMergerTool(
    isPaid: Boolean = false,
    onTriggerPayment: (toolName: String) -> Unit,
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    var idCardType by remember { mutableStateOf("Aadhaar Card") } // "Aadhaar Card", "Voter ID Card", "PAN Card", "Driving License", "Ration / Smart ID"
    var frontPhotoUri by remember { mutableStateOf<Uri?>(null) }
    var backPhotoUri by remember { mutableStateOf<Uri?>(null) }

    val frontPicker = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.GetContent()
    ) { uri: Uri? ->
        if (uri != null) {
            frontPhotoUri = uri
            Toast.makeText(context, "📸 Front Side ID Uploaded!", Toast.LENGTH_SHORT).show()
        }
    }

    val backPicker = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.GetContent()
    ) { uri: Uri? ->
        if (uri != null) {
            backPhotoUri = uri
            Toast.makeText(context, "📸 Back Side ID Uploaded!", Toast.LENGTH_SHORT).show()
        }
    }

    val idTypes = listOf("Aadhaar Card", "Voter ID Card", "PAN Card", "Driving License", "Ration / Smart ID")

    // Automatic layout rule: Voter ID = Vertical Top-Bottom, Aadhaar Card = Horizontal Side-by-Side
    val isVerticalLayout = idCardType == "Voter ID Card"

    Card(
        modifier = modifier
            .fillMaxWidth()
            .testTag("id_card_merger_card"),
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
    ) {
        Column(modifier = Modifier.padding(16.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column {
                    Text(
                        text = "AI Smart ID Card 1-Page Layout",
                        fontSize = 15.sp,
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.onSurface
                    )
                    Text(
                        text = "Upload Front & Back • Auto-fit Aadhaar (Horizontal) & Voter ID (Vertical)",
                        fontSize = 11.sp,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
                Surface(
                    shape = RoundedCornerShape(8.dp),
                    color = if (isPaid) AkinGreenSuccess.copy(alpha = 0.15f) else AkinAmberAccent.copy(alpha = 0.2f)
                ) {
                    Text(
                        text = if (isPaid) "✨ HD UNLOCKED" else "AUTO ALIGN",
                        fontSize = 10.sp,
                        fontWeight = FontWeight.Bold,
                        color = if (isPaid) AkinGreenSuccess else Color(0xFFB45309),
                        modifier = Modifier.padding(horizontal = 8.dp, vertical = 3.dp)
                    )
                }
            }

            Spacer(modifier = Modifier.height(14.dp))

            // Select ID Card Type
            Text("Select Document Type:", fontSize = 12.sp, fontWeight = FontWeight.SemiBold)
            Spacer(modifier = Modifier.height(6.dp))
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(6.dp)
            ) {
                idTypes.take(3).forEach { t ->
                    val isSel = idCardType == t
                    Surface(
                        shape = RoundedCornerShape(8.dp),
                        color = if (isSel) MaterialTheme.colorScheme.primaryContainer else MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f),
                        modifier = Modifier
                            .weight(1f)
                            .clickable { idCardType = t }
                    ) {
                        Text(
                            text = t.replace(" Card", ""),
                            fontSize = 11.sp,
                            fontWeight = if (isSel) FontWeight.Bold else FontWeight.Normal,
                            textAlign = TextAlign.Center,
                            modifier = Modifier.padding(vertical = 6.dp)
                        )
                    }
                }
            }
            Spacer(modifier = Modifier.height(6.dp))
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(6.dp)
            ) {
                idTypes.drop(3).forEach { t ->
                    val isSel = idCardType == t
                    Surface(
                        shape = RoundedCornerShape(8.dp),
                        color = if (isSel) MaterialTheme.colorScheme.primaryContainer else MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f),
                        modifier = Modifier
                            .weight(1f)
                            .clickable { idCardType = t }
                    ) {
                        Text(
                            text = t,
                            fontSize = 11.sp,
                            fontWeight = if (isSel) FontWeight.Bold else FontWeight.Normal,
                            textAlign = TextAlign.Center,
                            modifier = Modifier.padding(vertical = 6.dp)
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.height(12.dp))

            // Layout rule explanation indicator
            Surface(
                shape = RoundedCornerShape(8.dp),
                color = MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.35f),
                modifier = Modifier.fillMaxWidth()
            ) {
                Row(
                    modifier = Modifier.padding(8.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Icon(
                        imageVector = if (isVerticalLayout) Icons.Default.ViewStream else Icons.Default.ViewColumn,
                        contentDescription = "Layout",
                        tint = MaterialTheme.colorScheme.primary,
                        modifier = Modifier.size(18.dp)
                    )
                    Spacer(modifier = Modifier.width(6.dp))
                    Text(
                        text = if (isVerticalLayout)
                            "📌 Voter ID Card Layout: Top & Bottom (Vertical) on 1 page"
                        else
                            "📌 $idCardType Layout: Side by Side (Horizontal) on 1 page",
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.onPrimaryContainer
                    )
                }
            }

            Spacer(modifier = Modifier.height(12.dp))

            // Front & Back Upload Browse Buttons with Live Thumbnails
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                // Front Side Card
                Surface(
                    shape = RoundedCornerShape(10.dp),
                    color = if (frontPhotoUri != null) AkinGreenSuccess.copy(alpha = 0.1f) else Color(0xFFF1F5F9),
                    border = CardDefaults.outlinedCardBorder(),
                    modifier = Modifier
                        .weight(1f)
                        .clickable { frontPicker.launch("image/*") }
                ) {
                    Column(
                        modifier = Modifier.padding(10.dp),
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        if (frontPhotoUri != null) {
                            AsyncImage(
                                model = frontPhotoUri,
                                contentDescription = "Front Preview",
                                contentScale = ContentScale.Crop,
                                modifier = Modifier
                                    .size(width = 64.dp, height = 40.dp)
                                    .clip(RoundedCornerShape(4.dp))
                                    .border(1.dp, AkinGreenSuccess, RoundedCornerShape(4.dp))
                            )
                        } else {
                            Icon(Icons.Default.CreditCard, contentDescription = "Front", tint = AkinNavyDark, modifier = Modifier.size(24.dp))
                        }
                        Spacer(modifier = Modifier.height(4.dp))
                        Text("1. FRONT SIDE", fontSize = 10.sp, fontWeight = FontWeight.Bold)
                        Button(
                            onClick = { frontPicker.launch("image/*") },
                            contentPadding = PaddingValues(horizontal = 6.dp, vertical = 2.dp),
                            shape = RoundedCornerShape(6.dp),
                            colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.primary),
                            modifier = Modifier.height(26.dp)
                        ) {
                            Text(if (frontPhotoUri != null) "✓ Badlein" else "📁 Browse Front", fontSize = 9.sp)
                        }
                    }
                }

                // Back Side Card
                Surface(
                    shape = RoundedCornerShape(10.dp),
                    color = if (backPhotoUri != null) AkinGreenSuccess.copy(alpha = 0.1f) else Color(0xFFF1F5F9),
                    border = CardDefaults.outlinedCardBorder(),
                    modifier = Modifier
                        .weight(1f)
                        .clickable { backPicker.launch("image/*") }
                ) {
                    Column(
                        modifier = Modifier.padding(10.dp),
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        if (backPhotoUri != null) {
                            AsyncImage(
                                model = backPhotoUri,
                                contentDescription = "Back Preview",
                                contentScale = ContentScale.Crop,
                                modifier = Modifier
                                    .size(width = 64.dp, height = 40.dp)
                                    .clip(RoundedCornerShape(4.dp))
                                    .border(1.dp, AkinGreenSuccess, RoundedCornerShape(4.dp))
                            )
                        } else {
                            Icon(Icons.Default.QrCodeScanner, contentDescription = "Back", tint = AkinNavyDark, modifier = Modifier.size(24.dp))
                        }
                        Spacer(modifier = Modifier.height(4.dp))
                        Text("2. BACK SIDE", fontSize = 10.sp, fontWeight = FontWeight.Bold)
                        Button(
                            onClick = { backPicker.launch("image/*") },
                            contentPadding = PaddingValues(horizontal = 6.dp, vertical = 2.dp),
                            shape = RoundedCornerShape(6.dp),
                            colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.primary),
                            modifier = Modifier.height(26.dp)
                        ) {
                            Text(if (backPhotoUri != null) "✓ Badlein" else "📁 Browse Back", fontSize = 9.sp)
                        }
                    }
                }
            }

            Spacer(modifier = Modifier.height(14.dp))

            // Merged Single Page Sheet Preview (Vertical for Voter ID vs Horizontal for Aadhaar)
            Text("Single Page Print Layout Live Preview (A4 Page):", fontSize = 12.sp, fontWeight = FontWeight.SemiBold)
            Spacer(modifier = Modifier.height(6.dp))

            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(290.dp)
                    .background(Color(0xFFE2E8F0), RoundedCornerShape(12.dp))
                    .border(1.dp, Color(0xFFCBD5E1), RoundedCornerShape(12.dp)),
                contentAlignment = Alignment.Center
            ) {
                // A4 Paper representation (Ratio ~ 1 : 1.414)
                Card(
                    modifier = Modifier
                        .width(190.dp)
                        .height(268.dp),
                    colors = CardDefaults.cardColors(containerColor = Color.White),
                    shape = RoundedCornerShape(4.dp),
                    elevation = CardDefaults.cardElevation(defaultElevation = 4.dp)
                ) {
                    Column(
                        modifier = Modifier
                            .fillMaxSize()
                            .padding(8.dp),
                        horizontalAlignment = Alignment.CenterHorizontally,
                        verticalArrangement = Arrangement.Top
                    ) {
                        Text(
                            text = "AKASH INTERNET HUB • $idCardType A4 PRINT",
                            fontSize = 7.sp,
                            fontWeight = FontWeight.Bold,
                            color = AkinNavyDark
                        )

                        Spacer(modifier = Modifier.height(10.dp))

                        if (isVerticalLayout) {
                            // VOTER ID (ASSAM e-EPIC): VERTICAL FRONT & BACK SIDE-BY-SIDE AT TOP OF A4
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceEvenly,
                                verticalAlignment = Alignment.Top
                            ) {
                                // Front Vertical Mini Card (54mm x 86mm ratio) with RED CUTTING BORDER
                                Surface(
                                    modifier = Modifier
                                        .width(78.dp)
                                        .height(124.dp)
                                        .border(1.5.dp, Color(0xFFDC2626), RoundedCornerShape(2.dp)),
                                    color = Color(0xFFF8FAFC)
                                ) {
                                    if (frontPhotoUri != null) {
                                        AsyncImage(
                                            model = frontPhotoUri,
                                            contentDescription = "Front Vertical",
                                            contentScale = ContentScale.Crop,
                                            modifier = Modifier.fillMaxSize()
                                        )
                                    } else {
                                        Column(
                                            modifier = Modifier
                                                .fillMaxSize()
                                                .padding(3.dp),
                                            horizontalAlignment = Alignment.CenterHorizontally
                                        ) {
                                            Text(
                                                text = "ELECTION COMMISSION\nOF INDIA",
                                                fontSize = 5.sp,
                                                fontWeight = FontWeight.Bold,
                                                color = Color(0xFF1E3A8A),
                                                textAlign = TextAlign.Center,
                                                lineHeight = 6.sp
                                            )
                                            Spacer(modifier = Modifier.height(4.dp))
                                            Box(
                                                modifier = Modifier
                                                    .size(width = 24.dp, height = 30.dp)
                                                    .background(Color(0xFFCBD5E1), RoundedCornerShape(2.dp))
                                                    .border(0.5.dp, Color.Gray),
                                                contentAlignment = Alignment.Center
                                            ) {
                                                Icon(Icons.Default.Face, contentDescription = "Photo", modifier = Modifier.size(18.dp), tint = Color(0xFF475569))
                                            }
                                            Spacer(modifier = Modifier.height(4.dp))
                                            Text("EPIC NO: ABC1234567", fontSize = 5.sp, fontWeight = FontWeight.ExtraBold, color = Color.Black)
                                            Text("NAME: ELECTOR NAME", fontSize = 4.5.sp, color = Color.DarkGray)
                                            Text("FATHER: FATHER NAME", fontSize = 4.5.sp, color = Color.DarkGray)
                                            Text("GENDER / DOB", fontSize = 4.5.sp, color = Color.DarkGray)
                                            Spacer(modifier = Modifier.weight(1f))
                                            Surface(
                                                color = Color(0xFFDC2626).copy(alpha = 0.15f),
                                                shape = RoundedCornerShape(2.dp)
                                            ) {
                                                Text("FRONT (VERTICAL)", fontSize = 4.5.sp, fontWeight = FontWeight.Bold, color = Color(0xFFDC2626), modifier = Modifier.padding(1.dp))
                                            }
                                        }
                                    }
                                }

                                // Back Vertical Mini Card (54mm x 86mm ratio) with RED CUTTING BORDER
                                Surface(
                                    modifier = Modifier
                                        .width(78.dp)
                                        .height(124.dp)
                                        .border(1.5.dp, Color(0xFFDC2626), RoundedCornerShape(2.dp)),
                                    color = Color(0xFFF8FAFC)
                                ) {
                                    if (backPhotoUri != null) {
                                        AsyncImage(
                                            model = backPhotoUri,
                                            contentDescription = "Back Vertical",
                                            contentScale = ContentScale.Crop,
                                            modifier = Modifier.fillMaxSize()
                                        )
                                    } else {
                                        Column(
                                            modifier = Modifier
                                                .fillMaxSize()
                                                .padding(3.dp),
                                            horizontalAlignment = Alignment.CenterHorizontally
                                        ) {
                                            Text(
                                                text = "ELECTORAL DETAILS\n& ADDRESS",
                                                fontSize = 5.sp,
                                                fontWeight = FontWeight.Bold,
                                                color = Color(0xFF1E3A8A),
                                                textAlign = TextAlign.Center,
                                                lineHeight = 6.sp
                                            )
                                            Spacer(modifier = Modifier.height(4.dp))
                                            Icon(Icons.Default.QrCode2, contentDescription = "QR", modifier = Modifier.size(24.dp), tint = Color.Black)
                                            Spacer(modifier = Modifier.height(2.dp))
                                            Text("Address: Geramari, Dhubri", fontSize = 4.5.sp, color = Color.DarkGray)
                                            Text("Assam - 783339", fontSize = 4.5.sp, color = Color.DarkGray)
                                            Text("Assembly: Dhubri LAC", fontSize = 4.5.sp, fontWeight = FontWeight.Bold, color = Color.Black)
                                            Text("Part No: 12 • Polling Stn", fontSize = 4.5.sp, color = Color.DarkGray)
                                            Spacer(modifier = Modifier.weight(1f))
                                            Surface(
                                                color = Color(0xFFDC2626).copy(alpha = 0.15f),
                                                shape = RoundedCornerShape(2.dp)
                                            ) {
                                                Text("BACK (VERTICAL)", fontSize = 4.5.sp, fontWeight = FontWeight.Bold, color = Color(0xFFDC2626), modifier = Modifier.padding(1.dp))
                                            }
                                        }
                                    }
                                }
                            }
                        } else {
                            // AADHAAR CARD / OTHER: HORIZONTAL SIDE-BY-SIDE LAYOUT (86mm x 54mm)
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceEvenly,
                                verticalAlignment = Alignment.Top
                            ) {
                                // Front Mini Card
                                Surface(
                                    modifier = Modifier
                                        .width(82.dp)
                                        .height(52.dp)
                                        .border(1.dp, Color(0xFFDC2626), RoundedCornerShape(2.dp)),
                                    color = Color(0xFFF8FAFC)
                                ) {
                                    if (frontPhotoUri != null) {
                                        AsyncImage(
                                            model = frontPhotoUri,
                                            contentDescription = "Front Horizontal",
                                            contentScale = ContentScale.Crop,
                                            modifier = Modifier.fillMaxSize()
                                        )
                                    } else {
                                        Column(modifier = Modifier.padding(3.dp)) {
                                            Text("GOVT OF INDIA", fontSize = 5.sp, fontWeight = FontWeight.Bold, color = Color(0xFF1E3A8A))
                                            Spacer(modifier = Modifier.height(2.dp))
                                            Row(verticalAlignment = Alignment.CenterVertically) {
                                                Box(modifier = Modifier.size(width = 14.dp, height = 18.dp).background(Color.LightGray))
                                                Spacer(modifier = Modifier.width(3.dp))
                                                Column {
                                                    Text("CITIZEN NAME", fontSize = 4.5.sp, fontWeight = FontWeight.SemiBold)
                                                    Text("DOB: 01/01/2000", fontSize = 4.sp)
                                                    Text("XXXX XXXX 1234", fontSize = 4.5.sp, fontWeight = FontWeight.Bold)
                                                }
                                            }
                                        }
                                    }
                                }

                                // Back Mini Card
                                Surface(
                                    modifier = Modifier
                                        .width(82.dp)
                                        .height(52.dp)
                                        .border(1.dp, Color(0xFFDC2626), RoundedCornerShape(2.dp)),
                                    color = Color(0xFFF8FAFC)
                                ) {
                                    if (backPhotoUri != null) {
                                        AsyncImage(
                                            model = backPhotoUri,
                                            contentDescription = "Back Horizontal",
                                            contentScale = ContentScale.Crop,
                                            modifier = Modifier.fillMaxSize()
                                        )
                                    } else {
                                        Column(modifier = Modifier.padding(3.dp)) {
                                            Text("ADDRESS / DETAILS", fontSize = 5.sp, fontWeight = FontWeight.Bold, color = Color(0xFF1E3A8A))
                                            Spacer(modifier = Modifier.height(2.dp))
                                            Row(verticalAlignment = Alignment.CenterVertically) {
                                                Column(modifier = Modifier.weight(1f)) {
                                                    Text("Geramari, Dhubri", fontSize = 4.sp)
                                                    Text("Assam - 783339", fontSize = 4.sp)
                                                }
                                                Icon(Icons.Default.QrCode, contentDescription = "QR", modifier = Modifier.size(16.dp), tint = Color.Black)
                                            }
                                        }
                                    }
                                }
                            }
                        }

                        Spacer(modifier = Modifier.weight(1f))
                        Text(
                            text = "✂️ Red Border Cut Line • Standard Assam Print Alignment",
                            fontSize = 5.5.sp,
                            color = Color(0xFFDC2626),
                            fontWeight = FontWeight.SemiBold
                        )
                        Spacer(modifier = Modifier.height(2.dp))
                        Text(
                            text = "Remaining A4 Page space left blank for easy scissors / guillotine cutting",
                            fontSize = 4.5.sp,
                            color = Color.Gray,
                            textAlign = TextAlign.Center
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.height(16.dp))

            // Standard Dual Download Buttons (Free vs ₹10 Paid)
            DualDownloadActionButtons(
                toolTitle = "$idCardType Single Page Merged Print",
                isPaid = isPaid,
                onFreeDownload = {
                    Toast.makeText(context, "📥 Saved with watermark: 'Downloaded From Akash Internet Hub'", Toast.LENGTH_LONG).show()
                },
                onPayDownload = {
                    onTriggerPayment("$idCardType Single Page HD Print (No Watermark)")
                },
                onUnlockedDownload = {
                    Toast.makeText(context, "📥 Clean HD 1-Page $idCardType Merged Print Ready Downloaded!", Toast.LENGTH_LONG).show()
                }
            )
        }
    }
}
