package com.example.ui.screens.tools

import android.content.Context
import android.widget.Toast
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.theme.AkinGreenSuccess
import com.example.ui.theme.AkinNavyDark

@Composable
fun IdCardMergerTool(
    isPaid: Boolean = false,
    onTriggerPayment: (toolName: String) -> Unit,
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    var idCardType by remember { mutableStateOf("Aadhaar Card") }
    var layoutStyle by remember { mutableStateOf("Side by Side (Single Page)") }
    var hasFrontUploaded by remember { mutableStateOf(true) }
    var hasBackUploaded by remember { mutableStateOf(true) }

    val idTypes = listOf("Aadhaar Card", "Voter ID Card", "PAN Card", "Driving License", "Student / College ID")
    val layouts = listOf("Side by Side (Single Page)", "Stacked Vertical (Print Cut)")

    Card(
        modifier = modifier
            .fillMaxWidth()
            .testTag("id_card_merger_card"),
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
    ) {
        Column(modifier = Modifier.padding(16.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column {
                    Text(
                        text = "AI Smart ID Card 1-Page Layout",
                        fontSize = 15.sp,
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.onSurface
                    )
                    Text(
                        text = "Auto AI detect & align Front + Back on single A4 print page",
                        fontSize = 11.sp,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
                Surface(
                    shape = RoundedCornerShape(8.dp),
                    color = AkinGreenSuccess.copy(alpha = 0.15f)
                ) {
                    Text(
                        text = "Auto Align",
                        fontSize = 10.sp,
                        fontWeight = FontWeight.Bold,
                        color = AkinGreenSuccess,
                        modifier = Modifier.padding(horizontal = 8.dp, vertical = 3.dp)
                    )
                }
            }

            Spacer(modifier = Modifier.height(14.dp))

            // Select ID Card Type
            Text("Select Document Type:", fontSize = 12.sp, fontWeight = FontWeight.SemiBold)
            Spacer(modifier = Modifier.height(4.dp))
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(6.dp)
            ) {
                idTypes.take(3).forEach { t ->
                    val isSel = idCardType == t
                    Surface(
                        shape = RoundedCornerShape(8.dp),
                        color = if (isSel) MaterialTheme.colorScheme.primaryContainer else MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f),
                        modifier = Modifier
                            .weight(1f)
                            .clickable { idCardType = t }
                    ) {
                        Text(
                            text = t.replace(" Card", ""),
                            fontSize = 11.sp,
                            fontWeight = if (isSel) FontWeight.Bold else FontWeight.Normal,
                            textAlign = TextAlign.Center,
                            modifier = Modifier.padding(vertical = 6.dp)
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.height(12.dp))

            // Front & Back Upload Status Box
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                Surface(
                    shape = RoundedCornerShape(10.dp),
                    color = Color(0xFFF1F5F9),
                    border = CardDefaults.outlinedCardBorder(),
                    modifier = Modifier
                        .weight(1f)
                        .clickable {
                            hasFrontUploaded = true
                            Toast.makeText(context, "Front Side Uploaded & AI Detected!", Toast.LENGTH_SHORT).show()
                        }
                ) {
                    Column(
                        modifier = Modifier.padding(10.dp),
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        Icon(Icons.Default.CreditCard, contentDescription = "Front", tint = AkinNavyDark, modifier = Modifier.size(20.dp))
                        Spacer(modifier = Modifier.height(4.dp))
                        Text("1. FRONT SIDE", fontSize = 10.sp, fontWeight = FontWeight.Bold)
                        Text("✓ AI Auto-Cropped", fontSize = 9.sp, color = AkinGreenSuccess)
                    }
                }

                Surface(
                    shape = RoundedCornerShape(10.dp),
                    color = Color(0xFFF1F5F9),
                    border = CardDefaults.outlinedCardBorder(),
                    modifier = Modifier
                        .weight(1f)
                        .clickable {
                            hasBackUploaded = true
                            Toast.makeText(context, "Back Side Uploaded & AI Detected!", Toast.LENGTH_SHORT).show()
                        }
                ) {
                    Column(
                        modifier = Modifier.padding(10.dp),
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        Icon(Icons.Default.QrCodeScanner, contentDescription = "Back", tint = AkinNavyDark, modifier = Modifier.size(20.dp))
                        Spacer(modifier = Modifier.height(4.dp))
                        Text("2. BACK SIDE", fontSize = 10.sp, fontWeight = FontWeight.Bold)
                        Text("✓ AI Auto-Cropped", fontSize = 9.sp, color = AkinGreenSuccess)
                    }
                }
            }

            Spacer(modifier = Modifier.height(14.dp))

            // Merged Single Page Sheet Preview
            Text("Single Page Print Layout Preview:", fontSize = 12.sp, fontWeight = FontWeight.SemiBold)
            Spacer(modifier = Modifier.height(6.dp))
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(180.dp)
                    .background(Color(0xFFE2E8F0), RoundedCornerShape(12.dp))
                    .border(1.dp, Color(0xFFCBD5E1), RoundedCornerShape(12.dp)),
                contentAlignment = Alignment.Center
            ) {
                Card(
                    modifier = Modifier
                        .width(220.dp)
                        .height(150.dp),
                    colors = CardDefaults.cardColors(containerColor = Color.White),
                    shape = RoundedCornerShape(4.dp),
                    elevation = CardDefaults.cardElevation(defaultElevation = 3.dp)
                ) {
                    Column(
                        modifier = Modifier
                            .fillMaxSize()
                            .padding(8.dp),
                        horizontalAlignment = Alignment.CenterHorizontally,
                        verticalArrangement = Arrangement.SpaceEvenly
                    ) {
                        Text(
                            text = "AKASH INTERNET HUB • $idCardType A4 PRINT",
                            fontSize = 8.sp,
                            fontWeight = FontWeight.Bold,
                            color = AkinNavyDark
                        )

                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceEvenly
                        ) {
                            // Front Mini Card
                            Surface(
                                modifier = Modifier
                                    .width(90.dp)
                                    .height(58.dp)
                                    .border(1.dp, Color.Gray, RoundedCornerShape(4.dp)),
                                color = Color(0xFFF8FAFC)
                            ) {
                                Column(modifier = Modifier.padding(4.dp)) {
                                    Text("GOVT OF INDIA", fontSize = 6.sp, fontWeight = FontWeight.Bold, color = Color(0xFF1E3A8A))
                                    Spacer(modifier = Modifier.height(2.dp))
                                    Row(verticalAlignment = Alignment.CenterVertically) {
                                        Box(
                                            modifier = Modifier
                                                .size(width = 16.dp, height = 20.dp)
                                                .background(Color.LightGray)
                                        )
                                        Spacer(modifier = Modifier.width(4.dp))
                                        Column {
                                            Text("NAME / CITIZEN", fontSize = 6.sp, fontWeight = FontWeight.SemiBold)
                                            Text("DOB: 01/01/2000", fontSize = 5.sp)
                                            Text("XXXX XXXX 1234", fontSize = 6.sp, fontWeight = FontWeight.Bold)
                                        }
                                    }
                                }
                            }

                            // Back Mini Card
                            Surface(
                                modifier = Modifier
                                    .width(90.dp)
                                    .height(58.dp)
                                    .border(1.dp, Color.Gray, RoundedCornerShape(4.dp)),
                                color = Color(0xFFF8FAFC)
                            ) {
                                Column(modifier = Modifier.padding(4.dp)) {
                                    Text("ADDRESS / DETAILS", fontSize = 6.sp, fontWeight = FontWeight.Bold, color = Color(0xFF1E3A8A))
                                    Spacer(modifier = Modifier.height(2.dp))
                                    Row(verticalAlignment = Alignment.CenterVertically) {
                                        Column(modifier = Modifier.weight(1f)) {
                                            Text("Geramari, Dhubri", fontSize = 5.sp)
                                            Text("Assam - 783339", fontSize = 5.sp)
                                        }
                                        Icon(Icons.Default.QrCode, contentDescription = "QR", modifier = Modifier.size(18.dp), tint = Color.Black)
                                    }
                                }
                            }
                        }

                        Text("✂️ Standard Cutting Guide & Single Page Margin Applied", fontSize = 7.sp, color = Color.Gray)
                    }
                }
            }

            Spacer(modifier = Modifier.height(16.dp))

            // Standard Dual Download Buttons (Free vs ₹10 Paid)
            DualDownloadActionButtons(
                toolTitle = "$idCardType Single Page Merged Print",
                isPaid = isPaid,
                onFreeDownload = {
                    Toast.makeText(context, "Saved with watermark: 'Downloaded From Akash Internet Hub'", Toast.LENGTH_LONG).show()
                },
                onPayDownload = {
                    onTriggerPayment("$idCardType Single Page HD Print (No Watermark)")
                },
                onUnlockedDownload = {
                    Toast.makeText(context, "📥 Clean HD 1-Page $idCardType Merged Print Ready Downloaded!", Toast.LENGTH_LONG).show()
                }
            )
        }
    }
}
