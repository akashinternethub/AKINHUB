package com.example.ui.components

import android.content.Context
import android.content.Intent
import android.net.Uri
import android.widget.Toast
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material.icons.outlined.*
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.NoticeAlert
import com.example.ui.theme.*
import java.util.Calendar
import java.util.TimeZone

object ContactHelper {
    const val PHONE_NUMBER = "+917002134700"
    const val WHATSAPP_NUMBER = "917002134700"
    const val HUB_EMAIL = "akashinternethub@gmail.com"
    const val HUB_WEBSITE = "https://www.akinhub.in"
    const val AI_HOME_URL = "https://www.akinhub.in/AI-HOME"
    const val AUTOMATIC_PRINT_URL = "https://akinhub.pagekite.me/"
    const val EXACT_LOCATION = "Akash Internet Hub, Near Saba Petrol Pump, Geramari, Dhubri, Assam - 783339"
    const val MAPS_QUERY = "Akash Internet Hub, Near Saba Petrol Pump, Geramari, Dhubri, Assam 783339"

    /**
     * Print service operates strictly from 10:30 AM to 06:30 PM (18:30) in Indian Standard Time (IST)
     */
    fun isPrintHoursActive(): Boolean {
        val cal = Calendar.getInstance(TimeZone.getTimeZone("Asia/Kolkata"))
        val totalMinutes = cal.get(Calendar.HOUR_OF_DAY) * 60 + cal.get(Calendar.MINUTE)
        val openMinutes = 10 * 60 + 30   // 630 minutes (10:30 AM)
        val closeMinutes = 18 * 60 + 30  // 1110 minutes (06:30 PM)
        return totalMinutes in openMinutes..closeMinutes
    }

    fun openDialer(context: Context) {
        try {
            val intent = Intent(Intent.ACTION_DIAL, Uri.parse("tel:$PHONE_NUMBER"))
            context.startActivity(intent)
        } catch (e: Exception) {
            Toast.makeText(context, "Call: $PHONE_NUMBER", Toast.LENGTH_SHORT).show()
        }
    }

    fun openWhatsApp(context: Context, prefilledMessage: String = "Hello Akash Internet Hub, I need assistance regarding online services.") {
        try {
            val url = "https://api.whatsapp.com/send?phone=$WHATSAPP_NUMBER&text=${Uri.encode(prefilledMessage)}"
            val intent = Intent(Intent.ACTION_VIEW, Uri.parse(url))
            context.startActivity(intent)
        } catch (e: Exception) {
            Toast.makeText(context, "WhatsApp: $PHONE_NUMBER", Toast.LENGTH_SHORT).show()
        }
    }

    fun openEmail(context: Context, subject: String = "Inquiry - AKINHUB Digital Services") {
        try {
            val intent = Intent(Intent.ACTION_SENDTO).apply {
                data = Uri.parse("mailto:$HUB_EMAIL")
                putExtra(Intent.EXTRA_SUBJECT, subject)
            }
            context.startActivity(intent)
        } catch (e: Exception) {
            Toast.makeText(context, "Email: $HUB_EMAIL", Toast.LENGTH_SHORT).show()
        }
    }

    fun openWebsite(context: Context, url: String = HUB_WEBSITE) {
        try {
            val validUrl = if (!url.startsWith("http://") && !url.startsWith("https://")) "https://$url" else url
            val intent = Intent(Intent.ACTION_VIEW, Uri.parse(validUrl))
            context.startActivity(intent)
        } catch (e: Exception) {
            Toast.makeText(context, "Website: $url", Toast.LENGTH_SHORT).show()
        }
    }

    fun openAiHomeWebsite(context: Context) {
        openWebsite(context, AI_HOME_URL)
    }

    fun openAutomaticPrint(context: Context) {
        openWebsite(context, AUTOMATIC_PRINT_URL)
    }

    fun openMaps(context: Context) {
        try {
            val uri = Uri.parse("https://www.google.com/maps/search/?api=1&query=${Uri.encode(MAPS_QUERY)}")
            val intent = Intent(Intent.ACTION_VIEW, uri)
            context.startActivity(intent)
        } catch (e: Exception) {
            Toast.makeText(context, EXACT_LOCATION, Toast.LENGTH_LONG).show()
        }
    }
}

@Composable
fun AkinhubHeroHeader(
    onBookPrintClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    val isOpenNow = ContactHelper.isPrintHoursActive()

    Card(
        modifier = modifier
            .fillMaxWidth()
            .testTag("hero_header_card"),
        shape = RoundedCornerShape(20.dp),
        colors = CardDefaults.cardColors(containerColor = Color.Transparent),
        elevation = CardDefaults.cardElevation(defaultElevation = 3.dp)
    ) {
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .background(
                    Brush.linearGradient(
                        listOf(AkinNavyDark, AkinNavy, AkinBlueDark)
                    )
                )
                .padding(18.dp)
        ) {
            Column {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Surface(
                            shape = CircleShape,
                            color = AkinAmberAccent,
                            modifier = Modifier.size(44.dp)
                        ) {
                            Box(contentAlignment = Alignment.Center) {
                                Text(
                                    text = "A",
                                    fontSize = 24.sp,
                                    fontWeight = FontWeight.Black,
                                    color = AkinNavyDark
                                )
                            }
                        }
                        Spacer(modifier = Modifier.width(12.dp))
                        Column {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Text(
                                    text = "AKINHUB",
                                    fontSize = 22.sp,
                                    fontWeight = FontWeight.ExtraBold,
                                    color = Color.White
                                )
                                Spacer(modifier = Modifier.width(8.dp))
                                Surface(
                                    shape = RoundedCornerShape(6.dp),
                                    color = if (isOpenNow) AkinGreenSuccess.copy(alpha = 0.25f) else MaterialTheme.colorScheme.error.copy(alpha = 0.25f),
                                    border = CardDefaults.outlinedCardBorder().copy(
                                        brush = Brush.linearGradient(
                                            if (isOpenNow) listOf(AkinGreenSuccess, AkinGreenSuccess) else listOf(MaterialTheme.colorScheme.error, MaterialTheme.colorScheme.error)
                                        )
                                    )
                                ) {
                                    Row(
                                        modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp),
                                        verticalAlignment = Alignment.CenterVertically
                                    ) {
                                        Box(
                                            modifier = Modifier
                                                .size(6.dp)
                                                .background(if (isOpenNow) AkinGreenSuccess else MaterialTheme.colorScheme.error, CircleShape)
                                        )
                                        Spacer(modifier = Modifier.width(4.dp))
                                        Text(
                                            text = if (isOpenNow) "OPEN (10:30-6:30)" else "CLOSED NOW",
                                            fontSize = 10.sp,
                                            fontWeight = FontWeight.Bold,
                                            color = if (isOpenNow) AkinGreenSuccess else Color.White
                                        )
                                    }
                                }
                            }
                            Text(
                                text = "Akash Internet Hub • Geramari, Dhubri",
                                fontSize = 12.sp,
                                color = AkinBlueLight
                            )
                        }
                    }

                    Surface(
                        shape = RoundedCornerShape(12.dp),
                        color = Color.White.copy(alpha = 0.15f)
                    ) {
                        Row(
                            modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Icon(
                                imageVector = Icons.Filled.Star,
                                contentDescription = "Rating",
                                tint = AkinAmberAccent,
                                modifier = Modifier.size(16.dp)
                            )
                            Spacer(modifier = Modifier.width(3.dp))
                            Text(
                                text = "5.0",
                                fontSize = 13.sp,
                                fontWeight = FontWeight.Bold,
                                color = Color.White
                            )
                        }
                    }
                }

                Spacer(modifier = Modifier.height(10.dp))

                // Exact Address Pill
                Surface(
                    shape = RoundedCornerShape(8.dp),
                    color = Color.White.copy(alpha = 0.10f),
                    modifier = Modifier
                        .fillMaxWidth()
                        .clickable { ContactHelper.openMaps(context) }
                ) {
                    Row(
                        modifier = Modifier.padding(horizontal = 8.dp, vertical = 6.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Icon(
                            imageVector = Icons.Filled.LocationOn,
                            contentDescription = "Exact Location",
                            tint = AkinAmberAccent,
                            modifier = Modifier.size(14.dp)
                        )
                        Spacer(modifier = Modifier.width(6.dp))
                        Text(
                            text = ContactHelper.EXACT_LOCATION,
                            fontSize = 11.sp,
                            color = Color.White.copy(alpha = 0.95f),
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis,
                            modifier = Modifier.weight(1f)
                        )
                    }
                }

                Spacer(modifier = Modifier.height(12.dp))

                // Direct Automatic Print Button (Connected to PC Server)
                Button(
                    onClick = onBookPrintClick,
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(46.dp)
                        .testTag("hero_auto_print_button"),
                    shape = RoundedCornerShape(12.dp),
                    colors = ButtonDefaults.buttonColors(
                        containerColor = AkinAmberAccent,
                        contentColor = AkinNavyDark
                    ),
                    elevation = ButtonDefaults.buttonElevation(defaultElevation = 4.dp)
                ) {
                    Icon(
                        imageVector = Icons.Filled.Bolt,
                        contentDescription = "Auto Print",
                        tint = AkinNavyDark,
                        modifier = Modifier.size(20.dp)
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        text = "CLICK KARO PRINT AUTOMATIC HO JAYEGA ⚡",
                        fontSize = 12.sp,
                        fontWeight = FontWeight.Black,
                        color = AkinNavyDark,
                        maxLines = 1
                    )
                }

                Spacer(modifier = Modifier.height(10.dp))

                // Direct AI-HOME Webpage Button
                OutlinedButton(
                    onClick = { ContactHelper.openAiHomeWebsite(context) },
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(40.dp)
                        .testTag("hero_ai_home_button"),
                    shape = RoundedCornerShape(10.dp),
                    colors = ButtonDefaults.outlinedButtonColors(
                        contentColor = Color.White
                    ),
                    border = CardDefaults.outlinedCardBorder().copy(
                        brush = Brush.linearGradient(listOf(Color.White.copy(alpha = 0.6f), Color.White.copy(alpha = 0.6f)))
                    )
                ) {
                    Icon(
                        imageVector = Icons.Filled.Language,
                        contentDescription = "AI-HOME",
                        tint = AkinBlueLight,
                        modifier = Modifier.size(16.dp)
                    )
                    Spacer(modifier = Modifier.width(6.dp))
                    Text(
                        text = "Visit Official AI-HOME (akinhub.in/AI-HOME)",
                        fontSize = 12.sp,
                        fontWeight = FontWeight.Bold,
                        color = Color.White
                    )
                }

                Spacer(modifier = Modifier.height(12.dp))

                // Quick Action Buttons
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Button(
                        onClick = { ContactHelper.openWhatsApp(context) },
                        modifier = Modifier
                            .weight(1.2f)
                            .height(40.dp)
                            .testTag("hero_whatsapp_button"),
                        shape = RoundedCornerShape(10.dp),
                        colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF25D366))
                    ) {
                        Icon(
                            imageVector = Icons.Filled.Chat,
                            contentDescription = "WhatsApp",
                            tint = Color.White,
                            modifier = Modifier.size(16.dp)
                        )
                        Spacer(modifier = Modifier.width(6.dp))
                        Text(
                            text = "WhatsApp",
                            fontSize = 12.sp,
                            fontWeight = FontWeight.Bold,
                            color = Color.White
                        )
                    }

                    FilledTonalButton(
                        onClick = { ContactHelper.openDialer(context) },
                        modifier = Modifier
                            .weight(1f)
                            .height(40.dp)
                            .testTag("hero_call_button"),
                        shape = RoundedCornerShape(10.dp),
                        colors = ButtonDefaults.filledTonalButtonColors(
                            containerColor = Color.White.copy(alpha = 0.2f),
                            contentColor = Color.White
                        )
                    ) {
                        Icon(
                            imageVector = Icons.Filled.Call,
                            contentDescription = "Call Akash Hub",
                            tint = Color.White,
                            modifier = Modifier.size(16.dp)
                        )
                        Spacer(modifier = Modifier.width(4.dp))
                        Text(
                            text = "Call",
                            fontSize = 12.sp,
                            fontWeight = FontWeight.Bold,
                            color = Color.White
                        )
                    }

                    FilledIconButton(
                        onClick = { ContactHelper.openMaps(context) },
                        modifier = Modifier
                            .size(40.dp)
                            .testTag("hero_directions_button"),
                        shape = RoundedCornerShape(10.dp),
                        colors = IconButtonDefaults.filledIconButtonColors(
                            containerColor = Color.White.copy(alpha = 0.2f),
                            contentColor = Color.White
                        )
                    ) {
                        Icon(
                            imageVector = Icons.Filled.Navigation,
                            contentDescription = "Directions",
                            modifier = Modifier.size(18.dp)
                        )
                    }
                }
            }
        }
    }
}

@Composable
fun NoticeBannerStrip(
    notices: List<NoticeAlert>,
    onNoticeClick: (NoticeAlert) -> Unit,
    modifier: Modifier = Modifier
) {
    if (notices.isEmpty()) return

    val notice = notices.firstOrNull() ?: return

    Surface(
        modifier = modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(12.dp))
            .clickable { onNoticeClick(notice) }
            .testTag("notice_ticker_banner"),
        color = MaterialTheme.colorScheme.secondaryContainer.copy(alpha = 0.7f),
        border = CardDefaults.outlinedCardBorder()
    ) {
        Row(
            modifier = Modifier.padding(horizontal = 12.dp, vertical = 10.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Surface(
                shape = CircleShape,
                color = AkinAmberAccent,
                modifier = Modifier.size(24.dp)
            ) {
                Box(contentAlignment = Alignment.Center) {
                    Icon(
                        imageVector = Icons.Filled.Campaign,
                        contentDescription = "Alert",
                        tint = AkinNavyDark,
                        modifier = Modifier.size(16.dp)
                    )
                }
            }
            Spacer(modifier = Modifier.width(10.dp))
            Column(modifier = Modifier.weight(1f)) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text(
                        text = "LATEST NOTICE",
                        fontSize = 10.sp,
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.primary
                    )
                    Spacer(modifier = Modifier.width(6.dp))
                    Text(
                        text = "• ${notice.tag}",
                        fontSize = 10.sp,
                        fontWeight = FontWeight.SemiBold,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
                Text(
                    text = notice.title,
                    fontSize = 12.sp,
                    fontWeight = FontWeight.Medium,
                    color = MaterialTheme.colorScheme.onSurface,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                )
            }
            Icon(
                imageVector = Icons.Filled.ChevronRight,
                contentDescription = "View Details",
                tint = MaterialTheme.colorScheme.onSurfaceVariant,
                modifier = Modifier.size(18.dp)
            )
        }
    }
}
