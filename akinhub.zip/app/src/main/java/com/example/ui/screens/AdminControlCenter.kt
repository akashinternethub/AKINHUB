package com.example.ui.screens

import android.widget.Toast
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.*
import androidx.compose.material.icons.outlined.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.input.VisualTransformation
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import com.example.data.model.*
import com.example.ui.dialogs.ReceiptViewerDialog
import com.example.ui.theme.APP_THEME_PALETTES
import com.example.ui.theme.AppThemeOption
import com.example.ui.theme.AkinAmberAccent
import com.example.ui.theme.AkinGreenSuccess
import com.example.ui.theme.AkinNavyDark
import com.example.ui.viewmodel.AkinhubViewModel

enum class AdminTab(val title: String, val icon: androidx.compose.ui.graphics.vector.ImageVector) {
    SERVICES("Services", Icons.Default.MiscellaneousServices),
    TRACKER("Tracker & Receipts", Icons.Default.ReceiptLong),
    SHOP_AND_ALERTS("Shop Status & Alerts", Icons.Default.Campaign),
    PAYMENT_AND_APP("Razorpay & Receipts", Icons.Default.Payments),
    THEME_AND_BUTTONS("🎨 Theme & Buttons", Icons.Default.Palette),
    HUB_AND_SECURITY("Hub & Security", Icons.Default.Security)
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun AdminControlCenterScreen(
    viewModel: AkinhubViewModel,
    onExitAdmin: () -> Unit,
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    val uiState by viewModel.uiState.collectAsState()
    val hubInfo by viewModel.hubInfo.collectAsState()

    var selectedAdminTab by remember { mutableStateOf(AdminTab.SERVICES) }

    // Dialog state for Service edit / add
    var serviceToEdit by remember { mutableStateOf<HubService?>(null) }
    var showAddServiceDialog by remember { mutableStateOf(false) }

    // Dialog state for Tracker status & receipt edit
    var appToUpdate by remember { mutableStateOf<ServiceApplication?>(null) }
    var appToEditReceipt by remember { mutableStateOf<ServiceApplication?>(null) }
    var appToViewReceipt by remember { mutableStateOf<ServiceApplication?>(null) }
    var showAddManualAppDialog by remember { mutableStateOf(false) }

    // Dialog state for Notice add / edit
    var noticeToEdit by remember { mutableStateOf<NoticeAlert?>(null) }
    var showAddNoticeDialog by remember { mutableStateOf(false) }

    // Popup preview state
    var showBroadcastPopupPreview by remember { mutableStateOf(false) }

    Scaffold(
        modifier = modifier
            .fillMaxSize()
            .testTag("admin_control_center_scaffold"),
        topBar = {
            TopAppBar(
                title = {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Surface(
                            shape = RoundedCornerShape(8.dp),
                            color = Color(0xFFEF4444)
                        ) {
                            Text(
                                text = "ADMIN",
                                fontSize = 11.sp,
                                fontWeight = FontWeight.Black,
                                color = Color.White,
                                modifier = Modifier.padding(horizontal = 6.dp, vertical = 3.dp)
                            )
                        }
                        Spacer(modifier = Modifier.width(8.dp))
                        Column {
                            Text(
                                text = "Akash Hub Master Admin",
                                fontSize = 16.sp,
                                fontWeight = FontWeight.Bold
                            )
                            Text(
                                text = "Live Control Center & App Editor",
                                fontSize = 11.sp,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                    }
                },
                navigationIcon = {
                    IconButton(onClick = onExitAdmin) {
                        Icon(
                            imageVector = Icons.AutoMirrored.Filled.ArrowBack,
                            contentDescription = "Back to App"
                        )
                    }
                },
                actions = {
                    Button(
                        onClick = onExitAdmin,
                        colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.primary),
                        shape = RoundedCornerShape(20.dp),
                        modifier = Modifier.padding(end = 8.dp)
                    ) {
                        Icon(
                            imageVector = Icons.Default.Visibility,
                            contentDescription = null,
                            modifier = Modifier.size(16.dp)
                        )
                        Spacer(modifier = Modifier.width(4.dp))
                        Text("Customer View", fontSize = 11.sp)
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = MaterialTheme.colorScheme.surface
                )
            )
        }
    ) { innerPadding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
        ) {
            // Admin Navigation Tabs
            ScrollableTabRow(
                selectedTabIndex = selectedAdminTab.ordinal,
                edgePadding = 12.dp,
                modifier = Modifier.fillMaxWidth()
            ) {
                AdminTab.values().forEach { tab ->
                    Tab(
                        selected = selectedAdminTab == tab,
                        onClick = { selectedAdminTab = tab },
                        text = {
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(6.dp)
                            ) {
                                Icon(
                                    imageVector = tab.icon,
                                    contentDescription = null,
                                    modifier = Modifier.size(16.dp)
                                )
                                Text(
                                    tab.title,
                                    fontSize = 12.sp,
                                    fontWeight = if (selectedAdminTab == tab) FontWeight.Bold else FontWeight.Normal
                                )
                            }
                        }
                    )
                }
            }

            // Tab Content
            when (selectedAdminTab) {
                AdminTab.SERVICES -> {
                    AdminServicesSection(
                        services = uiState.services,
                        onAddService = { showAddServiceDialog = true },
                        onEditService = { serviceToEdit = it },
                        onDeleteService = {
                            viewModel.deleteService(it.id)
                            Toast.makeText(context, "Deleted: ${it.title}", Toast.LENGTH_SHORT).show()
                        }
                    )
                }
                AdminTab.TRACKER -> {
                    AdminTrackerSection(
                        applications = uiState.applications,
                        printOrders = uiState.printOrders,
                        onAddManualApp = { showAddManualAppDialog = true },
                        onUpdateStatus = { appToUpdate = it },
                        onEditReceipt = { appToEditReceipt = it },
                        onViewReceipt = { appToViewReceipt = it },
                        onDeleteApp = {
                            viewModel.deleteApplication(it.id)
                            Toast.makeText(context, "Deleted application #${it.id}", Toast.LENGTH_SHORT).show()
                        },
                        onUpdatePrintOrder = { orderId, newStatus ->
                            viewModel.updatePrintOrderStatus(orderId, newStatus)
                            Toast.makeText(context, "Print order updated: $newStatus", Toast.LENGTH_SHORT).show()
                        }
                    )
                }
                AdminTab.SHOP_AND_ALERTS -> {
                    AdminShopAndAlertsSection(
                        hubInfo = hubInfo,
                        onSaveShopStatus = { isOpen, message ->
                            viewModel.toggleShopStatus(isOpen, message)
                            Toast.makeText(
                                context,
                                if (isOpen) "✅ Dukan OPEN set live!" else "⛔ Dukan CLOSED set live!",
                                Toast.LENGTH_SHORT
                            ).show()
                        },
                        onSaveBroadcastPopup = { show, title, message, isEmergency ->
                            viewModel.setBroadcastPopup(show, title, message, isEmergency)
                            Toast.makeText(
                                context,
                                if (show) "📢 Popup broadcast broadcasted to homepage!" else "Popup broadcast turned OFF",
                                Toast.LENGTH_SHORT
                            ).show()
                        },
                        onPreviewPopup = {
                            showBroadcastPopupPreview = true
                        }
                    )
                }
                AdminTab.PAYMENT_AND_APP -> {
                    AdminPaymentAndAppSettingsSection(
                        hubInfo = hubInfo,
                        onSaveRazorpay = { buttonId, upiId ->
                            viewModel.updateRazorpayConfig(buttonId, upiId)
                            Toast.makeText(context, "💳 Razorpay Gateway ID & UPI updated!", Toast.LENGTH_SHORT).show()
                        },
                        onSaveReceiptSettings = { header, subHeader, address, email, note, seal ->
                            viewModel.updateReceiptConfig(header, subHeader, address, email, note, seal)
                            Toast.makeText(context, "🧾 Receipt Template updated live!", Toast.LENGTH_SHORT).show()
                        }
                    )
                }
                AdminTab.THEME_AND_BUTTONS -> {
                    AdminThemeAndButtonsSection(
                        hubInfo = hubInfo,
                        onSaveButtonConfig = { payText, freeText, unlockedText, watermark, hdPrice ->
                            viewModel.updateButtonAndPriceConfig(payText, freeText, unlockedText, watermark, hdPrice)
                            Toast.makeText(context, "✨ Download button labels & pricing updated live!", Toast.LENGTH_SHORT).show()
                        },
                        onSelectTheme = { themeId ->
                            viewModel.updateAppThemeColor(themeId)
                            Toast.makeText(context, "🎨 App theme color updated live!", Toast.LENGTH_SHORT).show()
                        }
                    )
                }
                AdminTab.HUB_AND_SECURITY -> {
                    AdminHubAndSecuritySection(
                        hubInfo = hubInfo,
                        notices = uiState.notices,
                        onSaveHubInfo = {
                            viewModel.updateHubInfo(it)
                            Toast.makeText(context, "Hub details updated live!", Toast.LENGTH_SHORT).show()
                        },
                        onUpdateCredentials = { user, pass ->
                            viewModel.updateAdminCredentials(user, pass)
                            Toast.makeText(context, "🔐 Admin Username & Password updated successfully!", Toast.LENGTH_LONG).show()
                        },
                        onAddNotice = { showAddNoticeDialog = true },
                        onEditNotice = { noticeToEdit = it },
                        onDeleteNotice = {
                            viewModel.deleteNotice(it.id)
                            Toast.makeText(context, "Notice deleted", Toast.LENGTH_SHORT).show()
                        }
                    )
                }
            }
        }
    }

    // Add / Edit Service Dialog
    if (showAddServiceDialog || serviceToEdit != null) {
        val initial = serviceToEdit
        EditServiceDialog(
            initialService = initial,
            onDismiss = {
                showAddServiceDialog = false
                serviceToEdit = null
            },
            onSave = { updatedService ->
                viewModel.addOrUpdateService(updatedService)
                showAddServiceDialog = false
                serviceToEdit = null
                Toast.makeText(context, "Service saved: ${updatedService.title}", Toast.LENGTH_SHORT).show()
            }
        )
    }

    // Update Application Status Dialog
    appToUpdate?.let { app ->
        UpdateAppStatusDialog(
            app = app,
            onDismiss = { appToUpdate = null },
            onSave = { newStatus, remark, trackingRef ->
                viewModel.updateApplicationStatus(app.id, newStatus, remark, trackingRef)
                appToUpdate = null
                Toast.makeText(context, "Status updated to ${newStatus.title}", Toast.LENGTH_SHORT).show()
            }
        )
    }

    // Edit Receipt Details for Application
    appToEditReceipt?.let { app ->
        EditReceiptDetailsDialog(
            app = app,
            onDismiss = { appToEditReceipt = null },
            onSave = { updatedApp ->
                viewModel.addOrUpdateApplication(updatedApp)
                appToEditReceipt = null
                Toast.makeText(context, "Receipt details updated for #${updatedApp.id}", Toast.LENGTH_SHORT).show()
            }
        )
    }

    // View Receipt Dialog
    appToViewReceipt?.let { app ->
        ReceiptViewerDialog(
            application = app,
            hubInfo = hubInfo,
            onDismiss = { appToViewReceipt = null }
        )
    }

    // Add Manual Application Dialog
    if (showAddManualAppDialog) {
        AddManualAppDialog(
            onDismiss = { showAddManualAppDialog = false },
            onSave = { newApp ->
                viewModel.addOrUpdateApplication(newApp)
                showAddManualAppDialog = false
                Toast.makeText(context, "Tracking application #${newApp.id} created!", Toast.LENGTH_SHORT).show()
            }
        )
    }

    // Add / Edit Notice Dialog
    if (showAddNoticeDialog || noticeToEdit != null) {
        val initial = noticeToEdit
        EditNoticeDialog(
            initialNotice = initial,
            onDismiss = {
                showAddNoticeDialog = false
                noticeToEdit = null
            },
            onSave = { updatedNotice ->
                viewModel.addOrUpdateNotice(updatedNotice)
                showAddNoticeDialog = false
                noticeToEdit = null
                Toast.makeText(context, "Notice updated!", Toast.LENGTH_SHORT).show()
            }
        )
    }

    // Broadcast Popup Preview Dialog
    if (showBroadcastPopupPreview) {
        Dialog(onDismissRequest = { showBroadcastPopupPreview = false }) {
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(16.dp),
                shape = RoundedCornerShape(20.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
            ) {
                Column(
                    modifier = Modifier.padding(20.dp),
                    horizontalAlignment = Alignment.CenterHorizontally,
                    verticalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    Surface(
                        shape = CircleShape,
                        color = if (hubInfo.isEmergencyBroadcast) Color(0xFFEF4444) else AkinAmberAccent,
                        modifier = Modifier.size(52.dp)
                    ) {
                        Box(contentAlignment = Alignment.Center) {
                            Icon(
                                imageVector = if (hubInfo.isEmergencyBroadcast) Icons.Default.Warning else Icons.Default.Campaign,
                                contentDescription = null,
                                tint = if (hubInfo.isEmergencyBroadcast) Color.White else AkinNavyDark,
                                modifier = Modifier.size(28.dp)
                            )
                        }
                    }

                    Text(
                        text = hubInfo.popupNotificationTitle.ifBlank { "Important Notice from Akash Hub" },
                        fontSize = 17.sp,
                        fontWeight = FontWeight.Bold,
                        color = if (hubInfo.isEmergencyBroadcast) Color(0xFFEF4444) else MaterialTheme.colorScheme.primary
                    )

                    Text(
                        text = hubInfo.popupNotificationMessage.ifBlank { "No message body written yet." },
                        fontSize = 13.5.sp,
                        color = MaterialTheme.colorScheme.onSurface,
                        lineHeight = 18.sp
                    )

                    Button(
                        onClick = { showBroadcastPopupPreview = false },
                        modifier = Modifier.fillMaxWidth(),
                        shape = RoundedCornerShape(10.dp)
                    ) {
                        Text("Got it / Theek Hai")
                    }
                }
            }
        }
    }
}

// ==================== SECTION 1: SERVICES ====================
@Composable
fun AdminServicesSection(
    services: List<HubService>,
    onAddService: () -> Unit,
    onEditService: (HubService) -> Unit,
    onDeleteService: (HubService) -> Unit
) {
    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .padding(14.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        item {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column {
                    Text(
                        text = "CSC & Govt Services (${services.size})",
                        fontSize = 16.sp,
                        fontWeight = FontWeight.Bold
                    )
                    Text(
                        text = "Edit prices, portal links & documents",
                        fontSize = 11.sp,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }

                Button(
                    onClick = onAddService,
                    shape = RoundedCornerShape(10.dp)
                ) {
                    Icon(imageVector = Icons.Default.Add, contentDescription = null, modifier = Modifier.size(16.dp))
                    Spacer(modifier = Modifier.width(4.dp))
                    Text("Add Service", fontSize = 12.sp)
                }
            }
        }

        items(services) { service ->
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(14.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
            ) {
                Column(modifier = Modifier.padding(14.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = service.title,
                            fontSize = 14.sp,
                            fontWeight = FontWeight.Bold,
                            modifier = Modifier.weight(1f)
                        )
                        Surface(
                            shape = RoundedCornerShape(8.dp),
                            color = MaterialTheme.colorScheme.primaryContainer
                        ) {
                            Text(
                                text = service.totalFee,
                                fontSize = 12.sp,
                                fontWeight = FontWeight.ExtraBold,
                                color = MaterialTheme.colorScheme.primary,
                                modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(4.dp))

                    Text(
                        text = "Govt Fee: ${service.officialGovtFee} | Center Charge: ${service.centerCharge} | Time: ${service.processingTime}",
                        fontSize = 11.sp,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )

                    if (!service.officialPortalUrl.isNullOrBlank()) {
                        Text(
                            text = "🔗 Portal: ${service.officialPortalUrl}",
                            fontSize = 10.5.sp,
                            color = MaterialTheme.colorScheme.primary,
                            maxLines = 1
                        )
                    }

                    Spacer(modifier = Modifier.height(8.dp))

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.End,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        OutlinedButton(
                            onClick = { onEditService(service) },
                            shape = RoundedCornerShape(8.dp),
                            modifier = Modifier.height(34.dp)
                        ) {
                            Icon(imageVector = Icons.Default.Edit, contentDescription = null, modifier = Modifier.size(14.dp))
                            Spacer(modifier = Modifier.width(4.dp))
                            Text("Edit Service", fontSize = 11.sp)
                        }

                        Spacer(modifier = Modifier.width(8.dp))

                        IconButton(
                            onClick = { onDeleteService(service) },
                            modifier = Modifier.size(34.dp)
                        ) {
                            Icon(imageVector = Icons.Default.Delete, contentDescription = "Delete", tint = Color(0xFFEF4444), modifier = Modifier.size(18.dp))
                        }
                    }
                }
            }
        }
    }
}

// ==================== SECTION 2: TRACKER & RECEIPTS ====================
@Composable
fun AdminTrackerSection(
    applications: List<ServiceApplication>,
    printOrders: List<PrintOrder>,
    onAddManualApp: () -> Unit,
    onUpdateStatus: (ServiceApplication) -> Unit,
    onEditReceipt: (ServiceApplication) -> Unit,
    onViewReceipt: (ServiceApplication) -> Unit,
    onDeleteApp: (ServiceApplication) -> Unit,
    onUpdatePrintOrder: (String, String) -> Unit
) {
    var selectedTrackerTab by remember { mutableStateOf(0) }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(14.dp)
    ) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column {
                Text(
                    text = "Application & Receipt Control",
                    fontSize = 16.sp,
                    fontWeight = FontWeight.Bold
                )
                Text(
                    text = "Update status steps, ack numbers & edit receipt slips",
                    fontSize = 11.sp,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }

            Button(
                onClick = onAddManualApp,
                shape = RoundedCornerShape(10.dp)
            ) {
                Icon(imageVector = Icons.Default.Add, contentDescription = null, modifier = Modifier.size(16.dp))
                Spacer(modifier = Modifier.width(4.dp))
                Text("New Record", fontSize = 12.sp)
            }
        }

        Spacer(modifier = Modifier.height(10.dp))

        TabRow(selectedTabIndex = selectedTrackerTab) {
            Tab(
                selected = selectedTrackerTab == 0,
                onClick = { selectedTrackerTab = 0 },
                text = { Text("Govt Applications (${applications.size})", fontSize = 12.sp) }
            )
            Tab(
                selected = selectedTrackerTab == 1,
                onClick = { selectedTrackerTab = 1 },
                text = { Text("Print Orders (${printOrders.size})", fontSize = 12.sp) }
            )
        }

        Spacer(modifier = Modifier.height(10.dp))

        if (selectedTrackerTab == 0) {
            LazyColumn(
                verticalArrangement = Arrangement.spacedBy(10.dp),
                modifier = Modifier.fillMaxSize()
            ) {
                items(applications) { app ->
                    Card(
                        modifier = Modifier.fillMaxWidth(),
                        shape = RoundedCornerShape(14.dp),
                        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
                    ) {
                        Column(modifier = Modifier.padding(14.dp)) {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Column {
                                    Text(
                                        text = "${app.id} (${app.trackingRefNumber})",
                                        fontSize = 13.sp,
                                        fontWeight = FontWeight.ExtraBold,
                                        color = MaterialTheme.colorScheme.primary
                                    )
                                    Text(
                                        text = "${app.dateSubmitted} • Fee: ${app.totalPaid}",
                                        fontSize = 10.5.sp,
                                        color = MaterialTheme.colorScheme.onSurfaceVariant
                                    )
                                }

                                Surface(
                                    shape = RoundedCornerShape(8.dp),
                                    color = when (app.status) {
                                        ApplicationStatus.COMPLETED_READY -> AkinGreenSuccess.copy(alpha = 0.2f)
                                        ApplicationStatus.PROCESSING_AT_HUB -> MaterialTheme.colorScheme.primaryContainer
                                        ApplicationStatus.DOCUMENT_VERIFIED -> MaterialTheme.colorScheme.secondaryContainer
                                        ApplicationStatus.SUBMITTED -> MaterialTheme.colorScheme.surfaceVariant
                                        ApplicationStatus.ACTION_REQUIRED -> MaterialTheme.colorScheme.errorContainer
                                    }
                                ) {
                                    Text(
                                        text = app.status.title,
                                        fontSize = 11.sp,
                                        fontWeight = FontWeight.Bold,
                                        color = when (app.status) {
                                            ApplicationStatus.COMPLETED_READY -> Color(0xFF047857)
                                            ApplicationStatus.PROCESSING_AT_HUB -> MaterialTheme.colorScheme.primary
                                            ApplicationStatus.DOCUMENT_VERIFIED -> MaterialTheme.colorScheme.onSecondaryContainer
                                            ApplicationStatus.SUBMITTED -> MaterialTheme.colorScheme.onSurfaceVariant
                                            ApplicationStatus.ACTION_REQUIRED -> MaterialTheme.colorScheme.error
                                        },
                                        modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                                    )
                                }
                            }

                            Spacer(modifier = Modifier.height(8.dp))

                            Text(
                                text = app.serviceTitle,
                                fontSize = 14.5.sp,
                                fontWeight = FontWeight.Bold
                            )

                            Text(
                                text = "Applicant: ${app.applicantName} • 📞 ${app.phone}",
                                fontSize = 12.sp,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )

                            if (app.remark.isNotBlank()) {
                                Spacer(modifier = Modifier.height(4.dp))
                                Text(
                                    text = "Remark: ${app.remark}",
                                    fontSize = 11.5.sp,
                                    color = MaterialTheme.colorScheme.primary
                                )
                            }

                            Spacer(modifier = Modifier.height(10.dp))

                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.spacedBy(6.dp)
                            ) {
                                Button(
                                    onClick = { onUpdateStatus(app) },
                                    modifier = Modifier.weight(1.2f),
                                    shape = RoundedCornerShape(8.dp)
                                ) {
                                    Icon(imageVector = Icons.Default.CheckCircle, contentDescription = null, modifier = Modifier.size(13.dp))
                                    Spacer(modifier = Modifier.width(3.dp))
                                    Text("Step / Status", fontSize = 11.sp)
                                }

                                OutlinedButton(
                                    onClick = { onEditReceipt(app) },
                                    modifier = Modifier.weight(1.2f),
                                    shape = RoundedCornerShape(8.dp)
                                ) {
                                    Icon(imageVector = Icons.Default.Edit, contentDescription = null, modifier = Modifier.size(13.dp))
                                    Spacer(modifier = Modifier.width(3.dp))
                                    Text("Edit Receipt", fontSize = 11.sp)
                                }

                                IconButton(
                                    onClick = { onViewReceipt(app) },
                                    modifier = Modifier.size(36.dp)
                                ) {
                                    Icon(Icons.Default.ReceiptLong, contentDescription = "View Receipt", tint = MaterialTheme.colorScheme.primary, modifier = Modifier.size(18.dp))
                                }

                                IconButton(
                                    onClick = { onDeleteApp(app) },
                                    modifier = Modifier.size(36.dp)
                                ) {
                                    Icon(imageVector = Icons.Default.Delete, contentDescription = "Delete", tint = Color(0xFFEF4444), modifier = Modifier.size(18.dp))
                                }
                            }
                        }
                    }
                }
            }
        } else {
            LazyColumn(
                verticalArrangement = Arrangement.spacedBy(10.dp),
                modifier = Modifier.fillMaxSize()
            ) {
                items(printOrders) { order ->
                    Card(
                        modifier = Modifier.fillMaxWidth(),
                        shape = RoundedCornerShape(14.dp),
                        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
                    ) {
                        Column(modifier = Modifier.padding(14.dp)) {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween
                            ) {
                                Text("#${order.id} • ${order.title}", fontWeight = FontWeight.Bold, fontSize = 14.sp)
                                Text("₹${"%.2f".format(order.totalCost)}", fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.primary)
                            }
                            Text("Customer: ${order.customerName} (📞 ${order.customerPhone})", fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                            Text("Current Status: ${order.status}", fontSize = 11.5.sp, fontWeight = FontWeight.SemiBold)

                            Spacer(modifier = Modifier.height(8.dp))

                            Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                                Button(
                                    onClick = { onUpdatePrintOrder(order.id, "Printing in Progress") },
                                    modifier = Modifier.weight(1f),
                                    shape = RoundedCornerShape(8.dp)
                                ) {
                                    Text("In Print", fontSize = 10.5.sp)
                                }
                                Button(
                                    onClick = { onUpdatePrintOrder(order.id, "Ready for Counter Pickup") },
                                    modifier = Modifier.weight(1f),
                                    shape = RoundedCornerShape(8.dp)
                                ) {
                                    Text("Ready Pickup", fontSize = 10.5.sp)
                                }
                                OutlinedButton(
                                    onClick = { onUpdatePrintOrder(order.id, "Delivered & Closed") },
                                    modifier = Modifier.weight(1f),
                                    shape = RoundedCornerShape(8.dp)
                                ) {
                                    Text("Delivered", fontSize = 10.5.sp)
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}

// ==================== SECTION 3: SHOP STATUS & POPUP ALERTS ====================
@Composable
fun AdminShopAndAlertsSection(
    hubInfo: HubInfo,
    onSaveShopStatus: (Boolean, String) -> Unit,
    onSaveBroadcastPopup: (Boolean, String, String, Boolean) -> Unit,
    onPreviewPopup: () -> Unit
) {
    var isShopOpen by remember(hubInfo) { mutableStateOf(hubInfo.isShopOpen) }
    var shopClosedMessage by remember(hubInfo) { mutableStateOf(hubInfo.shopClosedMessage) }

    var showPopupNotification by remember(hubInfo) { mutableStateOf(hubInfo.showPopupNotification) }
    var popupTitle by remember(hubInfo) { mutableStateOf(hubInfo.popupNotificationTitle) }
    var popupMessage by remember(hubInfo) { mutableStateOf(hubInfo.popupNotificationMessage) }
    var isEmergencyBroadcast by remember(hubInfo) { mutableStateOf(hubInfo.isEmergencyBroadcast) }

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .padding(14.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        // Shop Status Open / Close Control Card
        item {
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(
                    containerColor = if (isShopOpen) AkinGreenSuccess.copy(alpha = 0.08f) else Color(0xFFEF4444).copy(alpha = 0.08f)
                ),
                border = BorderStroke(1.5.dp, if (isShopOpen) AkinGreenSuccess else Color(0xFFEF4444))
            ) {
                Column(
                    modifier = Modifier.padding(16.dp),
                    verticalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column {
                            Text(
                                text = "🏪 Dukan Status (Open / Close)",
                                fontSize = 16.sp,
                                fontWeight = FontWeight.Bold
                            )
                            Text(
                                text = if (isShopOpen) "Dukan is currently OPEN for print & orders" else "Dukan is CLOSED (Print & orders disabled)",
                                fontSize = 11.5.sp,
                                color = if (isShopOpen) Color(0xFF047857) else Color(0xFFB91C1C),
                                fontWeight = FontWeight.SemiBold
                            )
                        }

                        Switch(
                            checked = isShopOpen,
                            onCheckedChange = { isShopOpen = it }
                        )
                    }

                    OutlinedTextField(
                        value = shopClosedMessage,
                        onValueChange = { shopClosedMessage = it },
                        label = { Text("Shop Closed Message (shown to users)") },
                        modifier = Modifier.fillMaxWidth(),
                        minLines = 2
                    )

                    Button(
                        onClick = { onSaveShopStatus(isShopOpen, shopClosedMessage) },
                        modifier = Modifier.fillMaxWidth(),
                        shape = RoundedCornerShape(10.dp),
                        colors = ButtonDefaults.buttonColors(
                            containerColor = if (isShopOpen) AkinNavyDark else Color(0xFFEF4444)
                        )
                    ) {
                        Icon(imageVector = Icons.Default.Save, contentDescription = null, modifier = Modifier.size(16.dp))
                        Spacer(modifier = Modifier.width(6.dp))
                        Text(if (isShopOpen) "Update Shop Status: OPEN" else "Update Shop Status: CLOSED")
                    }
                }
            }
        }

        // Broadcast Homepage Popup Notification Card
        item {
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
            ) {
                Column(
                    modifier = Modifier.padding(16.dp),
                    verticalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column {
                            Text(
                                text = "📢 Homepage Popup Broadcast",
                                fontSize = 16.sp,
                                fontWeight = FontWeight.Bold
                            )
                            Text(
                                text = "Pops up on user app open when enabled",
                                fontSize = 11.5.sp,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }

                        Switch(
                            checked = showPopupNotification,
                            onCheckedChange = { showPopupNotification = it }
                        )
                    }

                    OutlinedTextField(
                        value = popupTitle,
                        onValueChange = { popupTitle = it },
                        label = { Text("Broadcast Popup Title") },
                        modifier = Modifier.fillMaxWidth()
                    )

                    OutlinedTextField(
                        value = popupMessage,
                        onValueChange = { popupMessage = it },
                        label = { Text("Broadcast Message Body") },
                        placeholder = { Text("e.g. Aaj server maintenance ke karan sham 5 baje tak forms band rahenge...") },
                        modifier = Modifier.fillMaxWidth(),
                        minLines = 3
                    )

                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween,
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Text(
                            text = "Emergency Red Alert Style",
                            fontSize = 13.sp,
                            fontWeight = FontWeight.Medium
                        )
                        Switch(
                            checked = isEmergencyBroadcast,
                            onCheckedChange = { isEmergencyBroadcast = it }
                        )
                    }

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        OutlinedButton(
                            onClick = onPreviewPopup,
                            modifier = Modifier.weight(1f),
                            shape = RoundedCornerShape(10.dp)
                        ) {
                            Icon(Icons.Default.Visibility, contentDescription = null, modifier = Modifier.size(16.dp))
                            Spacer(modifier = Modifier.width(4.dp))
                            Text("Preview Popup", fontSize = 12.sp)
                        }

                        Button(
                            onClick = {
                                onSaveBroadcastPopup(showPopupNotification, popupTitle, popupMessage, isEmergencyBroadcast)
                            },
                            modifier = Modifier.weight(1.3f),
                            shape = RoundedCornerShape(10.dp)
                        ) {
                            Icon(Icons.Default.Campaign, contentDescription = null, modifier = Modifier.size(16.dp))
                            Spacer(modifier = Modifier.width(4.dp))
                            Text("Send / Save Popup", fontSize = 12.sp)
                        }
                    }
                }
            }
        }
    }
}

// ==================== SECTION 4: RAZORPAY & RECEIPT TEMPLATE ====================
@Composable
fun AdminPaymentAndAppSettingsSection(
    hubInfo: HubInfo,
    onSaveRazorpay: (String, String) -> Unit,
    onSaveReceiptSettings: (String, String, String, String, String, String) -> Unit
) {
    var razorpayButtonId by remember(hubInfo) { mutableStateOf(hubInfo.razorpayButtonId) }
    var upiId by remember(hubInfo) { mutableStateOf(hubInfo.upiId) }

    var receiptHeader by remember(hubInfo) { mutableStateOf(hubInfo.receiptHeader) }
    var receiptSubHeader by remember(hubInfo) { mutableStateOf(hubInfo.receiptSubHeader) }
    var receiptAddress by remember(hubInfo) { mutableStateOf(hubInfo.receiptAddress) }
    var receiptEmail by remember(hubInfo) { mutableStateOf(hubInfo.receiptEmail) }
    var receiptNote by remember(hubInfo) { mutableStateOf(hubInfo.receiptCustomNote) }
    var receiptSealText by remember(hubInfo) { mutableStateOf(hubInfo.receiptSealText) }

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .padding(14.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        // Razorpay Gateway Card
        item {
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
            ) {
                Column(
                    modifier = Modifier.padding(16.dp),
                    verticalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    Text(
                        text = "💳 Razorpay Gateway & UPI Setup",
                        fontSize = 16.sp,
                        fontWeight = FontWeight.Bold
                    )
                    Text(
                        text = "Change the live Razorpay button ID & UPI ID across the entire application",
                        fontSize = 11.5.sp,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )

                    OutlinedTextField(
                        value = razorpayButtonId,
                        onValueChange = { razorpayButtonId = it },
                        label = { Text("Razorpay Button ID") },
                        placeholder = { Text("pl_Q3i6h1QvG9uP4v") },
                        modifier = Modifier.fillMaxWidth()
                    )

                    OutlinedTextField(
                        value = upiId,
                        onValueChange = { upiId = it },
                        label = { Text("Hub UPI ID (GPay / PhonePe / Paytm)") },
                        placeholder = { Text("7002134700@okbizaxis") },
                        modifier = Modifier.fillMaxWidth()
                    )

                    Button(
                        onClick = { onSaveRazorpay(razorpayButtonId, upiId) },
                        modifier = Modifier.fillMaxWidth(),
                        shape = RoundedCornerShape(10.dp)
                    ) {
                        Icon(Icons.Default.Save, contentDescription = null, modifier = Modifier.size(16.dp))
                        Spacer(modifier = Modifier.width(6.dp))
                        Text("Save Razorpay & UPI")
                    }
                }
            }
        }

        // Receipt Template Card
        item {
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
            ) {
                Column(
                    modifier = Modifier.padding(16.dp),
                    verticalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    Text(
                        text = "🧾 Acknowledgement Receipt Slip Template",
                        fontSize = 16.sp,
                        fontWeight = FontWeight.Bold
                    )
                    Text(
                        text = "Modify header, address, official seal & notes shown on Tracker receipts",
                        fontSize = 11.5.sp,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )

                    OutlinedTextField(
                        value = receiptHeader,
                        onValueChange = { receiptHeader = it },
                        label = { Text("Receipt Header Title") },
                        modifier = Modifier.fillMaxWidth()
                    )

                    OutlinedTextField(
                        value = receiptSubHeader,
                        onValueChange = { receiptSubHeader = it },
                        label = { Text("Receipt Sub-Header") },
                        modifier = Modifier.fillMaxWidth()
                    )

                    OutlinedTextField(
                        value = receiptAddress,
                        onValueChange = { receiptAddress = it },
                        label = { Text("Address on Receipt") },
                        modifier = Modifier.fillMaxWidth()
                    )

                    OutlinedTextField(
                        value = receiptEmail,
                        onValueChange = { receiptEmail = it },
                        label = { Text("Email on Receipt") },
                        modifier = Modifier.fillMaxWidth()
                    )

                    OutlinedTextField(
                        value = receiptSealText,
                        onValueChange = { receiptSealText = it },
                        label = { Text("Official Seal Text") },
                        modifier = Modifier.fillMaxWidth()
                    )

                    OutlinedTextField(
                        value = receiptNote,
                        onValueChange = { receiptNote = it },
                        label = { Text("Footer Custom Disclaimer / Note") },
                        modifier = Modifier.fillMaxWidth(),
                        minLines = 2
                    )

                    Button(
                        onClick = {
                            onSaveReceiptSettings(
                                receiptHeader,
                                receiptSubHeader,
                                receiptAddress,
                                receiptEmail,
                                receiptNote,
                                receiptSealText
                            )
                        },
                        modifier = Modifier.fillMaxWidth(),
                        shape = RoundedCornerShape(10.dp)
                    ) {
                        Icon(Icons.Default.Save, contentDescription = null, modifier = Modifier.size(16.dp))
                        Spacer(modifier = Modifier.width(6.dp))
                        Text("Save Receipt Template Live")
                    }
                }
            }
        }
    }
}

// ==================== SECTION 5: APP THEME & DOWNLOAD BUTTON CUSTOMIZER ====================
@Composable
fun AdminThemeAndButtonsSection(
    hubInfo: HubInfo,
    onSaveButtonConfig: (String, String, String, String, String) -> Unit,
    onSelectTheme: (String) -> Unit
) {
    var payHdButtonText by remember(hubInfo) { mutableStateOf(hubInfo.payHdButtonText) }
    var freeDownloadButtonText by remember(hubInfo) { mutableStateOf(hubInfo.freeDownloadButtonText) }
    var unlockedButtonText by remember(hubInfo) { mutableStateOf(hubInfo.unlockedButtonText) }
    var watermarkText by remember(hubInfo) { mutableStateOf(hubInfo.watermarkText) }
    var hdPriceText by remember(hubInfo) { mutableStateOf(hubInfo.hdPriceText) }

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .padding(14.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        // Card 1: 1-Click App Theme Color Customizer
        item {
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
            ) {
                Column(
                    modifier = Modifier.padding(16.dp),
                    verticalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Surface(
                            shape = CircleShape,
                            color = MaterialTheme.colorScheme.primaryContainer,
                            modifier = Modifier.size(36.dp)
                        ) {
                            Box(contentAlignment = Alignment.Center) {
                                Icon(
                                    imageVector = Icons.Default.Palette,
                                    contentDescription = "Theme",
                                    tint = MaterialTheme.colorScheme.primary,
                                    modifier = Modifier.size(20.dp)
                                )
                            }
                        }
                        Spacer(modifier = Modifier.width(10.dp))
                        Column {
                            Text(
                                text = "🎨 One-Click App Theme Colors",
                                fontSize = 16.sp,
                                fontWeight = FontWeight.Bold
                            )
                            Text(
                                text = "Instantly change the entire app's look and matching color scheme",
                                fontSize = 11.5.sp,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                    }

                    Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        APP_THEME_PALETTES.forEach { theme ->
                            val isSelected = (hubInfo.appThemeColorId == theme.id)

                            Surface(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .clip(RoundedCornerShape(12.dp))
                                    .border(
                                        width = if (isSelected) 2.5.dp else 1.dp,
                                        color = if (isSelected) theme.primaryColor else Color(0xFFE2E8F0),
                                        shape = RoundedCornerShape(12.dp)
                                    )
                                    .clickable { onSelectTheme(theme.id) },
                                color = if (isSelected) theme.containerColor.copy(alpha = 0.5f) else MaterialTheme.colorScheme.surface
                            ) {
                                Row(
                                    modifier = Modifier.padding(12.dp),
                                    verticalAlignment = Alignment.CenterVertically,
                                    horizontalArrangement = Arrangement.SpaceBetween
                                ) {
                                    Row(
                                        verticalAlignment = Alignment.CenterVertically,
                                        modifier = Modifier.weight(1f)
                                    ) {
                                        // Palette preview color dots
                                        Row(
                                            horizontalArrangement = Arrangement.spacedBy(4.dp),
                                            verticalAlignment = Alignment.CenterVertically
                                        ) {
                                            Surface(shape = CircleShape, color = theme.primaryColor, modifier = Modifier.size(22.dp)) {}
                                            Surface(shape = CircleShape, color = theme.secondaryColor, modifier = Modifier.size(16.dp)) {}
                                            Surface(shape = CircleShape, color = theme.containerColor, modifier = Modifier.size(12.dp)) {}
                                        }

                                        Spacer(modifier = Modifier.width(12.dp))

                                        Column {
                                            Text(
                                                text = theme.name,
                                                fontSize = 13.5.sp,
                                                fontWeight = if (isSelected) FontWeight.ExtraBold else FontWeight.SemiBold,
                                                color = MaterialTheme.colorScheme.onSurface
                                            )
                                            Text(
                                                text = theme.description,
                                                fontSize = 11.sp,
                                                color = MaterialTheme.colorScheme.onSurfaceVariant
                                            )
                                        }
                                    }

                                    if (isSelected) {
                                        Surface(
                                            shape = RoundedCornerShape(8.dp),
                                            color = AkinGreenSuccess
                                        ) {
                                            Row(
                                                modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp),
                                                verticalAlignment = Alignment.CenterVertically
                                            ) {
                                                Icon(Icons.Default.Check, contentDescription = null, tint = Color.White, modifier = Modifier.size(12.dp))
                                                Spacer(modifier = Modifier.width(3.dp))
                                                Text("ACTIVE", fontSize = 9.sp, fontWeight = FontWeight.Bold, color = Color.White)
                                            }
                                        }
                                    } else {
                                        OutlinedButton(
                                            onClick = { onSelectTheme(theme.id) },
                                            modifier = Modifier.height(34.dp),
                                            shape = RoundedCornerShape(8.dp),
                                            contentPadding = PaddingValues(horizontal = 10.dp)
                                        ) {
                                            Text("Apply", fontSize = 11.sp)
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }

        // Card 2: AI Tools Button Text & Pricing Customizer
        item {
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
            ) {
                Column(
                    modifier = Modifier.padding(16.dp),
                    verticalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    Text(
                        text = "🔘 AI Tools Button Text & Price Editor",
                        fontSize = 16.sp,
                        fontWeight = FontWeight.Bold
                    )
                    Text(
                        text = "Customize Pay & Download HD button labels, Free Download text, and Watermark across AI Resume, Bio Data & Photo Tools",
                        fontSize = 11.5.sp,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )

                    OutlinedTextField(
                        value = payHdButtonText,
                        onValueChange = { payHdButtonText = it },
                        label = { Text("Paid / HD Download Button Text") },
                        placeholder = { Text("Pay ₹10 & Download HD (No Watermark)") },
                        modifier = Modifier.fillMaxWidth()
                    )

                    OutlinedTextField(
                        value = freeDownloadButtonText,
                        onValueChange = { freeDownloadButtonText = it },
                        label = { Text("Free Download Button Text") },
                        placeholder = { Text("Free Download (With Watermark)") },
                        modifier = Modifier.fillMaxWidth()
                    )

                    OutlinedTextField(
                        value = unlockedButtonText,
                        onValueChange = { unlockedButtonText = it },
                        label = { Text("Unlocked / Success Button Text") },
                        placeholder = { Text("✨ Download Clean HD File (Unlocked)") },
                        modifier = Modifier.fillMaxWidth()
                    )

                    OutlinedTextField(
                        value = watermarkText,
                        onValueChange = { watermarkText = it },
                        label = { Text("Free File Watermark Stamp Text") },
                        placeholder = { Text("Downloaded From Akash Internet Hub") },
                        modifier = Modifier.fillMaxWidth()
                    )

                    OutlinedTextField(
                        value = hdPriceText,
                        onValueChange = { hdPriceText = it },
                        label = { Text("Standard HD Tool Price (₹)") },
                        placeholder = { Text("10") },
                        modifier = Modifier.fillMaxWidth()
                    )

                    Button(
                        onClick = {
                            onSaveButtonConfig(
                                payHdButtonText,
                                freeDownloadButtonText,
                                unlockedButtonText,
                                watermarkText,
                                hdPriceText
                            )
                        },
                        modifier = Modifier.fillMaxWidth(),
                        shape = RoundedCornerShape(10.dp)
                    ) {
                        Icon(Icons.Default.Save, contentDescription = null, modifier = Modifier.size(16.dp))
                        Spacer(modifier = Modifier.width(6.dp))
                        Text("Save Button Labels & Price Live")
                    }
                }
            }
        }
    }
}

// ==================== SECTION 6: HUB INFO & SECURITY ====================
@Composable
fun AdminHubAndSecuritySection(
    hubInfo: HubInfo,
    notices: List<NoticeAlert>,
    onSaveHubInfo: (HubInfo) -> Unit,
    onUpdateCredentials: (String, String) -> Unit,
    onAddNotice: () -> Unit,
    onEditNotice: (NoticeAlert) -> Unit,
    onDeleteNotice: (NoticeAlert) -> Unit
) {
    var newUsername by remember(hubInfo) { mutableStateOf(hubInfo.adminUsername) }
    var newPassword by remember(hubInfo) { mutableStateOf(hubInfo.adminPassword) }
    var showPassword by remember { mutableStateOf(false) }

    var hubName by remember(hubInfo) { mutableStateOf(hubInfo.hubName) }
    var ownerName by remember(hubInfo) { mutableStateOf(hubInfo.ownerName) }
    var phone by remember(hubInfo) { mutableStateOf(hubInfo.phone) }
    var whatsapp by remember(hubInfo) { mutableStateOf(hubInfo.whatsapp) }
    var address by remember(hubInfo) { mutableStateOf(hubInfo.address) }
    var timings by remember(hubInfo) { mutableStateOf(hubInfo.timings) }
    var announcementBanner by remember(hubInfo) { mutableStateOf(hubInfo.announcementBanner) }

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .padding(14.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        // Admin Credentials Reset Card
        item {
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
            ) {
                Column(
                    modifier = Modifier.padding(16.dp),
                    verticalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    Text(
                        text = "🔐 Admin Login Credentials (Username & Password)",
                        fontSize = 16.sp,
                        fontWeight = FontWeight.Bold
                    )
                    Text(
                        text = "Change your Admin portal login username and password anytime here",
                        fontSize = 11.5.sp,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )

                    OutlinedTextField(
                        value = newUsername,
                        onValueChange = { newUsername = it },
                        label = { Text("Admin Username") },
                        modifier = Modifier.fillMaxWidth()
                    )

                    OutlinedTextField(
                        value = newPassword,
                        onValueChange = { newPassword = it },
                        label = { Text("Admin Password") },
                        visualTransformation = if (showPassword) VisualTransformation.None else PasswordVisualTransformation(),
                        trailingIcon = {
                            IconButton(onClick = { showPassword = !showPassword }) {
                                Icon(
                                    imageVector = if (showPassword) Icons.Default.Visibility else Icons.Default.VisibilityOff,
                                    contentDescription = "Toggle Password"
                                )
                            }
                        },
                        modifier = Modifier.fillMaxWidth()
                    )

                    Button(
                        onClick = {
                            if (newUsername.isNotBlank() && newPassword.isNotBlank()) {
                                onUpdateCredentials(newUsername, newPassword)
                            }
                        },
                        modifier = Modifier.fillMaxWidth(),
                        shape = RoundedCornerShape(10.dp),
                        enabled = newUsername.isNotBlank() && newPassword.isNotBlank()
                    ) {
                        Icon(Icons.Default.LockReset, contentDescription = null, modifier = Modifier.size(16.dp))
                        Spacer(modifier = Modifier.width(6.dp))
                        Text("Reset & Save Admin Credentials")
                    }
                }
            }
        }

        // Hub Contact & Info Details
        item {
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
            ) {
                Column(
                    modifier = Modifier.padding(16.dp),
                    verticalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    Text(
                        text = "🏠 Hub Contact & Info Details",
                        fontSize = 16.sp,
                        fontWeight = FontWeight.Bold
                    )

                    OutlinedTextField(
                        value = hubName,
                        onValueChange = { hubName = it },
                        label = { Text("Hub Name") },
                        modifier = Modifier.fillMaxWidth()
                    )

                    OutlinedTextField(
                        value = ownerName,
                        onValueChange = { ownerName = it },
                        label = { Text("Owner Name") },
                        modifier = Modifier.fillMaxWidth()
                    )

                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        OutlinedTextField(
                            value = phone,
                            onValueChange = { phone = it },
                            label = { Text("Phone") },
                            modifier = Modifier.weight(1f)
                        )
                        OutlinedTextField(
                            value = whatsapp,
                            onValueChange = { whatsapp = it },
                            label = { Text("WhatsApp") },
                            modifier = Modifier.weight(1f)
                        )
                    }

                    OutlinedTextField(
                        value = address,
                        onValueChange = { address = it },
                        label = { Text("Full Address") },
                        modifier = Modifier.fillMaxWidth()
                    )

                    OutlinedTextField(
                        value = timings,
                        onValueChange = { timings = it },
                        label = { Text("Working Hours / Timings") },
                        modifier = Modifier.fillMaxWidth()
                    )

                    OutlinedTextField(
                        value = announcementBanner,
                        onValueChange = { announcementBanner = it },
                        label = { Text("Top Live Ticker Announcement Banner") },
                        modifier = Modifier.fillMaxWidth(),
                        minLines = 2
                    )

                    Button(
                        onClick = {
                            onSaveHubInfo(
                                hubInfo.copy(
                                    hubName = hubName,
                                    ownerName = ownerName,
                                    phone = phone,
                                    whatsapp = whatsapp,
                                    address = address,
                                    timings = timings,
                                    announcementBanner = announcementBanner
                                )
                            )
                        },
                        modifier = Modifier.fillMaxWidth(),
                        shape = RoundedCornerShape(10.dp)
                    ) {
                        Icon(imageVector = Icons.Default.Save, contentDescription = null, modifier = Modifier.size(16.dp))
                        Spacer(modifier = Modifier.width(6.dp))
                        Text("Save Hub Details Live")
                    }
                }
            }
        }

        // Notice Board Management
        item {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = "📢 Notice Board Tickers (${notices.size})",
                    fontSize = 15.sp,
                    fontWeight = FontWeight.Bold
                )
                Button(
                    onClick = onAddNotice,
                    shape = RoundedCornerShape(8.dp)
                ) {
                    Icon(imageVector = Icons.Default.Add, contentDescription = null, modifier = Modifier.size(14.dp))
                    Spacer(modifier = Modifier.width(4.dp))
                    Text("Add Notice", fontSize = 11.sp)
                }
            }
        }

        items(notices) { notice ->
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(12.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
            ) {
                Column(modifier = Modifier.padding(12.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Text(
                            text = notice.title,
                            fontSize = 13.5.sp,
                            fontWeight = FontWeight.Bold
                        )
                        Row {
                            IconButton(onClick = { onEditNotice(notice) }, modifier = Modifier.size(28.dp)) {
                                Icon(Icons.Default.Edit, contentDescription = "Edit", modifier = Modifier.size(16.dp))
                            }
                            IconButton(onClick = { onDeleteNotice(notice) }, modifier = Modifier.size(28.dp)) {
                                Icon(Icons.Default.Delete, contentDescription = "Delete", tint = Color(0xFFEF4444), modifier = Modifier.size(16.dp))
                            }
                        }
                    }
                    Text(
                        text = notice.description,
                        fontSize = 11.5.sp,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            }
        }
    }
}

// ==================== DIALOGS ====================

@Composable
fun EditServiceDialog(
    initialService: HubService?,
    onDismiss: () -> Unit,
    onSave: (HubService) -> Unit
) {
    var title by remember { mutableStateOf(initialService?.title ?: "") }
    var category by remember { mutableStateOf(initialService?.category ?: ServiceCategory.IDENTITY_GOVT) }
    var govtFee by remember { mutableStateOf(initialService?.officialGovtFee ?: "₹0") }
    var centerCharge by remember { mutableStateOf(initialService?.centerCharge ?: "₹100") }
    var totalFee by remember { mutableStateOf(initialService?.totalFee ?: "₹100") }
    var processingTime by remember { mutableStateOf(initialService?.processingTime ?: "1 - 3 Days") }
    var description by remember { mutableStateOf(initialService?.description ?: "") }
    var portalUrl by remember { mutableStateOf(initialService?.officialPortalUrl ?: "") }
    var reqDocsText by remember { mutableStateOf(initialService?.requiredDocuments?.joinToString(", ") ?: "Aadhaar Card, Photo") }

    Dialog(onDismissRequest = onDismiss) {
        Card(
            modifier = Modifier
                .fillMaxWidth()
                .fillMaxHeight(0.9f),
            shape = RoundedCornerShape(20.dp)
        ) {
            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(16.dp),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                Text(
                    text = if (initialService == null) "Add New Hub Service" else "Edit Hub Service",
                    fontSize = 16.sp,
                    fontWeight = FontWeight.Bold
                )

                OutlinedTextField(
                    value = title,
                    onValueChange = { title = it },
                    label = { Text("Service Title") },
                    modifier = Modifier.fillMaxWidth()
                )

                Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    OutlinedTextField(
                        value = govtFee,
                        onValueChange = { govtFee = it },
                        label = { Text("Govt Fee") },
                        modifier = Modifier.weight(1f)
                    )
                    OutlinedTextField(
                        value = centerCharge,
                        onValueChange = { centerCharge = it },
                        label = { Text("Center Charge") },
                        modifier = Modifier.weight(1f)
                    )
                    OutlinedTextField(
                        value = totalFee,
                        onValueChange = { totalFee = it },
                        label = { Text("Total Fee") },
                        modifier = Modifier.weight(1f)
                    )
                }

                OutlinedTextField(
                    value = processingTime,
                    onValueChange = { processingTime = it },
                    label = { Text("Processing Days") },
                    modifier = Modifier.fillMaxWidth()
                )

                OutlinedTextField(
                    value = portalUrl,
                    onValueChange = { portalUrl = it },
                    label = { Text("Official Govt Website / Link") },
                    modifier = Modifier.fillMaxWidth()
                )

                OutlinedTextField(
                    value = reqDocsText,
                    onValueChange = { reqDocsText = it },
                    label = { Text("Required Documents (comma separated)") },
                    modifier = Modifier.fillMaxWidth()
                )

                OutlinedTextField(
                    value = description,
                    onValueChange = { description = it },
                    label = { Text("Service Description") },
                    modifier = Modifier
                        .fillMaxWidth()
                        .weight(1f),
                    minLines = 2
                )

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    OutlinedButton(onClick = onDismiss, modifier = Modifier.weight(1f)) {
                        Text("Cancel")
                    }
                    Button(
                        onClick = {
                            val id = initialService?.id ?: "srv_${System.currentTimeMillis()}"
                            val docsList = reqDocsText.split(",").map { it.trim() }.filter { it.isNotBlank() }
                            onSave(
                                HubService(
                                    id = id,
                                    title = title,
                                    category = category,
                                    description = description,
                                    requiredDocuments = docsList,
                                    processingTime = processingTime,
                                    officialGovtFee = govtFee,
                                    centerCharge = centerCharge,
                                    totalFee = totalFee,
                                    officialPortalUrl = portalUrl.ifBlank { null }
                                )
                            )
                        },
                        modifier = Modifier.weight(1f),
                        enabled = title.isNotBlank()
                    ) {
                        Text("Save")
                    }
                }
            }
        }
    }
}

@Composable
fun UpdateAppStatusDialog(
    app: ServiceApplication,
    onDismiss: () -> Unit,
    onSave: (ApplicationStatus, String, String) -> Unit
) {
    var selectedStatus by remember { mutableStateOf(app.status) }
    var remark by remember { mutableStateOf(app.remark) }
    var trackingRef by remember { mutableStateOf(app.trackingRefNumber) }

    Dialog(onDismissRequest = onDismiss) {
        Card(
            modifier = Modifier.fillMaxWidth(),
            shape = RoundedCornerShape(20.dp)
        ) {
            Column(
                modifier = Modifier.padding(16.dp),
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                Text(
                    text = "Update Status for #${app.id}",
                    fontSize = 16.sp,
                    fontWeight = FontWeight.Bold
                )

                Text(
                    text = "${app.serviceTitle} • ${app.applicantName}",
                    fontSize = 12.sp,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )

                Text("Select New Status / Step Progress:", fontSize = 13.sp, fontWeight = FontWeight.SemiBold)

                ApplicationStatus.values().forEach { status ->
                    Surface(
                        shape = RoundedCornerShape(8.dp),
                        color = if (selectedStatus == status) MaterialTheme.colorScheme.primaryContainer else MaterialTheme.colorScheme.surfaceVariant,
                        modifier = Modifier
                            .fillMaxWidth()
                            .clickable { selectedStatus = status }
                    ) {
                        Row(
                            modifier = Modifier.padding(horizontal = 12.dp, vertical = 8.dp),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Text(
                                text = "Step ${status.stepNumber}: ${status.title}",
                                fontSize = 12.5.sp,
                                fontWeight = if (selectedStatus == status) FontWeight.Bold else FontWeight.Normal
                            )
                            if (selectedStatus == status) {
                                Icon(imageVector = Icons.Default.Check, contentDescription = null, tint = MaterialTheme.colorScheme.primary)
                            }
                        }
                    }
                }

                OutlinedTextField(
                    value = trackingRef,
                    onValueChange = { trackingRef = it },
                    label = { Text("Tracking Reference / Govt Ack No") },
                    modifier = Modifier.fillMaxWidth()
                )

                OutlinedTextField(
                    value = remark,
                    onValueChange = { remark = it },
                    label = { Text("Admin Remark (Visible to applicant)") },
                    modifier = Modifier.fillMaxWidth()
                )

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    OutlinedButton(onClick = onDismiss, modifier = Modifier.weight(1f)) {
                        Text("Cancel")
                    }
                    Button(
                        onClick = { onSave(selectedStatus, remark, trackingRef) },
                        modifier = Modifier.weight(1f)
                    ) {
                        Text("Update")
                    }
                }
            }
        }
    }
}

@Composable
fun EditReceiptDetailsDialog(
    app: ServiceApplication,
    onDismiss: () -> Unit,
    onSave: (ServiceApplication) -> Unit
) {
    var serviceTitle by remember { mutableStateOf(app.serviceTitle) }
    var applicantName by remember { mutableStateOf(app.applicantName) }
    var phone by remember { mutableStateOf(app.phone) }
    var email by remember { mutableStateOf(app.email) }
    var totalPaid by remember { mutableStateOf(app.totalPaid) }
    var trackingRef by remember { mutableStateOf(app.trackingRefNumber) }
    var dateSubmitted by remember { mutableStateOf(app.dateSubmitted) }
    var remark by remember { mutableStateOf(app.remark) }

    Dialog(
        onDismissRequest = onDismiss,
        properties = DialogProperties(usePlatformDefaultWidth = false)
    ) {
        Card(
            modifier = Modifier
                .fillMaxWidth(0.92f)
                .fillMaxHeight(0.85f),
            shape = RoundedCornerShape(20.dp)
        ) {
            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(16.dp),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                Text(
                    text = "Edit Receipt Data for #${app.id}",
                    fontSize = 16.sp,
                    fontWeight = FontWeight.Bold
                )

                LazyColumn(
                    modifier = Modifier.weight(1f),
                    verticalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    item {
                        OutlinedTextField(
                            value = applicantName,
                            onValueChange = { applicantName = it },
                            label = { Text("Applicant Name") },
                            modifier = Modifier.fillMaxWidth()
                        )
                    }
                    item {
                        OutlinedTextField(
                            value = serviceTitle,
                            onValueChange = { serviceTitle = it },
                            label = { Text("Service Title") },
                            modifier = Modifier.fillMaxWidth()
                        )
                    }
                    item {
                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            OutlinedTextField(
                                value = phone,
                                onValueChange = { phone = it },
                                label = { Text("Mobile Phone") },
                                modifier = Modifier.weight(1f)
                            )
                            OutlinedTextField(
                                value = totalPaid,
                                onValueChange = { totalPaid = it },
                                label = { Text("Fee Collected") },
                                modifier = Modifier.weight(1f)
                            )
                        }
                    }
                    item {
                        OutlinedTextField(
                            value = email,
                            onValueChange = { email = it },
                            label = { Text("Email ID") },
                            modifier = Modifier.fillMaxWidth()
                        )
                    }
                    item {
                        OutlinedTextField(
                            value = trackingRef,
                            onValueChange = { trackingRef = it },
                            label = { Text("Portal Ref / Ack Number") },
                            modifier = Modifier.fillMaxWidth()
                        )
                    }
                    item {
                        OutlinedTextField(
                            value = dateSubmitted,
                            onValueChange = { dateSubmitted = it },
                            label = { Text("Date & Time on Receipt") },
                            modifier = Modifier.fillMaxWidth()
                        )
                    }
                    item {
                        OutlinedTextField(
                            value = remark,
                            onValueChange = { remark = it },
                            label = { Text("Remark on Receipt") },
                            modifier = Modifier.fillMaxWidth(),
                            minLines = 2
                        )
                    }
                }

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    OutlinedButton(onClick = onDismiss, modifier = Modifier.weight(1f)) {
                        Text("Cancel")
                    }
                    Button(
                        onClick = {
                            onSave(
                                app.copy(
                                    serviceTitle = serviceTitle,
                                    applicantName = applicantName,
                                    phone = phone,
                                    email = email,
                                    totalPaid = totalPaid,
                                    trackingRefNumber = trackingRef,
                                    dateSubmitted = dateSubmitted,
                                    remark = remark
                                )
                            )
                        },
                        modifier = Modifier.weight(1f)
                    ) {
                        Text("Save Receipt")
                    }
                }
            }
        }
    }
}

@Composable
fun AddManualAppDialog(
    onDismiss: () -> Unit,
    onSave: (ServiceApplication) -> Unit
) {
    var title by remember { mutableStateOf("New PAN Card (Form 49A)") }
    var name by remember { mutableStateOf("Akash Internet Hub") }
    var phone by remember { mutableStateOf("+91 7002134700") }
    var status by remember { mutableStateOf(ApplicationStatus.SUBMITTED) }
    var refNum by remember { mutableStateOf("AKN-REF-${(1000..9999).random()}") }
    var remark by remember { mutableStateOf("Application Received at Counter.") }

    Dialog(onDismissRequest = onDismiss) {
        Card(
            modifier = Modifier.fillMaxWidth(),
            shape = RoundedCornerShape(20.dp)
        ) {
            Column(
                modifier = Modifier.padding(16.dp),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                Text("Add Tracking Entry", fontSize = 16.sp, fontWeight = FontWeight.Bold)

                OutlinedTextField(value = title, onValueChange = { title = it }, label = { Text("Service Title") }, modifier = Modifier.fillMaxWidth())
                OutlinedTextField(value = name, onValueChange = { name = it }, label = { Text("Applicant Name") }, modifier = Modifier.fillMaxWidth())
                OutlinedTextField(value = phone, onValueChange = { phone = it }, label = { Text("Mobile Phone") }, modifier = Modifier.fillMaxWidth())
                OutlinedTextField(value = refNum, onValueChange = { refNum = it }, label = { Text("Ref / Ack Number") }, modifier = Modifier.fillMaxWidth())
                OutlinedTextField(value = remark, onValueChange = { remark = it }, label = { Text("Remark") }, modifier = Modifier.fillMaxWidth())

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    OutlinedButton(onClick = onDismiss, modifier = Modifier.weight(1f)) { Text("Cancel") }
                    Button(
                        onClick = {
                            val newApp = ServiceApplication(
                                id = "AKN-2026-${(1000..9999).random()}",
                                serviceTitle = title,
                                category = ServiceCategory.IDENTITY_GOVT,
                                applicantName = name,
                                phone = phone,
                                email = "akashinternethub@gmail.com",
                                dateSubmitted = "Today",
                                status = status,
                                trackingRefNumber = refNum,
                                totalPaid = "₹200.00",
                                uploadedDocuments = listOf("Standard_KYC.pdf"),
                                remark = remark
                            )
                            onSave(newApp)
                        },
                        modifier = Modifier.weight(1f)
                    ) { Text("Create") }
                }
            }
        }
    }
}

@Composable
fun EditNoticeDialog(
    initialNotice: NoticeAlert?,
    onDismiss: () -> Unit,
    onSave: (NoticeAlert) -> Unit
) {
    var title by remember { mutableStateOf(initialNotice?.title ?: "") }
    var tag by remember { mutableStateOf(initialNotice?.tag ?: "Recruitment") }
    var description by remember { mutableStateOf(initialNotice?.description ?: "") }

    Dialog(onDismissRequest = onDismiss) {
        Card(modifier = Modifier.fillMaxWidth(), shape = RoundedCornerShape(20.dp)) {
            Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                Text(if (initialNotice == null) "Add Notice Alert" else "Edit Notice Alert", fontSize = 16.sp, fontWeight = FontWeight.Bold)

                OutlinedTextField(value = title, onValueChange = { title = it }, label = { Text("Notice Title") }, modifier = Modifier.fillMaxWidth())
                OutlinedTextField(value = tag, onValueChange = { tag = it }, label = { Text("Tag (e.g. Recruitment, Identity)") }, modifier = Modifier.fillMaxWidth())
                OutlinedTextField(value = description, onValueChange = { description = it }, label = { Text("Notice Details") }, modifier = Modifier.fillMaxWidth(), minLines = 2)

                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedButton(onClick = onDismiss, modifier = Modifier.weight(1f)) { Text("Cancel") }
                    Button(
                        onClick = {
                            val id = initialNotice?.id ?: "not_${System.currentTimeMillis()}"
                            onSave(
                                NoticeAlert(
                                    id = id,
                                    title = title,
                                    tag = tag,
                                    date = "22 Aug 2026",
                                    description = description,
                                    isImportant = true
                                )
                            )
                        },
                        modifier = Modifier.weight(1f),
                        enabled = title.isNotBlank()
                    ) { Text("Save") }
                }
            }
        }
    }
}
