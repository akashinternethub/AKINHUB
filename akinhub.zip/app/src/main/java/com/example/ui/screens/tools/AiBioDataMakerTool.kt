package com.example.ui.screens.tools

import android.widget.Toast
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.blur
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.rotate
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.theme.AkinAmberAccent
import com.example.ui.theme.AkinGreenSuccess

@Composable
fun AiBioDataMakerTool(
    isPaid: Boolean = false,
    onTriggerPayment: (itemName: String, amount: Int, buttonId: String) -> Unit,
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current

    // Personal Details
    var fullName by remember { mutableStateOf("Ankita Sharma") }
    var dob by remember { mutableStateOf("15/07/1999") }
    var birthTime by remember { mutableStateOf("06:45 AM") }
    var birthPlace by remember { mutableStateOf("Dhubri, Assam") }
    var height by remember { mutableStateOf("5 ft 3 in (160 cm)") }
    var complexion by remember { mutableStateOf("Fair") }
    var religionCaste by remember { mutableStateOf("Hindu / Brahmin") }
    var gotraRashi by remember { mutableStateOf("Kashyap Gotra / Cancer (Kark Rashi)") }

    // Education & Occupation
    var qualification by remember { mutableStateOf("M.Com (Finance) - Gauhati University") }
    var occupation by remember { mutableStateOf("Accountant in Govt Undertaking (Dhubri)") }
    var annualIncome by remember { mutableStateOf("₹4,20,000 per annum") }

    // Family Details
    var fatherName by remember { mutableStateOf("Late Ramesh Sharma (Ex-Govt Teacher)") }
    var motherName by remember { mutableStateOf("Sunita Sharma (Homemaker)") }
    var siblings by remember { mutableStateOf("1 Elder Brother (Married, Software Engineer), 1 Younger Sister (Studying)") }
    var permanentAddress by remember { mutableStateOf("Near Saba Petrol Pump, Geramari, Dhubri, Assam - 783339") }
    var contactNumber by remember { mutableStateOf("+91 94350 77665") }

    var isPhotoUploaded by remember { mutableStateOf(true) }
    var isSimulatingScreenshotProtection by remember { mutableStateOf(false) }

    Card(
        modifier = modifier
            .fillMaxWidth()
            .testTag("ai_biodata_maker_card"),
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
    ) {
        Column(modifier = Modifier.padding(16.dp)) {
            // Header
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text(
                            text = "AI Marriage & Pro Bio Data Maker",
                            fontSize = 16.sp,
                            fontWeight = FontWeight.Bold,
                            color = MaterialTheme.colorScheme.onSurface
                        )
                        Spacer(modifier = Modifier.width(6.dp))
                        Surface(
                            shape = RoundedCornerShape(4.dp),
                            color = Color(0xFFD97706)
                        ) {
                            Text(
                                text = "SPECIAL",
                                fontSize = 9.sp,
                                fontWeight = FontWeight.Bold,
                                color = Color.White,
                                modifier = Modifier.padding(horizontal = 5.dp, vertical = 2.dp)
                            )
                        }
                    }
                    Text(
                        text = "Create elegant, auspicious Marriage Biodata in seconds",
                        fontSize = 11.sp,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }

                // Security Blur toggle
                IconButton(
                    onClick = {
                        isSimulatingScreenshotProtection = !isSimulatingScreenshotProtection
                        Toast.makeText(
                            context,
                            if (isSimulatingScreenshotProtection) "🔒 Screenshot Protection Enabled" else "Preview Normal",
                            Toast.LENGTH_SHORT
                        ).show()
                    }
                ) {
                    Icon(
                        imageVector = if (isSimulatingScreenshotProtection) Icons.Default.Security else Icons.Default.Visibility,
                        contentDescription = "Protection Mode",
                        tint = if (isSimulatingScreenshotProtection) AkinAmberAccent else MaterialTheme.colorScheme.primary
                    )
                }
            }

            Spacer(modifier = Modifier.height(12.dp))

            // Step 1: Input Fields & Uploads
            Text("1. Enter Personal, Family & Astrological Details", fontSize = 13.sp, fontWeight = FontWeight.Bold)
            Spacer(modifier = Modifier.height(6.dp))

            OutlinedTextField(
                value = fullName,
                onValueChange = { fullName = it },
                label = { Text("Candidate Full Name") },
                modifier = Modifier.fillMaxWidth(),
                singleLine = true
            )
            Spacer(modifier = Modifier.height(6.dp))

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                OutlinedTextField(
                    value = dob,
                    onValueChange = { dob = it },
                    label = { Text("Date of Birth") },
                    modifier = Modifier.weight(1f),
                    singleLine = true
                )
                OutlinedTextField(
                    value = birthTime,
                    onValueChange = { birthTime = it },
                    label = { Text("Birth Time") },
                    modifier = Modifier.weight(1f),
                    singleLine = true
                )
            }
            Spacer(modifier = Modifier.height(6.dp))

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                OutlinedTextField(
                    value = birthPlace,
                    onValueChange = { birthPlace = it },
                    label = { Text("Place of Birth") },
                    modifier = Modifier.weight(1f),
                    singleLine = true
                )
                OutlinedTextField(
                    value = height,
                    onValueChange = { height = it },
                    label = { Text("Height") },
                    modifier = Modifier.weight(1f),
                    singleLine = true
                )
            }
            Spacer(modifier = Modifier.height(6.dp))

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                OutlinedTextField(
                    value = religionCaste,
                    onValueChange = { religionCaste = it },
                    label = { Text("Religion & Caste") },
                    modifier = Modifier.weight(1.1f),
                    singleLine = true
                )
                OutlinedTextField(
                    value = gotraRashi,
                    onValueChange = { gotraRashi = it },
                    label = { Text("Gotra / Rashi") },
                    modifier = Modifier.weight(1f),
                    singleLine = true
                )
            }
            Spacer(modifier = Modifier.height(6.dp))

            OutlinedTextField(
                value = qualification,
                onValueChange = { qualification = it },
                label = { Text("Educational Qualification") },
                modifier = Modifier.fillMaxWidth(),
                singleLine = true
            )
            Spacer(modifier = Modifier.height(6.dp))

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                OutlinedTextField(
                    value = occupation,
                    onValueChange = { occupation = it },
                    label = { Text("Occupation / Job") },
                    modifier = Modifier.weight(1.2f),
                    singleLine = true
                )
                OutlinedTextField(
                    value = annualIncome,
                    onValueChange = { annualIncome = it },
                    label = { Text("Annual Income") },
                    modifier = Modifier.weight(0.9f),
                    singleLine = true
                )
            }
            Spacer(modifier = Modifier.height(6.dp))

            OutlinedTextField(
                value = fatherName,
                onValueChange = { fatherName = it },
                label = { Text("Father's Name & Occupation") },
                modifier = Modifier.fillMaxWidth(),
                singleLine = true
            )
            Spacer(modifier = Modifier.height(6.dp))

            OutlinedTextField(
                value = motherName,
                onValueChange = { motherName = it },
                label = { Text("Mother's Name & Occupation") },
                modifier = Modifier.fillMaxWidth(),
                singleLine = true
            )
            Spacer(modifier = Modifier.height(6.dp))

            OutlinedTextField(
                value = siblings,
                onValueChange = { siblings = it },
                label = { Text("Brothers & Sisters (Siblings)") },
                modifier = Modifier.fillMaxWidth(),
                singleLine = true
            )
            Spacer(modifier = Modifier.height(6.dp))

            OutlinedTextField(
                value = permanentAddress,
                onValueChange = { permanentAddress = it },
                label = { Text("Permanent Family Address") },
                modifier = Modifier.fillMaxWidth(),
                singleLine = true
            )
            Spacer(modifier = Modifier.height(6.dp))

            OutlinedTextField(
                value = contactNumber,
                onValueChange = { contactNumber = it },
                label = { Text("Family Contact & WhatsApp Number") },
                modifier = Modifier.fillMaxWidth(),
                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Phone),
                singleLine = true
            )

            Spacer(modifier = Modifier.height(10.dp))

            // Photo Upload Simulation
            Surface(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(10.dp))
                    .clickable {
                        isPhotoUploaded = !isPhotoUploaded
                        Toast.makeText(context, if (isPhotoUploaded) "Photo Attached to Bio Data!" else "Photo Removed", Toast.LENGTH_SHORT).show()
                    },
                color = if (isPhotoUploaded) MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.5f) else MaterialTheme.colorScheme.surfaceVariant
            ) {
                Row(
                    modifier = Modifier.padding(12.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Icon(
                        imageVector = if (isPhotoUploaded) Icons.Default.CheckCircle else Icons.Default.AddPhotoAlternate,
                        contentDescription = "Photo",
                        tint = if (isPhotoUploaded) AkinGreenSuccess else MaterialTheme.colorScheme.primary
                    )
                    Spacer(modifier = Modifier.width(10.dp))
                    Column {
                        Text(
                            text = if (isPhotoUploaded) "Candidate Photo Uploaded (candidate_photo.jpg)" else "Upload Photo for Bio Data",
                            fontSize = 12.sp,
                            fontWeight = FontWeight.Bold
                        )
                        Text(
                            text = "Framed automatically with decorative golden-royal border",
                            fontSize = 10.sp,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.height(18.dp))

            // Step 2: Live Bio Data Preview with Watermark & Anti-Screenshot Protection
            Text("2. Live Bio Data Preview", fontSize = 13.sp, fontWeight = FontWeight.Bold)
            Spacer(modifier = Modifier.height(6.dp))

            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .wrapContentHeight()
                    .clip(RoundedCornerShape(14.dp))
                    .background(Color(0xFFFFFBEB)) // Soft auspicious ivory-cream background
                    .border(2.dp, Color(0xFFD97706), RoundedCornerShape(14.dp))
                    .padding(16.dp)
            ) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .then(if (isSimulatingScreenshotProtection) Modifier.blur(12.dp) else Modifier),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    // Auspicious Symbol Header
                    Text(
                        text = "॥ श्री गणेशाय नमः ॥",
                        fontSize = 13.sp,
                        fontWeight = FontWeight.ExtraBold,
                        color = Color(0xFFB45309),
                        textAlign = TextAlign.Center
                    )
                    Text(
                        text = "BIO-DATA",
                        fontSize = 18.sp,
                        fontWeight = FontWeight.Black,
                        color = Color(0xFF78350F),
                        letterSpacing = 3.sp
                    )

                    Spacer(modifier = Modifier.height(8.dp))

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.Top
                    ) {
                        Column(modifier = Modifier.weight(1f)) {
                            BioDataFieldRow("Name", fullName.ifBlank { "Candidate Name" })
                            BioDataFieldRow("Date of Birth", dob)
                            BioDataFieldRow("Time of Birth", birthTime)
                            BioDataFieldRow("Place of Birth", birthPlace)
                            BioDataFieldRow("Height", height)
                            BioDataFieldRow("Complexion", complexion)
                            BioDataFieldRow("Religion / Caste", religionCaste)
                            BioDataFieldRow("Gotra / Rashi", gotraRashi)
                        }

                        if (isPhotoUploaded) {
                            Surface(
                                modifier = Modifier
                                    .padding(start = 10.dp)
                                    .size(72.dp, 90.dp)
                                    .border(2.dp, Color(0xFFD97706), RoundedCornerShape(8.dp))
                                    .clip(RoundedCornerShape(8.dp)),
                                color = Color(0xFFFEF3C7)
                            ) {
                                Box(contentAlignment = Alignment.Center) {
                                    Icon(Icons.Default.Person, contentDescription = "Photo", tint = Color(0xFF92400E), modifier = Modifier.size(48.dp))
                                }
                            }
                        }
                    }

                    HorizontalDivider(modifier = Modifier.padding(vertical = 8.dp), color = Color(0xFFD97706).copy(alpha = 0.5f))

                    // Education & Career
                    Text(
                        text = "EDUCATIONAL & PROFESSIONAL DETAILS",
                        fontSize = 10.5.sp,
                        fontWeight = FontWeight.Bold,
                        color = Color(0xFFB45309),
                        modifier = Modifier.fillMaxWidth()
                    )
                    Spacer(modifier = Modifier.height(4.dp))
                    BioDataFieldRow("Education", qualification)
                    BioDataFieldRow("Occupation", occupation)
                    BioDataFieldRow("Annual Income", annualIncome)

                    HorizontalDivider(modifier = Modifier.padding(vertical = 8.dp), color = Color(0xFFD97706).copy(alpha = 0.5f))

                    // Family Details
                    Text(
                        text = "FAMILY DETAILS & CONTACT",
                        fontSize = 10.5.sp,
                        fontWeight = FontWeight.Bold,
                        color = Color(0xFFB45309),
                        modifier = Modifier.fillMaxWidth()
                    )
                    Spacer(modifier = Modifier.height(4.dp))
                    BioDataFieldRow("Father's Name", fatherName)
                    BioDataFieldRow("Mother's Name", motherName)
                    BioDataFieldRow("Siblings", siblings)
                    BioDataFieldRow("Address", permanentAddress)
                    BioDataFieldRow("Contact No.", contactNumber)
                }

                // Security & Watermark Overlays
                Box(
                    modifier = Modifier.matchParentSize(),
                    contentAlignment = Alignment.Center
                ) {
                    Text(
                        text = "AKASH INTERNET HUB\nBIODATA PREVIEW ONLY\nDO NOT SCREENSHOT",
                        color = Color.Red.copy(alpha = 0.18f),
                        fontSize = 17.sp,
                        fontWeight = FontWeight.Black,
                        textAlign = TextAlign.Center,
                        lineHeight = 22.sp,
                        modifier = Modifier.rotate(-28f)
                    )
                }

                if (isSimulatingScreenshotProtection) {
                    Box(
                        modifier = Modifier
                            .matchParentSize()
                            .background(Color.Black.copy(alpha = 0.65f)),
                        contentAlignment = Alignment.Center
                    ) {
                        Column(horizontalAlignment = Alignment.CenterHorizontally) {
                            Icon(Icons.Default.Security, contentDescription = "Protected", tint = AkinAmberAccent, modifier = Modifier.size(36.dp))
                            Spacer(modifier = Modifier.height(4.dp))
                            Text(
                                text = "SCREENSHOT PROTECTED",
                                color = Color.White,
                                fontWeight = FontWeight.Bold,
                                fontSize = 13.sp
                            )
                            Text(
                                text = "Download original PDF via buttons below",
                                color = Color.White.copy(alpha = 0.8f),
                                fontSize = 10.sp
                            )
                        }
                    }
                }
            }

            Spacer(modifier = Modifier.height(16.dp))

            // Step 3: Two Clear Download Buttons
            // Button 1: Free Download With Watermark
            OutlinedButton(
                onClick = {
                    Toast.makeText(
                        context,
                        "📥 Free Bio Data Downloaded with Watermark: 'Downloaded From Akash Internet Hub'",
                        Toast.LENGTH_LONG
                    ).show()
                },
                modifier = Modifier
                    .fillMaxWidth()
                    .height(46.dp)
                    .testTag("free_biodata_download_button"),
                shape = RoundedCornerShape(10.dp)
            ) {
                Icon(Icons.Default.Download, contentDescription = "Free Download", modifier = Modifier.size(18.dp))
                Spacer(modifier = Modifier.width(6.dp))
                Text(
                    text = "Free Download (With Watermark)",
                    fontSize = 12.sp,
                    fontWeight = FontWeight.SemiBold
                )
            }

            Spacer(modifier = Modifier.height(10.dp))

            if (isPaid) {
                // Unlocked Clean Bio Data PDF Button
                Button(
                    onClick = {
                        Toast.makeText(
                            context,
                            "📥 Clean Auspicious Bio Data PDF Downloaded (Without Watermark)!",
                            Toast.LENGTH_LONG
                        ).show()
                    },
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(48.dp)
                        .testTag("download_unlocked_biodata_button"),
                    shape = RoundedCornerShape(10.dp),
                    colors = ButtonDefaults.buttonColors(containerColor = AkinGreenSuccess, contentColor = Color.White)
                ) {
                    Icon(Icons.Default.DownloadDone, contentDescription = "Download Clean PDF", modifier = Modifier.size(20.dp))
                    Spacer(modifier = Modifier.width(8.dp))
                    Column(horizontalAlignment = Alignment.Start) {
                        Text(
                            text = "✨ Download Clean Bio Data PDF (Unlocked)",
                            fontSize = 13.sp,
                            fontWeight = FontWeight.Bold,
                            color = Color.White
                        )
                        Text(
                            text = "100% Watermark Free • Elegant Marriage Template",
                            fontSize = 9.sp,
                            color = Color.White.copy(alpha = 0.9f)
                        )
                    }
                }
            } else {
                // Button 2: Pay ₹100 & Get Clean PDF
                Button(
                    onClick = {
                        onTriggerPayment(
                            "Marriage / Pro Bio Data Clean PDF (Without Watermark)",
                            100,
                            "pl_TSYm6s9zRAFbLQ"
                        )
                    },
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(48.dp)
                        .testTag("pay_biodata_clean_pdf_button"),
                    shape = RoundedCornerShape(10.dp),
                    colors = ButtonDefaults.buttonColors(containerColor = Color(0xFFD97706))
                ) {
                    Icon(Icons.Default.PictureAsPdf, contentDescription = "Pay PDF", modifier = Modifier.size(18.dp))
                    Spacer(modifier = Modifier.width(8.dp))
                    Column(horizontalAlignment = Alignment.Start) {
                        Text(
                            text = "Pay ₹100 & Get Clean PDF (No Watermark)",
                            fontSize = 13.sp,
                            fontWeight = FontWeight.Bold,
                            color = Color.White
                        )
                        Text(
                            text = "Razorpay Checkout • High-Resolution Auspicious Format",
                            fontSize = 9.sp,
                            color = Color.White.copy(alpha = 0.9f)
                        )
                    }
                }
            }
        }
    }
}

@Composable
private fun BioDataFieldRow(label: String, value: String) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 2.dp),
        verticalAlignment = Alignment.Top
    ) {
        Text(
            text = "$label :",
            fontSize = 9.5.sp,
            fontWeight = FontWeight.Bold,
            color = Color(0xFF78350F),
            modifier = Modifier.width(90.dp)
        )
        Text(
            text = value,
            fontSize = 9.5.sp,
            color = Color(0xFF1E293B),
            modifier = Modifier.weight(1f),
            lineHeight = 13.sp
        )
    }
}
