package com.example.ui.screens.tools

import android.net.Uri
import android.widget.Toast
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.blur
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.rotate
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import coil.compose.AsyncImage
import com.example.data.model.HubInfo
import com.example.ui.dialogs.FileDownloadProgressDialog
import com.example.ui.theme.AkinAmberAccent
import com.example.ui.theme.AkinGreenSuccess
import com.example.utils.DocumentExportHelper
import kotlinx.coroutines.launch
import java.io.File

enum class BioDataType {
    MARRIAGE,
    SIMPLE_JOB
}

@Composable
fun AiBioDataMakerTool(
    hubInfo: HubInfo = HubInfo(),
    isPaid: Boolean = false,
    onTriggerPayment: (itemName: String, amount: Int, buttonId: String) -> Unit,
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    val coroutineScope = rememberCoroutineScope()

    // Mode Selector: Marriage vs Simple Job Bio Data
    var selectedType by remember { mutableStateOf(BioDataType.MARRIAGE) }

    // Common & Marriage Fields
    var fullName by remember { mutableStateOf("Akash Internet Hub") }
    var dob by remember { mutableStateOf("15/07/1999") }
    var birthTime by remember { mutableStateOf("06:45 AM") }
    var birthPlace by remember { mutableStateOf("Dhubri, Assam") }
    var height by remember { mutableStateOf("5 ft 3 in (160 cm)") }
    var complexion by remember { mutableStateOf("Fair") }
    var religionCaste by remember { mutableStateOf("Hindu / Brahmin") }
    var gotraRashi by remember { mutableStateOf("Kashyap Gotra / Cancer (Kark Rashi)") }
    var qualification by remember { mutableStateOf("M.Com (Finance) - Gauhati University") }
    var occupation by remember { mutableStateOf("Accountant in Govt Undertaking (Dhubri)") }
    var annualIncome by remember { mutableStateOf("₹4,20,000 per annum") }
    var fatherName by remember { mutableStateOf("Late Ramesh Sharma (Ex-Govt Teacher)") }
    var motherName by remember { mutableStateOf("Sunita Sharma (Homemaker)") }
    var siblings by remember { mutableStateOf("1 Elder Brother (Married, Software Engineer), 1 Younger Sister (Studying)") }
    var permanentAddress by remember { mutableStateOf("Near Saba Petrol Pump, Geramari, Dhubri, Assam - 783339") }
    var contactNumber by remember { mutableStateOf("+91 7002134700") }

    // Simple Job Bio Data Specific Fields
    var gender by remember { mutableStateOf("Male") }
    var maritalStatus by remember { mutableStateOf("Unmarried") }
    var nationality by remember { mutableStateOf("Indian") }
    var religionCategory by remember { mutableStateOf("General / OBC") }
    var emailAddress by remember { mutableStateOf("akashinternethub@gmail.com") }
    var presentAddress by remember { mutableStateOf("Ward No. 4, College Nagar, Dhubri, Assam - 783324") }
    var careerObjective by remember { mutableStateOf("Seeking a challenging position in a growth-oriented organization where I can utilize my skills and experience.") }
    var technicalSkills by remember { mutableStateOf("MS Office Suite, Tally Prime, Online Portal Management, Fast Typing (45 WPM)") }
    var workExperience by remember { mutableStateOf("2 Years as Senior Service Operator at Digital Seva Center") }
    var languagesKnown by remember { mutableStateOf("English (Proficient), Hindi (Fluent), Assamese (Native)") }

    // Candidate Photo Upload
    var selectedPhotoUri by remember { mutableStateOf<Uri?>(null) }
    val photoPickerLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.GetContent()
    ) { uri: Uri? ->
        if (uri != null) {
            selectedPhotoUri = uri
            Toast.makeText(context, "📸 Candidate photo attached to Bio Data!", Toast.LENGTH_SHORT).show()
        }
    }

    var isSimulatingScreenshotProtection by remember { mutableStateOf(false) }

    // Download Progress Dialog state
    var isDownloading by remember { mutableStateOf(false) }
    var progressMessage by remember { mutableStateOf("") }
    var downloadedFile by remember { mutableStateOf<File?>(null) }

    FileDownloadProgressDialog(
        isDownloading = isDownloading,
        progressMessage = progressMessage,
        downloadedFile = downloadedFile,
        onDismiss = {
            isDownloading = false
            downloadedFile = null
            progressMessage = ""
        }
    )

    Card(
        modifier = modifier
            .fillMaxWidth()
            .testTag("ai_biodata_maker_card"),
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
    ) {
        Column(modifier = Modifier.padding(16.dp)) {
            // Header
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text(
                            text = "AI Bio Data Maker",
                            fontSize = 17.sp,
                            fontWeight = FontWeight.Bold,
                            color = MaterialTheme.colorScheme.onSurface
                        )
                        Spacer(modifier = Modifier.width(6.dp))
                        Surface(
                            shape = RoundedCornerShape(4.dp),
                            color = if (selectedType == BioDataType.MARRIAGE) Color(0xFFD97706) else MaterialTheme.colorScheme.primary
                        ) {
                            Text(
                                text = if (selectedType == BioDataType.MARRIAGE) "MARRIAGE" else "JOB FORMAT",
                                fontSize = 9.sp,
                                fontWeight = FontWeight.Bold,
                                color = Color.White,
                                modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                            )
                        }
                    }
                    Text(
                        text = "Create professional Marriage or Employment Bio Data",
                        fontSize = 11.5.sp,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }

                // Security Blur toggle
                IconButton(
                    onClick = {
                        isSimulatingScreenshotProtection = !isSimulatingScreenshotProtection
                        Toast.makeText(
                            context,
                            if (isSimulatingScreenshotProtection) "🔒 Screenshot Protection Enabled" else "Preview Normal",
                            Toast.LENGTH_SHORT
                        ).show()
                    }
                ) {
                    Icon(
                        imageVector = if (isSimulatingScreenshotProtection) Icons.Default.Security else Icons.Default.Visibility,
                        contentDescription = "Protection Mode",
                        tint = if (isSimulatingScreenshotProtection) AkinAmberAccent else MaterialTheme.colorScheme.primary
                    )
                }
            }

            Spacer(modifier = Modifier.height(14.dp))

            // Bio Data Type Switcher Tabs
            Surface(
                shape = RoundedCornerShape(12.dp),
                color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f),
                border = BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.5f))
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(4.dp)
                ) {
                    // Option 1: Marriage Bio Data Maker
                    Surface(
                        onClick = { selectedType = BioDataType.MARRIAGE },
                        shape = RoundedCornerShape(9.dp),
                        color = if (selectedType == BioDataType.MARRIAGE) Color(0xFFD97706) else Color.Transparent,
                        modifier = Modifier.weight(1f)
                    ) {
                        Row(
                            modifier = Modifier.padding(vertical = 9.dp),
                            horizontalArrangement = Arrangement.Center,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Icon(
                                Icons.Default.Favorite,
                                contentDescription = null,
                                tint = if (selectedType == BioDataType.MARRIAGE) Color.White else MaterialTheme.colorScheme.onSurfaceVariant,
                                modifier = Modifier.size(16.dp)
                            )
                            Spacer(modifier = Modifier.width(6.dp))
                            Text(
                                text = "Marriage Bio Data",
                                fontSize = 12.sp,
                                fontWeight = if (selectedType == BioDataType.MARRIAGE) FontWeight.Bold else FontWeight.Medium,
                                color = if (selectedType == BioDataType.MARRIAGE) Color.White else MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                    }

                    Spacer(modifier = Modifier.width(4.dp))

                    // Option 2: Simple Bio Data Maker For Job etc.
                    Surface(
                        onClick = { selectedType = BioDataType.SIMPLE_JOB },
                        shape = RoundedCornerShape(9.dp),
                        color = if (selectedType == BioDataType.SIMPLE_JOB) MaterialTheme.colorScheme.primary else Color.Transparent,
                        modifier = Modifier.weight(1f)
                    ) {
                        Row(
                            modifier = Modifier.padding(vertical = 9.dp),
                            horizontalArrangement = Arrangement.Center,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Icon(
                                Icons.Default.Work,
                                contentDescription = null,
                                tint = if (selectedType == BioDataType.SIMPLE_JOB) Color.White else MaterialTheme.colorScheme.onSurfaceVariant,
                                modifier = Modifier.size(16.dp)
                            )
                            Spacer(modifier = Modifier.width(6.dp))
                            Text(
                                text = "Simple Job Bio Data",
                                fontSize = 12.sp,
                                fontWeight = if (selectedType == BioDataType.SIMPLE_JOB) FontWeight.Bold else FontWeight.Medium,
                                color = if (selectedType == BioDataType.SIMPLE_JOB) Color.White else MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                    }
                }
            }

            Spacer(modifier = Modifier.height(14.dp))

            // Photo Upload Section
            Card(
                modifier = Modifier.fillMaxWidth(),
                colors = CardDefaults.cardColors(
                    containerColor = if (selectedType == BioDataType.MARRIAGE) Color(0xFFFFFBEB) else MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.45f)
                ),
                shape = RoundedCornerShape(12.dp),
                border = BorderStroke(
                    1.dp,
                    if (selectedType == BioDataType.MARRIAGE) Color(0xFFFDE68A) else MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.6f)
                )
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(12.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Box(
                        modifier = Modifier
                            .size(68.dp, 80.dp)
                            .clip(RoundedCornerShape(8.dp))
                            .border(
                                1.5.dp,
                                if (selectedPhotoUri != null) AkinGreenSuccess else if (selectedType == BioDataType.MARRIAGE) Color(0xFFD97706) else MaterialTheme.colorScheme.primary,
                                RoundedCornerShape(8.dp)
                            )
                            .background(Color.White)
                            .clickable { photoPickerLauncher.launch("image/*") },
                        contentAlignment = Alignment.Center
                    ) {
                        if (selectedPhotoUri != null) {
                            AsyncImage(
                                model = selectedPhotoUri,
                                contentDescription = "Candidate Photo",
                                contentScale = ContentScale.Crop,
                                modifier = Modifier.fillMaxSize()
                            )
                        } else {
                            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                                Icon(
                                    imageVector = Icons.Default.AddPhotoAlternate,
                                    contentDescription = "Add Candidate Photo",
                                    tint = if (selectedType == BioDataType.MARRIAGE) Color(0xFFD97706) else MaterialTheme.colorScheme.primary,
                                    modifier = Modifier.size(26.dp)
                                )
                                Spacer(modifier = Modifier.height(2.dp))
                                Text(
                                    "Add Photo",
                                    fontSize = 9.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = if (selectedType == BioDataType.MARRIAGE) Color(0xFFD97706) else MaterialTheme.colorScheme.primary
                                )
                            }
                        }
                    }

                    Spacer(modifier = Modifier.width(12.dp))

                    Column(modifier = Modifier.weight(1f)) {
                        Text(
                            text = if (selectedPhotoUri != null) "✅ Candidate Photo Attached" else "📷 Upload Candidate Photo (Optional)",
                            fontSize = 12.5.sp,
                            fontWeight = FontWeight.Bold,
                            color = MaterialTheme.colorScheme.onSurface
                        )
                        Text(
                            text = "Photo will be cleanly positioned on top-right of Bio Data PDF",
                            fontSize = 10.5.sp,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                        Spacer(modifier = Modifier.height(6.dp))
                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            Button(
                                onClick = { photoPickerLauncher.launch("image/*") },
                                shape = RoundedCornerShape(8.dp),
                                colors = if (selectedType == BioDataType.MARRIAGE) ButtonDefaults.buttonColors(containerColor = Color(0xFFD97706)) else ButtonDefaults.buttonColors(),
                                contentPadding = PaddingValues(horizontal = 12.dp, vertical = 4.dp),
                                modifier = Modifier.height(32.dp)
                            ) {
                                Icon(Icons.Default.CloudUpload, contentDescription = null, modifier = Modifier.size(13.dp))
                                Spacer(modifier = Modifier.width(4.dp))
                                Text(if (selectedPhotoUri != null) "Change" else "Choose Photo", fontSize = 11.sp)
                            }
                            if (selectedPhotoUri != null) {
                                OutlinedButton(
                                    onClick = { selectedPhotoUri = null },
                                    shape = RoundedCornerShape(8.dp),
                                    contentPadding = PaddingValues(horizontal = 8.dp, vertical = 4.dp),
                                    modifier = Modifier.height(32.dp)
                                ) {
                                    Icon(Icons.Default.Delete, contentDescription = "Remove", tint = Color(0xFFDC2626), modifier = Modifier.size(13.dp))
                                    Spacer(modifier = Modifier.width(2.dp))
                                    Text("Remove", fontSize = 10.5.sp, color = Color(0xFFDC2626))
                                }
                            }
                        }
                    }
                }
            }

            Spacer(modifier = Modifier.height(14.dp))

            // Form Fields for Selected Bio Data Type
            if (selectedType == BioDataType.MARRIAGE) {
                // ==================== MARRIAGE BIODATA FORM ====================
                Text("1. Personal, Family & Astrological Details", fontSize = 13.sp, fontWeight = FontWeight.Bold)
                Spacer(modifier = Modifier.height(6.dp))

                OutlinedTextField(
                    value = fullName,
                    onValueChange = { fullName = it },
                    label = { Text("Candidate Full Name (Default: Akash Internet Hub)") },
                    modifier = Modifier.fillMaxWidth(),
                    singleLine = true
                )
                Spacer(modifier = Modifier.height(6.dp))

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    OutlinedTextField(
                        value = dob,
                        onValueChange = { dob = it },
                        label = { Text("Date of Birth") },
                        modifier = Modifier.weight(1f),
                        singleLine = true
                    )
                    OutlinedTextField(
                        value = birthTime,
                        onValueChange = { birthTime = it },
                        label = { Text("Birth Time") },
                        modifier = Modifier.weight(1f),
                        singleLine = true
                    )
                }
                Spacer(modifier = Modifier.height(6.dp))

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    OutlinedTextField(
                        value = birthPlace,
                        onValueChange = { birthPlace = it },
                        label = { Text("Birth Place") },
                        modifier = Modifier.weight(1f),
                        singleLine = true
                    )
                    OutlinedTextField(
                        value = height,
                        onValueChange = { height = it },
                        label = { Text("Height") },
                        modifier = Modifier.weight(1f),
                        singleLine = true
                    )
                }
                Spacer(modifier = Modifier.height(6.dp))

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    OutlinedTextField(
                        value = religionCaste,
                        onValueChange = { religionCaste = it },
                        label = { Text("Religion / Caste") },
                        modifier = Modifier.weight(1f),
                        singleLine = true
                    )
                    OutlinedTextField(
                        value = gotraRashi,
                        onValueChange = { gotraRashi = it },
                        label = { Text("Gotra / Zodiac Rashi") },
                        modifier = Modifier.weight(1f),
                        singleLine = true
                    )
                }

                Spacer(modifier = Modifier.height(10.dp))

                Text("Education & Income Details:", fontSize = 12.sp, fontWeight = FontWeight.SemiBold)
                Spacer(modifier = Modifier.height(4.dp))
                OutlinedTextField(
                    value = qualification,
                    onValueChange = { qualification = it },
                    label = { Text("Highest Educational Qualification") },
                    modifier = Modifier.fillMaxWidth(),
                    singleLine = true
                )
                Spacer(modifier = Modifier.height(4.dp))
                OutlinedTextField(
                    value = occupation,
                    onValueChange = { occupation = it },
                    label = { Text("Current Occupation / Business") },
                    modifier = Modifier.fillMaxWidth(),
                    singleLine = true
                )
                Spacer(modifier = Modifier.height(4.dp))
                OutlinedTextField(
                    value = annualIncome,
                    onValueChange = { annualIncome = it },
                    label = { Text("Annual Income (CTC)") },
                    modifier = Modifier.fillMaxWidth(),
                    singleLine = true
                )

                Spacer(modifier = Modifier.height(10.dp))

                Text("Family & Contact Details:", fontSize = 12.sp, fontWeight = FontWeight.SemiBold)
                Spacer(modifier = Modifier.height(4.dp))
                OutlinedTextField(
                    value = fatherName,
                    onValueChange = { fatherName = it },
                    label = { Text("Father's Name & Occupation") },
                    modifier = Modifier.fillMaxWidth(),
                    singleLine = true
                )
                Spacer(modifier = Modifier.height(4.dp))
                OutlinedTextField(
                    value = motherName,
                    onValueChange = { motherName = it },
                    label = { Text("Mother's Name & Occupation") },
                    modifier = Modifier.fillMaxWidth(),
                    singleLine = true
                )
                Spacer(modifier = Modifier.height(4.dp))
                OutlinedTextField(
                    value = siblings,
                    onValueChange = { siblings = it },
                    label = { Text("Siblings (Brothers & Sisters)") },
                    modifier = Modifier.fillMaxWidth()
                )
                Spacer(modifier = Modifier.height(4.dp))
                OutlinedTextField(
                    value = contactNumber,
                    onValueChange = { contactNumber = it },
                    label = { Text("Contact Mobile Number") },
                    modifier = Modifier.fillMaxWidth(),
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Phone),
                    singleLine = true
                )
                Spacer(modifier = Modifier.height(4.dp))
                OutlinedTextField(
                    value = permanentAddress,
                    onValueChange = { permanentAddress = it },
                    label = { Text("Permanent Native Address") },
                    modifier = Modifier.fillMaxWidth()
                )
            } else {
                // ==================== SIMPLE JOB BIODATA FORM ====================
                Text("1. Fill Personal & Employment Details", fontSize = 13.sp, fontWeight = FontWeight.Bold)
                Spacer(modifier = Modifier.height(6.dp))

                OutlinedTextField(
                    value = fullName,
                    onValueChange = { fullName = it },
                    label = { Text("Full Name (Default: Akash Internet Hub)") },
                    modifier = Modifier.fillMaxWidth(),
                    singleLine = true
                )
                Spacer(modifier = Modifier.height(6.dp))

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    OutlinedTextField(
                        value = fatherName,
                        onValueChange = { fatherName = it },
                        label = { Text("Father's Name") },
                        modifier = Modifier.weight(1f),
                        singleLine = true
                    )
                    OutlinedTextField(
                        value = motherName,
                        onValueChange = { motherName = it },
                        label = { Text("Mother's Name") },
                        modifier = Modifier.weight(1f),
                        singleLine = true
                    )
                }
                Spacer(modifier = Modifier.height(6.dp))

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    OutlinedTextField(
                        value = dob,
                        onValueChange = { dob = it },
                        label = { Text("Date of Birth") },
                        modifier = Modifier.weight(1f),
                        singleLine = true
                    )
                    OutlinedTextField(
                        value = gender,
                        onValueChange = { gender = it },
                        label = { Text("Gender") },
                        modifier = Modifier.weight(1f),
                        singleLine = true
                    )
                }
                Spacer(modifier = Modifier.height(6.dp))

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    OutlinedTextField(
                        value = maritalStatus,
                        onValueChange = { maritalStatus = it },
                        label = { Text("Marital Status") },
                        modifier = Modifier.weight(1f),
                        singleLine = true
                    )
                    OutlinedTextField(
                        value = nationality,
                        onValueChange = { nationality = it },
                        label = { Text("Nationality") },
                        modifier = Modifier.weight(1f),
                        singleLine = true
                    )
                }
                Spacer(modifier = Modifier.height(6.dp))

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    OutlinedTextField(
                        value = contactNumber,
                        onValueChange = { contactNumber = it },
                        label = { Text("Mobile Number") },
                        modifier = Modifier.weight(1f),
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Phone),
                        singleLine = true
                    )
                    OutlinedTextField(
                        value = emailAddress,
                        onValueChange = { emailAddress = it },
                        label = { Text("Email Address") },
                        modifier = Modifier.weight(1f),
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Email),
                        singleLine = true
                    )
                }

                Spacer(modifier = Modifier.height(10.dp))

                Text("Address & Objective Details:", fontSize = 12.sp, fontWeight = FontWeight.SemiBold)
                Spacer(modifier = Modifier.height(4.dp))
                OutlinedTextField(
                    value = careerObjective,
                    onValueChange = { careerObjective = it },
                    label = { Text("Career Objective / Summary") },
                    modifier = Modifier.fillMaxWidth()
                )
                Spacer(modifier = Modifier.height(4.dp))
                OutlinedTextField(
                    value = presentAddress,
                    onValueChange = { presentAddress = it },
                    label = { Text("Present Address") },
                    modifier = Modifier.fillMaxWidth()
                )
                Spacer(modifier = Modifier.height(4.dp))
                OutlinedTextField(
                    value = permanentAddress,
                    onValueChange = { permanentAddress = it },
                    label = { Text("Permanent Address") },
                    modifier = Modifier.fillMaxWidth()
                )

                Spacer(modifier = Modifier.height(10.dp))

                Text("Qualifications, Skills & Experience:", fontSize = 12.sp, fontWeight = FontWeight.SemiBold)
                Spacer(modifier = Modifier.height(4.dp))
                OutlinedTextField(
                    value = qualification,
                    onValueChange = { qualification = it },
                    label = { Text("Academic Qualification (Highest Degree & Board)") },
                    modifier = Modifier.fillMaxWidth()
                )
                Spacer(modifier = Modifier.height(4.dp))
                OutlinedTextField(
                    value = technicalSkills,
                    onValueChange = { technicalSkills = it },
                    label = { Text("Technical / Computer Skills") },
                    modifier = Modifier.fillMaxWidth()
                )
                Spacer(modifier = Modifier.height(4.dp))
                OutlinedTextField(
                    value = workExperience,
                    onValueChange = { workExperience = it },
                    label = { Text("Work Experience") },
                    modifier = Modifier.fillMaxWidth()
                )
                Spacer(modifier = Modifier.height(4.dp))
                OutlinedTextField(
                    value = languagesKnown,
                    onValueChange = { languagesKnown = it },
                    label = { Text("Languages Known") },
                    modifier = Modifier.fillMaxWidth(),
                    singleLine = true
                )
            }

            Spacer(modifier = Modifier.height(16.dp))

            // Step 2: Live Preview (Clean English Format - No Hindi)
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = if (selectedType == BioDataType.MARRIAGE) "2. Marriage Template Live Preview" else "2. Job Bio Data Live Preview",
                    fontSize = 13.sp,
                    fontWeight = FontWeight.Bold
                )
                Text(
                    text = if (isPaid) "✅ Unlocked High-Res" else "🔒 Watermarked Preview",
                    fontSize = 11.sp,
                    fontWeight = FontWeight.Bold,
                    color = if (isPaid) AkinGreenSuccess else Color(0xFFD97706)
                )
            }
            Spacer(modifier = Modifier.height(6.dp))

            // ==================== LIVE PREVIEW CARD ====================
            if (selectedType == BioDataType.MARRIAGE) {
                // Marriage Preview (Clean English Header & Golden Border)
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(350.dp)
                        .clip(RoundedCornerShape(8.dp))
                        .border(2.dp, Color(0xFFD97706), RoundedCornerShape(8.dp))
                        .background(Color(0xFFFFFBEB))
                ) {
                    Column(
                        modifier = Modifier
                            .fillMaxSize()
                            .padding(14.dp)
                            .then(if (isSimulatingScreenshotProtection) Modifier.blur(14.dp) else Modifier)
                    ) {
                        // Clean Header (No Hindi) & Candidate Photo
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.Top
                        ) {
                            Column(modifier = Modifier.weight(1f)) {
                                Text(
                                    text = "✦ CURRICULUM VITAE ✦",
                                    fontSize = 10.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = Color(0xFF991B1B),
                                    letterSpacing = 1.sp
                                )
                                Text(
                                    text = "MARRIAGE BIODATA",
                                    fontSize = 13.5.sp,
                                    fontWeight = FontWeight.ExtraBold,
                                    color = Color(0xFFB45309),
                                    letterSpacing = 1.sp
                                )
                            }

                            // Top-Right Candidate Photo Box
                            Surface(
                                shape = RoundedCornerShape(4.dp),
                                border = BorderStroke(1.5.dp, Color(0xFFD97706)),
                                color = Color(0xFFFEF3C7),
                                modifier = Modifier.size(42.dp, 50.dp)
                            ) {
                                if (selectedPhotoUri != null) {
                                    AsyncImage(
                                        model = selectedPhotoUri,
                                        contentDescription = "Candidate Photo",
                                        contentScale = ContentScale.Crop,
                                        modifier = Modifier.fillMaxSize()
                                    )
                                } else {
                                    Box(contentAlignment = Alignment.Center) {
                                        Icon(Icons.Default.Person, contentDescription = "Photo", tint = Color(0xFFD97706), modifier = Modifier.size(24.dp))
                                    }
                                }
                            }
                        }

                        Spacer(modifier = Modifier.height(8.dp))

                        // Personal section
                        Text("PERSONAL DETAILS", fontSize = 9.sp, fontWeight = FontWeight.Bold, color = Color(0xFF991B1B))
                        BioDataFieldRow("Name", fullName.ifBlank { "Akash Internet Hub" })
                        BioDataFieldRow("DOB", "$dob ($birthTime)")
                        BioDataFieldRow("Place", birthPlace)
                        BioDataFieldRow("Height", "$height, $complexion")
                        BioDataFieldRow("Caste/Gotra", "$religionCaste / $gotraRashi")

                        Spacer(modifier = Modifier.height(4.dp))

                        // Education & Career
                        Text("EDUCATION & PROFESSION", fontSize = 9.sp, fontWeight = FontWeight.Bold, color = Color(0xFF991B1B))
                        BioDataFieldRow("Degree", qualification)
                        BioDataFieldRow("Occupation", occupation)
                        BioDataFieldRow("Income", annualIncome)

                        Spacer(modifier = Modifier.height(4.dp))

                        // Family
                        Text("FAMILY BACKGROUND", fontSize = 9.sp, fontWeight = FontWeight.Bold, color = Color(0xFF991B1B))
                        BioDataFieldRow("Father", fatherName)
                        BioDataFieldRow("Mother", motherName)
                        BioDataFieldRow("Contact", contactNumber)
                    }

                    // Center Watermark Overlay
                    if (!isPaid) {
                        Text(
                            text = hubInfo.watermarkText.ifBlank { "Downloaded From Akash Internet Hub" },
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Bold,
                            color = Color(0xFF991B1B).copy(alpha = 0.16f),
                            modifier = Modifier
                                .align(Alignment.Center)
                                .rotate(-28f)
                        )
                    }

                    if (isSimulatingScreenshotProtection) {
                        Box(
                            modifier = Modifier
                                .matchParentSize()
                                .background(Color.Black.copy(alpha = 0.65f)),
                            contentAlignment = Alignment.Center
                        ) {
                            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                                Icon(Icons.Default.Security, contentDescription = "Protected", tint = AkinAmberAccent, modifier = Modifier.size(36.dp))
                                Spacer(modifier = Modifier.height(4.dp))
                                Text(
                                    text = "SCREENSHOT PROTECTED",
                                    color = Color.White,
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 13.sp
                                )
                                Text(
                                    text = "Download original PDF via buttons below",
                                    color = Color.White.copy(alpha = 0.8f),
                                    fontSize = 10.sp
                                )
                            }
                        }
                    }
                }
            } else {
                // Simple Job Bio Data Preview (Corporate Formal Navy/White)
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(350.dp)
                        .clip(RoundedCornerShape(8.dp))
                        .border(2.dp, Color(0xFF1E3A8A), RoundedCornerShape(8.dp))
                        .background(Color.White)
                ) {
                    Column(
                        modifier = Modifier
                            .fillMaxSize()
                            .padding(14.dp)
                            .then(if (isSimulatingScreenshotProtection) Modifier.blur(14.dp) else Modifier)
                    ) {
                        // Header Bar & Photo
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.Top
                        ) {
                            Column(modifier = Modifier.weight(1f)) {
                                Text(
                                    text = "BIO-DATA FOR EMPLOYMENT",
                                    fontSize = 12.sp,
                                    fontWeight = FontWeight.ExtraBold,
                                    color = Color(0xFF1E3A8A),
                                    letterSpacing = 0.8.sp
                                )
                                Text(
                                    text = fullName.ifBlank { "Akash Internet Hub" },
                                    fontSize = 11.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = Color(0xFF0F172A)
                                )
                                Text(
                                    text = "$contactNumber • $emailAddress",
                                    fontSize = 9.sp,
                                    color = Color(0xFF475569)
                                )
                            }

                            // Top-Right Photo Box
                            Surface(
                                shape = RoundedCornerShape(4.dp),
                                border = BorderStroke(1.dp, Color(0xFF1E3A8A)),
                                color = Color(0xFFF1F5F9),
                                modifier = Modifier.size(42.dp, 50.dp)
                            ) {
                                if (selectedPhotoUri != null) {
                                    AsyncImage(
                                        model = selectedPhotoUri,
                                        contentDescription = "Photo",
                                        contentScale = ContentScale.Crop,
                                        modifier = Modifier.fillMaxSize()
                                    )
                                } else {
                                    Box(contentAlignment = Alignment.Center) {
                                        Icon(Icons.Default.Person, contentDescription = "Photo", tint = Color(0xFF64748B), modifier = Modifier.size(24.dp))
                                    }
                                }
                            }
                        }

                        Spacer(modifier = Modifier.height(6.dp))

                        // Personal Info
                        Surface(
                            shape = RoundedCornerShape(2.dp),
                            color = Color(0xFFE0E7FF),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Text(
                                "1. PERSONAL DETAILS",
                                fontSize = 8.5.sp,
                                fontWeight = FontWeight.Bold,
                                color = Color(0xFF1E3A8A),
                                modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                            )
                        }
                        JobBioDataFieldRow("Father's Name", fatherName)
                        JobBioDataFieldRow("DOB / Gender", "$dob • $gender")
                        JobBioDataFieldRow("Marital / Nat.", "$maritalStatus • $nationality")

                        Spacer(modifier = Modifier.height(3.dp))

                        // Academic & Skills
                        Surface(
                            shape = RoundedCornerShape(2.dp),
                            color = Color(0xFFE0E7FF),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Text(
                                "2. QUALIFICATIONS & SKILLS",
                                fontSize = 8.5.sp,
                                fontWeight = FontWeight.Bold,
                                color = Color(0xFF1E3A8A),
                                modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                            )
                        }
                        JobBioDataFieldRow("Degree", qualification)
                        JobBioDataFieldRow("Skills", technicalSkills)
                        JobBioDataFieldRow("Experience", workExperience)

                        Spacer(modifier = Modifier.height(4.dp))

                        // Declaration & Signature Place
                        Text(
                            text = "Declaration: I hereby declare that all information given above is true.",
                            fontSize = 8.sp,
                            color = Color(0xFF64748B)
                        )
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Text("Date: 22/08/2026", fontSize = 8.sp, fontWeight = FontWeight.Bold, color = Color(0xFF1E293B))
                            Text("(Signature of Candidate)", fontSize = 8.sp, fontWeight = FontWeight.Bold, color = Color(0xFF1E293B))
                        }
                    }

                    // Watermark Overlay
                    if (!isPaid) {
                        Text(
                            text = hubInfo.watermarkText.ifBlank { "Downloaded From Akash Internet Hub" },
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Bold,
                            color = Color(0xFF1E3A8A).copy(alpha = 0.16f),
                            modifier = Modifier
                                .align(Alignment.Center)
                                .rotate(-28f)
                        )
                    }

                    if (isSimulatingScreenshotProtection) {
                        Box(
                            modifier = Modifier
                                .matchParentSize()
                                .background(Color.Black.copy(alpha = 0.65f)),
                            contentAlignment = Alignment.Center
                        ) {
                            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                                Icon(Icons.Default.Security, contentDescription = "Protected", tint = MaterialTheme.colorScheme.primary, modifier = Modifier.size(36.dp))
                                Spacer(modifier = Modifier.height(4.dp))
                                Text(
                                    text = "SCREENSHOT PROTECTED",
                                    color = Color.White,
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 13.sp
                                )
                                Text(
                                    text = "Download original PDF via buttons below",
                                    color = Color.White.copy(alpha = 0.8f),
                                    fontSize = 10.sp
                                )
                            }
                        }
                    }
                }
            }

            Spacer(modifier = Modifier.height(16.dp))

            // Step 3: Two Clear Download Buttons (Free with Watermark vs HD Unlocked)
            // Button 1: Free Download With Watermark
            OutlinedButton(
                onClick = {
                    coroutineScope.launch {
                        isDownloading = true
                        downloadedFile = null
                        if (selectedType == BioDataType.MARRIAGE) {
                            progressMessage = "Generating Free Marriage Biodata PDF..."
                            val file = DocumentExportHelper.generateAndSaveBioDataPdf(
                                context = context,
                                fullName = fullName,
                                dob = dob,
                                birthTime = birthTime,
                                birthPlace = birthPlace,
                                height = height,
                                complexion = complexion,
                                religionCaste = religionCaste,
                                gotraRashi = gotraRashi,
                                qualification = qualification,
                                occupation = occupation,
                                annualIncome = annualIncome,
                                fatherName = fatherName,
                                motherName = motherName,
                                siblings = siblings,
                                permanentAddress = permanentAddress,
                                contactNumber = contactNumber,
                                photoUri = selectedPhotoUri,
                                isWatermarked = true,
                                watermarkText = hubInfo.watermarkText,
                                onProgressUpdate = { msg -> progressMessage = msg }
                            )
                            downloadedFile = file
                        } else {
                            progressMessage = "Generating Free Job Biodata PDF..."
                            val file = DocumentExportHelper.generateAndSaveSimpleJobBioDataPdf(
                                context = context,
                                fullName = fullName,
                                fatherName = fatherName,
                                motherName = motherName,
                                dob = dob,
                                gender = gender,
                                maritalStatus = maritalStatus,
                                nationality = nationality,
                                religionCategory = religionCategory,
                                contactNumber = contactNumber,
                                emailAddress = emailAddress,
                                presentAddress = presentAddress,
                                permanentAddress = permanentAddress,
                                careerObjective = careerObjective,
                                qualification = qualification,
                                technicalSkills = technicalSkills,
                                workExperience = workExperience,
                                languagesKnown = languagesKnown,
                                photoUri = selectedPhotoUri,
                                isWatermarked = true,
                                watermarkText = hubInfo.watermarkText,
                                onProgressUpdate = { msg -> progressMessage = msg }
                            )
                            downloadedFile = file
                        }
                    }
                },
                modifier = Modifier
                    .fillMaxWidth()
                    .height(46.dp)
                    .testTag("free_biodata_download_button"),
                shape = RoundedCornerShape(10.dp)
            ) {
                Icon(Icons.Default.Download, contentDescription = "Free Download", modifier = Modifier.size(18.dp))
                Spacer(modifier = Modifier.width(6.dp))
                Text(
                    text = hubInfo.freeDownloadButtonText.ifBlank { "Free Download (With Watermark)" },
                    fontSize = 12.sp,
                    fontWeight = FontWeight.SemiBold
                )
            }

            Spacer(modifier = Modifier.height(10.dp))

            if (isPaid) {
                // Unlocked Clean Bio Data PDF Button
                Button(
                    onClick = {
                        coroutineScope.launch {
                            isDownloading = true
                            downloadedFile = null
                            if (selectedType == BioDataType.MARRIAGE) {
                                progressMessage = "Generating Clean Marriage Biodata..."
                                val file = DocumentExportHelper.generateAndSaveBioDataPdf(
                                    context = context,
                                    fullName = fullName,
                                    dob = dob,
                                    birthTime = birthTime,
                                    birthPlace = birthPlace,
                                    height = height,
                                    complexion = complexion,
                                    religionCaste = religionCaste,
                                    gotraRashi = gotraRashi,
                                    qualification = qualification,
                                    occupation = occupation,
                                    annualIncome = annualIncome,
                                    fatherName = fatherName,
                                    motherName = motherName,
                                    siblings = siblings,
                                    permanentAddress = permanentAddress,
                                    contactNumber = contactNumber,
                                    photoUri = selectedPhotoUri,
                                    isWatermarked = false,
                                    watermarkText = hubInfo.watermarkText,
                                    onProgressUpdate = { msg -> progressMessage = msg }
                                )
                                downloadedFile = file
                            } else {
                                progressMessage = "Generating Clean Job Biodata..."
                                val file = DocumentExportHelper.generateAndSaveSimpleJobBioDataPdf(
                                    context = context,
                                    fullName = fullName,
                                    fatherName = fatherName,
                                    motherName = motherName,
                                    dob = dob,
                                    gender = gender,
                                    maritalStatus = maritalStatus,
                                    nationality = nationality,
                                    religionCategory = religionCategory,
                                    contactNumber = contactNumber,
                                    emailAddress = emailAddress,
                                    presentAddress = presentAddress,
                                    permanentAddress = permanentAddress,
                                    careerObjective = careerObjective,
                                    qualification = qualification,
                                    technicalSkills = technicalSkills,
                                    workExperience = workExperience,
                                    languagesKnown = languagesKnown,
                                    photoUri = selectedPhotoUri,
                                    isWatermarked = false,
                                    watermarkText = hubInfo.watermarkText,
                                    onProgressUpdate = { msg -> progressMessage = msg }
                                )
                                downloadedFile = file
                            }
                        }
                    },
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(48.dp)
                        .testTag("download_unlocked_biodata_button"),
                    shape = RoundedCornerShape(10.dp),
                    colors = ButtonDefaults.buttonColors(containerColor = AkinGreenSuccess, contentColor = Color.White)
                ) {
                    Icon(Icons.Default.DownloadDone, contentDescription = "Download Clean PDF", modifier = Modifier.size(20.dp))
                    Spacer(modifier = Modifier.width(8.dp))
                    Column(horizontalAlignment = Alignment.Start) {
                        Text(
                            text = hubInfo.unlockedButtonText.ifBlank { "✨ Download Clean Bio Data PDF (Unlocked)" },
                            fontSize = 13.sp,
                            fontWeight = FontWeight.Bold,
                            color = Color.White
                        )
                        Text(
                            text = if (selectedType == BioDataType.MARRIAGE) "100% Watermark Free • Marriage Bio Data" else "100% Watermark Free • Job Bio Data",
                            fontSize = 9.sp,
                            color = Color.White.copy(alpha = 0.9f)
                        )
                    }
                }
            } else {
                // Button 2: Pay & Get Clean PDF
                val priceInt = hubInfo.hdPriceText.toIntOrNull() ?: 100
                Button(
                    onClick = {
                        val itemName = if (selectedType == BioDataType.MARRIAGE) "Marriage Bio Data Clean PDF (Without Watermark)" else "Employment Job Bio Data Clean PDF (Without Watermark)"
                        onTriggerPayment(
                            itemName,
                            priceInt,
                            "pl_TSYm6s9zRAFbLQ"
                        )
                    },
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(48.dp)
                        .testTag("pay_biodata_clean_pdf_button"),
                    shape = RoundedCornerShape(10.dp),
                    colors = ButtonDefaults.buttonColors(
                        containerColor = if (selectedType == BioDataType.MARRIAGE) Color(0xFFD97706) else MaterialTheme.colorScheme.primary
                    )
                ) {
                    Icon(Icons.Default.PictureAsPdf, contentDescription = "Pay PDF", modifier = Modifier.size(18.dp))
                    Spacer(modifier = Modifier.width(8.dp))
                    Column(horizontalAlignment = Alignment.Start) {
                        Text(
                            text = hubInfo.payHdButtonText.ifBlank { "Pay ₹$priceInt & Get Clean PDF (No Watermark)" },
                            fontSize = 13.sp,
                            fontWeight = FontWeight.Bold,
                            color = Color.White
                        )
                        Text(
                            text = if (selectedType == BioDataType.MARRIAGE) "Razorpay Checkout • High-Resolution Marriage Template" else "Razorpay Checkout • High-Resolution Job Format",
                            fontSize = 9.sp,
                            color = Color.White.copy(alpha = 0.9f)
                        )
                    }
                }
            }
        }
    }
}

@Composable
private fun BioDataFieldRow(label: String, value: String) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 2.dp),
        verticalAlignment = Alignment.Top
    ) {
        Text(
            text = "$label :",
            fontSize = 9.5.sp,
            fontWeight = FontWeight.Bold,
            color = Color(0xFF78350F),
            modifier = Modifier.width(90.dp)
        )
        Text(
            text = value,
            fontSize = 9.5.sp,
            color = Color(0xFF1E293B),
            modifier = Modifier.weight(1f),
            lineHeight = 13.sp
        )
    }
}

@Composable
private fun JobBioDataFieldRow(label: String, value: String) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 1.5.dp),
        verticalAlignment = Alignment.Top
    ) {
        Text(
            text = "$label :",
            fontSize = 9.sp,
            fontWeight = FontWeight.Bold,
            color = Color(0xFF334155),
            modifier = Modifier.width(96.dp)
        )
        Text(
            text = value,
            fontSize = 9.sp,
            color = Color(0xFF0F172A),
            modifier = Modifier.weight(1f),
            lineHeight = 12.sp
        )
    }
}
