package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.components.ContactHelper
import com.example.ui.dialogs.PaymentIncompletePopupDialog
import com.example.ui.dialogs.RazorpayPaymentDialog
import com.example.ui.screens.tools.AiBioDataMakerTool
import com.example.ui.screens.tools.AiMediaGeneratorTool
import com.example.ui.screens.tools.AiPhotoTools
import com.example.ui.screens.tools.AiResumeBuilderTool
import com.example.ui.screens.tools.DocumentConvertersTool
import com.example.ui.screens.tools.IdCardMergerTool
import com.example.ui.theme.AkinAmberAccent
import com.example.ui.theme.AkinGreenSuccess
import com.example.ui.viewmodel.AgeCalculationResult
import com.example.ui.viewmodel.ElectricityBillResult

data class ToolPaymentRequest(
    val toolKey: String,
    val itemName: String,
    val amountRs: Int,
    val buttonId: String
)

@Composable
fun ToolsScreen(
    ageResult: AgeCalculationResult?,
    billResult: ElectricityBillResult?,
    hubInfo: com.example.data.model.HubInfo = com.example.data.model.HubInfo(),
    onCalculateAge: (dobY: Int, dobM: Int, dobD: Int, cutY: Int, cutM: Int, cutD: Int) -> Unit,
    onCalculateBill: (Double) -> Unit,
    onPayElectricityBillClick: () -> Unit,
    onBackToHome: () -> Unit = {},
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    var selectedToolIndex by remember { mutableStateOf(0) }
    var activePaymentRequest by remember { mutableStateOf<ToolPaymentRequest?>(null) }
    var cancelledPaymentInfo by remember { mutableStateOf<ToolPaymentRequest?>(null) }
    val unlockedToolKeys = remember { mutableStateListOf<String>() }

    // Age calculator inputs
    var birthYear by remember { mutableStateOf("2000") }
    var birthMonth by remember { mutableStateOf("1") }
    var birthDay by remember { mutableStateOf("1") }

    var cutoffYear by remember { mutableStateOf("2026") }
    var cutoffMonth by remember { mutableStateOf("8") }
    var cutoffDay by remember { mutableStateOf("1") }

    // Units input
    var unitsText by remember { mutableStateOf("150") }

    // Photo Spec preset
    var selectedPhotoPreset by remember { mutableStateOf("ADRE 2026 (Assam Direct Recruitment)") }

    // Razorpay checkout modal
    activePaymentRequest?.let { req ->
        RazorpayPaymentDialog(
            itemName = req.itemName,
            amountRs = req.amountRs,
            paymentButtonId = req.buttonId,
            onPaymentSuccess = {
                if (!unlockedToolKeys.contains(req.toolKey)) {
                    unlockedToolKeys.add(req.toolKey)
                }
            },
            onPaymentCancelledOrFailed = {
                cancelledPaymentInfo = req
            },
            onDismiss = { activePaymentRequest = null }
        )
    }

    // Popup notification if user cancels, skips or payment is not completed
    cancelledPaymentInfo?.let { req ->
        PaymentIncompletePopupDialog(
            itemName = req.itemName,
            amountRs = req.amountRs,
            onRetryPayment = {
                activePaymentRequest = req
                cancelledPaymentInfo = null
            },
            onDismiss = { cancelledPaymentInfo = null }
        )
    }

    LazyColumn(
        modifier = modifier
            .fillMaxSize()
            .testTag("tools_screen_list"),
        contentPadding = PaddingValues(start = 16.dp, end = 16.dp, top = 12.dp, bottom = 90.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        // Quick Navigation Bar back to Main Hub
        item {
            Surface(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(12.dp))
                    .clickable { onBackToHome() }
                    .testTag("tools_back_to_home_banner"),
                color = MaterialTheme.colorScheme.surfaceVariant
            ) {
                Row(
                    modifier = Modifier.padding(horizontal = 14.dp, vertical = 10.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(
                            imageVector = Icons.Default.ArrowBack,
                            contentDescription = "Back",
                            tint = MaterialTheme.colorScheme.primary,
                            modifier = Modifier.size(18.dp)
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = "Back to All Services & Schemes",
                            fontSize = 13.sp,
                            fontWeight = FontWeight.SemiBold,
                            color = MaterialTheme.colorScheme.primary
                        )
                    }
                    Surface(
                        shape = RoundedCornerShape(20.dp),
                        color = MaterialTheme.colorScheme.primary
                    ) {
                        Text(
                            text = "🏠 Home",
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Bold,
                            color = MaterialTheme.colorScheme.onPrimary,
                            modifier = Modifier.padding(horizontal = 10.dp, vertical = 4.dp)
                        )
                    }
                }
            }
        }
        item {
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("tools_header_card"),
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.primaryContainer)
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text(
                            text = "AI Cyber & Media Tools",
                            fontSize = 17.sp,
                            fontWeight = FontWeight.Bold,
                            color = MaterialTheme.colorScheme.onPrimaryContainer
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                        Surface(
                            shape = RoundedCornerShape(6.dp),
                            color = AkinAmberAccent
                        ) {
                            Text(
                                text = "Akash Hub AI",
                                fontSize = 10.sp,
                                fontWeight = FontWeight.Black,
                                color = Color.Black,
                                modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                            )
                        }
                    }
                    Spacer(modifier = Modifier.height(4.dp))
                    Text(
                        text = "Passport photo maker, AI CV Resume, Bio Data maker, ID card 1-page merge, converters, text-to-photo & AI video generation.",
                        fontSize = 11.sp,
                        color = MaterialTheme.colorScheme.onPrimaryContainer.copy(alpha = 0.85f),
                        lineHeight = 15.sp
                    )
                }
            }
        }

        // Tool Selector Tabs
        item {
            ScrollableTabRow(
                selectedTabIndex = selectedToolIndex,
                edgePadding = 0.dp,
                containerColor = Color.Transparent,
                divider = {}
            ) {
                Tab(
                    selected = selectedToolIndex == 0,
                    onClick = { selectedToolIndex = 0 },
                    text = { Text("📸 Passport & Crop", fontSize = 12.sp, fontWeight = if (selectedToolIndex == 0) FontWeight.Bold else FontWeight.Normal) }
                )
                Tab(
                    selected = selectedToolIndex == 1,
                    onClick = { selectedToolIndex = 1 },
                    text = { Text("📄 AI CV Resume", fontSize = 12.sp, fontWeight = if (selectedToolIndex == 1) FontWeight.Bold else FontWeight.Normal) }
                )
                Tab(
                    selected = selectedToolIndex == 2,
                    onClick = { selectedToolIndex = 2 },
                    text = { Text("💍 AI Bio Data", fontSize = 12.sp, fontWeight = if (selectedToolIndex == 2) FontWeight.Bold else FontWeight.Normal) }
                )
                Tab(
                    selected = selectedToolIndex == 3,
                    onClick = { selectedToolIndex = 3 },
                    text = { Text("🪪 ID Card 1-Page", fontSize = 12.sp, fontWeight = if (selectedToolIndex == 3) FontWeight.Bold else FontWeight.Normal) }
                )
                Tab(
                    selected = selectedToolIndex == 4,
                    onClick = { selectedToolIndex = 4 },
                    text = { Text("📄 Converters & OCR", fontSize = 12.sp, fontWeight = if (selectedToolIndex == 4) FontWeight.Bold else FontWeight.Normal) }
                )
                Tab(
                    selected = selectedToolIndex == 5,
                    onClick = { selectedToolIndex = 5 },
                    text = { Text("✨ AI Photo & Video", fontSize = 12.sp, fontWeight = if (selectedToolIndex == 5) FontWeight.Bold else FontWeight.Normal) }
                )
                Tab(
                    selected = selectedToolIndex == 6,
                    onClick = { selectedToolIndex = 6 },
                    text = { Text("🎂 Age Calculator", fontSize = 12.sp, fontWeight = if (selectedToolIndex == 6) FontWeight.Bold else FontWeight.Normal) }
                )
                Tab(
                    selected = selectedToolIndex == 7,
                    onClick = { selectedToolIndex = 7 },
                    text = { Text("⚡ APDCL & Specs", fontSize = 12.sp, fontWeight = if (selectedToolIndex == 7) FontWeight.Bold else FontWeight.Normal) }
                )
            }
        }

        // TOOL 0: AI PASSPORT MAKER & MANUAL CROP
        if (selectedToolIndex == 0) {
            item {
                AiPhotoTools(
                    unlockedTools = unlockedToolKeys.toSet(),
                    onTriggerPayment = { toolKey, itemName, amount, buttonId ->
                        activePaymentRequest = ToolPaymentRequest(toolKey, itemName, amount, buttonId)
                    }
                )
            }
        }

        // TOOL 1: AI CV / RESUME BUILDER (₹150 Razorpay pl_TSYk8HTVZ5jbAb)
        if (selectedToolIndex == 1) {
            item {
                AiResumeBuilderTool(
                    hubInfo = hubInfo,
                    isPaid = unlockedToolKeys.contains("cv_resume_hd"),
                    onTriggerPayment = { itemName, amount, buttonId ->
                        activePaymentRequest = ToolPaymentRequest("cv_resume_hd", itemName, amount, buttonId)
                    }
                )
            }
        }

        // TOOL 2: AI BIO DATA MAKER (₹100 Razorpay pl_TSYm6s9zRAFbLQ)
        if (selectedToolIndex == 2) {
            item {
                AiBioDataMakerTool(
                    hubInfo = hubInfo,
                    isPaid = unlockedToolKeys.contains("biodata_hd"),
                    onTriggerPayment = { itemName, amount, buttonId ->
                        activePaymentRequest = ToolPaymentRequest("biodata_hd", itemName, amount, buttonId)
                    }
                )
            }
        }

        // TOOL 3: ID CARD AUTO DETECT & 1-PAGE MERGER
        if (selectedToolIndex == 3) {
            item {
                IdCardMergerTool(
                    isPaid = unlockedToolKeys.contains("id_card_hd"),
                    onTriggerPayment = { toolName ->
                        activePaymentRequest = ToolPaymentRequest("id_card_hd", toolName, 10, "pl_TSU7RSYHOBTThn")
                    }
                )
            }
        }

        // TOOL 4: DOCUMENT CONVERTERS & OCR TEXT EDIT
        if (selectedToolIndex == 4) {
            item {
                DocumentConvertersTool(
                    isPaid = unlockedToolKeys.contains("doc_convert_hd"),
                    onTriggerPayment = { toolName ->
                        activePaymentRequest = ToolPaymentRequest("doc_convert_hd", toolName, 10, "pl_TSU7RSYHOBTThn")
                    }
                )
            }
        }

        // TOOL 5: AI PROMPT TO PHOTO & VIDEO GENERATOR
        if (selectedToolIndex == 5) {
            item {
                AiMediaGeneratorTool(
                    isPaid = unlockedToolKeys.contains("ai_media_hd"),
                    hubInfo = hubInfo,
                    onTriggerPayment = { toolName ->
                        activePaymentRequest = ToolPaymentRequest("ai_media_hd", toolName, 10, "pl_TSU7RSYHOBTThn")
                    }
                )
            }
        }

        // TOOL 6: AGE CALCULATOR
        if (selectedToolIndex == 6) {
            item {
                Card(
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("age_calculator_card"),
                    shape = RoundedCornerShape(16.dp),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                    elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
                ) {
                    Column(modifier = Modifier.padding(16.dp)) {
                        Text(
                            text = "Govt Job Age Eligibility Calculator",
                            fontSize = 15.sp,
                            fontWeight = FontWeight.Bold,
                            color = MaterialTheme.colorScheme.onSurface
                        )
                        Text(
                            text = "Calculate exact age as on cutoff date (e.g. 01/08/2026)",
                            fontSize = 11.sp,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )

                        Spacer(modifier = Modifier.height(14.dp))

                        Text("Date of Birth (DD / MM / YYYY):", fontSize = 12.sp, fontWeight = FontWeight.SemiBold)
                        Spacer(modifier = Modifier.height(6.dp))
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            OutlinedTextField(
                                value = birthDay,
                                onValueChange = { if (it.length <= 2) birthDay = it },
                                label = { Text("Day") },
                                modifier = Modifier.weight(1f),
                                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                                singleLine = true
                            )
                            OutlinedTextField(
                                value = birthMonth,
                                onValueChange = { if (it.length <= 2) birthMonth = it },
                                label = { Text("Month") },
                                modifier = Modifier.weight(1f),
                                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                                singleLine = true
                            )
                            OutlinedTextField(
                                value = birthYear,
                                onValueChange = { if (it.length <= 4) birthYear = it },
                                label = { Text("Year") },
                                modifier = Modifier.weight(1.3f),
                                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                                singleLine = true
                            )
                        }

                        Spacer(modifier = Modifier.height(12.dp))

                        Text("Cutoff Date (DD / MM / YYYY):", fontSize = 12.sp, fontWeight = FontWeight.SemiBold)
                        Spacer(modifier = Modifier.height(6.dp))
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            OutlinedTextField(
                                value = cutoffDay,
                                onValueChange = { if (it.length <= 2) cutoffDay = it },
                                label = { Text("Day") },
                                modifier = Modifier.weight(1f),
                                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                                singleLine = true
                            )
                            OutlinedTextField(
                                value = cutoffMonth,
                                onValueChange = { if (it.length <= 2) cutoffMonth = it },
                                label = { Text("Month") },
                                modifier = Modifier.weight(1f),
                                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                                singleLine = true
                            )
                            OutlinedTextField(
                                value = cutoffYear,
                                onValueChange = { if (it.length <= 4) cutoffYear = it },
                                label = { Text("Year") },
                                modifier = Modifier.weight(1.3f),
                                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                                singleLine = true
                            )
                        }

                        Spacer(modifier = Modifier.height(14.dp))

                        Button(
                            onClick = {
                                val bY = birthYear.toIntOrNull() ?: 2000
                                val bM = birthMonth.toIntOrNull() ?: 1
                                val bD = birthDay.toIntOrNull() ?: 1
                                val cY = cutoffYear.toIntOrNull() ?: 2026
                                val cM = cutoffMonth.toIntOrNull() ?: 8
                                val cD = cutoffDay.toIntOrNull() ?: 1
                                onCalculateAge(bY, bM, bD, cY, cM, cD)
                            },
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(44.dp)
                                .testTag("calculate_age_button"),
                            shape = RoundedCornerShape(10.dp)
                        ) {
                            Icon(Icons.Default.Calculate, contentDescription = "Calculate")
                            Spacer(modifier = Modifier.width(6.dp))
                            Text("Calculate Exact Age", fontWeight = FontWeight.Bold)
                        }

                        if (ageResult != null) {
                            Spacer(modifier = Modifier.height(16.dp))
                            Card(
                                modifier = Modifier.fillMaxWidth(),
                                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.secondaryContainer.copy(alpha = 0.5f)),
                                shape = RoundedCornerShape(12.dp)
                            ) {
                                Column(modifier = Modifier.padding(14.dp)) {
                                    Text(
                                        text = "Your Exact Age on Cutoff Date:",
                                        fontSize = 12.sp,
                                        fontWeight = FontWeight.SemiBold,
                                        color = MaterialTheme.colorScheme.onSecondaryContainer
                                    )
                                    Spacer(modifier = Modifier.height(6.dp))
                                    Text(
                                        text = "${ageResult.years} Years, ${ageResult.months} Months, ${ageResult.days} Days",
                                        fontSize = 18.sp,
                                        fontWeight = FontWeight.ExtraBold,
                                        color = MaterialTheme.colorScheme.primary
                                    )
                                    Spacer(modifier = Modifier.height(10.dp))
                                    Text(
                                        text = "Eligible Recruitment Exams:",
                                        fontSize = 12.sp,
                                        fontWeight = FontWeight.Bold
                                    )
                                    Spacer(modifier = Modifier.height(4.dp))
                                    if (ageResult.eligibleExams.isEmpty()) {
                                        Text(
                                            text = "⚠️ Age falls outside standard general category brackets. Check specific OBC/SC/ST age relaxation.",
                                            fontSize = 11.sp,
                                            color = MaterialTheme.colorScheme.error
                                        )
                                    } else {
                                        ageResult.eligibleExams.forEach { exam ->
                                            Row(
                                                verticalAlignment = Alignment.CenterVertically,
                                                modifier = Modifier.padding(vertical = 2.dp)
                                            ) {
                                                Icon(
                                                    imageVector = Icons.Default.CheckCircle,
                                                    contentDescription = "Eligible",
                                                    tint = AkinGreenSuccess,
                                                    modifier = Modifier.size(14.dp)
                                                )
                                                Spacer(modifier = Modifier.width(6.dp))
                                                Text(text = exam, fontSize = 11.sp)
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }

        // TOOL 7: APDCL BILL ESTIMATOR & PHOTO SPECS
        if (selectedToolIndex == 7) {
            item {
                Card(
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("photo_spec_card"),
                    shape = RoundedCornerShape(16.dp),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                    elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
                ) {
                    Column(modifier = Modifier.padding(16.dp)) {
                        Text(
                            text = "Govt Portal Photo & Signature Guidelines",
                            fontSize = 15.sp,
                            fontWeight = FontWeight.Bold
                        )
                        Text(
                            text = "Exact specifications required to prevent form rejection on Govt servers",
                            fontSize = 11.sp,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )

                        Spacer(modifier = Modifier.height(12.dp))

                        val presets = listOf(
                            "ADRE 2026 (Assam Direct Recruitment)",
                            "Assam Police 2026",
                            "SSC GD / CGL Exam",
                            "New PAN Card (Form 49A)",
                            "Passport Seva"
                        )

                        presets.forEach { preset ->
                            val isSelected = selectedPhotoPreset == preset
                            Surface(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(vertical = 3.dp)
                                    .clip(RoundedCornerShape(8.dp))
                                    .background(if (isSelected) MaterialTheme.colorScheme.primaryContainer else MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.4f)),
                                onClick = { selectedPhotoPreset = preset }
                            ) {
                                Row(
                                    modifier = Modifier.padding(horizontal = 12.dp, vertical = 8.dp),
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    RadioButton(
                                        selected = isSelected,
                                        onClick = { selectedPhotoPreset = preset },
                                        modifier = Modifier.size(20.dp)
                                    )
                                    Spacer(modifier = Modifier.width(8.dp))
                                    Text(
                                        text = preset,
                                        fontSize = 12.sp,
                                        fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal
                                    )
                                }
                            }
                        }

                        Spacer(modifier = Modifier.height(14.dp))

                        Card(
                            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.secondaryContainer.copy(alpha = 0.5f)),
                            shape = RoundedCornerShape(12.dp)
                        ) {
                            Column(modifier = Modifier.padding(12.dp)) {
                                Text(
                                    text = "Specs for $selectedPhotoPreset:",
                                    fontSize = 13.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = MaterialTheme.colorScheme.onSecondaryContainer
                                )
                                Spacer(modifier = Modifier.height(6.dp))
                                Text("📸 Photograph: 200 × 230 px | 20 KB - 50 KB | JPG / JPEG | White / Light Background", fontSize = 11.sp, lineHeight = 15.sp)
                                Spacer(modifier = Modifier.height(4.dp))
                                Text("✍️ Signature: 140 × 60 px | 10 KB - 20 KB | Black Ink Pen on White Paper", fontSize = 11.sp, lineHeight = 15.sp)
                            }
                        }
                    }
                }
            }

            item {
                Card(
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("electricity_calc_card"),
                    shape = RoundedCornerShape(16.dp),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                    elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
                ) {
                    Column(modifier = Modifier.padding(16.dp)) {
                        Text(
                            text = "APDCL Electricity Bill Calculator",
                            fontSize = 15.sp,
                            fontWeight = FontWeight.Bold
                        )
                        Text(
                            text = "Assam Power Distribution LT Domestic Tariff Estimator",
                            fontSize = 11.sp,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )

                        Spacer(modifier = Modifier.height(14.dp))

                        OutlinedTextField(
                            value = unitsText,
                            onValueChange = {
                                unitsText = it
                                val u = it.toDoubleOrNull() ?: 0.0
                                onCalculateBill(u)
                            },
                            label = { Text("Monthly Consumed Units (kWh)") },
                            modifier = Modifier
                                .fillMaxWidth()
                                .testTag("bill_units_input"),
                            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                            singleLine = true,
                            trailingIcon = { Text("Units", modifier = Modifier.padding(end = 12.dp), fontSize = 12.sp) }
                        )

                        if (billResult != null) {
                            Spacer(modifier = Modifier.height(14.dp))
                            Card(
                                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.7f)),
                                shape = RoundedCornerShape(12.dp)
                            ) {
                                Column(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .padding(14.dp)
                                ) {
                                    Row(
                                        modifier = Modifier.fillMaxWidth(),
                                        horizontalArrangement = Arrangement.SpaceBetween
                                    ) {
                                        Text("Energy Charge (Slab):", fontSize = 12.sp)
                                        Text("₹${"%.2f".format(billResult.energyCharge)}", fontSize = 12.sp, fontWeight = FontWeight.SemiBold)
                                    }
                                    Spacer(modifier = Modifier.height(4.dp))
                                    Row(
                                        modifier = Modifier.fillMaxWidth(),
                                        horizontalArrangement = Arrangement.SpaceBetween
                                    ) {
                                        Text("Fixed Monthly Charge:", fontSize = 12.sp)
                                        Text("₹${"%.2f".format(billResult.fixedCharge)}", fontSize = 12.sp, fontWeight = FontWeight.SemiBold)
                                    }
                                    Spacer(modifier = Modifier.height(4.dp))
                                    Row(
                                        modifier = Modifier.fillMaxWidth(),
                                        horizontalArrangement = Arrangement.SpaceBetween
                                    ) {
                                        Text("Electricity Duty (5%):", fontSize = 12.sp)
                                        Text("₹${"%.2f".format(billResult.dutyTax)}", fontSize = 12.sp, fontWeight = FontWeight.SemiBold)
                                    }

                                    HorizontalDivider(
                                        modifier = Modifier.padding(vertical = 8.dp),
                                        color = MaterialTheme.colorScheme.onPrimaryContainer.copy(alpha = 0.2f)
                                    )

                                    Row(
                                        modifier = Modifier.fillMaxWidth(),
                                        horizontalArrangement = Arrangement.SpaceBetween,
                                        verticalAlignment = Alignment.CenterVertically
                                    ) {
                                        Text("Estimated Bill Total:", fontSize = 14.sp, fontWeight = FontWeight.Bold)
                                        Text(
                                            text = "₹${"%.2f".format(billResult.totalEstimatedBill)}",
                                            fontSize = 18.sp,
                                            fontWeight = FontWeight.ExtraBold,
                                            color = MaterialTheme.colorScheme.primary
                                        )
                                    }
                                }
                            }

                            Spacer(modifier = Modifier.height(14.dp))

                            Button(
                                onClick = onPayElectricityBillClick,
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .testTag("pay_bill_at_hub_button"),
                                shape = RoundedCornerShape(10.dp)
                            ) {
                                Icon(Icons.Default.Bolt, contentDescription = "Pay")
                                Spacer(modifier = Modifier.width(6.dp))
                                Text("Pay APDCL Bill at Akash Hub", fontWeight = FontWeight.Bold)
                            }
                        }
                    }
                }
            }
        }
    }
}
