package com.example.ui.viewmodel

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.localization.AppLanguage
import com.example.data.model.*
import com.example.data.repository.AkinhubRepository
import com.example.data.repository.GovernmentSchemesRepository
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date
import java.util.Locale

enum class AppTab(val title: String, val iconName: String) {
    EXPLORE("Services", "home"),
    SCHEMES("Govt Schemes", "account_balance"),
    JOBS("Govt Jobs", "work"),
    TRACKER("My Tracker", "assignment"),
    TOOLS("Smart Tools", "build"),
    ABOUT("About Hub", "storefront")
}

data class AgeCalculationResult(
    val years: Int,
    val months: Int,
    val days: Int,
    val totalDays: Long,
    val eligibleExams: List<String>
)

data class ElectricityBillResult(
    val units: Double,
    val energyCharge: Double,
    val fixedCharge: Double,
    val dutyTax: Double,
    val totalEstimatedBill: Double
)

data class AkinhubUiState(
    val selectedTab: AppTab = AppTab.EXPLORE,
    val selectedCategory: ServiceCategory = ServiceCategory.ALL,
    val currentLanguage: AppLanguage = AppLanguage.ENGLISH,
    val searchQuery: String = "",
    val services: List<HubService> = emptyList(),
    val jobAlerts: List<JobAlert> = emptyList(),
    val governmentSchemes: List<GovernmentScheme> = emptyList(),
    val applications: List<ServiceApplication> = emptyList(),
    val printOrders: List<PrintOrder> = emptyList(),
    val notices: List<NoticeAlert> = emptyList(),
    val reviews: List<HubReview> = emptyList(),
    val selectedServiceForDetail: HubService? = null,
    val selectedJobForDetail: JobAlert? = null,
    val activeApplicationForReceipt: ServiceApplication? = null,
    val showApplyDialogForService: HubService? = null,
    val showPrintOrderDialog: Boolean = false,
    val showPrintClosedDialog: Boolean = false,
    val isVoiceGreetingEnabled: Boolean = true,
    val successSnackbarMessage: String? = null,
    // Age Calculator Tool State
    val dobDate: String = "2000-01-01",
    val cutoffDate: String = "2026-08-01",
    val ageResult: AgeCalculationResult? = null,
    // Bill Estimator Tool State
    val consumedUnitsInput: String = "150",
    val billResult: ElectricityBillResult? = null,
    // Tracker Search
    val trackerSearchQuery: String = ""
)

class AkinhubViewModel(
    private val repository: AkinhubRepository = AkinhubRepository(),
    private val schemesRepository: GovernmentSchemesRepository = GovernmentSchemesRepository()
) : ViewModel() {

    private val _uiState = MutableStateFlow(AkinhubUiState())
    val uiState: StateFlow<AkinhubUiState> = _uiState.asStateFlow()
    val hubInfo: StateFlow<HubInfo> = repository.hubInfo

    init {
        // Collect repository flows
        viewModelScope.launch {
            repository.services.collect { list ->
                _uiState.update { it.copy(services = list) }
            }
        }
        viewModelScope.launch {
            repository.jobAlerts.collect { list ->
                _uiState.update { it.copy(jobAlerts = list) }
            }
        }
        viewModelScope.launch {
            schemesRepository.schemes.collect { list ->
                _uiState.update { it.copy(governmentSchemes = list) }
            }
        }
        viewModelScope.launch {
            repository.applications.collect { list ->
                _uiState.update { it.copy(applications = list) }
            }
        }
        viewModelScope.launch {
            repository.printOrders.collect { list ->
                _uiState.update { it.copy(printOrders = list) }
            }
        }
        viewModelScope.launch {
            repository.notices.collect { list ->
                _uiState.update { it.copy(notices = list) }
            }
        }
        viewModelScope.launch {
            repository.reviews.collect { list ->
                _uiState.update { it.copy(reviews = list) }
            }
        }

        // Initialize default tool calculations
        calculateAge(2000, 1, 1, 2026, 8, 1)
        calculateElectricityBill(150.0)
    }

    fun setLanguage(language: AppLanguage) {
        _uiState.update { it.copy(currentLanguage = language) }
    }

    fun setVoiceGreetingEnabled(enabled: Boolean) {
        _uiState.update { it.copy(isVoiceGreetingEnabled = enabled) }
    }

    fun refreshDailySchemes() {
        schemesRepository.refreshDailySchemes()
    }

    fun selectTab(tab: AppTab) {
        _uiState.update { it.copy(selectedTab = tab) }
    }

    fun selectCategory(category: ServiceCategory) {
        _uiState.update { it.copy(selectedCategory = category) }
    }

    fun updateSearchQuery(query: String) {
        _uiState.update { it.copy(searchQuery = query) }
    }

    fun updateTrackerSearchQuery(query: String) {
        _uiState.update { it.copy(trackerSearchQuery = query) }
    }

    fun showServiceDetail(service: HubService?) {
        _uiState.update { it.copy(selectedServiceForDetail = service) }
    }

    fun showJobDetail(job: JobAlert?) {
        _uiState.update { it.copy(selectedJobForDetail = job) }
    }

    fun openApplyDialog(service: HubService?) {
        _uiState.update { it.copy(showApplyDialogForService = service, selectedServiceForDetail = null) }
    }

    fun closeApplyDialog() {
        _uiState.update { it.copy(showApplyDialogForService = null) }
    }

    fun handlePrintButtonClick() {
        val active = com.example.ui.components.ContactHelper.isPrintHoursActive()
        if (active) {
            _uiState.update { it.copy(showPrintOrderDialog = true, showPrintClosedDialog = false) }
        } else {
            _uiState.update { it.copy(showPrintClosedDialog = true, showPrintOrderDialog = false) }
        }
    }

    fun openPrintOrderDialog(show: Boolean) {
        if (show) {
            handlePrintButtonClick()
        } else {
            _uiState.update { it.copy(showPrintOrderDialog = false) }
        }
    }

    fun closePrintClosedDialog() {
        _uiState.update { it.copy(showPrintClosedDialog = false) }
    }

    fun viewApplicationReceipt(app: ServiceApplication?) {
        _uiState.update { it.copy(activeApplicationForReceipt = app) }
    }

    fun clearSnackbarMessage() {
        _uiState.update { it.copy(successSnackbarMessage = null) }
    }

    fun submitServiceApplication(
        service: HubService,
        applicantName: String,
        phone: String,
        email: String,
        attachedDocs: List<String>,
        notes: String
    ) {
        val newApp = repository.submitServiceApplication(
            service = service,
            name = applicantName,
            phone = phone,
            email = email,
            attachedDocs = attachedDocs,
            notes = notes
        )
        _uiState.update {
            it.copy(
                showApplyDialogForService = null,
                activeApplicationForReceipt = newApp,
                selectedTab = AppTab.TRACKER,
                successSnackbarMessage = "Application submitted! Tracking ID: ${newApp.id}"
            )
        }
    }

    fun submitPrintOrder(
        title: String,
        printType: String,
        copies: Int,
        pages: Int,
        isLaminated: Boolean,
        customerName: String,
        customerPhone: String
    ) {
        val order = repository.submitPrintOrder(
            title = title,
            printType = printType,
            copies = copies,
            pages = pages,
            isLaminated = isLaminated,
            customerName = customerName,
            customerPhone = customerPhone
        )
        _uiState.update {
            it.copy(
                showPrintOrderDialog = false,
                selectedTab = AppTab.TRACKER,
                successSnackbarMessage = "Print Order #${order.id} Placed! Ready for pickup soon."
            )
        }
    }

    fun calculateAge(dobY: Int, dobM: Int, dobD: Int, cutY: Int, cutM: Int, cutD: Int) {
        var years = cutY - dobY
        var months = cutM - dobM
        var days = cutD - dobD

        if (days < 0) {
            months -= 1
            days += 30
        }
        if (months < 0) {
            years -= 1
            months += 12
        }

        val eligible = mutableListOf<String>()
        if (years in 18..40) eligible.add("ADRE Assam Grade III & IV (18-40 yrs)")
        if (years in 18..25) eligible.add("Assam Police Constable (18-25 yrs)")
        if (years in 18..23) eligible.add("SSC GD Constable (18-23 yrs)")
        if (years in 18..33) eligible.add("Railway RRB Non-Tech (18-33 yrs)")
        if (years in 21..38) eligible.add("APSC Combined Competitive Exam (21-38 yrs)")
        if (years in 18..27) eligible.add("SSC CHSL / MTS (18-27 yrs)")

        val totalDays = (years * 365L) + (months * 30L) + days
        val result = AgeCalculationResult(
            years = maxOf(0, years),
            months = maxOf(0, months),
            days = maxOf(0, days),
            totalDays = totalDays,
            eligibleExams = eligible
        )

        _uiState.update {
            it.copy(
                dobDate = "$dobY-${dobM.toString().padStart(2, '0')}-${dobD.toString().padStart(2, '0')}",
                cutoffDate = "$cutY-${cutM.toString().padStart(2, '0')}-${cutD.toString().padStart(2, '0')}",
                ageResult = result
            )
        }
    }

    fun calculateElectricityBill(units: Double) {
        val safeUnits = maxOf(0.0, units)
        var energyCharge = 0.0

        if (safeUnits <= 120) {
            energyCharge = safeUnits * 5.40
        } else if (safeUnits <= 240) {
            energyCharge = (120 * 5.40) + ((safeUnits - 120) * 6.65)
        } else {
            energyCharge = (120 * 5.40) + (120 * 6.65) + ((safeUnits - 240) * 7.65)
        }

        val fixedCharge = 60.0
        val dutyTax = (energyCharge + fixedCharge) * 0.05
        val total = energyCharge + fixedCharge + dutyTax

        _uiState.update {
            it.copy(
                consumedUnitsInput = safeUnits.toInt().toString(),
                billResult = ElectricityBillResult(
                    units = safeUnits,
                    energyCharge = energyCharge,
                    fixedCharge = fixedCharge,
                    dutyTax = dutyTax,
                    totalEstimatedBill = total
                )
            )
        }
    }

    // ==================== ADMIN METHODS ====================

    fun updateHubInfo(info: HubInfo) {
        repository.updateHubInfo(info)
    }

    fun addOrUpdateService(service: HubService) {
        repository.addOrUpdateService(service)
    }

    fun deleteService(serviceId: String) {
        repository.deleteService(serviceId)
    }

    fun addOrUpdateJob(job: JobAlert) {
        repository.addOrUpdateJob(job)
    }

    fun deleteJob(jobId: String) {
        repository.deleteJob(jobId)
    }

    fun updateApplicationStatus(
        appId: String,
        newStatus: ApplicationStatus,
        remark: String? = null,
        trackingRef: String? = null
    ) {
        repository.updateApplicationStatus(appId, newStatus, remark, trackingRef)
    }

    fun addOrUpdateApplication(application: ServiceApplication) {
        repository.addOrUpdateApplication(application)
    }

    fun deleteApplication(appId: String) {
        repository.deleteApplication(appId)
    }

    fun addOrUpdateNotice(notice: NoticeAlert) {
        repository.addOrUpdateNotice(notice)
    }

    fun deleteNotice(noticeId: String) {
        repository.deleteNotice(noticeId)
    }

    fun updatePrintOrderStatus(orderId: String, newStatus: String) {
        repository.updatePrintOrderStatus(orderId, newStatus)
    }

    fun toggleShopStatus(isOpen: Boolean, customMessage: String? = null) {
        val current = repository.hubInfo.value
        repository.updateHubInfo(
            current.copy(
                isShopOpen = isOpen,
                shopClosedMessage = customMessage ?: current.shopClosedMessage
            )
        )
    }

    fun setBroadcastPopup(show: Boolean, title: String, message: String, isEmergency: Boolean = false) {
        val current = repository.hubInfo.value
        repository.updateHubInfo(
            current.copy(
                showPopupNotification = show,
                popupNotificationTitle = title,
                popupNotificationMessage = message,
                isEmergencyBroadcast = isEmergency
            )
        )
    }

    fun updateAdminCredentials(newUsername: String, newPass: String) {
        val current = repository.hubInfo.value
        repository.updateHubInfo(
            current.copy(
                adminUsername = newUsername,
                adminPassword = newPass
            )
        )
    }

    fun updateRazorpayConfig(buttonId: String, upiId: String? = null) {
        val current = repository.hubInfo.value
        repository.updateHubInfo(
            current.copy(
                razorpayButtonId = buttonId,
                upiId = upiId ?: current.upiId
            )
        )
    }

    fun updateToolRazorpayButtons(
        defaultBtn: String,
        passportBtn: String,
        resumeBtn: String,
        bioDataBtn: String,
        idCardBtn: String,
        convertersBtn: String,
        upiId: String? = null
    ) {
        val current = repository.hubInfo.value
        repository.updateHubInfo(
            current.copy(
                razorpayButtonId = defaultBtn,
                razorpayButtonIdPassport = passportBtn,
                razorpayButtonIdResume = resumeBtn,
                razorpayButtonIdBioData = bioDataBtn,
                razorpayButtonIdIdCard = idCardBtn,
                razorpayButtonIdConverters = convertersBtn,
                upiId = upiId ?: current.upiId
            )
        )
    }

    fun updateReceiptConfig(
        header: String,
        subHeader: String,
        address: String,
        email: String,
        note: String,
        sealText: String
    ) {
        val current = repository.hubInfo.value
        repository.updateHubInfo(
            current.copy(
                receiptHeader = header,
                receiptSubHeader = subHeader,
                receiptAddress = address,
                receiptEmail = email,
                receiptCustomNote = note,
                receiptSealText = sealText
            )
        )
    }

    fun updateButtonAndPriceConfig(
        payText: String,
        freeText: String,
        unlockedText: String,
        watermark: String,
        hdPrice: String
    ) {
        val current = repository.hubInfo.value
        repository.updateHubInfo(
            current.copy(
                payHdButtonText = payText,
                freeDownloadButtonText = freeText,
                unlockedButtonText = unlockedText,
                watermarkText = watermark,
                hdPriceText = hdPrice
            )
        )
    }

    fun updateAppThemeColor(themeId: String) {
        val current = repository.hubInfo.value
        repository.updateHubInfo(
            current.copy(appThemeColorId = themeId)
        )
    }
}
