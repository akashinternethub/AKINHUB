package com.example.ui.screens.tools

import android.content.Context
import android.graphics.*
import android.graphics.Color as AndroidColor
import android.widget.Toast
import androidx.compose.animation.*
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.theme.AkinAmberAccent
import com.example.ui.theme.AkinBlueLight
import com.example.ui.theme.AkinGreenSuccess
import com.example.ui.theme.AkinNavyDark

data class FormalSuitOption(
    val id: String,
    val name: String,
    val category: String,
    val suitColor: Color,
    val lapelColor: Color,
    val shirtColor: Color,
    val tieColor: Color,
    val hasTie: Boolean = true,
    val isFemale: Boolean = false,
    val iconEmoji: String = "👔"
)

val FORMAL_SUIT_CATALOG = listOf(
    FormalSuitOption("navy_red_tie", "Navy Executive Suit & Red Tie", "Corporate & Govt", Color(0xFF1E3A8A), Color(0xFF172554), Color(0xFFFFFFFF), Color(0xFFDC2626), true, false, "👔"),
    FormalSuitOption("charcoal_black", "Charcoal Slim Suit & Black Tie", "Official / ADRE", Color(0xFF1E293B), Color(0xFF0F172A), Color(0xFFF8FAFC), Color(0xFF020617), true, false, "🤵"),
    FormalSuitOption("royal_blue", "Royal Blue Blazer & Sky Shirt", "Formal Business", Color(0xFF1D4ED8), Color(0xFF1E40AF), Color(0xFFE0F2FE), Color(0xFFB45309), true, false, "👔"),
    FormalSuitOption("black_tuxedo", "Classic Black Tuxedo & Bowtie", "Diplomatic / Visa", Color(0xFF09090B), Color(0xFF18181B), Color(0xFFFFFFFF), Color(0xFF18181B), true, false, "🤵‍♂️"),
    FormalSuitOption("italian_grey", "Executive Grey Suit & Blue Tie", "Modern Corporate", Color(0xFF475569), Color(0xFF334155), Color(0xFFFFFFFF), Color(0xFF2563EB), true, false, "👔"),
    FormalSuitOption("nehru_navy", "Modi Coat / Nehru Bandhgala", "Indian Formal Govt", Color(0xFF1E3A8A), Color(0xFF1E3A8A), Color(0xFFFEF08A), Color.Transparent, false, false, "🥻"),
    FormalSuitOption("nehru_maroon", "Khadi Silk Bandhgala (Maroon)", "Indian Official", Color(0xFF881337), Color(0xFF701A75), Color(0xFFFFF1F2), Color.Transparent, false, false, "🥻"),
    FormalSuitOption("white_shirt_tie", "Crisp White Shirt & Navy Tie", "Interview / Exam", Color(0xFFE2E8F0), Color(0xFFCBD5E1), Color(0xFFFFFFFF), Color(0xFF1E3A8A), true, false, "👔"),
    FormalSuitOption("women_navy_blazer", "Women's Navy Corporate Blazer", "Women's Formal", Color(0xFF1E3A8A), Color(0xFF172554), Color(0xFFFFFFFF), Color(0xFF0284C7), true, true, "👩‍💼"),
    FormalSuitOption("women_grey_blazer", "Women's Charcoal Executive Suit", "Women's Formal", Color(0xFF334155), Color(0xFF1E293B), Color(0xFFF1F5F9), Color(0xFF9333EA), true, true, "👩‍💼"),
    FormalSuitOption("women_silk_saree", "Women's Formal Silk Saree & Border", "Indian Official", Color(0xFF9A3412), Color(0xFFD97706), Color(0xFFFEF3C7), Color.Transparent, false, true, "🥻"),
    FormalSuitOption("doctor_coat", "Doctor White Lab Coat & Tie", "Medical & Healthcare", Color(0xFFF8FAFC), Color(0xFFE2E8F0), Color(0xFF38BDF8), Color(0xFF0369A1), true, false, "🥼"),
    FormalSuitOption("advocate_coat", "Advocate Black Coat & White Band", "Legal & Judiciary", Color(0xFF020617), Color(0xFF0F172A), Color(0xFFFFFFFF), Color(0xFFFFFFFF), false, false, "⚖️")
)

@Composable
fun AiPhotoTools(
    unlockedTools: Set<String> = emptySet(),
    onTriggerPayment: (toolKey: String, itemName: String, amountRs: Int, buttonId: String) -> Unit,
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    var subTab by remember { mutableStateOf(0) } // 0: Passport Maker, 1: Background Remover, 2: Crop by Marker & Size

    Column(
        modifier = modifier.fillMaxWidth(),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        // Mode Switcher
        ScrollableTabRow(
            selectedTabIndex = subTab,
            edgePadding = 0.dp,
            containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f),
            modifier = Modifier.clip(RoundedCornerShape(12.dp)),
            divider = {}
        ) {
            Tab(
                selected = subTab == 0,
                onClick = { subTab = 0 },
                text = { Text("📸 Passport Maker", fontSize = 12.sp, fontWeight = if (subTab == 0) FontWeight.Bold else FontWeight.Normal) }
            )
            Tab(
                selected = subTab == 1,
                onClick = { subTab = 1 },
                text = { Text("✂️ AI Auto Bg Removal", fontSize = 12.sp, fontWeight = if (subTab == 1) FontWeight.Bold else FontWeight.Normal) }
            )
            Tab(
                selected = subTab == 2,
                onClick = { subTab = 2 },
                text = { Text("📐 Crop by Marker & Size", fontSize = 12.sp, fontWeight = if (subTab == 2) FontWeight.Bold else FontWeight.Normal) }
            )
        }

        if (subTab == 0) {
            PassportPhotoStudio(
                isPaid = unlockedTools.contains("passport_hd"),
                onTriggerPayment = {
                    onTriggerPayment("passport_hd", "AI Passport Photo HD (No Watermark)", 10, "pl_TSU7RSYHOBTThn")
                }
            )
        } else if (subTab == 1) {
            AiBackgroundRemoverStudio(
                isPaid = unlockedTools.contains("bg_remover_hd"),
                onTriggerPayment = {
                    onTriggerPayment("bg_remover_hd", "AI Background Removal HD (No Watermark)", 10, "pl_TSU7RSYHOBTThn")
                }
            )
        } else {
            ManualCropStudio(
                isPaid = unlockedTools.contains("crop_hd"),
                onTriggerPayment = {
                    onTriggerPayment("crop_hd", "Govt Portal Custom Cropped HD Photo", 10, "pl_TSU7RSYHOBTThn")
                }
            )
        }
    }
}

@Composable
fun PassportPhotoStudio(
    isPaid: Boolean,
    onTriggerPayment: () -> Unit
) {
    val context = LocalContext.current
    var selectedPreset by remember { mutableStateOf("Passport (3.5 × 4.5 cm)") }
    var brightness by remember { mutableStateOf(1.0f) }
    var contrast by remember { mutableStateOf(1.0f) }
    var warmth by remember { mutableStateOf(1.0f) }
    var strokeColorIndex by remember { mutableStateOf(0) } // 0: Black, 1: White, 2: Dark Blue, 3: None
    var strokeWidth by remember { mutableStateOf(2) } // 1 to 4 px
    var copiesOnA4 by remember { mutableStateOf(8) } // 4, 8, 12, 16, 24, 32
    var isA4Mode by remember { mutableStateOf(false) }
    var selectedSuit by remember { mutableStateOf(FORMAL_SUIT_CATALOG[0]) }

    val strokeColors = listOf(
        Pair("Black Stroke", Color.Black),
        Pair("White Border", Color.White),
        Pair("Navy Blue", AkinNavyDark),
        Pair("No Stroke", Color.Transparent)
    )

    Card(
        modifier = Modifier
            .fillMaxWidth()
            .testTag("passport_studio_card"),
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
    ) {
        Column(modifier = Modifier.padding(16.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column {
                    Text(
                        text = "AI Passport Photo Studio",
                        fontSize = 15.sp,
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.onSurface
                    )
                    Text(
                        text = "Formal Suits, Color Correction, Stroke & A4 Grid",
                        fontSize = 11.sp,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
                Surface(
                    shape = RoundedCornerShape(8.dp),
                    color = if (isPaid) AkinGreenSuccess.copy(alpha = 0.15f) else AkinAmberAccent.copy(alpha = 0.2f)
                ) {
                    Text(
                        text = if (isPaid) "✨ HD UNLOCKED" else "AI SUIT STUDIO",
                        fontSize = 10.sp,
                        fontWeight = FontWeight.Bold,
                        color = if (isPaid) AkinGreenSuccess else Color(0xFFB45309),
                        modifier = Modifier.padding(horizontal = 8.dp, vertical = 3.dp)
                    )
                }
            }

            Spacer(modifier = Modifier.height(14.dp))

            // Photo Preview Canvas
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(if (isA4Mode) 220.dp else 200.dp)
                    .background(Color(0xFFE2E8F0), RoundedCornerShape(12.dp))
                    .border(1.dp, Color(0xFFCBD5E1), RoundedCornerShape(12.dp)),
                contentAlignment = Alignment.Center
            ) {
                if (isA4Mode) {
                    // A4 Sheet Grid Preview
                    A4SheetPreviewCanvas(
                        copies = copiesOnA4,
                        strokeColor = strokeColors[strokeColorIndex].second,
                        strokeWidth = strokeWidth,
                        brightness = brightness,
                        suit = selectedSuit
                    )
                } else {
                    // Single Passport Photo Preview with interactive suit rendering
                    SinglePassportPreview(
                        strokeColor = strokeColors[strokeColorIndex].second,
                        strokeWidth = strokeWidth,
                        brightness = brightness,
                        contrast = contrast,
                        warmth = warmth,
                        suit = selectedSuit
                    )
                }
            }

            Spacer(modifier = Modifier.height(14.dp))

            // Formal Suit Selector Carousel (12+ Options)
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = "👔 Choose Formal Suit & Attire (12+ Options):",
                    fontSize = 12.sp,
                    fontWeight = FontWeight.Bold,
                    color = MaterialTheme.colorScheme.onSurface
                )
                Text(
                    text = selectedSuit.category,
                    fontSize = 10.sp,
                    color = MaterialTheme.colorScheme.primary,
                    fontWeight = FontWeight.SemiBold
                )
            }
            Spacer(modifier = Modifier.height(6.dp))

            LazyRow(
                horizontalArrangement = Arrangement.spacedBy(8.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                items(FORMAL_SUIT_CATALOG) { suit ->
                    val isSel = selectedSuit.id == suit.id
                    Surface(
                        shape = RoundedCornerShape(10.dp),
                        color = if (isSel) MaterialTheme.colorScheme.primaryContainer else MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.6f),
                        border = if (isSel) CardDefaults.outlinedCardBorder().copy(brush = Brush.linearGradient(listOf(MaterialTheme.colorScheme.primary, MaterialTheme.colorScheme.primary)), width = 2.dp) else CardDefaults.outlinedCardBorder(),
                        modifier = Modifier
                            .clickable { selectedSuit = suit }
                    ) {
                        Row(
                            modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(text = suit.iconEmoji, fontSize = 14.sp)
                            Spacer(modifier = Modifier.width(6.dp))
                            Column {
                                Text(
                                    text = suit.name,
                                    fontSize = 11.sp,
                                    fontWeight = if (isSel) FontWeight.Bold else FontWeight.Normal,
                                    color = if (isSel) MaterialTheme.colorScheme.onPrimaryContainer else MaterialTheme.colorScheme.onSurface
                                )
                                Text(
                                    text = suit.category,
                                    fontSize = 9.sp,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                )
                            }
                        }
                    }
                }
            }

            Spacer(modifier = Modifier.height(14.dp))

            // Aspect & Presets
            Text("Crop Preset:", fontSize = 12.sp, fontWeight = FontWeight.SemiBold)
            Spacer(modifier = Modifier.height(4.dp))
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(6.dp)
            ) {
                listOf("Passport (3.5×4.5 cm)", "Stamp Size (2.5×3 cm)", "Square 2×2 Inch").forEach { p ->
                    val isSel = selectedPreset == p
                    Surface(
                        shape = RoundedCornerShape(8.dp),
                        color = if (isSel) MaterialTheme.colorScheme.primaryContainer else MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f),
                        modifier = Modifier
                            .weight(1f)
                            .clickable { selectedPreset = p }
                    ) {
                        Text(
                            text = p,
                            fontSize = 10.sp,
                            fontWeight = if (isSel) FontWeight.Bold else FontWeight.Normal,
                            textAlign = TextAlign.Center,
                            modifier = Modifier.padding(vertical = 6.dp)
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.height(12.dp))

            // Color Correction Sliders
            Text("AI Color Correction & Lighting:", fontSize = 12.sp, fontWeight = FontWeight.SemiBold)
            Spacer(modifier = Modifier.height(4.dp))
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text("Brightness", fontSize = 11.sp, modifier = Modifier.width(70.dp))
                Slider(
                    value = brightness,
                    onValueChange = { brightness = it },
                    valueRange = 0.6f..1.4f,
                    modifier = Modifier.weight(1f)
                )
            }
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text("Contrast", fontSize = 11.sp, modifier = Modifier.width(70.dp))
                Slider(
                    value = contrast,
                    onValueChange = { contrast = it },
                    valueRange = 0.6f..1.4f,
                    modifier = Modifier.weight(1f)
                )
            }
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text("Warmth", fontSize = 11.sp, modifier = Modifier.width(70.dp))
                Slider(
                    value = warmth,
                    onValueChange = { warmth = it },
                    valueRange = 0.6f..1.4f,
                    modifier = Modifier.weight(1f)
                )
            }

            Spacer(modifier = Modifier.height(8.dp))

            // Photo Border / Stroke
            Text("Photo Cut Border / Stroke:", fontSize = 12.sp, fontWeight = FontWeight.SemiBold)
            Spacer(modifier = Modifier.height(4.dp))
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(6.dp)
            ) {
                strokeColors.forEachIndexed { idx, pair ->
                    val isSel = strokeColorIndex == idx
                    OutlinedButton(
                        onClick = { strokeColorIndex = idx },
                        modifier = Modifier.weight(1f),
                        colors = ButtonDefaults.outlinedButtonColors(
                            containerColor = if (isSel) MaterialTheme.colorScheme.primaryContainer else Color.Transparent
                        ),
                        contentPadding = PaddingValues(horizontal = 4.dp, vertical = 4.dp)
                    ) {
                        Text(pair.first, fontSize = 9.sp, fontWeight = if (isSel) FontWeight.Bold else FontWeight.Normal)
                    }
                }
            }

            Spacer(modifier = Modifier.height(12.dp))

            // Add to A4 Paper Option
            Surface(
                shape = RoundedCornerShape(12.dp),
                color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.4f),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(12.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(Icons.Default.Dashboard, contentDescription = "A4", tint = MaterialTheme.colorScheme.primary, modifier = Modifier.size(18.dp))
                            Spacer(modifier = Modifier.width(6.dp))
                            Text("Add to A4 Paper Sheet (Multiple Copies)", fontSize = 12.sp, fontWeight = FontWeight.Bold)
                        }
                        Switch(
                            checked = isA4Mode,
                            onCheckedChange = { isA4Mode = it },
                            modifier = Modifier.height(24.dp)
                        )
                    }

                    if (isA4Mode) {
                        Spacer(modifier = Modifier.height(8.dp))
                        Text("Select Number of Copies on A4 Sheet:", fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                        Spacer(modifier = Modifier.height(6.dp))
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(6.dp)
                        ) {
                            listOf(4, 8, 12, 16, 24, 32).forEach { c ->
                                val isSel = copiesOnA4 == c
                                Surface(
                                    shape = RoundedCornerShape(8.dp),
                                    color = if (isSel) AkinNavyDark else MaterialTheme.colorScheme.surface,
                                    border = CardDefaults.outlinedCardBorder(),
                                    modifier = Modifier
                                        .weight(1f)
                                        .clickable { copiesOnA4 = c }
                                ) {
                                    Text(
                                        text = "$c",
                                        fontSize = 11.sp,
                                        fontWeight = FontWeight.Bold,
                                        color = if (isSel) Color.White else MaterialTheme.colorScheme.onSurface,
                                        textAlign = TextAlign.Center,
                                        modifier = Modifier.padding(vertical = 6.dp)
                                    )
                                }
                            }
                        }
                    }
                }
            }

            Spacer(modifier = Modifier.height(16.dp))

            // Standard Dual Download Buttons (Free vs ₹10 Paid / Unlocked)
            DualDownloadActionButtons(
                toolTitle = if (isA4Mode) "A4 Sheet ($copiesOnA4 Passport Copies)" else "Passport Photo HD (${selectedSuit.name})",
                isPaid = isPaid,
                onFreeDownload = {
                    Toast.makeText(context, "Saved with watermark: 'Downloaded From Akash Internet Hub'", Toast.LENGTH_LONG).show()
                },
                onPayDownload = onTriggerPayment,
                onUnlockedDownload = {
                    Toast.makeText(context, "📥 Clean HD Passport Photo Downloaded (300 DPI Vector Quality)!", Toast.LENGTH_LONG).show()
                }
            )
        }
    }
}

@Composable
fun AiBackgroundRemoverStudio(
    isPaid: Boolean,
    onTriggerPayment: () -> Unit
) {
    val context = LocalContext.current
    var selectedColorIndex by remember { mutableStateOf(0) }

    val bgColors = listOf(
        Triple("Studio Light Blue (Passport)", Color(0xFF90CAF9), "#90CAF9"),
        Triple("Pure Govt White", Color(0xFFFFFFFF), "#FFFFFF"),
        Triple("Crimson Red", Color(0xFFE53935), "#E53935"),
        Triple("Neutral Studio Grey", Color(0xFFECEFF1), "#ECEFF1"),
        Triple("Emerald Green", Color(0xFF2E7D32), "#2E7D32"),
        Triple("Transparent / PNG", Color.Transparent, "PNG")
    )

    Card(
        modifier = Modifier
            .fillMaxWidth()
            .testTag("bg_remover_studio_card"),
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
    ) {
        Column(modifier = Modifier.padding(16.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column {
                    Text(
                        text = "AI Auto Background Removal & Color Picker",
                        fontSize = 15.sp,
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.onSurface
                    )
                    Text(
                        text = "One-tap smart cutout with custom official background colors",
                        fontSize = 11.sp,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
                Surface(
                    shape = RoundedCornerShape(8.dp),
                    color = if (isPaid) AkinGreenSuccess.copy(alpha = 0.15f) else MaterialTheme.colorScheme.primaryContainer
                ) {
                    Text(
                        text = if (isPaid) "✨ HD UNLOCKED" else "AI CUTOUT",
                        fontSize = 10.sp,
                        fontWeight = FontWeight.Bold,
                        color = if (isPaid) AkinGreenSuccess else MaterialTheme.colorScheme.primary,
                        modifier = Modifier.padding(horizontal = 8.dp, vertical = 3.dp)
                    )
                }
            }

            Spacer(modifier = Modifier.height(14.dp))

            // Preview
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(200.dp)
                    .background(
                        if (bgColors[selectedColorIndex].second == Color.Transparent) Color(0xFFD1D5DB) else bgColors[selectedColorIndex].second,
                        RoundedCornerShape(12.dp)
                    )
                    .border(1.dp, Color(0xFFCBD5E1), RoundedCornerShape(12.dp)),
                contentAlignment = Alignment.Center
            ) {
                // Render stylized cutout avatar
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Box(
                        modifier = Modifier
                            .size(110.dp)
                            .background(Color(0xFF334155), CircleShape)
                            .border(2.dp, Color.White, CircleShape),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            imageVector = Icons.Default.Person,
                            contentDescription = "Cutout Avatar",
                            tint = Color.White,
                            modifier = Modifier.size(76.dp)
                        )
                    }
                    Spacer(modifier = Modifier.height(8.dp))
                    Surface(
                        shape = RoundedCornerShape(6.dp),
                        color = Color.Black.copy(alpha = 0.6f)
                    ) {
                        Text(
                            text = "Background: ${bgColors[selectedColorIndex].first}",
                            fontSize = 10.sp,
                            fontWeight = FontWeight.Bold,
                            color = Color.White,
                            modifier = Modifier.padding(horizontal = 8.dp, vertical = 2.dp)
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.height(14.dp))

            Text("Choose New Background Color:", fontSize = 12.sp, fontWeight = FontWeight.SemiBold)
            Spacer(modifier = Modifier.height(8.dp))

            // Background Color Palette Grid
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                bgColors.chunked(3).forEach { rowColors ->
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        rowColors.forEach { item ->
                            val isSel = bgColors[selectedColorIndex] == item
                            Surface(
                                shape = RoundedCornerShape(10.dp),
                                color = if (item.second == Color.Transparent) Color(0xFFE2E8F0) else item.second,
                                border = if (isSel) CardDefaults.outlinedCardBorder().copy(brush = Brush.linearGradient(listOf(AkinNavyDark, AkinNavyDark)), width = 2.dp) else CardDefaults.outlinedCardBorder(),
                                modifier = Modifier
                                    .weight(1f)
                                    .height(44.dp)
                                    .clickable { selectedColorIndex = bgColors.indexOf(item) }
                            ) {
                                Row(
                                    modifier = Modifier.padding(horizontal = 6.dp, vertical = 4.dp),
                                    verticalAlignment = Alignment.CenterVertically,
                                    horizontalArrangement = Arrangement.Center
                                ) {
                                    if (isSel) {
                                        Icon(Icons.Default.Check, contentDescription = "Selected", tint = if (item.second == Color.White || item.second == Color(0xFFECEFF1) || item.second == Color(0xFF90CAF9)) Color.Black else Color.White, modifier = Modifier.size(14.dp))
                                        Spacer(modifier = Modifier.width(4.dp))
                                    }
                                    Text(
                                        text = item.first.split(" ").first(),
                                        fontSize = 10.sp,
                                        fontWeight = if (isSel) FontWeight.ExtraBold else FontWeight.Normal,
                                        color = if (item.second == Color.White || item.second == Color(0xFFECEFF1) || item.second == Color(0xFF90CAF9)) Color.Black else if (item.second == Color.Transparent) Color.DarkGray else Color.White
                                    )
                                }
                            }
                        }
                    }
                }
            }

            Spacer(modifier = Modifier.height(16.dp))

            // Standard Dual Download Buttons
            DualDownloadActionButtons(
                toolTitle = "AI Background Removed Photo (${bgColors[selectedColorIndex].first})",
                isPaid = isPaid,
                onFreeDownload = {
                    Toast.makeText(context, "Saved with watermark: 'Downloaded From Akash Internet Hub'", Toast.LENGTH_LONG).show()
                },
                onPayDownload = onTriggerPayment,
                onUnlockedDownload = {
                    Toast.makeText(context, "📥 Clean HD Cutout Photo Downloaded (Transparent / Color Background)!", Toast.LENGTH_LONG).show()
                }
            )
        }
    }
}

@Composable
fun SinglePassportPreview(
    strokeColor: Color,
    strokeWidth: Int,
    brightness: Float,
    contrast: Float,
    warmth: Float,
    suit: FormalSuitOption
) {
    Surface(
        modifier = Modifier
            .width(135.dp)
            .height(175.dp)
            .border(strokeWidth.dp, strokeColor, RoundedCornerShape(4.dp))
            .background(Color(0xFF90CAF9).copy(alpha = brightness.coerceIn(0.7f, 1.3f)), RoundedCornerShape(4.dp)),
        shadowElevation = 4.dp
    ) {
        Box(
            modifier = Modifier.fillMaxSize(),
            contentAlignment = Alignment.Center
        ) {
            Column(
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.Bottom,
                modifier = Modifier.fillMaxSize()
            ) {
                // Head / Face
                Icon(
                    imageVector = if (suit.isFemale) Icons.Default.Face3 else Icons.Default.Face,
                    contentDescription = "Portrait",
                    tint = AkinNavyDark.copy(alpha = (contrast * 0.9f).coerceIn(0.5f, 1.0f)),
                    modifier = Modifier.size(76.dp)
                )

                // Render Stylized Suit & Lapels & Tie
                Box(
                    modifier = Modifier
                        .fillMaxWidth(0.92f)
                        .height(46.dp)
                        .clip(RoundedCornerShape(topStart = 14.dp, topEnd = 14.dp))
                        .background(suit.suitColor)
                ) {
                    // Shirt Collar & Tie Layer
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .align(Alignment.TopCenter),
                        horizontalArrangement = Arrangement.Center
                    ) {
                        // Shirt V-Neck Collar
                        Box(
                            modifier = Modifier
                                .width(30.dp)
                                .height(26.dp)
                                .clip(RoundedCornerShape(bottomStart = 8.dp, bottomEnd = 8.dp))
                                .background(suit.shirtColor),
                            contentAlignment = Alignment.Center
                        ) {
                            if (suit.hasTie) {
                                // Tie
                                Box(
                                    modifier = Modifier
                                        .width(9.dp)
                                        .height(24.dp)
                                        .background(suit.tieColor, RoundedCornerShape(bottomStart = 4.dp, bottomEnd = 4.dp))
                                )
                            }
                        }
                    }

                    // Suit Label text
                    Text(
                        text = suit.name.split(" ").take(2).joinToString(" ").uppercase(),
                        fontSize = 7.5.sp,
                        fontWeight = FontWeight.ExtraBold,
                        color = Color.White.copy(alpha = 0.9f),
                        textAlign = TextAlign.Center,
                        modifier = Modifier
                            .align(Alignment.BottomCenter)
                            .padding(bottom = 2.dp)
                    )
                }
            }
        }
    }
}

@Composable
fun A4SheetPreviewCanvas(
    copies: Int,
    strokeColor: Color,
    strokeWidth: Int,
    brightness: Float,
    suit: FormalSuitOption
) {
    Card(
        modifier = Modifier
            .width(160.dp)
            .height(200.dp),
        colors = CardDefaults.cardColors(containerColor = Color.White),
        shape = RoundedCornerShape(2.dp),
        elevation = CardDefaults.cardElevation(defaultElevation = 4.dp)
    ) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(8.dp),
            verticalArrangement = Arrangement.SpaceEvenly
        ) {
            val cols = if (copies <= 8) 2 else if (copies <= 16) 4 else 4
            val rows = (copies + cols - 1) / cols

            for (r in 0 until rows.coerceAtMost(6)) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceEvenly
                ) {
                    for (c in 0 until cols) {
                        val index = r * cols + c
                        if (index < copies) {
                            Box(
                                modifier = Modifier
                                    .size(width = 24.dp, height = 30.dp)
                                    .border(1.dp, strokeColor)
                                    .background(Color(0xFF90CAF9)),
                                contentAlignment = Alignment.Center
                            ) {
                                Icon(
                                    imageVector = if (suit.isFemale) Icons.Default.Face3 else Icons.Default.Face,
                                    contentDescription = "Mini",
                                    tint = AkinNavyDark,
                                    modifier = Modifier.size(16.dp)
                                )
                            }
                        } else {
                            Spacer(modifier = Modifier.size(24.dp, 30.dp))
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun ManualCropStudio(
    isPaid: Boolean,
    onTriggerPayment: () -> Unit
) {
    val context = LocalContext.current
    var cropMode by remember { mutableStateOf(0) } // 0: Crop by Marker, 1: Crop by Exact Size

    // Marker controls (percentages from 0 to 100)
    var markerLeft by remember { mutableStateOf(10f) }
    var markerTop by remember { mutableStateOf(10f) }
    var markerRight by remember { mutableStateOf(90f) }
    var markerBottom by remember { mutableStateOf(90f) }

    // Exact Size controls with units (Inches, CM, MM, Pixels)
    var customWidth by remember { mutableStateOf("3.5") }
    var customHeight by remember { mutableStateOf("4.5") }
    var selectedUnit by remember { mutableStateOf("cm") } // "cm", "in", "mm", "px"
    var selectedDpi by remember { mutableStateOf("300 DPI") }
    var maxFileSizeKb by remember { mutableStateOf("50") }
    var selectedPresetName by remember { mutableStateOf("Passport (3.5 × 4.5 cm)") }

    val unitsList = listOf("cm", "in", "mm", "px")

    Card(
        modifier = Modifier
            .fillMaxWidth()
            .testTag("manual_crop_studio_card"),
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
    ) {
        Column(modifier = Modifier.padding(16.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column {
                    Text(
                        text = "Manual Crop by Marker & Custom Size",
                        fontSize = 15.sp,
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.onSurface
                    )
                    Text(
                        text = "Custom Inch / CM / MM / PX dimensions for Govt Portals",
                        fontSize = 11.sp,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
                Surface(
                    shape = RoundedCornerShape(6.dp),
                    color = if (isPaid) AkinGreenSuccess.copy(alpha = 0.15f) else AkinAmberAccent
                ) {
                    Text(
                        text = if (isPaid) "✨ HD UNLOCKED" else "INCH / CM / MM",
                        fontSize = 9.sp,
                        fontWeight = FontWeight.Bold,
                        color = if (isPaid) AkinGreenSuccess else Color.Black,
                        modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                    )
                }
            }

            Spacer(modifier = Modifier.height(12.dp))

            // Sub-mode tabs
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                FilterChip(
                    selected = cropMode == 0,
                    onClick = { cropMode = 0 },
                    label = { Text("🎯 Interactive Marker Crop", fontSize = 11.sp) },
                    modifier = Modifier.weight(1f)
                )
                FilterChip(
                    selected = cropMode == 1,
                    onClick = { cropMode = 1 },
                    label = { Text("📏 Custom Inch / CM / PX", fontSize = 11.sp) },
                    modifier = Modifier.weight(1f)
                )
            }

            Spacer(modifier = Modifier.height(14.dp))

            // Interactive Live Canvas with Marker lines and Grid
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(210.dp)
                    .clip(RoundedCornerShape(12.dp))
                    .background(Color(0xFF0F172A)),
                contentAlignment = Alignment.Center
            ) {
                // Background sample avatar/photo image
                Column(
                    horizontalAlignment = Alignment.CenterHorizontally,
                    verticalArrangement = Arrangement.Center
                ) {
                    Surface(
                        modifier = Modifier
                            .size(110.dp, 135.dp)
                            .clip(RoundedCornerShape(8.dp)),
                        color = Color(0xFF64748B)
                    ) {
                        Box(contentAlignment = Alignment.Center) {
                            Icon(
                                imageVector = Icons.Default.Person,
                                contentDescription = "Sample",
                                tint = Color.White.copy(alpha = 0.9f),
                                modifier = Modifier.size(80.dp)
                            )
                        }
                    }
                }

                // Marker Boundary Overlay
                Canvas(modifier = Modifier.fillMaxSize()) {
                    val w = size.width
                    val h = size.height

                    val leftPx = w * (markerLeft / 100f)
                    val topPx = h * (markerTop / 100f)
                    val rightPx = w * (markerRight / 100f)
                    val bottomPx = h * (markerBottom / 100f)
                    val cropW = maxOf(20f, rightPx - leftPx)
                    val cropH = maxOf(20f, bottomPx - topPx)

                    // Draw outer dim mask
                    drawRect(
                        color = Color.Black.copy(alpha = 0.45f),
                        size = size
                    )

                    // Clear active crop rect
                    drawRect(
                        color = Color.Transparent,
                        topLeft = Offset(leftPx, topPx),
                        size = Size(cropW, cropH)
                    )

                    // Active Crop Rectangle Border
                    drawRect(
                        color = Color(0xFFF59E0B),
                        topLeft = Offset(leftPx, topPx),
                        size = Size(cropW, cropH),
                        style = Stroke(width = 3.dp.toPx())
                    )

                    // Rule of Thirds Grid inside Crop
                    val thirdW = cropW / 3f
                    val thirdH = cropH / 3f

                    drawLine(Color.White.copy(alpha = 0.5f), Offset(leftPx + thirdW, topPx), Offset(leftPx + thirdW, topPx + cropH), strokeWidth = 1.dp.toPx())
                    drawLine(Color.White.copy(alpha = 0.5f), Offset(leftPx + 2 * thirdW, topPx), Offset(leftPx + 2 * thirdW, topPx + cropH), strokeWidth = 1.dp.toPx())
                    drawLine(Color.White.copy(alpha = 0.5f), Offset(leftPx, topPx + thirdH), Offset(leftPx + cropW, topPx + thirdH), strokeWidth = 1.dp.toPx())
                    drawLine(Color.White.copy(alpha = 0.5f), Offset(leftPx, topPx + 2 * thirdH), Offset(leftPx + cropW, topPx + 2 * thirdH), strokeWidth = 1.dp.toPx())

                    // 4 Corner Anchor Handles
                    val handleRadius = 6.dp.toPx()
                    drawCircle(Color(0xFF10B981), handleRadius, Offset(leftPx, topPx))
                    drawCircle(Color(0xFF10B981), handleRadius, Offset(rightPx, topPx))
                    drawCircle(Color(0xFF10B981), handleRadius, Offset(leftPx, bottomPx))
                    drawCircle(Color(0xFF10B981), handleRadius, Offset(rightPx, bottomPx))
                }

                // Live dimension indicator badge
                Surface(
                    shape = RoundedCornerShape(6.dp),
                    color = Color.Black.copy(alpha = 0.75f),
                    modifier = Modifier
                        .align(Alignment.BottomEnd)
                        .padding(8.dp)
                ) {
                    Text(
                        text = if (cropMode == 0) "Marker: ${(markerRight - markerLeft).toInt()}% × ${(markerBottom - markerTop).toInt()}%" else "$customWidth × $customHeight $selectedUnit (Max: $maxFileSizeKb KB)",
                        color = AkinAmberAccent,
                        fontSize = 10.sp,
                        fontWeight = FontWeight.Bold,
                        modifier = Modifier.padding(horizontal = 6.dp, vertical = 3.dp)
                    )
                }
            }

            Spacer(modifier = Modifier.height(14.dp))

            if (cropMode == 0) {
                // Interactive Sliders for Marker boundaries
                Text("Adjust Markers (Left, Top, Right, Bottom):", fontSize = 12.sp, fontWeight = FontWeight.SemiBold)
                Spacer(modifier = Modifier.height(4.dp))

                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text("Left Marker:", fontSize = 11.sp, modifier = Modifier.width(80.dp))
                    Slider(
                        value = markerLeft,
                        onValueChange = { if (it < markerRight - 15f) markerLeft = it },
                        valueRange = 0f..60f,
                        modifier = Modifier.weight(1f)
                    )
                    Text("${markerLeft.toInt()}%", fontSize = 11.sp, fontWeight = FontWeight.Bold, modifier = Modifier.width(36.dp))
                }

                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text("Top Marker:", fontSize = 11.sp, modifier = Modifier.width(80.dp))
                    Slider(
                        value = markerTop,
                        onValueChange = { if (it < markerBottom - 15f) markerTop = it },
                        valueRange = 0f..60f,
                        modifier = Modifier.weight(1f)
                    )
                    Text("${markerTop.toInt()}%", fontSize = 11.sp, fontWeight = FontWeight.Bold, modifier = Modifier.width(36.dp))
                }

                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text("Right Marker:", fontSize = 11.sp, modifier = Modifier.width(80.dp))
                    Slider(
                        value = markerRight,
                        onValueChange = { if (it > markerLeft + 15f) markerRight = it },
                        valueRange = 40f..100f,
                        modifier = Modifier.weight(1f)
                    )
                    Text("${markerRight.toInt()}%", fontSize = 11.sp, fontWeight = FontWeight.Bold, modifier = Modifier.width(36.dp))
                }

                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text("Bottom Marker:", fontSize = 11.sp, modifier = Modifier.width(80.dp))
                    Slider(
                        value = markerBottom,
                        onValueChange = { if (it > markerTop + 15f) markerBottom = it },
                        valueRange = 40f..100f,
                        modifier = Modifier.weight(1f)
                    )
                    Text("${markerBottom.toInt()}%", fontSize = 11.sp, fontWeight = FontWeight.Bold, modifier = Modifier.width(36.dp))
                }
            } else {
                // Crop by Exact User Size Requirement in Inch / CM / MM / Pixels
                Text("Popular Presets or Type Custom Dimensions:", fontSize = 12.sp, fontWeight = FontWeight.SemiBold)
                Spacer(modifier = Modifier.height(6.dp))

                val presets = listOf(
                    Triple("Passport (3.5×4.5 cm)", Pair("3.5", "4.5"), "cm"),
                    Triple("Square (2.0×2.0 in)", Pair("2.0", "2.0"), "in"),
                    Triple("ADRE Photo (200×230 px)", Pair("200", "230"), "px"),
                    Triple("Police Sign (140×60 px)", Pair("140", "60"), "px"),
                    Triple("Stamp Size (25×30 mm)", Pair("25", "30"), "mm"),
                    Triple("US Visa (2×2 Inch)", Pair("2.0", "2.0"), "in")
                )

                LazyRow(
                    horizontalArrangement = Arrangement.spacedBy(6.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    items(presets) { (preset, dims, unit) ->
                        FilterChip(
                            selected = selectedPresetName == preset,
                            onClick = {
                                selectedPresetName = preset
                                customWidth = dims.first
                                customHeight = dims.second
                                selectedUnit = unit
                            },
                            label = { Text(preset, fontSize = 10.sp) }
                        )
                    }
                }

                Spacer(modifier = Modifier.height(10.dp))

                // Unit selection chips (Inches, CM, MM, PX)
                Text("Select Measurement Unit:", fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                Spacer(modifier = Modifier.height(4.dp))
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    unitsList.forEach { unit ->
                        val isSel = selectedUnit == unit
                        Surface(
                            shape = RoundedCornerShape(8.dp),
                            color = if (isSel) MaterialTheme.colorScheme.primaryContainer else MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f),
                            border = if (isSel) CardDefaults.outlinedCardBorder().copy(brush = Brush.linearGradient(listOf(MaterialTheme.colorScheme.primary, MaterialTheme.colorScheme.primary)), width = 1.5.dp) else null,
                            modifier = Modifier
                                .weight(1f)
                                .clickable { selectedUnit = unit }
                        ) {
                            Text(
                                text = when (unit) {
                                    "in" -> "Inches (in)"
                                    "cm" -> "Centimeter (cm)"
                                    "mm" -> "Millimeter (mm)"
                                    else -> "Pixels (px)"
                                },
                                fontSize = 10.sp,
                                fontWeight = if (isSel) FontWeight.Bold else FontWeight.Normal,
                                textAlign = TextAlign.Center,
                                modifier = Modifier.padding(vertical = 6.dp)
                            )
                        }
                    }
                }

                Spacer(modifier = Modifier.height(10.dp))

                // Width & Height inputs
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    OutlinedTextField(
                        value = customWidth,
                        onValueChange = { customWidth = it },
                        label = { Text("Width ($selectedUnit)") },
                        modifier = Modifier.weight(1f),
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
                        singleLine = true
                    )
                    OutlinedTextField(
                        value = customHeight,
                        onValueChange = { customHeight = it },
                        label = { Text("Height ($selectedUnit)") },
                        modifier = Modifier.weight(1f),
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
                        singleLine = true
                    )
                }

                Spacer(modifier = Modifier.height(8.dp))

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    OutlinedTextField(
                        value = maxFileSizeKb,
                        onValueChange = { maxFileSizeKb = it },
                        label = { Text("Max Target File Size (KB)") },
                        modifier = Modifier.weight(1f),
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                        singleLine = true
                    )
                    OutlinedTextField(
                        value = selectedDpi,
                        onValueChange = { selectedDpi = it },
                        label = { Text("Resolution (DPI)") },
                        modifier = Modifier.weight(1f),
                        singleLine = true
                    )
                }
            }

            Spacer(modifier = Modifier.height(14.dp))

            // Dual Download Buttons
            DualDownloadActionButtons(
                toolTitle = "Cropped Photo ($customWidth × $customHeight $selectedUnit)",
                isPaid = isPaid,
                onFreeDownload = {
                    Toast.makeText(context, "📥 Cropped Photo Saved with Watermark: 'Downloaded From Akash Internet Hub'", Toast.LENGTH_LONG).show()
                },
                onPayDownload = onTriggerPayment,
                onUnlockedDownload = {
                    Toast.makeText(context, "📥 Clean HD Cropped Photo Downloaded ($customWidth×$customHeight $selectedUnit - Perfect for Govt Portals)!", Toast.LENGTH_LONG).show()
                }
            )
        }
    }
}

/**
 * Standard Reusable Dual Download Buttons across all AI Tools
 */
@Composable
fun DualDownloadActionButtons(
    toolTitle: String,
    isPaid: Boolean = false,
    onFreeDownload: () -> Unit,
    onPayDownload: () -> Unit,
    onUnlockedDownload: () -> Unit = {},
    modifier: Modifier = Modifier
) {
    Column(
        modifier = modifier.fillMaxWidth(),
        verticalArrangement = Arrangement.spacedBy(8.dp)
    ) {
        // Free Download Button with Watermark
        OutlinedButton(
            onClick = onFreeDownload,
            modifier = Modifier
                .fillMaxWidth()
                .height(44.dp)
                .testTag("free_download_button"),
            shape = RoundedCornerShape(10.dp)
        ) {
            Icon(Icons.Default.FileDownload, contentDescription = "Free Download", modifier = Modifier.size(17.dp))
            Spacer(modifier = Modifier.width(6.dp))
            Text(
                text = "Free Download (With Watermark)",
                fontSize = 12.sp,
                fontWeight = FontWeight.SemiBold
            )
        }

        if (isPaid) {
            // UNLOCKED Clean HD Download Button
            Button(
                onClick = onUnlockedDownload,
                modifier = Modifier
                    .fillMaxWidth()
                    .height(48.dp)
                    .testTag("download_unlocked_hd_button"),
                shape = RoundedCornerShape(10.dp),
                colors = ButtonDefaults.buttonColors(containerColor = AkinGreenSuccess, contentColor = Color.White),
                elevation = ButtonDefaults.buttonElevation(defaultElevation = 3.dp)
            ) {
                Icon(Icons.Default.DownloadDone, contentDescription = "Download HD", modifier = Modifier.size(20.dp))
                Spacer(modifier = Modifier.width(8.dp))
                Column(horizontalAlignment = Alignment.Start) {
                    Text(
                        text = "✨ Download Clean HD File (Unlocked)",
                        fontSize = 12.5.sp,
                        fontWeight = FontWeight.Bold,
                        color = Color.White
                    )
                    Text(
                        text = "100% Watermark Free • High-Resolution Original",
                        fontSize = 9.sp,
                        color = Color.White.copy(alpha = 0.9f)
                    )
                }
            }
        } else {
            // Pay ₹10 & Download Button without Watermark (Razorpay checkout)
            Button(
                onClick = onPayDownload,
                modifier = Modifier
                    .fillMaxWidth()
                    .height(48.dp)
                    .testTag("pay_download_button"),
                shape = RoundedCornerShape(10.dp),
                colors = ButtonDefaults.buttonColors(containerColor = AkinAmberAccent, contentColor = AkinNavyDark),
                elevation = ButtonDefaults.buttonElevation(defaultElevation = 2.dp)
            ) {
                Icon(Icons.Default.WorkspacePremium, contentDescription = "Pay ₹10", tint = AkinNavyDark, modifier = Modifier.size(18.dp))
                Spacer(modifier = Modifier.width(6.dp))
                Column(horizontalAlignment = Alignment.Start) {
                    Text(
                        text = "Pay ₹10 & Download HD (No Watermark)",
                        fontSize = 12.sp,
                        fontWeight = FontWeight.Bold,
                        color = AkinNavyDark
                    )
                    Text(
                        text = "Razorpay Checkout • payment ke baad HD download unlock hoga",
                        fontSize = 9.sp,
                        color = AkinNavyDark.copy(alpha = 0.85f)
                    )
                }
            }
        }
    }
}
