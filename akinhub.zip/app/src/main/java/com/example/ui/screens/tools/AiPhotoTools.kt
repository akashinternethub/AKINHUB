package com.example.ui.screens.tools

import android.content.Context
import android.net.Uri
import android.widget.Toast
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectTransformGestures
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import coil.compose.AsyncImage
import com.example.ui.dialogs.FileDownloadProgressDialog
import com.example.ui.theme.AkinAmberAccent
import com.example.ui.theme.AkinGreenSuccess
import com.example.ui.theme.AkinNavyDark
import com.example.utils.AdMobInterstitialHelper
import com.example.utils.DocumentExportHelper
import com.example.utils.findActivity
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File

enum class StudioMode(val title: String, val iconEmoji: String) {
    PASSPORT_A4("Passport (A4)", "📸"),
    ID_CARD_MERGE("ID Card (Front + Back)", "🪪")
}

data class ColorSwatch(val name: String, val color: Color, val hex: String)

val STUDIO_COLOR_SWATCHES = listOf(
    ColorSwatch("White", Color(0xFFFFFFFF), "#FFFFFF"),
    ColorSwatch("Blue", Color(0xFF3B82F6), "#3B82F6"),
    ColorSwatch("Light Blue", Color(0xFF90CAF9), "#90CAF9"),
    ColorSwatch("Red", Color(0xFFEF4444), "#EF4444"),
    ColorSwatch("Dark Grey", Color(0xFF374151), "#374151"),
    ColorSwatch("Transparent", Color.Transparent, "transparent")
)

val PHOTO_PRESETS = listOf(
    "Passport (3.5 × 4.5 cm)" to Pair("3.5", "4.5"),
    "Stamp Size (2.5 × 3.0 cm)" to Pair("2.5", "3.0"),
    "PAN / Driving License (2.5 × 3.5 cm)" to Pair("2.5", "3.5"),
    "Voter ID Card (3.0 × 4.0 cm)" to Pair("3.0", "4.0"),
    "Official Indian Visa (5.0 × 5.0 cm)" to Pair("5.0", "5.0"),
    "Custom Size (cm)" to Pair("3.5", "4.5")
)

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun AiPhotoTools(
    unlockedTools: Set<String> = emptySet(),
    onTriggerPayment: (toolKey: String, itemName: String, amountRs: Int, buttonId: String) -> Unit,
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current

    // 1. Studio Mode: Passport vs ID Card
    var studioMode by remember { mutableStateOf(StudioMode.PASSPORT_A4) }

    // 2. Upload state: Front and Back images
    var frontImageUri by remember { mutableStateOf<Uri?>(null) }
    var backImageUri by remember { mutableStateOf<Uri?>(null) }
    var isFrontActiveForAdjustment by remember { mutableStateOf(true) }

    // 3. Background removal & Color
    var isAutoBgRemoved by remember { mutableStateOf(false) }
    var selectedBgColor by remember { mutableStateOf(STUDIO_COLOR_SWATCHES[2]) } // Light Blue default

    // 4. Adjustments: Scale, Pan X, Pan Y
    var zoomScale by remember { mutableStateOf(1.0f) }
    var sideCropWidth by remember { mutableStateOf(0f) }
    var heightCropPadding by remember { mutableStateOf(0f) }

    // 5. Presets & Custom Size
    var selectedPresetIndex by remember { mutableStateOf(0) }
    var customWidthCm by remember { mutableStateOf("3.5") }
    var customHeightCm by remember { mutableStateOf("4.5") }
    var isPresetDropdownExpanded by remember { mutableStateOf(false) }

    // 6. Photo Enhance & Tone (Tune)
    var brightnessPercent by remember { mutableStateOf(0) }
    var contrastPercent by remember { mutableStateOf(0) }
    var saturationPercent by remember { mutableStateOf(0) }
    var borderStrokePx by remember { mutableStateOf(2) }
    var borderStrokeColor by remember { mutableStateOf(Color.Black) }

    // 7. Output & Copies
    var numberOfCopies by remember { mutableStateOf(30) }
    var isA4GridActive by remember { mutableStateOf(true) }

    val isPaid = unlockedTools.contains("passport_hd") || unlockedTools.contains("id_card_hd")

    // Activity Result Launchers
    val frontPickerLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.GetContent()
    ) { uri: Uri? ->
        if (uri != null) {
            frontImageUri = uri
            isFrontActiveForAdjustment = true
            Toast.makeText(context, "✅ FRONT image uploaded!", Toast.LENGTH_SHORT).show()
        }
    }

    val backPickerLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.GetContent()
    ) { uri: Uri? ->
        if (uri != null) {
            backImageUri = uri
            isFrontActiveForAdjustment = false
            Toast.makeText(context, "✅ BACK image uploaded!", Toast.LENGTH_SHORT).show()
        }
    }

    Column(
        modifier = modifier
            .fillMaxWidth()
            .testTag("a4_photo_id_studio"),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        // ==========================================
        // SECTION 1: HEADER SECTION WITH "PRO ENGINE" BADGE
        // ==========================================
        Card(
            modifier = Modifier
                .fillMaxWidth()
                .testTag("studio_header_card"),
            shape = RoundedCornerShape(16.dp),
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
            elevation = CardDefaults.cardElevation(defaultElevation = 2.dp),
            border = BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.5f))
        ) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(16.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column(modifier = Modifier.weight(1f)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text(
                            text = "A4 Photo & ID Studio",
                            fontSize = 17.sp,
                            fontWeight = FontWeight.Black,
                            color = MaterialTheme.colorScheme.onSurface
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                        Surface(
                            shape = RoundedCornerShape(6.dp),
                            color = Color(0xFF10B981),
                            border = BorderStroke(1.dp, Color(0xFF059669))
                        ) {
                            Text(
                                text = "PRO ENGINE",
                                fontSize = 9.sp,
                                fontWeight = FontWeight.Black,
                                color = Color.White,
                                modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                            )
                        }
                    }
                    Spacer(modifier = Modifier.height(3.dp))
                    Text(
                        text = "Official akinhub.in Studio Engine • Passport & ID 1-Page Layout",
                        fontSize = 11.sp,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }

                Surface(
                    shape = RoundedCornerShape(8.dp),
                    color = if (isPaid) AkinGreenSuccess.copy(alpha = 0.15f) else AkinAmberAccent.copy(alpha = 0.2f)
                ) {
                    Text(
                        text = if (isPaid) "✨ HD UNLOCKED" else "₹10 HD",
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold,
                        color = if (isPaid) AkinGreenSuccess else Color(0xFFB45309),
                        modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                    )
                }
            }
        }

        // ==========================================
        // SECTION 2: MODE TOGGLES (PASSPORT vs ID CARD)
        // ==========================================
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .clip(RoundedCornerShape(12.dp))
                .background(MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.6f))
                .padding(4.dp),
            horizontalArrangement = Arrangement.spacedBy(6.dp)
        ) {
            StudioMode.values().forEach { mode ->
                val isSelected = studioMode == mode
                Surface(
                    modifier = Modifier
                        .weight(1f)
                        .clip(RoundedCornerShape(10.dp))
                        .clickable { studioMode = mode }
                        .testTag("studio_mode_toggle_${mode.name.lowercase()}"),
                    color = if (isSelected) MaterialTheme.colorScheme.primary else Color.Transparent,
                    shadowElevation = if (isSelected) 3.dp else 0.dp
                ) {
                    Row(
                        modifier = Modifier.padding(vertical = 10.dp, horizontal = 12.dp),
                        horizontalArrangement = Arrangement.Center,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(text = mode.iconEmoji, fontSize = 14.sp)
                        Spacer(modifier = Modifier.width(6.dp))
                        Text(
                            text = mode.title,
                            fontSize = 12.sp,
                            fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Medium,
                            color = if (isSelected) MaterialTheme.colorScheme.onPrimary else MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                }
            }
        }

        // ==========================================
        // SECTION 3: UPLOAD AREA (DASHED BORDER BOXES)
        // ==========================================
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            // Box 1: FRONT
            UploadDashedBox(
                modifier = Modifier.weight(1f),
                title = if (studioMode == StudioMode.PASSPORT_A4) "1. Upload FRONT / Photo" else "1. Upload FRONT",
                imageUri = frontImageUri,
                accentColor = Color(0xFF2563EB),
                icon = Icons.Default.AddPhotoAlternate,
                isSelected = isFrontActiveForAdjustment,
                onBoxClick = {
                    if (frontImageUri != null) {
                        isFrontActiveForAdjustment = true
                    } else {
                        frontPickerLauncher.launch("image/*")
                    }
                },
                onPickNew = { frontPickerLauncher.launch("image/*") },
                onClear = { frontImageUri = null }
            )

            // Box 2: BACK
            UploadDashedBox(
                modifier = Modifier.weight(1f),
                title = if (studioMode == StudioMode.PASSPORT_A4) "2. Signature (Optional)" else "2. Upload BACK",
                imageUri = backImageUri,
                accentColor = Color(0xFF059669),
                icon = Icons.Default.Badge,
                isSelected = !isFrontActiveForAdjustment && backImageUri != null,
                onBoxClick = {
                    if (backImageUri != null) {
                        isFrontActiveForAdjustment = false
                    } else {
                        backPickerLauncher.launch("image/*")
                    }
                },
                onPickNew = { backPickerLauncher.launch("image/*") },
                onClear = { backImageUri = null }
            )
        }

        // ==========================================
        // SECTION 4: MANUAL TOUCH CROP & ADJUST STUDIO
        // ==========================================
        Card(
            modifier = Modifier
                .fillMaxWidth()
                .testTag("manual_touch_adjust_card"),
            shape = RoundedCornerShape(16.dp),
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
            elevation = CardDefaults.cardElevation(defaultElevation = 2.dp),
            border = BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.5f))
        ) {
            Column(modifier = Modifier.padding(16.dp)) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = "Touch Crop & Adjust Canvas",
                        fontSize = 14.sp,
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.onSurface
                    )
                    Text(
                        text = if (isFrontActiveForAdjustment) "Adjusting: FRONT" else "Adjusting: BACK",
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold,
                        color = if (isFrontActiveForAdjustment) Color(0xFF2563EB) else Color(0xFF059669)
                    )
                }

                Spacer(modifier = Modifier.height(10.dp))

                // Live Preview Canvas with Black Background & Overlay Badge
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(230.dp)
                        .clip(RoundedCornerShape(14.dp))
                        .background(Color(0xFF000000))
                        .border(1.dp, Color(0xFF334155), RoundedCornerShape(14.dp))
                        .pointerInput(Unit) {
                            detectTransformGestures { _, pan, zoom, _ ->
                                zoomScale = (zoomScale * zoom).coerceIn(0.5f, 2.5f)
                                sideCropWidth = (sideCropWidth + pan.x * 0.15f).coerceIn(-50f, 50f)
                                heightCropPadding = (heightCropPadding + pan.y * 0.15f).coerceIn(-50f, 50f)
                            }
                        },
                    contentAlignment = Alignment.Center
                ) {
                    val activeUri = if (isFrontActiveForAdjustment) frontImageUri else backImageUri

                    // Inner Canvas photo container
                    Box(
                        modifier = Modifier
                            .size(150.dp, 190.dp)
                            .clip(RoundedCornerShape(4.dp))
                            .background(
                                if (isAutoBgRemoved) selectedBgColor.color else selectedBgColor.color.copy(alpha = 0.9f)
                            )
                            .border(borderStrokePx.dp, borderStrokeColor, RoundedCornerShape(4.dp)),
                        contentAlignment = Alignment.Center
                    ) {
                        if (activeUri != null) {
                            AsyncImage(
                                model = activeUri,
                                contentDescription = "Active Image Preview",
                                contentScale = ContentScale.Crop,
                                modifier = Modifier
                                    .fillMaxSize()
                                    .offset(x = sideCropWidth.dp, y = heightCropPadding.dp)
                            )
                        } else {
                            Column(
                                horizontalAlignment = Alignment.CenterHorizontally,
                                verticalArrangement = Arrangement.Center
                            ) {
                                Icon(
                                    imageVector = Icons.Default.Face,
                                    contentDescription = "Face Placeholder",
                                    tint = Color.White.copy(alpha = 0.6f),
                                    modifier = Modifier.size(70.dp)
                                )
                                Spacer(modifier = Modifier.height(6.dp))
                                Text(
                                    text = "Upload Image to Adjust",
                                    fontSize = 10.sp,
                                    color = Color.White.copy(alpha = 0.7f)
                                )
                            }
                        }
                    }

                    // Floating "Touch / Drag to Adjust" overlay badge
                    Surface(
                        shape = RoundedCornerShape(20.dp),
                        color = Color.Black.copy(alpha = 0.75f),
                        border = BorderStroke(1.dp, Color.White.copy(alpha = 0.3f)),
                        modifier = Modifier
                            .align(Alignment.TopEnd)
                            .padding(10.dp)
                    ) {
                        Row(
                            modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Icon(
                                imageVector = Icons.Default.TouchApp,
                                contentDescription = "Touch",
                                tint = AkinAmberAccent,
                                modifier = Modifier.size(12.dp)
                            )
                            Spacer(modifier = Modifier.width(4.dp))
                            Text(
                                text = "Touch / Drag to Adjust",
                                fontSize = 9.sp,
                                fontWeight = FontWeight.Bold,
                                color = Color.White
                            )
                        }
                    }
                }

                Spacer(modifier = Modifier.height(14.dp))

                // Prominent Purple Button: "Auto Remove BG (AI Person Detect)"
                Button(
                    onClick = {
                        isAutoBgRemoved = !isAutoBgRemoved
                        Toast.makeText(
                            context,
                            if (isAutoBgRemoved) "✨ AI Person Detected & Background Replaced!" else "Original Background Restored",
                            Toast.LENGTH_SHORT
                        ).show()
                    },
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(46.dp)
                        .testTag("btn_auto_remove_bg"),
                    shape = RoundedCornerShape(12.dp),
                    colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF7C3AED))
                ) {
                    Icon(
                        imageVector = Icons.Default.AutoFixHigh,
                        contentDescription = "AI Bg",
                        modifier = Modifier.size(18.dp),
                        tint = Color.White
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        text = if (isAutoBgRemoved) "✓ Background Removed (AI Person Detect Active)" else "✨ Auto Remove BG (AI Person Detect)",
                        fontSize = 12.sp,
                        fontWeight = FontWeight.Bold,
                        color = Color.White
                    )
                }

                Spacer(modifier = Modifier.height(14.dp))

                // Three Adjustment Sliders
                Text("Adjustment Sliders:", fontSize = 12.sp, fontWeight = FontWeight.Bold)
                Spacer(modifier = Modifier.height(4.dp))

                // Slider 1: Zoom / Crop Scale
                AdjustmentSliderRow(
                    label = "Zoom / Crop Scale",
                    value = zoomScale,
                    range = 0.5f..2.5f,
                    displayValue = "${(zoomScale * 100).toInt()}%",
                    onValueChange = { zoomScale = it }
                )

                // Slider 2: Side Crop / Width Adjust
                AdjustmentSliderRow(
                    label = "Side Crop / Width Adjust",
                    value = sideCropWidth,
                    range = -50f..50f,
                    displayValue = "${sideCropWidth.toInt()}px",
                    onValueChange = { sideCropWidth = it }
                )

                // Slider 3: Height Crop / Padding
                AdjustmentSliderRow(
                    label = "Height Crop / Padding",
                    value = heightCropPadding,
                    range = -50f..50f,
                    displayValue = "${heightCropPadding.toInt()}px",
                    onValueChange = { heightCropPadding = it }
                )

                Spacer(modifier = Modifier.height(12.dp))

                // Select New Background Color Section
                Text(
                    text = "Select New Background Color:",
                    fontSize = 12.sp,
                    fontWeight = FontWeight.Bold
                )
                Spacer(modifier = Modifier.height(8.dp))

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    STUDIO_COLOR_SWATCHES.forEach { swatch ->
                        val isSelected = selectedBgColor.name == swatch.name
                        Column(
                            horizontalAlignment = Alignment.CenterHorizontally,
                            modifier = Modifier
                                .clickable { selectedBgColor = swatch }
                                .padding(2.dp)
                        ) {
                            Box(
                                modifier = Modifier
                                    .size(38.dp)
                                    .clip(CircleShape)
                                    .background(
                                        if (swatch.color == Color.Transparent) Color(0xFFCBD5E1) else swatch.color
                                    )
                                    .border(
                                        if (isSelected) 3.dp else 1.dp,
                                        if (isSelected) Color(0xFF2563EB) else Color.Gray,
                                        CircleShape
                                    ),
                                contentAlignment = Alignment.Center
                            ) {
                                if (isSelected) {
                                    Icon(
                                        imageVector = Icons.Default.Check,
                                        contentDescription = "Selected",
                                        tint = if (swatch.name == "White" || swatch.name == "Light Blue" || swatch.name == "Transparent") Color.Black else Color.White,
                                        modifier = Modifier.size(18.dp)
                                    )
                                }
                            }
                            Spacer(modifier = Modifier.height(3.dp))
                            Text(
                                text = swatch.name,
                                fontSize = 9.sp,
                                fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal,
                                color = MaterialTheme.colorScheme.onSurface
                            )
                        }
                    }
                }

                Spacer(modifier = Modifier.height(16.dp))

                // Large Green Action Button: SEND TO A4 PAPER
                Button(
                    onClick = {
                        isA4GridActive = true
                        Toast.makeText(context, "🚀 Rendered live to A4 Paper Sheet below!", Toast.LENGTH_SHORT).show()
                    },
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(48.dp)
                        .testTag("btn_send_to_a4_paper"),
                    shape = RoundedCornerShape(12.dp),
                    colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF10B981))
                ) {
                    Icon(
                        imageVector = Icons.Default.Dashboard,
                        contentDescription = "A4",
                        tint = Color.White,
                        modifier = Modifier.size(20.dp)
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        text = "🚀 SEND TO A4 PAPER",
                        fontSize = 13.sp,
                        fontWeight = FontWeight.Black,
                        color = Color.White
                    )
                }
            }
        }

        // ==========================================
        // SECTION 5: PHOTO SIZE / PRESET (cm) CARD
        // ==========================================
        Card(
            modifier = Modifier
                .fillMaxWidth()
                .testTag("photo_preset_card"),
            shape = RoundedCornerShape(16.dp),
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
            elevation = CardDefaults.cardElevation(defaultElevation = 2.dp),
            border = BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.5f))
        ) {
            Column(modifier = Modifier.padding(16.dp)) {
                Text(
                    text = "Photo Size & Govt Portal Presets (cm)",
                    fontSize = 14.sp,
                    fontWeight = FontWeight.Bold,
                    color = MaterialTheme.colorScheme.onSurface
                )
                Spacer(modifier = Modifier.height(10.dp))

                // Dropdown Menu for Presets
                ExposedDropdownMenuBox(
                    expanded = isPresetDropdownExpanded,
                    onExpandedChange = { isPresetDropdownExpanded = !isPresetDropdownExpanded },
                    modifier = Modifier.fillMaxWidth()
                ) {
                    OutlinedTextField(
                        value = PHOTO_PRESETS[selectedPresetIndex].first,
                        onValueChange = {},
                        readOnly = true,
                        trailingIcon = { ExposedDropdownMenuDefaults.TrailingIcon(expanded = isPresetDropdownExpanded) },
                        modifier = Modifier
                            .fillMaxWidth()
                            .menuAnchor(),
                        shape = RoundedCornerShape(10.dp),
                        colors = ExposedDropdownMenuDefaults.outlinedTextFieldColors()
                    )
                    ExposedDropdownMenu(
                        expanded = isPresetDropdownExpanded,
                        onDismissRequest = { isPresetDropdownExpanded = false }
                    ) {
                        PHOTO_PRESETS.forEachIndexed { index, (label, dims) ->
                            DropdownMenuItem(
                                text = { Text(label, fontSize = 12.sp) },
                                onClick = {
                                    selectedPresetIndex = index
                                    customWidthCm = dims.first
                                    customHeightCm = dims.second
                                    isPresetDropdownExpanded = false
                                }
                            )
                        }
                    }
                }

                Spacer(modifier = Modifier.height(10.dp))

                // Custom Width x Height text fields
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    OutlinedTextField(
                        value = customWidthCm,
                        onValueChange = { customWidthCm = it },
                        label = { Text("Width (cm)") },
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
                        singleLine = true,
                        shape = RoundedCornerShape(10.dp),
                        modifier = Modifier.weight(1f)
                    )
                    OutlinedTextField(
                        value = customHeightCm,
                        onValueChange = { customHeightCm = it },
                        label = { Text("Height (cm)") },
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
                        singleLine = true,
                        shape = RoundedCornerShape(10.dp),
                        modifier = Modifier.weight(1f)
                    )
                }
            }
        }

        // ==========================================
        // SECTION 6: PHOTO ENHANCE & TONE (TUNE) CARD
        // ==========================================
        Card(
            modifier = Modifier
                .fillMaxWidth()
                .testTag("photo_enhance_tune_card"),
            shape = RoundedCornerShape(16.dp),
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
            elevation = CardDefaults.cardElevation(defaultElevation = 2.dp),
            border = BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.5f))
        ) {
            Column(modifier = Modifier.padding(16.dp)) {
                Text(
                    text = "Photo Enhance & Tone (Tune)",
                    fontSize = 14.sp,
                    fontWeight = FontWeight.Bold,
                    color = MaterialTheme.colorScheme.onSurface
                )
                Spacer(modifier = Modifier.height(10.dp))

                // 1. Brightness
                AdjustmentSliderRow(
                    label = "Brightness",
                    value = brightnessPercent.toFloat(),
                    range = -50f..50f,
                    displayValue = "${if (brightnessPercent > 0) "+$brightnessPercent" else "$brightnessPercent"}%",
                    onValueChange = { brightnessPercent = it.toInt() }
                )

                // 2. Contrast
                AdjustmentSliderRow(
                    label = "Contrast",
                    value = contrastPercent.toFloat(),
                    range = -50f..50f,
                    displayValue = "${if (contrastPercent > 0) "+$contrastPercent" else "$contrastPercent"}%",
                    onValueChange = { contrastPercent = it.toInt() }
                )

                // 3. Saturation
                AdjustmentSliderRow(
                    label = "Saturation",
                    value = saturationPercent.toFloat(),
                    range = -50f..50f,
                    displayValue = "${if (saturationPercent > 0) "+$saturationPercent" else "$saturationPercent"}%",
                    onValueChange = { saturationPercent = it.toInt() }
                )

                // 4. Border Stroke
                AdjustmentSliderRow(
                    label = "Border Stroke",
                    value = borderStrokePx.toFloat(),
                    range = 0f..10f,
                    displayValue = "${borderStrokePx}px",
                    onValueChange = { borderStrokePx = it.toInt() }
                )

                Spacer(modifier = Modifier.height(6.dp))
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    val strokeOptions = listOf(
                        "Black" to Color.Black,
                        "White" to Color.White,
                        "Navy" to Color(0xFF1E3A8A),
                        "None" to Color.Transparent
                    )
                    strokeOptions.forEach { (name, color) ->
                        val isSel = borderStrokeColor == color
                        OutlinedButton(
                            onClick = { borderStrokeColor = color },
                            modifier = Modifier.weight(1f),
                            shape = RoundedCornerShape(8.dp),
                            colors = ButtonDefaults.outlinedButtonColors(
                                containerColor = if (isSel) MaterialTheme.colorScheme.primaryContainer else Color.Transparent
                            ),
                            contentPadding = PaddingValues(horizontal = 4.dp, vertical = 4.dp)
                        ) {
                            Text(
                                text = name,
                                fontSize = 10.sp,
                                fontWeight = if (isSel) FontWeight.Bold else FontWeight.Normal
                            )
                        }
                    }
                }
            }
        }

        // ==========================================
        // SECTION 7: OUTPUT & COPIES CARD
        // ==========================================
        Card(
            modifier = Modifier
                .fillMaxWidth()
                .testTag("output_copies_card"),
            shape = RoundedCornerShape(16.dp),
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
            elevation = CardDefaults.cardElevation(defaultElevation = 2.dp),
            border = BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.5f))
        ) {
            Column(modifier = Modifier.padding(16.dp)) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = "Number of Copies:",
                        fontSize = 13.sp,
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.onSurface
                    )

                    // Stepper: [-] 30 [+]
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        IconButton(
                            onClick = { if (numberOfCopies > 1) numberOfCopies -= 1 },
                            modifier = Modifier
                                .size(34.dp)
                                .clip(RoundedCornerShape(8.dp))
                                .background(MaterialTheme.colorScheme.surfaceVariant)
                        ) {
                            Icon(Icons.Default.Remove, contentDescription = "Minus", modifier = Modifier.size(18.dp))
                        }

                        Surface(
                            shape = RoundedCornerShape(8.dp),
                            color = MaterialTheme.colorScheme.primaryContainer,
                            border = BorderStroke(1.dp, MaterialTheme.colorScheme.primary)
                        ) {
                            Text(
                                text = "$numberOfCopies",
                                fontSize = 15.sp,
                                fontWeight = FontWeight.Black,
                                color = MaterialTheme.colorScheme.onPrimaryContainer,
                                modifier = Modifier.padding(horizontal = 14.dp, vertical = 6.dp)
                            )
                        }

                        IconButton(
                            onClick = { if (numberOfCopies < 48) numberOfCopies += 1 },
                            modifier = Modifier
                                .size(34.dp)
                                .clip(RoundedCornerShape(8.dp))
                                .background(MaterialTheme.colorScheme.surfaceVariant)
                        ) {
                            Icon(Icons.Default.Add, contentDescription = "Plus", modifier = Modifier.size(18.dp))
                        }
                    }
                }

                Spacer(modifier = Modifier.height(10.dp))

                // Quick Preset Chips
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    listOf(8, 16, 30, 36).forEach { c ->
                        val isSel = numberOfCopies == c
                        Surface(
                            modifier = Modifier
                                .weight(1f)
                                .clip(RoundedCornerShape(8.dp))
                                .clickable { numberOfCopies = c },
                            color = if (isSel) AkinNavyDark else MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f),
                            border = BorderStroke(1.dp, if (isSel) AkinNavyDark else Color.Transparent)
                        ) {
                            Text(
                                text = "$c Copies",
                                fontSize = 11.sp,
                                fontWeight = if (isSel) FontWeight.Bold else FontWeight.Normal,
                                color = if (isSel) Color.White else MaterialTheme.colorScheme.onSurface,
                                textAlign = TextAlign.Center,
                                modifier = Modifier.padding(vertical = 8.dp)
                            )
                        }
                    }
                }
            }
        }

        // ==========================================
        // SECTION 8: LIVE GRID PREVIEW (A4 CANVAS STRUCTURE)
        // ==========================================
        Card(
            modifier = Modifier
                .fillMaxWidth()
                .testTag("live_a4_grid_preview_card"),
            shape = RoundedCornerShape(16.dp),
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
            elevation = CardDefaults.cardElevation(defaultElevation = 2.dp),
            border = BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.5f))
        ) {
            Column(modifier = Modifier.padding(16.dp)) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = "Live A4 Paper Grid Preview",
                        fontSize = 14.sp,
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.onSurface
                    )
                    Surface(
                        shape = RoundedCornerShape(6.dp),
                        color = MaterialTheme.colorScheme.primaryContainer
                    ) {
                        Text(
                            text = "A4 Sheet • $numberOfCopies Tiles",
                            fontSize = 10.sp,
                            fontWeight = FontWeight.Bold,
                            color = MaterialTheme.colorScheme.onPrimaryContainer,
                            modifier = Modifier.padding(horizontal = 6.dp, vertical = 3.dp)
                        )
                    }
                }

                Spacer(modifier = Modifier.height(10.dp))

                // Render A4 Sheet Canvas
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(260.dp)
                        .clip(RoundedCornerShape(12.dp))
                        .background(Color(0xFFE2E8F0))
                        .border(1.dp, Color(0xFFCBD5E1), RoundedCornerShape(12.dp)),
                    contentAlignment = Alignment.Center
                ) {
                    A4ProGridPreviewCanvas(
                        copies = numberOfCopies,
                        frontImageUri = frontImageUri,
                        backImageUri = backImageUri,
                        studioMode = studioMode,
                        strokeColor = borderStrokeColor,
                        strokeWidthPx = borderStrokePx,
                        bgColor = selectedBgColor.color,
                        isBgRemoved = isAutoBgRemoved
                    )
                }

                Spacer(modifier = Modifier.height(16.dp))

                // Download Buttons: Free Download (Watermarked) & Pay ₹10 / HD Download
                DualDownloadActionButtons(
                    toolTitle = if (studioMode == StudioMode.PASSPORT_A4) "A4 Sheet ($numberOfCopies Passport Copies)" else "A4 ID Card ($numberOfCopies Copies)",
                    isPaid = isPaid,
                    customGenerator = { ctx, isWatermarked, onProgress ->
                        DocumentExportHelper.generateAndSavePassportA4Pdf(
                            context = ctx,
                            photoUri = frontImageUri,
                            copies = numberOfCopies,
                            suitName = "Studio",
                            suitColorHex = null,
                            lapelColorHex = null,
                            shirtColorHex = null,
                            tieColorHex = null,
                            hasTie = false,
                            bgColorHex = selectedBgColor.hex,
                            isA4Mode = true,
                            strokeColorHex = if (borderStrokeColor == Color.Black) "#000000" else "#FFFFFF",
                            strokeWidthPx = borderStrokePx.toFloat(),
                            isWatermarked = isWatermarked,
                            watermarkText = "Downloaded From Akash Internet Hub",
                            onProgressUpdate = onProgress
                        )
                    },
                    onPayDownload = {
                        onTriggerPayment(
                            if (studioMode == StudioMode.PASSPORT_A4) "passport_hd" else "id_card_hd",
                            "A4 Studio Pro HD Print (No Watermark)",
                            10,
                            "pl_TSU7RSYHOBTThn"
                        )
                    }
                )
            }
        }
    }
}

@Composable
fun UploadDashedBox(
    modifier: Modifier = Modifier,
    title: String,
    imageUri: Uri?,
    accentColor: Color,
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    isSelected: Boolean,
    onBoxClick: () -> Unit,
    onPickNew: () -> Unit,
    onClear: () -> Unit
) {
    Surface(
        modifier = modifier
            .height(125.dp)
            .clip(RoundedCornerShape(12.dp))
            .clickable { onBoxClick() },
        color = if (imageUri != null) accentColor.copy(alpha = 0.08f) else MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.4f),
        border = BorderStroke(
            if (isSelected) 2.dp else 1.dp,
            if (isSelected) accentColor else MaterialTheme.colorScheme.outline.copy(alpha = 0.4f)
        ),
        shape = RoundedCornerShape(12.dp)
    ) {
        if (imageUri != null) {
            Box(modifier = Modifier.fillMaxSize()) {
                AsyncImage(
                    model = imageUri,
                    contentDescription = title,
                    contentScale = ContentScale.Crop,
                    modifier = Modifier.fillMaxSize()
                )
                Box(
                    modifier = Modifier
                        .fillMaxSize()
                        .background(Color.Black.copy(alpha = 0.45f))
                )
                Column(
                    modifier = Modifier
                        .fillMaxSize()
                        .padding(8.dp),
                    verticalArrangement = Arrangement.SpaceBetween,
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    Text(
                        text = title,
                        fontSize = 10.sp,
                        fontWeight = FontWeight.Bold,
                        color = Color.White
                    )
                    Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        Button(
                            onClick = onPickNew,
                            colors = ButtonDefaults.buttonColors(containerColor = accentColor),
                            contentPadding = PaddingValues(horizontal = 8.dp, vertical = 2.dp),
                            shape = RoundedCornerShape(6.dp),
                            modifier = Modifier.height(26.dp)
                        ) {
                            Text("Change", fontSize = 9.sp, color = Color.White)
                        }
                        Button(
                            onClick = onClear,
                            colors = ButtonDefaults.buttonColors(containerColor = Color.Red.copy(alpha = 0.8f)),
                            contentPadding = PaddingValues(horizontal = 8.dp, vertical = 2.dp),
                            shape = RoundedCornerShape(6.dp),
                            modifier = Modifier.height(26.dp)
                        ) {
                            Text("Clear", fontSize = 9.sp, color = Color.White)
                        }
                    }
                }
            }
        } else {
            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(8.dp),
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.Center
            ) {
                Icon(
                    imageVector = icon,
                    contentDescription = title,
                    tint = accentColor,
                    modifier = Modifier.size(28.dp)
                )
                Spacer(modifier = Modifier.height(6.dp))
                Text(
                    text = title,
                    fontSize = 11.sp,
                    fontWeight = FontWeight.Bold,
                    color = MaterialTheme.colorScheme.onSurface,
                    textAlign = TextAlign.Center
                )
                Text(
                    text = "Tap to upload",
                    fontSize = 9.sp,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
        }
    }
}

@Composable
fun AdjustmentSliderRow(
    label: String,
    value: Float,
    range: ClosedFloatingPointRange<Float>,
    displayValue: String,
    onValueChange: (Float) -> Unit
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 2.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Text(
            text = label,
            fontSize = 11.sp,
            modifier = Modifier.width(135.dp),
            color = MaterialTheme.colorScheme.onSurfaceVariant
        )
        Slider(
            value = value,
            onValueChange = onValueChange,
            valueRange = range,
            modifier = Modifier.weight(1f)
        )
        Text(
            text = displayValue,
            fontSize = 10.sp,
            fontWeight = FontWeight.Bold,
            color = MaterialTheme.colorScheme.primary,
            textAlign = TextAlign.End,
            modifier = Modifier.width(42.dp)
        )
    }
}

@Composable
fun A4ProGridPreviewCanvas(
    copies: Int,
    frontImageUri: Uri?,
    backImageUri: Uri?,
    studioMode: StudioMode,
    strokeColor: Color,
    strokeWidthPx: Int,
    bgColor: Color,
    isBgRemoved: Boolean
) {
    Card(
        modifier = Modifier
            .width(190.dp)
            .height(240.dp),
        colors = CardDefaults.cardColors(containerColor = Color.White),
        shape = RoundedCornerShape(3.dp),
        elevation = CardDefaults.cardElevation(defaultElevation = 6.dp)
    ) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(6.dp),
            verticalArrangement = Arrangement.SpaceEvenly
        ) {
            val cols = if (copies <= 8) 2 else if (copies <= 16) 4 else 5
            val maxDisplayRows = 6
            val rows = ((copies + cols - 1) / cols).coerceAtMost(maxDisplayRows)

            for (r in 0 until rows) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceEvenly
                ) {
                    for (c in 0 until cols) {
                        val index = r * cols + c
                        if (index < copies) {
                            Box(
                                modifier = Modifier
                                    .size(width = 28.dp, height = 34.dp)
                                    .border(
                                        if (strokeWidthPx > 0) 1.dp else 0.dp,
                                        strokeColor
                                    )
                                    .background(bgColor),
                                contentAlignment = Alignment.Center
                            ) {
                                val itemUri = if (studioMode == StudioMode.ID_CARD_MERGE && backImageUri != null && index % 2 == 1) {
                                    backImageUri
                                } else {
                                    frontImageUri
                                }

                                if (itemUri != null) {
                                    AsyncImage(
                                        model = itemUri,
                                        contentDescription = null,
                                        contentScale = ContentScale.Crop,
                                        modifier = Modifier.fillMaxSize()
                                    )
                                } else {
                                    Icon(
                                        imageVector = Icons.Default.Person,
                                        contentDescription = null,
                                        tint = AkinNavyDark.copy(alpha = 0.5f),
                                        modifier = Modifier.size(16.dp)
                                    )
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun DualDownloadActionButtons(
    toolTitle: String,
    isPaid: Boolean,
    customGenerator: suspend (Context, Boolean, (String) -> Unit) -> File?,
    onPayDownload: () -> Unit
) {
    val context = LocalContext.current
    val coroutineScope = rememberCoroutineScope()
    var isDownloading by remember { mutableStateOf(false) }
    var statusText by remember { mutableStateOf("") }
    var downloadedFile by remember { mutableStateOf<File?>(null) }

    if (isDownloading || downloadedFile != null) {
        FileDownloadProgressDialog(
            isDownloading = isDownloading,
            progressMessage = statusText,
            downloadedFile = downloadedFile,
            onDismiss = {
                isDownloading = false
                downloadedFile = null
            }
        )
    }

    Column(
        modifier = Modifier.fillMaxWidth(),
        verticalArrangement = Arrangement.spacedBy(8.dp)
    ) {
        if (isPaid) {
            Button(
                onClick = {
                    isDownloading = true
                    downloadedFile = null
                    coroutineScope.launch(Dispatchers.IO) {
                        try {
                            val file = customGenerator(context, false) { s ->
                                statusText = s
                            }
                            downloadedFile = file
                        } catch (e: Exception) {
                            withContext(Dispatchers.Main) {
                                Toast.makeText(context, "Error: ${e.message}", Toast.LENGTH_SHORT).show()
                            }
                        } finally {
                            isDownloading = false
                        }
                    }
                },
                modifier = Modifier
                    .fillMaxWidth()
                    .height(48.dp)
                    .testTag("btn_download_hd_unlocked"),
                shape = RoundedCornerShape(12.dp),
                colors = ButtonDefaults.buttonColors(containerColor = AkinGreenSuccess)
            ) {
                Icon(Icons.Default.Download, contentDescription = "Download HD", modifier = Modifier.size(18.dp))
                Spacer(modifier = Modifier.width(8.dp))
                Text("✨ Download Clean HD File (Unlocked)", fontSize = 13.sp, fontWeight = FontWeight.Bold)
            }
        } else {
            Button(
                onClick = onPayDownload,
                modifier = Modifier
                    .fillMaxWidth()
                    .height(48.dp)
                    .testTag("btn_pay_hd_download"),
                shape = RoundedCornerShape(12.dp),
                colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF1E40AF))
            ) {
                Icon(Icons.Default.LockOpen, contentDescription = "Pay & Unlock", modifier = Modifier.size(18.dp), tint = Color.White)
                Spacer(modifier = Modifier.width(8.dp))
                Text("Pay ₹10 & Download HD (No Watermark)", fontSize = 12.5.sp, fontWeight = FontWeight.Bold, color = Color.White)
            }

            OutlinedButton(
                onClick = {
                    val activity = context.findActivity()
                    if (activity != null) {
                        AdMobInterstitialHelper.showInterstitialAd(activity) {
                            // After ad completes
                        }
                    }

                    isDownloading = true
                    downloadedFile = null
                    coroutineScope.launch(Dispatchers.IO) {
                        try {
                            val file = customGenerator(context, true) { s ->
                                statusText = s
                            }
                            downloadedFile = file
                        } catch (e: Exception) {
                            withContext(Dispatchers.Main) {
                                Toast.makeText(context, "Error: ${e.message}", Toast.LENGTH_SHORT).show()
                            }
                        } finally {
                            isDownloading = false
                        }
                    }
                },
                modifier = Modifier
                    .fillMaxWidth()
                    .height(42.dp)
                    .testTag("btn_free_watermark_download"),
                shape = RoundedCornerShape(12.dp)
            ) {
                Icon(Icons.Default.Download, contentDescription = "Free Download", modifier = Modifier.size(16.dp))
                Spacer(modifier = Modifier.width(8.dp))
                Text("Free Download (With Watermark)", fontSize = 11.5.sp)
            }
        }
    }
}
