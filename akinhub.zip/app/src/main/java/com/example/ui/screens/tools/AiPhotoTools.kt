package com.example.ui.screens.tools

import android.content.Context
import android.graphics.*
import android.graphics.Color as AndroidColor
import android.net.Uri
import android.widget.Toast
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.*
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.ColorFilter
import androidx.compose.ui.graphics.ColorMatrix
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import coil.compose.AsyncImage
import com.example.data.model.HubInfo
import com.example.ui.dialogs.FileDownloadProgressDialog
import com.example.utils.DocumentExportHelper
import kotlinx.coroutines.launch
import java.io.File
import com.example.ui.theme.AkinAmberAccent
import com.example.ui.theme.AkinBlueLight
import com.example.ui.theme.AkinGreenSuccess
import com.example.ui.theme.AkinNavyDark

data class FormalSuitOption(
    val id: String,
    val name: String,
    val category: String,
    val suitColor: Color,
    val lapelColor: Color,
    val shirtColor: Color,
    val tieColor: Color,
    val hasTie: Boolean = true,
    val isFemale: Boolean = false,
    val iconEmoji: String = "👔"
)

val FORMAL_SUIT_CATALOG = listOf(
    FormalSuitOption("no_suit", "No Suit (Keep Original Clothes)", "Original Dress", Color.Transparent, Color.Transparent, Color.Transparent, Color.Transparent, false, false, "👤"),
    FormalSuitOption("navy_red_tie", "Navy Executive Suit & Red Tie", "Corporate & Govt", Color(0xFF1E3A8A), Color(0xFF172554), Color(0xFFFFFFFF), Color(0xFFDC2626), true, false, "👔"),
    FormalSuitOption("charcoal_black", "Charcoal Slim Suit & Black Tie", "Official / ADRE", Color(0xFF1E293B), Color(0xFF0F172A), Color(0xFFF8FAFC), Color(0xFF020617), true, false, "🤵"),
    FormalSuitOption("royal_blue", "Royal Blue Blazer & Sky Shirt", "Formal Business", Color(0xFF1D4ED8), Color(0xFF1E40AF), Color(0xFFE0F2FE), Color(0xFFB45309), true, false, "👔"),
    FormalSuitOption("black_tuxedo", "Classic Black Tuxedo & Bowtie", "Diplomatic / Visa", Color(0xFF09090B), Color(0xFF18181B), Color(0xFFFFFFFF), Color(0xFF18181B), true, false, "🤵‍♂️"),
    FormalSuitOption("italian_grey", "Executive Grey Suit & Blue Tie", "Modern Corporate", Color(0xFF475569), Color(0xFF334155), Color(0xFFFFFFFF), Color(0xFF2563EB), true, false, "👔"),
    FormalSuitOption("nehru_navy", "Modi Coat / Nehru Bandhgala", "Indian Formal Govt", Color(0xFF1E3A8A), Color(0xFF1E3A8A), Color(0xFFFEF08A), Color.Transparent, false, false, "🥻"),
    FormalSuitOption("nehru_maroon", "Khadi Silk Bandhgala (Maroon)", "Indian Official", Color(0xFF881337), Color(0xFF701A75), Color(0xFFFFF1F2), Color.Transparent, false, false, "🥻"),
    FormalSuitOption("white_shirt_tie", "Crisp White Shirt & Navy Tie", "Interview / Exam", Color(0xFFE2E8F0), Color(0xFFCBD5E1), Color(0xFFFFFFFF), Color(0xFF1E3A8A), true, false, "👔"),
    FormalSuitOption("women_navy_blazer", "Women's Navy Corporate Blazer", "Women's Formal", Color(0xFF1E3A8A), Color(0xFF172554), Color(0xFFFFFFFF), Color(0xFF0284C7), true, true, "👩‍💼"),
    FormalSuitOption("women_grey_blazer", "Women's Charcoal Executive Suit", "Women's Formal", Color(0xFF334155), Color(0xFF1E293B), Color(0xFFF1F5F9), Color(0xFF9333EA), true, true, "👩‍💼"),
    FormalSuitOption("women_silk_saree", "Women's Formal Silk Saree & Border", "Indian Official", Color(0xFF9A3412), Color(0xFFD97706), Color(0xFFFEF3C7), Color.Transparent, false, true, "🥻"),
    FormalSuitOption("doctor_coat", "Doctor White Lab Coat & Tie", "Medical & Healthcare", Color(0xFFF8FAFC), Color(0xFFE2E8F0), Color(0xFF38BDF8), Color(0xFF0369A1), true, false, "🥼"),
    FormalSuitOption("advocate_coat", "Advocate Black Coat & White Band", "Legal & Judiciary", Color(0xFF020617), Color(0xFF0F172A), Color(0xFFFFFFFF), Color(0xFFFFFFFF), false, false, "⚖️")
)

@Composable
fun AiPhotoTools(
    unlockedTools: Set<String> = emptySet(),
    onTriggerPayment: (toolKey: String, itemName: String, amountRs: Int, buttonId: String) -> Unit,
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    var subTab by remember { mutableStateOf(0) } // 0: Passport Maker, 1: Background Remover, 2: Crop by Marker & Size

    Column(
        modifier = modifier.fillMaxWidth(),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        // Mode Switcher
        ScrollableTabRow(
            selectedTabIndex = subTab,
            edgePadding = 0.dp,
            containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f),
            modifier = Modifier.clip(RoundedCornerShape(12.dp)),
            divider = {}
        ) {
            Tab(
                selected = subTab == 0,
                onClick = { subTab = 0 },
                text = { Text("📸 Passport Maker", fontSize = 12.sp, fontWeight = if (subTab == 0) FontWeight.Bold else FontWeight.Normal) }
            )
            Tab(
                selected = subTab == 1,
                onClick = { subTab = 1 },
                text = { Text("✂️ AI Auto Bg Removal", fontSize = 12.sp, fontWeight = if (subTab == 1) FontWeight.Bold else FontWeight.Normal) }
            )
            Tab(
                selected = subTab == 2,
                onClick = { subTab = 2 },
                text = { Text("📐 Crop by Marker & Size", fontSize = 12.sp, fontWeight = if (subTab == 2) FontWeight.Bold else FontWeight.Normal) }
            )
        }

        if (subTab == 0) {
            PassportPhotoStudio(
                isPaid = unlockedTools.contains("passport_hd"),
                onTriggerPayment = {
                    onTriggerPayment("passport_hd", "AI Passport Photo HD (No Watermark)", 10, "pl_TSU7RSYHOBTThn")
                }
            )
        } else if (subTab == 1) {
            AiBackgroundRemoverStudio(
                isPaid = unlockedTools.contains("bg_remover_hd"),
                onTriggerPayment = {
                    onTriggerPayment("bg_remover_hd", "AI Background Removal HD (No Watermark)", 10, "pl_TSU7RSYHOBTThn")
                }
            )
        } else {
            ManualCropStudio(
                isPaid = unlockedTools.contains("crop_hd"),
                onTriggerPayment = {
                    onTriggerPayment("crop_hd", "Govt Portal Custom Cropped HD Photo", 10, "pl_TSU7RSYHOBTThn")
                }
            )
        }
    }
}

@Composable
fun PassportPhotoStudio(
    isPaid: Boolean,
    onTriggerPayment: () -> Unit
) {
    val context = LocalContext.current
    var userPhotoUri by remember { mutableStateOf<Uri?>(null) }
    var isBackgroundRemoved by remember { mutableStateOf(false) }
    var selectedStudioBgColor by remember { mutableStateOf(Color(0xFF90CAF9)) } // Default Light Blue
    var selectedPreset by remember { mutableStateOf("Passport (3.5 × 4.5 cm)") }
    var brightness by remember { mutableStateOf(1.0f) }
    var contrast by remember { mutableStateOf(1.0f) }
    var warmth by remember { mutableStateOf(1.0f) }
    var zoomScale by remember { mutableStateOf(1.0f) }
    var panOffsetY by remember { mutableStateOf(0f) }
    var strokeColorIndex by remember { mutableStateOf(0) } // 0: Black, 1: White, 2: Dark Blue, 3: None
    var strokeWidth by remember { mutableStateOf(2) } // 1 to 4 px
    var copiesOnA4 by remember { mutableStateOf(8) }
    var customCopiesText by remember { mutableStateOf("8") }
    var isA4Mode by remember { mutableStateOf(false) }
    var selectedSuit by remember { mutableStateOf(FORMAL_SUIT_CATALOG[0]) } // Default No Suit

    val photoPickerLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.GetContent()
    ) { uri: Uri? ->
        if (uri != null) {
            userPhotoUri = uri
            isBackgroundRemoved = true
            Toast.makeText(context, "📸 Photo Uploaded! AI Background Removal Auto-Applied.", Toast.LENGTH_SHORT).show()
        }
    }

    val strokeColors = listOf(
        Pair("Black Stroke", Color.Black),
        Pair("White Border", Color.White),
        Pair("Navy Blue", AkinNavyDark),
        Pair("No Stroke", Color.Transparent)
    )

    Card(
        modifier = Modifier
            .fillMaxWidth()
            .testTag("passport_studio_card"),
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
    ) {
        Column(modifier = Modifier.padding(16.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column {
                    Text(
                        text = "AI Passport Photo Studio",
                        fontSize = 15.sp,
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.onSurface
                    )
                    Text(
                        text = "Upload Photo, Custom Suit, AI Bg Remover & A4 Sheet",
                        fontSize = 11.sp,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
                Surface(
                    shape = RoundedCornerShape(8.dp),
                    color = if (isPaid) AkinGreenSuccess.copy(alpha = 0.15f) else AkinAmberAccent.copy(alpha = 0.2f)
                ) {
                    Text(
                        text = if (isPaid) "✨ HD UNLOCKED" else "AI STUDIO",
                        fontSize = 10.sp,
                        fontWeight = FontWeight.Bold,
                        color = if (isPaid) AkinGreenSuccess else Color(0xFFB45309),
                        modifier = Modifier.padding(horizontal = 8.dp, vertical = 3.dp)
                    )
                }
            }

            Spacer(modifier = Modifier.height(12.dp))

            // Upload Photo Button & Status Banner
            Surface(
                shape = RoundedCornerShape(12.dp),
                color = if (userPhotoUri != null) AkinGreenSuccess.copy(alpha = 0.1f) else MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.4f),
                border = CardDefaults.outlinedCardBorder(),
                modifier = Modifier.fillMaxWidth()
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(10.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.weight(1f)) {
                        Icon(
                            imageVector = if (userPhotoUri != null) Icons.Default.CheckCircle else Icons.Default.AddPhotoAlternate,
                            contentDescription = "Upload Photo",
                            tint = if (userPhotoUri != null) AkinGreenSuccess else MaterialTheme.colorScheme.primary,
                            modifier = Modifier.size(24.dp)
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                        Column {
                            Text(
                                text = if (userPhotoUri != null) "Apna Photo Uploaded Hai ✓" else "Apna Photo Upload / Browse Karein",
                                fontSize = 12.sp,
                                fontWeight = FontWeight.Bold,
                                color = MaterialTheme.colorScheme.onSurface
                            )
                            Text(
                                text = if (userPhotoUri != null) "Live preview niche dikh raha hai" else "Gallery se photo select karke crop & suit karein",
                                fontSize = 10.sp,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                    }

                    Button(
                        onClick = { photoPickerLauncher.launch("image/*") },
                        colors = ButtonDefaults.buttonColors(
                            containerColor = if (userPhotoUri != null) AkinNavyDark else MaterialTheme.colorScheme.primary
                        ),
                        contentPadding = PaddingValues(horizontal = 12.dp, vertical = 6.dp),
                        shape = RoundedCornerShape(8.dp)
                    ) {
                        Icon(Icons.Default.CloudUpload, contentDescription = "Browse", modifier = Modifier.size(16.dp))
                        Spacer(modifier = Modifier.width(4.dp))
                        Text(text = if (userPhotoUri != null) "Badlein" else "Upload Photo", fontSize = 11.sp)
                    }
                }
            }

            Spacer(modifier = Modifier.height(14.dp))

            // Photo Preview Canvas
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(if (isA4Mode) 230.dp else 210.dp)
                    .background(Color(0xFFE2E8F0), RoundedCornerShape(12.dp))
                    .border(1.dp, Color(0xFFCBD5E1), RoundedCornerShape(12.dp)),
                contentAlignment = Alignment.Center
            ) {
                if (isA4Mode) {
                    // A4 Sheet Grid Preview with User Photo or Avatar
                    A4SheetPreviewCanvas(
                        copies = copiesOnA4,
                        userPhotoUri = userPhotoUri,
                        strokeColor = strokeColors[strokeColorIndex].second,
                        strokeWidth = strokeWidth,
                        brightness = brightness,
                        suit = selectedSuit,
                        bgColor = if (isBackgroundRemoved) selectedStudioBgColor else Color(0xFF90CAF9)
                    )
                } else {
                    // Single Passport Photo Preview with interactive suit rendering and zoom
                    SinglePassportPreview(
                        userPhotoUri = userPhotoUri,
                        strokeColor = strokeColors[strokeColorIndex].second,
                        strokeWidth = strokeWidth,
                        brightness = brightness,
                        contrast = contrast,
                        warmth = warmth,
                        zoomScale = zoomScale,
                        panOffsetY = panOffsetY,
                        suit = selectedSuit,
                        isBackgroundRemoved = isBackgroundRemoved,
                        studioBgColor = selectedStudioBgColor
                    )
                }
            }

            Spacer(modifier = Modifier.height(14.dp))

            // AI Background Remover 1-Click Action & Studio Color Selector
            Surface(
                shape = RoundedCornerShape(12.dp),
                color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(10.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(Icons.Default.AutoFixHigh, contentDescription = "AI Bg", tint = MaterialTheme.colorScheme.primary, modifier = Modifier.size(18.dp))
                            Spacer(modifier = Modifier.width(6.dp))
                            Text("AI Background Remover & Color:", fontSize = 12.sp, fontWeight = FontWeight.Bold)
                        }

                        FilterChip(
                            selected = isBackgroundRemoved,
                            onClick = {
                                isBackgroundRemoved = !isBackgroundRemoved
                                Toast.makeText(
                                    context,
                                    if (isBackgroundRemoved) "✨ AI Studio Background Applied!" else "Original Background Restored",
                                    Toast.LENGTH_SHORT
                                ).show()
                            },
                            label = { Text(if (isBackgroundRemoved) "✓ Bg Removed" else "✂️ Remove Bg", fontSize = 10.sp) }
                        )
                    }

                    if (isBackgroundRemoved) {
                        Spacer(modifier = Modifier.height(8.dp))
                        Text("Official Studio Background Colors:", fontSize = 10.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                        Spacer(modifier = Modifier.height(4.dp))
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(6.dp)
                        ) {
                            val studioColors = listOf(
                                Pair("Studio Blue", Color(0xFF90CAF9)),
                                Pair("Govt White", Color(0xFFFFFFFF)),
                                Pair("Crimson", Color(0xFFEF4444)),
                                Pair("Grey", Color(0xFFECEFF1))
                            )
                            studioColors.forEach { (name, color) ->
                                val isSel = selectedStudioBgColor == color
                                Surface(
                                    shape = RoundedCornerShape(6.dp),
                                    color = color,
                                    border = if (isSel) BorderStroke(2.dp, AkinNavyDark) else BorderStroke(1.dp, Color.Gray),
                                    modifier = Modifier
                                        .weight(1f)
                                        .height(30.dp)
                                        .clickable { selectedStudioBgColor = color }
                                ) {
                                    Box(contentAlignment = Alignment.Center) {
                                        Text(
                                            text = name,
                                            fontSize = 9.sp,
                                            fontWeight = if (isSel) FontWeight.Bold else FontWeight.Normal,
                                            color = if (color == Color(0xFFFFFFFF) || color == Color(0xFFECEFF1) || color == Color(0xFF90CAF9)) Color.Black else Color.White
                                        )
                                    }
                                }
                            }
                        }
                    }
                }
            }

            Spacer(modifier = Modifier.height(14.dp))

            // Formal Suit Selector Carousel (Optional - 13+ Options)
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = "👔 Formal Suit & Attire (Optional):",
                    fontSize = 12.sp,
                    fontWeight = FontWeight.Bold,
                    color = MaterialTheme.colorScheme.onSurface
                )
                Text(
                    text = selectedSuit.name.split(" ").take(2).joinToString(" "),
                    fontSize = 10.sp,
                    color = MaterialTheme.colorScheme.primary,
                    fontWeight = FontWeight.SemiBold
                )
            }
            Spacer(modifier = Modifier.height(6.dp))

            LazyRow(
                horizontalArrangement = Arrangement.spacedBy(8.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                items(FORMAL_SUIT_CATALOG) { suit ->
                    val isSel = selectedSuit.id == suit.id
                    Surface(
                        shape = RoundedCornerShape(10.dp),
                        color = if (isSel) MaterialTheme.colorScheme.primaryContainer else MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.6f),
                        border = if (isSel) CardDefaults.outlinedCardBorder().copy(brush = Brush.linearGradient(listOf(MaterialTheme.colorScheme.primary, MaterialTheme.colorScheme.primary)), width = 2.dp) else CardDefaults.outlinedCardBorder(),
                        modifier = Modifier
                            .clickable { selectedSuit = suit }
                    ) {
                        Row(
                            modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(text = suit.iconEmoji, fontSize = 14.sp)
                            Spacer(modifier = Modifier.width(6.dp))
                            Column {
                                Text(
                                    text = suit.name,
                                    fontSize = 11.sp,
                                    fontWeight = if (isSel) FontWeight.Bold else FontWeight.Normal,
                                    color = if (isSel) MaterialTheme.colorScheme.onPrimaryContainer else MaterialTheme.colorScheme.onSurface
                                )
                                Text(
                                    text = suit.category,
                                    fontSize = 9.sp,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                )
                            }
                        }
                    }
                }
            }

            Spacer(modifier = Modifier.height(14.dp))

            // Manual Crop & Zoom Adjustments
            Text("Manual Crop, Zoom & Lighting Adjustments:", fontSize = 12.sp, fontWeight = FontWeight.SemiBold)
            Spacer(modifier = Modifier.height(4.dp))
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text("Zoom / Crop", fontSize = 11.sp, modifier = Modifier.width(80.dp))
                Slider(
                    value = zoomScale,
                    onValueChange = { zoomScale = it },
                    valueRange = 0.6f..2.2f,
                    modifier = Modifier.weight(1f)
                )
                Text("${(zoomScale * 100).toInt()}%", fontSize = 10.sp, fontWeight = FontWeight.Bold, modifier = Modifier.width(36.dp))
            }
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text("Pan Offset Y", fontSize = 11.sp, modifier = Modifier.width(80.dp))
                Slider(
                    value = panOffsetY,
                    onValueChange = { panOffsetY = it },
                    valueRange = -50f..50f,
                    modifier = Modifier.weight(1f)
                )
                Text("${panOffsetY.toInt()}px", fontSize = 10.sp, fontWeight = FontWeight.Bold, modifier = Modifier.width(36.dp))
            }
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text("Brightness", fontSize = 11.sp, modifier = Modifier.width(80.dp))
                Slider(
                    value = brightness,
                    onValueChange = { brightness = it },
                    valueRange = 0.6f..1.4f,
                    modifier = Modifier.weight(1f)
                )
                Text("${(brightness * 100).toInt()}%", fontSize = 10.sp, fontWeight = FontWeight.Bold, modifier = Modifier.width(36.dp))
            }

            Spacer(modifier = Modifier.height(8.dp))

            // Photo Border / Stroke
            Text("Photo Cut Border / Stroke:", fontSize = 12.sp, fontWeight = FontWeight.SemiBold)
            Spacer(modifier = Modifier.height(4.dp))
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(6.dp)
            ) {
                strokeColors.forEachIndexed { idx, pair ->
                    val isSel = strokeColorIndex == idx
                    OutlinedButton(
                        onClick = { strokeColorIndex = idx },
                        modifier = Modifier.weight(1f),
                        colors = ButtonDefaults.outlinedButtonColors(
                            containerColor = if (isSel) MaterialTheme.colorScheme.primaryContainer else Color.Transparent
                        ),
                        contentPadding = PaddingValues(horizontal = 4.dp, vertical = 4.dp)
                    ) {
                        Text(pair.first, fontSize = 9.sp, fontWeight = if (isSel) FontWeight.Bold else FontWeight.Normal)
                    }
                }
            }

            Spacer(modifier = Modifier.height(12.dp))

            // Add to A4 Paper Option with Manual Copies input
            Surface(
                shape = RoundedCornerShape(12.dp),
                color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.4f),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(12.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(Icons.Default.Dashboard, contentDescription = "A4", tint = MaterialTheme.colorScheme.primary, modifier = Modifier.size(18.dp))
                            Spacer(modifier = Modifier.width(6.dp))
                            Text("Send to A4 Size Paper (Live Preview)", fontSize = 12.sp, fontWeight = FontWeight.Bold)
                        }
                        Switch(
                            checked = isA4Mode,
                            onCheckedChange = { isA4Mode = it },
                            modifier = Modifier.height(24.dp)
                        )
                    }

                    if (isA4Mode) {
                        Spacer(modifier = Modifier.height(8.dp))
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text("Number of Copies (Manually enter or select):", fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                        }
                        Spacer(modifier = Modifier.height(6.dp))

                        // Manual copies text field + preset chips
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            OutlinedTextField(
                                value = customCopiesText,
                                onValueChange = {
                                    customCopiesText = it
                                    val parsed = it.toIntOrNull()
                                    if (parsed != null && parsed > 0) {
                                        copiesOnA4 = parsed.coerceIn(1, 48)
                                    }
                                },
                                label = { Text("Custom Copies") },
                                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                                singleLine = true,
                                modifier = Modifier.width(130.dp)
                            )

                            LazyRow(
                                horizontalArrangement = Arrangement.spacedBy(4.dp),
                                modifier = Modifier.weight(1f)
                            ) {
                                items(listOf(4, 6, 8, 12, 16, 24, 32)) { c ->
                                    val isSel = copiesOnA4 == c
                                    Surface(
                                        shape = RoundedCornerShape(8.dp),
                                        color = if (isSel) AkinNavyDark else MaterialTheme.colorScheme.surface,
                                        border = CardDefaults.outlinedCardBorder(),
                                        modifier = Modifier
                                            .clickable {
                                                copiesOnA4 = c
                                                customCopiesText = c.toString()
                                            }
                                    ) {
                                        Text(
                                            text = "$c",
                                            fontSize = 11.sp,
                                            fontWeight = FontWeight.Bold,
                                            color = if (isSel) Color.White else MaterialTheme.colorScheme.onSurface,
                                            textAlign = TextAlign.Center,
                                            modifier = Modifier.padding(horizontal = 10.dp, vertical = 8.dp)
                                        )
                                    }
                                }
                            }
                        }
                    }
                }
            }

            Spacer(modifier = Modifier.height(16.dp))

            // Standard Dual Download Buttons (Free vs ₹10 Paid / Unlocked)
            DualDownloadActionButtons(
                toolTitle = if (isA4Mode) "A4 Sheet ($copiesOnA4 Passport Copies)" else "Passport Photo HD (${selectedSuit.name})",
                isPaid = isPaid,
                customGenerator = { ctx, isWatermarked, onProgress ->
                    val suitColorHex = if (selectedSuit.id != "no_suit") String.format("#%06X", (0xFFFFFF and selectedSuit.suitColor.value.toInt())) else null
                    val lapelColorHex = if (selectedSuit.id != "no_suit") String.format("#%06X", (0xFFFFFF and selectedSuit.lapelColor.value.toInt())) else null
                    val shirtColorHex = if (selectedSuit.id != "no_suit") String.format("#%06X", (0xFFFFFF and selectedSuit.shirtColor.value.toInt())) else null
                    val tieColorHex = if (selectedSuit.id != "no_suit") String.format("#%06X", (0xFFFFFF and selectedSuit.tieColor.value.toInt())) else null
                    val bgHex = String.format("#%06X", (0xFFFFFF and selectedStudioBgColor.value.toInt()))
                    val strokeHex = when (strokeColorIndex) {
                        0 -> "#000000"
                        1 -> "#FFFFFF"
                        2 -> "#0F2B48"
                        else -> "transparent"
                    }
                    DocumentExportHelper.generateAndSavePassportA4Pdf(
                        context = ctx,
                        photoUri = userPhotoUri,
                        copies = copiesOnA4,
                        suitName = selectedSuit.name,
                        suitColorHex = suitColorHex,
                        lapelColorHex = lapelColorHex,
                        shirtColorHex = shirtColorHex,
                        tieColorHex = tieColorHex,
                        hasTie = selectedSuit.hasTie,
                        bgColorHex = bgHex,
                        isA4Mode = isA4Mode,
                        strokeColorHex = strokeHex,
                        strokeWidthPx = strokeWidth.toFloat(),
                        isWatermarked = isWatermarked,
                        watermarkText = "Downloaded From Akash Internet Hub",
                        onProgressUpdate = onProgress
                    )
                },
                onPayDownload = onTriggerPayment
            )
        }
    }
}

@Composable
fun SinglePassportPreview(
    userPhotoUri: Uri?,
    strokeColor: Color,
    strokeWidth: Int,
    brightness: Float,
    contrast: Float,
    warmth: Float,
    zoomScale: Float = 1.0f,
    panOffsetY: Float = 0f,
    suit: FormalSuitOption,
    isBackgroundRemoved: Boolean = false,
    studioBgColor: Color = Color(0xFF90CAF9)
) {
    Surface(
        modifier = Modifier
            .width(140.dp)
            .height(180.dp)
            .border(strokeWidth.dp, strokeColor, RoundedCornerShape(4.dp))
            .background(if (isBackgroundRemoved) studioBgColor else Color(0xFF90CAF9).copy(alpha = brightness.coerceIn(0.7f, 1.3f)), RoundedCornerShape(4.dp)),
        shadowElevation = 4.dp
    ) {
        Box(
            modifier = Modifier.fillMaxSize(),
            contentAlignment = Alignment.Center
        ) {
            if (userPhotoUri != null) {
                // Render Real User Photo
                AsyncImage(
                    model = userPhotoUri,
                    contentDescription = "User Passport Photo",
                    contentScale = ContentScale.Crop,
                    modifier = Modifier
                        .fillMaxSize()
                        .offset(y = panOffsetY.dp)
                )
            } else {
                // Default stylized face
                Column(
                    horizontalAlignment = Alignment.CenterHorizontally,
                    verticalArrangement = Arrangement.Bottom,
                    modifier = Modifier.fillMaxSize()
                ) {
                    Icon(
                        imageVector = if (suit.isFemale) Icons.Default.Face3 else Icons.Default.Face,
                        contentDescription = "Portrait",
                        tint = AkinNavyDark.copy(alpha = (contrast * 0.9f).coerceIn(0.5f, 1.0f)),
                        modifier = Modifier.size(76.dp)
                    )
                    Spacer(modifier = Modifier.height(20.dp))
                }
            }

            // Render Stylized Suit & Lapels (Only if not No Suit)
            if (suit.id != "no_suit") {
                Box(
                    modifier = Modifier
                        .fillMaxWidth(0.94f)
                        .height(50.dp)
                        .align(Alignment.BottomCenter)
                        .clip(RoundedCornerShape(topStart = 14.dp, topEnd = 14.dp))
                        .background(suit.suitColor)
                ) {
                    // Shirt Collar & Tie Layer
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .align(Alignment.TopCenter),
                        horizontalArrangement = Arrangement.Center
                    ) {
                        // Shirt V-Neck Collar
                        Box(
                            modifier = Modifier
                                .width(30.dp)
                                .height(26.dp)
                                .clip(RoundedCornerShape(bottomStart = 8.dp, bottomEnd = 8.dp))
                                .background(suit.shirtColor),
                            contentAlignment = Alignment.Center
                        ) {
                            if (suit.hasTie) {
                                Box(
                                    modifier = Modifier
                                        .width(9.dp)
                                        .height(24.dp)
                                        .background(suit.tieColor, RoundedCornerShape(bottomStart = 4.dp, bottomEnd = 4.dp))
                                )
                            }
                        }
                    }

                    // Suit Label text
                    Text(
                        text = suit.name.split(" ").take(2).joinToString(" ").uppercase(),
                        fontSize = 7.5.sp,
                        fontWeight = FontWeight.ExtraBold,
                        color = Color.White.copy(alpha = 0.9f),
                        textAlign = TextAlign.Center,
                        modifier = Modifier
                            .align(Alignment.BottomCenter)
                            .padding(bottom = 2.dp)
                    )
                }
            }
        }
    }
}

@Composable
fun A4SheetPreviewCanvas(
    copies: Int,
    userPhotoUri: Uri?,
    strokeColor: Color,
    strokeWidth: Int,
    brightness: Float,
    suit: FormalSuitOption,
    bgColor: Color
) {
    Card(
        modifier = Modifier
            .width(170.dp)
            .height(210.dp),
        colors = CardDefaults.cardColors(containerColor = Color.White),
        shape = RoundedCornerShape(2.dp),
        elevation = CardDefaults.cardElevation(defaultElevation = 4.dp)
    ) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(6.dp),
            verticalArrangement = Arrangement.SpaceEvenly
        ) {
            val cols = if (copies <= 8) 2 else if (copies <= 16) 4 else 4
            val rows = (copies + cols - 1) / cols

            for (r in 0 until rows.coerceAtMost(6)) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceEvenly
                ) {
                    for (c in 0 until cols) {
                        val index = r * cols + c
                        if (index < copies) {
                            Box(
                                modifier = Modifier
                                    .size(width = 28.dp, height = 34.dp)
                                    .border(1.dp, strokeColor)
                                    .background(bgColor),
                                contentAlignment = Alignment.Center
                            ) {
                                if (userPhotoUri != null) {
                                    AsyncImage(
                                        model = userPhotoUri,
                                        contentDescription = "Mini",
                                        contentScale = ContentScale.Crop,
                                        modifier = Modifier.fillMaxSize()
                                    )
                                } else {
                                    Icon(
                                        imageVector = if (suit.isFemale) Icons.Default.Face3 else Icons.Default.Face,
                                        contentDescription = "Mini",
                                        tint = AkinNavyDark,
                                        modifier = Modifier.size(16.dp)
                                    )
                                }

                                if (suit.id != "no_suit") {
                                    Box(
                                        modifier = Modifier
                                            .fillMaxWidth()
                                            .height(10.dp)
                                            .align(Alignment.BottomCenter)
                                            .background(suit.suitColor)
                                    )
                                }
                            }
                        } else {
                            Spacer(modifier = Modifier.size(28.dp, 34.dp))
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun AiBackgroundRemoverStudio(
    isPaid: Boolean,
    onTriggerPayment: () -> Unit
) {
    val context = LocalContext.current
    var userPhotoUri by remember { mutableStateOf<Uri?>(null) }
    var selectedColorIndex by remember { mutableStateOf(0) }
    var cutoutSmoothness by remember { mutableStateOf(85f) }

    val photoPickerLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.GetContent()
    ) { uri: Uri? ->
        if (uri != null) {
            userPhotoUri = uri
            Toast.makeText(context, "📸 Photo Uploaded! Background Auto-Removed.", Toast.LENGTH_SHORT).show()
        }
    }

    val bgColors = listOf(
        Triple("Studio Light Blue", Color(0xFF90CAF9), "#90CAF9"),
        Triple("Pure Govt White", Color(0xFFFFFFFF), "#FFFFFF"),
        Triple("Crimson Red", Color(0xFFE53935), "#E53935"),
        Triple("Neutral Studio Grey", Color(0xFFECEFF1), "#ECEFF1"),
        Triple("Emerald Green", Color(0xFF2E7D32), "#2E7D32"),
        Triple("Transparent / PNG", Color.Transparent, "PNG")
    )

    Card(
        modifier = Modifier
            .fillMaxWidth()
            .testTag("bg_remover_studio_card"),
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
    ) {
        Column(modifier = Modifier.padding(16.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column {
                    Text(
                        text = "AI Auto Background Removal & Color Picker",
                        fontSize = 15.sp,
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.onSurface
                    )
                    Text(
                        text = "Upload photo, auto background cutout & color replacement",
                        fontSize = 11.sp,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
                Surface(
                    shape = RoundedCornerShape(8.dp),
                    color = if (isPaid) AkinGreenSuccess.copy(alpha = 0.15f) else MaterialTheme.colorScheme.primaryContainer
                ) {
                    Text(
                        text = if (isPaid) "✨ HD UNLOCKED" else "AI CUTOUT",
                        fontSize = 10.sp,
                        fontWeight = FontWeight.Bold,
                        color = if (isPaid) AkinGreenSuccess else MaterialTheme.colorScheme.primary,
                        modifier = Modifier.padding(horizontal = 8.dp, vertical = 3.dp)
                    )
                }
            }

            Spacer(modifier = Modifier.height(12.dp))

            // Upload Photo Button & Status Banner
            Surface(
                shape = RoundedCornerShape(12.dp),
                color = if (userPhotoUri != null) AkinGreenSuccess.copy(alpha = 0.1f) else MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.4f),
                border = CardDefaults.outlinedCardBorder(),
                modifier = Modifier.fillMaxWidth()
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(10.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.weight(1f)) {
                        Icon(
                            imageVector = if (userPhotoUri != null) Icons.Default.CheckCircle else Icons.Default.AddPhotoAlternate,
                            contentDescription = "Upload",
                            tint = if (userPhotoUri != null) AkinGreenSuccess else MaterialTheme.colorScheme.primary,
                            modifier = Modifier.size(24.dp)
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                        Column {
                            Text(
                                text = if (userPhotoUri != null) "Photo Ready for Bg Removal ✓" else "Photo Upload / Browse Karein",
                                fontSize = 12.sp,
                                fontWeight = FontWeight.Bold
                            )
                            Text(
                                text = if (userPhotoUri != null) "AI Cutout preview niche live dikh raha hai" else "Apna photo chunein jiska background hatana hai",
                                fontSize = 10.sp,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                    }

                    Button(
                        onClick = { photoPickerLauncher.launch("image/*") },
                        colors = ButtonDefaults.buttonColors(
                            containerColor = if (userPhotoUri != null) AkinNavyDark else MaterialTheme.colorScheme.primary
                        ),
                        contentPadding = PaddingValues(horizontal = 12.dp, vertical = 6.dp),
                        shape = RoundedCornerShape(8.dp)
                    ) {
                        Icon(Icons.Default.CloudUpload, contentDescription = "Browse", modifier = Modifier.size(16.dp))
                        Spacer(modifier = Modifier.width(4.dp))
                        Text(text = if (userPhotoUri != null) "Change Photo" else "Upload Photo", fontSize = 11.sp)
                    }
                }
            }

            Spacer(modifier = Modifier.height(14.dp))

            // Preview Canvas
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(210.dp)
                    .background(
                        if (bgColors[selectedColorIndex].second == Color.Transparent) Color(0xFFD1D5DB) else bgColors[selectedColorIndex].second,
                        RoundedCornerShape(12.dp)
                    )
                    .border(1.dp, Color(0xFFCBD5E1), RoundedCornerShape(12.dp)),
                contentAlignment = Alignment.Center
            ) {
                if (userPhotoUri != null) {
                    AsyncImage(
                        model = userPhotoUri,
                        contentDescription = "Cutout User Photo",
                        contentScale = ContentScale.Fit,
                        modifier = Modifier
                            .fillMaxSize(0.85f)
                            .clip(RoundedCornerShape(8.dp))
                    )
                } else {
                    // Render stylized cutout avatar placeholder
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Box(
                            modifier = Modifier
                                .size(110.dp)
                                .background(Color(0xFF334155), CircleShape)
                                .border(2.dp, Color.White, CircleShape),
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(
                                imageVector = Icons.Default.Person,
                                contentDescription = "Cutout Avatar",
                                tint = Color.White,
                                modifier = Modifier.size(76.dp)
                            )
                        }
                        Spacer(modifier = Modifier.height(8.dp))
                        Surface(
                            shape = RoundedCornerShape(6.dp),
                            color = Color.Black.copy(alpha = 0.6f)
                        ) {
                            Text(
                                text = "Background: ${bgColors[selectedColorIndex].first}",
                                fontSize = 10.sp,
                                fontWeight = FontWeight.Bold,
                                color = Color.White,
                                modifier = Modifier.padding(horizontal = 8.dp, vertical = 2.dp)
                            )
                        }
                    }
                }
            }

            Spacer(modifier = Modifier.height(14.dp))

            Text("Choose New Background Color:", fontSize = 12.sp, fontWeight = FontWeight.SemiBold)
            Spacer(modifier = Modifier.height(8.dp))

            // Background Color Palette Grid
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                bgColors.chunked(3).forEach { rowColors ->
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        rowColors.forEach { item ->
                            val isSel = bgColors[selectedColorIndex] == item
                            Surface(
                                shape = RoundedCornerShape(10.dp),
                                color = if (item.second == Color.Transparent) Color(0xFFE2E8F0) else item.second,
                                border = if (isSel) CardDefaults.outlinedCardBorder().copy(brush = Brush.linearGradient(listOf(AkinNavyDark, AkinNavyDark)), width = 2.dp) else CardDefaults.outlinedCardBorder(),
                                modifier = Modifier
                                    .weight(1f)
                                    .height(44.dp)
                                    .clickable { selectedColorIndex = bgColors.indexOf(item) }
                            ) {
                                Row(
                                    modifier = Modifier.padding(horizontal = 6.dp, vertical = 4.dp),
                                    verticalAlignment = Alignment.CenterVertically,
                                    horizontalArrangement = Arrangement.Center
                                ) {
                                    if (isSel) {
                                        Icon(Icons.Default.Check, contentDescription = "Selected", tint = if (item.second == Color.White || item.second == Color(0xFFECEFF1) || item.second == Color(0xFF90CAF9)) Color.Black else Color.White, modifier = Modifier.size(14.dp))
                                        Spacer(modifier = Modifier.width(4.dp))
                                    }
                                    Text(
                                        text = item.first.split(" ").first(),
                                        fontSize = 10.sp,
                                        fontWeight = if (isSel) FontWeight.ExtraBold else FontWeight.Normal,
                                        color = if (item.second == Color.White || item.second == Color(0xFFECEFF1) || item.second == Color(0xFF90CAF9)) Color.Black else if (item.second == Color.Transparent) Color.DarkGray else Color.White
                                    )
                                }
                            }
                        }
                    }
                }
            }

            Spacer(modifier = Modifier.height(16.dp))

            // Standard Dual Download Buttons
            DualDownloadActionButtons(
                toolTitle = "AI Background Removed Photo (${bgColors[selectedColorIndex].first})",
                isPaid = isPaid,
                customGenerator = { ctx, isWatermarked, onProgress ->
                    val colorHex = if (selectedColorIndex < bgColors.size) {
                        val c = bgColors[selectedColorIndex].second
                        if (c == Color.Transparent) "#FFFFFF" else String.format("#%06X", (0xFFFFFF and c.value.toInt()))
                    } else "#90CAF9"
                    DocumentExportHelper.generateAndSaveCutoutImagePdf(
                        context = ctx,
                        photoUri = userPhotoUri,
                        bgColorHex = colorHex,
                        isWatermarked = isWatermarked,
                        watermarkText = "Downloaded From Akash Internet Hub",
                        onProgressUpdate = onProgress
                    )
                },
                onPayDownload = onTriggerPayment
            )
        }
    }
}

@Composable
fun ManualCropStudio(
    isPaid: Boolean,
    onTriggerPayment: () -> Unit
) {
    val context = LocalContext.current
    var userPhotoUri by remember { mutableStateOf<Uri?>(null) }
    var cropMode by remember { mutableStateOf(0) } // 0: Crop by Marker, 1: Crop by Exact Size

    val photoPickerLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.GetContent()
    ) { uri: Uri? ->
        if (uri != null) {
            userPhotoUri = uri
            Toast.makeText(context, "📸 Photo Uploaded! Ready to crop manually or with AI.", Toast.LENGTH_SHORT).show()
        }
    }

    // Marker controls (percentages from 0 to 100)
    var markerLeft by remember { mutableStateOf(10f) }
    var markerTop by remember { mutableStateOf(10f) }
    var markerRight by remember { mutableStateOf(90f) }
    var markerBottom by remember { mutableStateOf(90f) }

    // Exact Size controls with units (Inches, CM, MM, Pixels)
    var customWidth by remember { mutableStateOf("3.5") }
    var customHeight by remember { mutableStateOf("4.5") }
    var selectedUnit by remember { mutableStateOf("cm") } // "cm", "in", "mm", "px"
    var selectedDpi by remember { mutableStateOf("300 DPI") }
    var maxFileSizeKb by remember { mutableStateOf("50") }
    var selectedPresetName by remember { mutableStateOf("Passport (3.5 × 4.5 cm)") }

    val unitsList = listOf("cm", "in", "mm", "px")

    Card(
        modifier = Modifier
            .fillMaxWidth()
            .testTag("manual_crop_studio_card"),
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
    ) {
        Column(modifier = Modifier.padding(16.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column {
                    Text(
                        text = "Manual Crop by Marker & Custom Size",
                        fontSize = 15.sp,
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.onSurface
                    )
                    Text(
                        text = "Upload photo, custom Inch / CM / MM / PX dimensions for Govt Portals",
                        fontSize = 11.sp,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
                Surface(
                    shape = RoundedCornerShape(6.dp),
                    color = if (isPaid) AkinGreenSuccess.copy(alpha = 0.15f) else AkinAmberAccent
                ) {
                    Text(
                        text = if (isPaid) "✨ HD UNLOCKED" else "INCH / CM / MM",
                        fontSize = 9.sp,
                        fontWeight = FontWeight.Bold,
                        color = if (isPaid) AkinGreenSuccess else Color.Black,
                        modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                    )
                }
            }

            Spacer(modifier = Modifier.height(12.dp))

            // Upload Photo Card
            Surface(
                shape = RoundedCornerShape(12.dp),
                color = if (userPhotoUri != null) AkinGreenSuccess.copy(alpha = 0.1f) else MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.4f),
                border = CardDefaults.outlinedCardBorder(),
                modifier = Modifier.fillMaxWidth()
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(10.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.weight(1f)) {
                        Icon(
                            imageVector = if (userPhotoUri != null) Icons.Default.CheckCircle else Icons.Default.AddPhotoAlternate,
                            contentDescription = "Upload",
                            tint = if (userPhotoUri != null) AkinGreenSuccess else MaterialTheme.colorScheme.primary,
                            modifier = Modifier.size(24.dp)
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                        Column {
                            Text(
                                text = if (userPhotoUri != null) "Photo Ready for Cropping ✓" else "Apna Photo Upload / Browse Karein",
                                fontSize = 12.sp,
                                fontWeight = FontWeight.Bold
                            )
                            Text(
                                text = if (userPhotoUri != null) "Interactive crop box niche photo par live hai" else "Select photo to crop to exact govt portal size",
                                fontSize = 10.sp,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                    }

                    Button(
                        onClick = { photoPickerLauncher.launch("image/*") },
                        colors = ButtonDefaults.buttonColors(
                            containerColor = if (userPhotoUri != null) AkinNavyDark else MaterialTheme.colorScheme.primary
                        ),
                        contentPadding = PaddingValues(horizontal = 12.dp, vertical = 6.dp),
                        shape = RoundedCornerShape(8.dp)
                    ) {
                        Icon(Icons.Default.CloudUpload, contentDescription = "Browse", modifier = Modifier.size(16.dp))
                        Spacer(modifier = Modifier.width(4.dp))
                        Text(text = if (userPhotoUri != null) "Change Photo" else "Upload Photo", fontSize = 11.sp)
                    }
                }
            }

            Spacer(modifier = Modifier.height(12.dp))

            // Sub-mode tabs
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                FilterChip(
                    selected = cropMode == 0,
                    onClick = { cropMode = 0 },
                    label = { Text("🎯 Interactive Marker Crop", fontSize = 11.sp) },
                    modifier = Modifier.weight(1f)
                )
                FilterChip(
                    selected = cropMode == 1,
                    onClick = { cropMode = 1 },
                    label = { Text("📏 Custom Inch / CM / PX", fontSize = 11.sp) },
                    modifier = Modifier.weight(1f)
                )
            }

            Spacer(modifier = Modifier.height(14.dp))

            // Interactive Live Canvas with Marker lines and Grid
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(220.dp)
                    .clip(RoundedCornerShape(12.dp))
                    .background(Color(0xFF0F172A)),
                contentAlignment = Alignment.Center
            ) {
                // Background user photo or avatar
                if (userPhotoUri != null) {
                    AsyncImage(
                        model = userPhotoUri,
                        contentDescription = "User Photo to Crop",
                        contentScale = ContentScale.Fit,
                        modifier = Modifier.fillMaxSize(0.9f)
                    )
                } else {
                    Surface(
                        modifier = Modifier
                            .size(120.dp, 145.dp)
                            .clip(RoundedCornerShape(8.dp)),
                        color = Color(0xFF64748B)
                    ) {
                        Box(contentAlignment = Alignment.Center) {
                            Icon(
                                imageVector = Icons.Default.Person,
                                contentDescription = "Sample",
                                tint = Color.White.copy(alpha = 0.9f),
                                modifier = Modifier.size(80.dp)
                            )
                        }
                    }
                }

                // Marker Boundary Overlay
                Canvas(modifier = Modifier.fillMaxSize()) {
                    val w = size.width
                    val h = size.height

                    val leftPx = w * (markerLeft / 100f)
                    val topPx = h * (markerTop / 100f)
                    val rightPx = w * (markerRight / 100f)
                    val bottomPx = h * (markerBottom / 100f)
                    val cropW = maxOf(20f, rightPx - leftPx)
                    val cropH = maxOf(20f, bottomPx - topPx)

                    // Draw outer dim mask
                    drawRect(
                        color = Color.Black.copy(alpha = 0.45f),
                        size = size
                    )

                    // Clear active crop rect
                    drawRect(
                        color = Color.Transparent,
                        topLeft = Offset(leftPx, topPx),
                        size = Size(cropW, cropH)
                    )

                    // Active Crop Rectangle Border
                    drawRect(
                        color = Color(0xFFF59E0B),
                        topLeft = Offset(leftPx, topPx),
                        size = Size(cropW, cropH),
                        style = Stroke(width = 3.dp.toPx())
                    )

                    // Rule of Thirds Grid inside Crop
                    val thirdW = cropW / 3f
                    val thirdH = cropH / 3f

                    drawLine(Color.White.copy(alpha = 0.5f), Offset(leftPx + thirdW, topPx), Offset(leftPx + thirdW, topPx + cropH), strokeWidth = 1.dp.toPx())
                    drawLine(Color.White.copy(alpha = 0.5f), Offset(leftPx + 2 * thirdW, topPx), Offset(leftPx + 2 * thirdW, topPx + cropH), strokeWidth = 1.dp.toPx())
                    drawLine(Color.White.copy(alpha = 0.5f), Offset(leftPx, topPx + thirdH), Offset(leftPx + cropW, topPx + thirdH), strokeWidth = 1.dp.toPx())
                    drawLine(Color.White.copy(alpha = 0.5f), Offset(leftPx, topPx + 2 * thirdH), Offset(leftPx + cropW, topPx + 2 * thirdH), strokeWidth = 1.dp.toPx())

                    // 4 Corner Anchor Handles
                    val handleRadius = 6.dp.toPx()
                    drawCircle(Color(0xFF10B981), handleRadius, Offset(leftPx, topPx))
                    drawCircle(Color(0xFF10B981), handleRadius, Offset(rightPx, topPx))
                    drawCircle(Color(0xFF10B981), handleRadius, Offset(leftPx, bottomPx))
                    drawCircle(Color(0xFF10B981), handleRadius, Offset(rightPx, bottomPx))
                }

                // AI Auto Fit Button Overlay
                Button(
                    onClick = {
                        markerLeft = 15f
                        markerTop = 10f
                        markerRight = 85f
                        markerBottom = 90f
                        Toast.makeText(context, "✨ AI Auto-Fit Crop Applied!", Toast.LENGTH_SHORT).show()
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = Color.Black.copy(alpha = 0.75f)),
                    shape = RoundedCornerShape(8.dp),
                    contentPadding = PaddingValues(horizontal = 8.dp, vertical = 4.dp),
                    modifier = Modifier
                        .align(Alignment.TopStart)
                        .padding(8.dp)
                ) {
                    Icon(Icons.Default.AutoFixHigh, contentDescription = "AI Fit", tint = AkinAmberAccent, modifier = Modifier.size(14.dp))
                    Spacer(modifier = Modifier.width(4.dp))
                    Text("AI Auto-Fit", fontSize = 10.sp, color = Color.White)
                }

                // Live dimension indicator badge
                Surface(
                    shape = RoundedCornerShape(6.dp),
                    color = Color.Black.copy(alpha = 0.75f),
                    modifier = Modifier
                        .align(Alignment.BottomEnd)
                        .padding(8.dp)
                ) {
                    Text(
                        text = if (cropMode == 0) "Marker: ${(markerRight - markerLeft).toInt()}% × ${(markerBottom - markerTop).toInt()}%" else "$customWidth × $customHeight $selectedUnit (Max: $maxFileSizeKb KB)",
                        color = AkinAmberAccent,
                        fontSize = 10.sp,
                        fontWeight = FontWeight.Bold,
                        modifier = Modifier.padding(horizontal = 6.dp, vertical = 3.dp)
                    )
                }
            }

            Spacer(modifier = Modifier.height(14.dp))

            if (cropMode == 0) {
                // Interactive Sliders for Marker boundaries
                Text("Adjust Markers (Left, Top, Right, Bottom):", fontSize = 12.sp, fontWeight = FontWeight.SemiBold)
                Spacer(modifier = Modifier.height(4.dp))

                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text("Left Marker:", fontSize = 11.sp, modifier = Modifier.width(80.dp))
                    Slider(
                        value = markerLeft,
                        onValueChange = { if (it < markerRight - 15f) markerLeft = it },
                        valueRange = 0f..60f,
                        modifier = Modifier.weight(1f)
                    )
                    Text("${markerLeft.toInt()}%", fontSize = 11.sp, fontWeight = FontWeight.Bold, modifier = Modifier.width(36.dp))
                }

                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text("Top Marker:", fontSize = 11.sp, modifier = Modifier.width(80.dp))
                    Slider(
                        value = markerTop,
                        onValueChange = { if (it < markerBottom - 15f) markerTop = it },
                        valueRange = 0f..60f,
                        modifier = Modifier.weight(1f)
                    )
                    Text("${markerTop.toInt()}%", fontSize = 11.sp, fontWeight = FontWeight.Bold, modifier = Modifier.width(36.dp))
                }

                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text("Right Marker:", fontSize = 11.sp, modifier = Modifier.width(80.dp))
                    Slider(
                        value = markerRight,
                        onValueChange = { if (it > markerLeft + 15f) markerRight = it },
                        valueRange = 40f..100f,
                        modifier = Modifier.weight(1f)
                    )
                    Text("${markerRight.toInt()}%", fontSize = 11.sp, fontWeight = FontWeight.Bold, modifier = Modifier.width(36.dp))
                }

                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text("Bottom Marker:", fontSize = 11.sp, modifier = Modifier.width(80.dp))
                    Slider(
                        value = markerBottom,
                        onValueChange = { if (it > markerTop + 15f) markerBottom = it },
                        valueRange = 40f..100f,
                        modifier = Modifier.weight(1f)
                    )
                    Text("${markerBottom.toInt()}%", fontSize = 11.sp, fontWeight = FontWeight.Bold, modifier = Modifier.width(36.dp))
                }
            } else {
                // Crop by Exact User Size Requirement in Inch / CM / MM / Pixels
                Text("Popular Presets or Type Custom Dimensions:", fontSize = 12.sp, fontWeight = FontWeight.SemiBold)
                Spacer(modifier = Modifier.height(6.dp))

                val presets = listOf(
                    Triple("Passport (3.5×4.5 cm)", Pair("3.5", "4.5"), "cm"),
                    Triple("Square (2.0×2.0 in)", Pair("2.0", "2.0"), "in"),
                    Triple("ADRE Photo (200×230 px)", Pair("200", "230"), "px"),
                    Triple("Police Sign (140×60 px)", Pair("140", "60"), "px"),
                    Triple("Stamp Size (25×30 mm)", Pair("25", "30"), "mm"),
                    Triple("US Visa (2×2 Inch)", Pair("2.0", "2.0"), "in")
                )

                LazyRow(
                    horizontalArrangement = Arrangement.spacedBy(6.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    items(presets) { (preset, dims, unit) ->
                        FilterChip(
                            selected = selectedPresetName == preset,
                            onClick = {
                                selectedPresetName = preset
                                customWidth = dims.first
                                customHeight = dims.second
                                selectedUnit = unit
                            },
                            label = { Text(preset, fontSize = 10.sp) }
                        )
                    }
                }

                Spacer(modifier = Modifier.height(10.dp))

                // Unit selection chips (Inches, CM, MM, PX)
                Text("Select Measurement Unit:", fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                Spacer(modifier = Modifier.height(4.dp))
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    unitsList.forEach { unit ->
                        val isSel = selectedUnit == unit
                        Surface(
                            shape = RoundedCornerShape(8.dp),
                            color = if (isSel) MaterialTheme.colorScheme.primaryContainer else MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f),
                            border = if (isSel) CardDefaults.outlinedCardBorder().copy(brush = Brush.linearGradient(listOf(MaterialTheme.colorScheme.primary, MaterialTheme.colorScheme.primary)), width = 1.5.dp) else null,
                            modifier = Modifier
                                .weight(1f)
                                .clickable { selectedUnit = unit }
                        ) {
                            Text(
                                text = when (unit) {
                                    "in" -> "Inches (in)"
                                    "cm" -> "Centimeter (cm)"
                                    "mm" -> "Millimeter (mm)"
                                    else -> "Pixels (px)"
                                },
                                fontSize = 10.sp,
                                fontWeight = if (isSel) FontWeight.Bold else FontWeight.Normal,
                                textAlign = TextAlign.Center,
                                modifier = Modifier.padding(vertical = 6.dp)
                            )
                        }
                    }
                }

                Spacer(modifier = Modifier.height(10.dp))

                // Width & Height inputs
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    OutlinedTextField(
                        value = customWidth,
                        onValueChange = { customWidth = it },
                        label = { Text("Width ($selectedUnit)") },
                        modifier = Modifier.weight(1f),
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
                        singleLine = true
                    )
                    OutlinedTextField(
                        value = customHeight,
                        onValueChange = { customHeight = it },
                        label = { Text("Height ($selectedUnit)") },
                        modifier = Modifier.weight(1f),
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
                        singleLine = true
                    )
                }

                Spacer(modifier = Modifier.height(8.dp))

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    OutlinedTextField(
                        value = maxFileSizeKb,
                        onValueChange = { maxFileSizeKb = it },
                        label = { Text("Max Target File Size (KB)") },
                        modifier = Modifier.weight(1f),
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                        singleLine = true
                    )
                    OutlinedTextField(
                        value = selectedDpi,
                        onValueChange = { selectedDpi = it },
                        label = { Text("Resolution (DPI)") },
                        modifier = Modifier.weight(1f),
                        singleLine = true
                    )
                }
            }

            Spacer(modifier = Modifier.height(14.dp))

            // Dual Download Buttons
            DualDownloadActionButtons(
                toolTitle = "Cropped Photo ($customWidth × $customHeight $selectedUnit)",
                isPaid = isPaid,
                customGenerator = { ctx, isWatermarked, onProgress ->
                    DocumentExportHelper.generateAndSaveCroppedPhotoPdf(
                        context = ctx,
                        photoUri = userPhotoUri,
                        widthValue = customWidth,
                        heightValue = customHeight,
                        unit = selectedUnit,
                        dpi = selectedDpi,
                        isWatermarked = isWatermarked,
                        watermarkText = "Downloaded From Akash Internet Hub",
                        onProgressUpdate = onProgress
                    )
                },
                onPayDownload = onTriggerPayment
            )
        }
    }
}

/**
 * Standard Reusable Dual Download Buttons across all AI Tools
 */
@Composable
fun DualDownloadActionButtons(
    toolTitle: String,
    isPaid: Boolean = false,
    toolKey: String = "",
    hubInfo: HubInfo = HubInfo(),
    customGenerator: (suspend (context: Context, isWatermarked: Boolean, onProgress: (String) -> Unit) -> File?)? = null,
    onFreeDownload: () -> Unit = {},
    onPayDownload: () -> Unit = {},
    onUnlockedDownload: () -> Unit = {},
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    val coroutineScope = rememberCoroutineScope()

    var isDownloading by remember { mutableStateOf(false) }
    var progressMessage by remember { mutableStateOf("") }
    var downloadedFile by remember { mutableStateOf<File?>(null) }

    FileDownloadProgressDialog(
        isDownloading = isDownloading,
        progressMessage = progressMessage,
        downloadedFile = downloadedFile,
        onDismiss = {
            isDownloading = false
            downloadedFile = null
            progressMessage = ""
        }
    )

    Column(
        modifier = modifier.fillMaxWidth(),
        verticalArrangement = Arrangement.spacedBy(8.dp)
    ) {
        // Free Download Button with Watermark + Loading Animation
        OutlinedButton(
            onClick = {
                coroutineScope.launch {
                    isDownloading = true
                    downloadedFile = null
                    progressMessage = "Generating Free Watermarked File..."
                    val file = if (customGenerator != null) {
                        customGenerator(context, true) { msg -> progressMessage = msg }
                    } else {
                        DocumentExportHelper.generateAndSaveGenericToolPdf(
                            context = context,
                            toolTitle = toolTitle,
                            description = "Standard 300 DPI Export • Free Edition with Hub Stamp",
                            isWatermarked = true,
                            watermarkText = hubInfo.watermarkText,
                            onProgressUpdate = { msg -> progressMessage = msg }
                        )
                    }
                    downloadedFile = file
                    onFreeDownload()
                }
            },
            modifier = Modifier
                .fillMaxWidth()
                .height(44.dp)
                .testTag("free_download_button"),
            shape = RoundedCornerShape(10.dp)
        ) {
            Icon(Icons.Default.FileDownload, contentDescription = "Free Download", modifier = Modifier.size(17.dp))
            Spacer(modifier = Modifier.width(6.dp))
            Text(
                text = hubInfo.freeDownloadButtonText.ifBlank { "Free Download (With Watermark)" },
                fontSize = 12.sp,
                fontWeight = FontWeight.SemiBold
            )
        }

        if (isPaid) {
            // UNLOCKED Clean HD Download Button + Loading Animation
            Button(
                onClick = {
                    coroutineScope.launch {
                        isDownloading = true
                        downloadedFile = null
                        progressMessage = "Generating Clean High-Definition HD Original..."
                        val file = if (customGenerator != null) {
                            customGenerator(context, false) { msg -> progressMessage = msg }
                        } else {
                            DocumentExportHelper.generateAndSaveGenericToolPdf(
                                context = context,
                                toolTitle = toolTitle,
                                description = "High-Precision 300 DPI Vector Quality • 100% Watermark Free",
                                isWatermarked = false,
                                watermarkText = hubInfo.watermarkText,
                                onProgressUpdate = { msg -> progressMessage = msg }
                            )
                        }
                        downloadedFile = file
                        onUnlockedDownload()
                    }
                },
                modifier = Modifier
                    .fillMaxWidth()
                    .height(48.dp)
                    .testTag("download_unlocked_hd_button"),
                shape = RoundedCornerShape(10.dp),
                colors = ButtonDefaults.buttonColors(containerColor = AkinGreenSuccess, contentColor = Color.White),
                elevation = ButtonDefaults.buttonElevation(defaultElevation = 3.dp)
            ) {
                Icon(Icons.Default.DownloadDone, contentDescription = "Download HD", modifier = Modifier.size(20.dp))
                Spacer(modifier = Modifier.width(8.dp))
                Column(horizontalAlignment = Alignment.Start) {
                    Text(
                        text = hubInfo.unlockedButtonText.ifBlank { "✨ Download Clean HD File (Unlocked)" },
                        fontSize = 12.5.sp,
                        fontWeight = FontWeight.Bold,
                        color = Color.White
                    )
                    Text(
                        text = "100% Watermark Free • High-Resolution Original",
                        fontSize = 9.sp,
                        color = Color.White.copy(alpha = 0.9f)
                    )
                }
            }
        } else {
            // Pay & Download Button without Watermark (Razorpay checkout)
            val payText = if (toolKey.isNotBlank()) hubInfo.getPayButtonTextForTool(toolKey) else hubInfo.payHdButtonText.ifBlank { "Pay ₹${hubInfo.hdPriceText.ifBlank { "10" }} & Download HD (No Watermark)" }
            Button(
                onClick = onPayDownload,
                modifier = Modifier
                    .fillMaxWidth()
                    .height(48.dp)
                    .testTag("pay_download_button"),
                shape = RoundedCornerShape(10.dp),
                colors = ButtonDefaults.buttonColors(containerColor = AkinAmberAccent, contentColor = AkinNavyDark),
                elevation = ButtonDefaults.buttonElevation(defaultElevation = 2.dp)
            ) {
                Icon(Icons.Default.WorkspacePremium, contentDescription = "Pay & Download", tint = AkinNavyDark, modifier = Modifier.size(18.dp))
                Spacer(modifier = Modifier.width(6.dp))
                Column(horizontalAlignment = Alignment.Start) {
                    Text(
                        text = payText,
                        fontSize = 12.sp,
                        fontWeight = FontWeight.Bold,
                        color = AkinNavyDark
                    )
                    Text(
                        text = "Razorpay Checkout • Instant HD Unlock",
                        fontSize = 9.sp,
                        color = AkinNavyDark.copy(alpha = 0.85f)
                    )
                }
            }
        }
    }
}
