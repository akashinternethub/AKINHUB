package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// Primary & Secondary Brand Colors for AKINHUB (Akash Internet Hub)
val AkinNavyDark = Color(0xFF0A192F)
val AkinNavy = Color(0xFF0F2B48)
val AkinBluePrimary = Color(0xFF0284C7)
val AkinBlueLight = Color(0xFF38BDF8)
val AkinBlueContainer = Color(0xFFE0F2FE)
val AkinBlueDark = Color(0xFF0369A1)

val AkinAmberAccent = Color(0xFFF59E0B)
val AkinAmberContainer = Color(0xFFFEF3C7)
val AkinGreenSuccess = Color(0xFF10B981)
val AkinGreenContainer = Color(0xFFD1FAE5)

// Neutral Colors
val AkinSlate50 = Color(0xFFF8FAFC)
val AkinSlate100 = Color(0xFFF1F5F9)
val AkinSlate200 = Color(0xFFE2E8F0)
val AkinSlate300 = Color(0xFFCBD5E1)
val AkinSlate600 = Color(0xFF475569)
val AkinSlate700 = Color(0xFF334155)
val AkinSlate800 = Color(0xFF1E293B)
val AkinSlate900 = Color(0xFF0F172A)

// Surfaces & Backgrounds
val AkinCardLight = Color(0xFFFFFFFF)
val AkinCardDark = Color(0xFF1E293B)
val AkinSurfaceVariantLight = Color(0xFFF0F9FF)
