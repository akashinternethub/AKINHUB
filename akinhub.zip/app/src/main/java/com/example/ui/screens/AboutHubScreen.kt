package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.components.ContactHelper
import com.example.ui.dialogs.PrintClosedDialog
import com.example.ui.theme.*

@Composable
fun AboutHubScreen(
    onBookPrintClick: () -> Unit = {},
    onOpenAdminMode: () -> Unit = {},
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    var feedbackText by remember { mutableStateOf("") }
    var feedbackSubmitted by remember { mutableStateOf(false) }
    var showClosedDialog by remember { mutableStateOf(false) }

    if (showClosedDialog) {
        PrintClosedDialog(onDismiss = { showClosedDialog = false })
    }

    LazyColumn(
        modifier = modifier
            .fillMaxSize()
            .testTag("about_hub_screen_list"),
        contentPadding = PaddingValues(start = 16.dp, end = 16.dp, top = 16.dp, bottom = 90.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        // Admin Access Banner
        item {
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .clickable { onOpenAdminMode() }
                    .testTag("admin_portal_card"),
                shape = RoundedCornerShape(14.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.7f)),
                border = androidx.compose.foundation.BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant)
            ) {
                Row(
                    modifier = Modifier.padding(14.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        Surface(
                            shape = CircleShape,
                            color = Color(0xFFEF4444),
                            modifier = Modifier.size(36.dp)
                        ) {
                            Box(contentAlignment = Alignment.Center) {
                                Icon(Icons.Default.AdminPanelSettings, contentDescription = "Admin", tint = Color.White, modifier = Modifier.size(20.dp))
                            }
                        }
                        Column {
                            Text(
                                text = "Akash Hub Admin App / Portal",
                                fontSize = 13.5.sp,
                                fontWeight = FontWeight.Bold
                            )
                            Text(
                                text = "Live Editor for Services, Tracker & Prices",
                                fontSize = 11.sp,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                    }
                    Button(
                        onClick = onOpenAdminMode,
                        shape = RoundedCornerShape(8.dp),
                        colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF0F172A))
                    ) {
                        Text("Open", fontSize = 11.sp)
                    }
                }
            }
        }
        // Hub Banner Card
        item {
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("about_hub_profile_card"),
                shape = RoundedCornerShape(20.dp),
                colors = CardDefaults.cardColors(containerColor = Color.Transparent),
                elevation = CardDefaults.cardElevation(defaultElevation = 3.dp)
            ) {
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .background(Brush.linearGradient(listOf(AkinNavyDark, AkinNavy, AkinBlueDark)))
                        .padding(20.dp)
                ) {
                    Column(horizontalAlignment = Alignment.CenterHorizontally, modifier = Modifier.fillMaxWidth()) {
                        Surface(
                            shape = CircleShape,
                            color = AkinAmberAccent,
                            modifier = Modifier.size(64.dp)
                        ) {
                            Box(contentAlignment = Alignment.Center) {
                                Text(
                                    text = "A",
                                    fontSize = 34.sp,
                                    fontWeight = FontWeight.Black,
                                    color = AkinNavyDark
                                )
                            }
                        }

                        Spacer(modifier = Modifier.height(12.dp))

                        Text(
                            text = "AKASH INTERNET HUB",
                            fontSize = 20.sp,
                            fontWeight = FontWeight.ExtraBold,
                            color = Color.White
                        )
                        Text(
                            text = "www.akinhub.in/AI-HOME",
                            fontSize = 13.sp,
                            color = AkinBlueLight
                        )

                        Spacer(modifier = Modifier.height(8.dp))

                        Surface(
                            shape = RoundedCornerShape(12.dp),
                            color = Color.White.copy(alpha = 0.15f)
                        ) {
                            Row(
                                modifier = Modifier.padding(horizontal = 10.dp, vertical = 5.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Icon(Icons.Filled.Verified, contentDescription = "Verified", tint = AkinGreenSuccess, modifier = Modifier.size(16.dp))
                                Spacer(modifier = Modifier.width(6.dp))
                                Text(
                                    text = "Certified Common Services & Cyber Center",
                                    fontSize = 11.sp,
                                    fontWeight = FontWeight.SemiBold,
                                    color = Color.White
                                )
                            }
                        }

                        Spacer(modifier = Modifier.height(12.dp))

                        // Fast Buttons: AI-HOME Webpage and Direct Print
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            Button(
                                onClick = { ContactHelper.openAiHomeWebsite(context) },
                                modifier = Modifier.weight(1f).height(38.dp),
                                shape = RoundedCornerShape(10.dp),
                                colors = ButtonDefaults.buttonColors(containerColor = AkinBlueLight, contentColor = AkinNavyDark)
                            ) {
                                Icon(Icons.Default.Language, contentDescription = "AI-HOME", modifier = Modifier.size(15.dp))
                                Spacer(modifier = Modifier.width(4.dp))
                                Text("Visit AI-HOME", fontSize = 11.sp, fontWeight = FontWeight.Bold)
                            }

                            Button(
                                onClick = {
                                    if (ContactHelper.isPrintHoursActive()) {
                                        ContactHelper.openAutomaticPrint(context)
                                    } else {
                                        showClosedDialog = true
                                    }
                                },
                                modifier = Modifier.weight(1.3f).height(38.dp),
                                shape = RoundedCornerShape(10.dp),
                                colors = ButtonDefaults.buttonColors(containerColor = AkinAmberAccent, contentColor = AkinNavyDark)
                            ) {
                                Icon(Icons.Default.Bolt, contentDescription = "Print", modifier = Modifier.size(15.dp))
                                Spacer(modifier = Modifier.width(4.dp))
                                Text("Auto Print ⚡", fontSize = 11.sp, fontWeight = FontWeight.Black)
                            }
                        }
                    }
                }
            }
        }

        // Direct PC Server Print Card
        item {
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(containerColor = AkinAmberAccent.copy(alpha = 0.2f)),
                border = androidx.compose.foundation.BorderStroke(1.dp, AkinAmberAccent)
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.Default.Bolt, contentDescription = "Print", tint = Color(0xFFD97706), modifier = Modifier.size(22.dp))
                        Spacer(modifier = Modifier.width(8.dp))
                        Column {
                            Text("AUTOMATIC PC SERVER PRINT", fontSize = 13.sp, fontWeight = FontWeight.ExtraBold)
                            Text("Directly connected to shop counter PC (10:30 AM - 06:30 PM)", fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                        }
                    }
                    Spacer(modifier = Modifier.height(10.dp))
                    Button(
                        onClick = {
                            if (ContactHelper.isPrintHoursActive()) {
                                ContactHelper.openAutomaticPrint(context)
                            } else {
                                showClosedDialog = true
                            }
                        },
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(44.dp)
                            .testTag("about_auto_print_button"),
                        shape = RoundedCornerShape(10.dp),
                        colors = ButtonDefaults.buttonColors(containerColor = AkinNavyDark, contentColor = Color.White)
                    ) {
                        Text("CLICK KARO PRINT AUTOMATIC HO JAYEGA ⚡", fontSize = 12.sp, fontWeight = FontWeight.Black)
                    }
                }
            }
        }

        // Quick Connect Channels
        item {
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Text(
                        text = "Official Contact & Direct Connect",
                        fontSize = 15.sp,
                        fontWeight = FontWeight.Bold
                    )

                    Spacer(modifier = Modifier.height(12.dp))

                    ContactRowItem(
                        icon = Icons.Default.Phone,
                        title = "Direct Call Support",
                        subtitle = ContactHelper.PHONE_NUMBER,
                        actionText = "Call Now",
                        onClick = { ContactHelper.openDialer(context) }
                    )

                    HorizontalDivider(modifier = Modifier.padding(vertical = 8.dp))

                    ContactRowItem(
                        icon = Icons.Default.Chat,
                        title = "WhatsApp Helpline",
                        subtitle = ContactHelper.PHONE_NUMBER,
                        actionText = "Chat",
                        onClick = { ContactHelper.openWhatsApp(context, "Hello Akash Internet Hub, I have an inquiry about services/printing.") }
                    )

                    HorizontalDivider(modifier = Modifier.padding(vertical = 8.dp))

                    ContactRowItem(
                        icon = Icons.Default.Language,
                        title = "AI-HOME Official Webpage",
                        subtitle = ContactHelper.AI_HOME_URL,
                        actionText = "Visit",
                        onClick = { ContactHelper.openAiHomeWebsite(context) }
                    )

                    HorizontalDivider(modifier = Modifier.padding(vertical = 8.dp))

                    ContactRowItem(
                        icon = Icons.Default.Email,
                        title = "Official Email",
                        subtitle = ContactHelper.HUB_EMAIL,
                        actionText = "Send Mail",
                        onClick = { ContactHelper.openEmail(context) }
                    )

                    HorizontalDivider(modifier = Modifier.padding(vertical = 8.dp))

                    ContactRowItem(
                        icon = Icons.Default.LocationOn,
                        title = "Exact Shop Location",
                        subtitle = ContactHelper.EXACT_LOCATION,
                        actionText = "Open Map",
                        onClick = { ContactHelper.openMaps(context) }
                    )

                    HorizontalDivider(modifier = Modifier.padding(vertical = 8.dp))

                    ContactRowItem(
                        icon = Icons.Default.AccessTime,
                        title = "Daily Active Print & Hub Hours",
                        subtitle = "10:30 AM - 06:30 PM (All 7 Days)",
                        actionText = if (ContactHelper.isPrintHoursActive()) "OPEN NOW" else "CLOSED",
                        onClick = {}
                    )
                }
            }
        }

        // Center Facilities & Services
        item {
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Text(
                        text = "Official Counter Rates & Facilities",
                        fontSize = 15.sp,
                        fontWeight = FontWeight.Bold
                    )

                    Spacer(modifier = Modifier.height(10.dp))

                    FacilityItem("🖨️ B/W Print: ₹10 / Page | Colour Print: ₹20 / Page")
                    FacilityItem("🆔 Aadhaar PVC Smart Card (Orginal Government Wala): ₹150")
                    FacilityItem("📄 New PAN Card (Form 49A + Biometric): ₹200")
                    FacilityItem("🗳️ New Voter Registration / Correction: ₹100")
                    FacilityItem("✈️ Passport Seva Online Application & Booking: ₹2,500")
                    FacilityItem("📋 All Govt Forms & Job Apply (ADRE/Scholarship/Sewa Setu): ₹150")
                    FacilityItem("⚡ High Speed Optical Fiber Internet for instant form submissions")
                    FacilityItem("🔒 100% Privacy Protection for citizen personal credentials & marksheets")
                }
            }
        }

        // Send Message / Feedback
        item {
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Text(
                        text = "Direct Message to Akash Hub (+917002134700)",
                        fontSize = 15.sp,
                        fontWeight = FontWeight.Bold
                    )
                    Spacer(modifier = Modifier.height(4.dp))
                    Text(
                        text = "Have questions about any recruitment form, smart card or print job? Send a quick note directly to our WhatsApp.",
                        fontSize = 11.sp,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )

                    Spacer(modifier = Modifier.height(10.dp))

                    OutlinedTextField(
                        value = feedbackText,
                        onValueChange = { feedbackText = it },
                        modifier = Modifier.fillMaxWidth(),
                        placeholder = { Text("Write your query or service request here...") },
                        minLines = 3,
                        shape = RoundedCornerShape(12.dp)
                    )

                    Spacer(modifier = Modifier.height(10.dp))

                    if (feedbackSubmitted) {
                        Surface(
                            shape = RoundedCornerShape(8.dp),
                            color = AkinGreenSuccess.copy(alpha = 0.2f),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Text(
                                text = "✅ Thank you! Message forwarded to Akash Internet Hub support team.",
                                fontSize = 12.sp,
                                fontWeight = FontWeight.SemiBold,
                                color = Color(0xFF047857),
                                modifier = Modifier.padding(10.dp)
                            )
                        }
                    } else {
                        Button(
                            onClick = {
                                if (feedbackText.isNotBlank()) {
                                    ContactHelper.openWhatsApp(context, "Hello Akash Internet Hub, Inquiry: $feedbackText")
                                    feedbackSubmitted = true
                                }
                            },
                            modifier = Modifier.fillMaxWidth(),
                            shape = RoundedCornerShape(10.dp)
                        ) {
                            Icon(Icons.Default.Send, contentDescription = "Send")
                            Spacer(modifier = Modifier.width(6.dp))
                            Text("Send to +917002134700 via WhatsApp", fontWeight = FontWeight.Bold)
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun ContactRowItem(
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    title: String,
    subtitle: String,
    actionText: String,
    onClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    Row(
        modifier = modifier
            .fillMaxWidth()
            .clickable { onClick() },
        verticalAlignment = Alignment.CenterVertically
    ) {
        Surface(
            shape = CircleShape,
            color = MaterialTheme.colorScheme.primaryContainer,
            modifier = Modifier.size(36.dp)
        ) {
            Box(contentAlignment = Alignment.Center) {
                Icon(imageVector = icon, contentDescription = title, tint = MaterialTheme.colorScheme.primary, modifier = Modifier.size(18.dp))
            }
        }
        Spacer(modifier = Modifier.width(12.dp))
        Column(modifier = Modifier.weight(1f)) {
            Text(text = title, fontSize = 13.sp, fontWeight = FontWeight.Bold)
            Text(text = subtitle, fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
        }
        TextButton(onClick = onClick) {
            Text(text = actionText, fontSize = 12.sp, fontWeight = FontWeight.SemiBold)
        }
    }
}

@Composable
fun FacilityItem(text: String) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 4.dp),
        verticalAlignment = Alignment.Top
    ) {
        Text(text = text, fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurface, lineHeight = 16.sp)
    }
}
