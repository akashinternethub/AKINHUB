package com.example.ui.theme

import android.os.Build
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.dynamicDarkColorScheme
import androidx.compose.material3.dynamicLightColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext

private val DarkColorScheme = darkColorScheme(
    primary = AkinBlueLight,
    onPrimary = AkinNavyDark,
    primaryContainer = AkinBlueDark,
    onPrimaryContainer = AkinBlueContainer,
    secondary = AkinAmberAccent,
    onSecondary = AkinNavyDark,
    secondaryContainer = Color(0xFF78350F),
    onSecondaryContainer = AkinAmberContainer,
    tertiary = AkinGreenSuccess,
    background = AkinSlate900,
    surface = AkinSlate800,
    onBackground = AkinSlate50,
    onSurface = AkinSlate50,
    surfaceVariant = Color(0xFF1E293B),
    onSurfaceVariant = AkinSlate200,
    outline = Color(0xFF475569)
)

private val LightColorScheme = lightColorScheme(
    primary = AkinBluePrimary,
    onPrimary = Color.White,
    primaryContainer = AkinBlueContainer,
    onPrimaryContainer = AkinNavyDark,
    secondary = AkinAmberAccent,
    onSecondary = AkinNavyDark,
    secondaryContainer = AkinAmberContainer,
    onSecondaryContainer = Color(0xFF78350F),
    tertiary = AkinGreenSuccess,
    background = AkinSlate50,
    surface = Color.White,
    onBackground = AkinSlate900,
    onSurface = AkinSlate900,
    surfaceVariant = AkinSurfaceVariantLight,
    onSurfaceVariant = AkinSlate700,
    outline = AkinSlate300
)

@Composable
fun MyApplicationTheme(
    darkTheme: Boolean = isSystemInDarkTheme(),
    dynamicColor: Boolean = false, // Keep branded colors consistent
    content: @Composable () -> Unit,
) {
    val colorScheme = when {
        dynamicColor && Build.VERSION.SDK_INT >= Build.VERSION_CODES.S -> {
            val context = LocalContext.current
            if (darkTheme) dynamicDarkColorScheme(context) else dynamicLightColorScheme(context)
        }
        darkTheme -> DarkColorScheme
        else -> LightColorScheme
    }

    MaterialTheme(
        colorScheme = colorScheme,
        typography = Typography,
        content = content
    )
}
