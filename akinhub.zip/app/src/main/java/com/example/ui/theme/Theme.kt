package com.example.ui.theme

import android.os.Build
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.ColorScheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

data class AppThemeOption(
    val id: String,
    val name: String,
    val description: String,
    val primaryColor: Color,
    val secondaryColor: Color,
    val containerColor: Color
)

val APP_THEME_PALETTES = listOf(
    AppThemeOption(
        id = "navy_amber",
        name = "Classic Akash Blue & Gold",
        description = "Official Government Cyber Center Signature Theme",
        primaryColor = Color(0xFF0284C7),
        secondaryColor = Color(0xFFF59E0B),
        containerColor = Color(0xFFE0F2FE)
    ),
    AppThemeOption(
        id = "emerald_gold",
        name = "Royal Emerald & Gold",
        description = "Prestigious Forest Green with Warm Gold Accents",
        primaryColor = Color(0xFF059669),
        secondaryColor = Color(0xFFD97706),
        containerColor = Color(0xFFD1FAE5)
    ),
    AppThemeOption(
        id = "saffron_teal",
        name = "Assam Saffron & Teal",
        description = "Vibrant Cultural Saffron paired with Clean Teal",
        primaryColor = Color(0xFFD97706),
        secondaryColor = Color(0xFF0D9488),
        containerColor = Color(0xFFFEF3C7)
    ),
    AppThemeOption(
        id = "indigo_violet",
        name = "Deep Indigo & Violet",
        description = "Modern Tech & Cyber Space Indigo Gradient",
        primaryColor = Color(0xFF4F46E5),
        secondaryColor = Color(0xFF8B5CF6),
        containerColor = Color(0xFFEEF2FF)
    ),
    AppThemeOption(
        id = "crimson_ruby",
        name = "Crimson Ruby & Rose",
        description = "High-Energy Red with Soft Rose Elements",
        primaryColor = Color(0xFFE11D48),
        secondaryColor = Color(0xFFFB7185),
        containerColor = Color(0xFFFFE4E6)
    ),
    AppThemeOption(
        id = "cyan_cyber",
        name = "Cyber Cyan & Electric Blue",
        description = "Ultramodern Digital Hub Cyan with High Contrast",
        primaryColor = Color(0xFF0891B2),
        secondaryColor = Color(0xFF06B6D4),
        containerColor = Color(0xFFCFFAFE)
    ),
    AppThemeOption(
        id = "obsidian_gold",
        name = "Midnight Obsidian & Gold",
        description = "Premium Dark Slate with Golden Amber Highlights",
        primaryColor = Color(0xFF0F172A),
        secondaryColor = Color(0xFFF59E0B),
        containerColor = Color(0xFFE2E8F0)
    ),
    AppThemeOption(
        id = "purple_royal",
        name = "Imperial Purple & Magenta",
        description = "Regal Purple with Radiant Orchid Glow",
        primaryColor = Color(0xFF7C3AED),
        secondaryColor = Color(0xFFEC4899),
        containerColor = Color(0xFFEDE9FE)
    ),
    AppThemeOption(
        id = "forest_green",
        name = "Forest Pine & Mint",
        description = "Eco Nature Pine Green with Bright Mint Badges",
        primaryColor = Color(0xFF15803D),
        secondaryColor = Color(0xFF22C55E),
        containerColor = Color(0xFFDCFCE7)
    ),
    AppThemeOption(
        id = "chocolate_amber",
        name = "Warm Espresso & Amber",
        description = "Cozy Deep Brown with Warm Honey Details",
        primaryColor = Color(0xFF78350F),
        secondaryColor = Color(0xFFF59E0B),
        containerColor = Color(0xFFFEF3C7)
    )
)

fun getAppColorScheme(themeId: String, isDark: Boolean): ColorScheme {
    val theme = APP_THEME_PALETTES.find { it.id == themeId } ?: APP_THEME_PALETTES.first()
    val primary = theme.primaryColor
    val secondary = theme.secondaryColor
    val container = theme.containerColor

    return if (isDark) {
        darkColorScheme(
            primary = primary,
            onPrimary = Color.White,
            primaryContainer = primary.copy(alpha = 0.35f),
            onPrimaryContainer = container,
            secondary = secondary,
            onSecondary = Color.Black,
            secondaryContainer = secondary.copy(alpha = 0.25f),
            onSecondaryContainer = Color.White,
            tertiary = AkinGreenSuccess,
            background = AkinSlate900,
            surface = AkinSlate800,
            onBackground = AkinSlate50,
            onSurface = AkinSlate50,
            surfaceVariant = Color(0xFF1E293B),
            onSurfaceVariant = AkinSlate200,
            outline = Color(0xFF475569)
        )
    } else {
        lightColorScheme(
            primary = primary,
            onPrimary = Color.White,
            primaryContainer = container,
            onPrimaryContainer = Color(0xFF0F172A),
            secondary = secondary,
            onSecondary = Color.Black,
            secondaryContainer = container,
            onSecondaryContainer = Color(0xFF0F172A),
            tertiary = AkinGreenSuccess,
            background = AkinSlate50,
            surface = Color.White,
            onBackground = AkinSlate900,
            onSurface = AkinSlate900,
            surfaceVariant = container.copy(alpha = 0.3f),
            onSurfaceVariant = AkinSlate700,
            outline = AkinSlate300
        )
    }
}

@Composable
fun MyApplicationTheme(
    themeId: String = "navy_amber",
    darkTheme: Boolean = isSystemInDarkTheme(),
    content: @Composable () -> Unit,
) {
    val colorScheme = getAppColorScheme(themeId, darkTheme)

    MaterialTheme(
        colorScheme = colorScheme,
        typography = Typography,
        content = content
    )
}
