package com.example.data.preferences

import android.content.Context
import android.content.SharedPreferences
import com.example.data.model.HubInfo

object AdminPreferencesManager {

    private const val PREFS_NAME = "akinhub_admin_storage"

    // Receipt Template Keys
    private const val KEY_RECEIPT_HEADER = "receipt_header"
    private const val KEY_RECEIPT_SUBHEADER = "receipt_subheader"
    private const val KEY_RECEIPT_ADDRESS = "receipt_address"
    private const val KEY_RECEIPT_EMAIL = "receipt_email"
    private const val KEY_RECEIPT_NOTE = "receipt_custom_note"
    private const val KEY_RECEIPT_SEAL = "receipt_seal_text"

    // Shop Status Keys
    private const val KEY_IS_SHOP_OPEN = "is_shop_open"
    private const val KEY_SHOP_CLOSED_MSG = "shop_closed_message"

    // Broadcast Popup Keys
    private const val KEY_SHOW_POPUP = "show_popup_notification"
    private const val KEY_POPUP_TITLE = "popup_notification_title"
    private const val KEY_POPUP_MSG = "popup_notification_message"
    private const val KEY_POPUP_EMERGENCY = "is_emergency_broadcast"

    // Razorpay Button IDs & Pricing Keys
    private const val KEY_RZP_DEFAULT = "razorpay_button_id"
    private const val KEY_RZP_PASSPORT = "razorpay_button_id_passport"
    private const val KEY_RZP_RESUME = "razorpay_button_id_resume"
    private const val KEY_RZP_BIODATA = "razorpay_button_id_biodata"
    private const val KEY_RZP_AI_GEN = "razorpay_button_id_ai_generator"
    private const val KEY_RZP_IDCARD = "razorpay_button_id_idcard"
    private const val KEY_RZP_CONVERTERS = "razorpay_button_id_converters"

    private const val KEY_PRICE_PASSPORT = "price_passport"
    private const val KEY_PRICE_RESUME = "price_resume"
    private const val KEY_PRICE_BIODATA = "price_biodata"
    private const val KEY_PRICE_AI_GEN = "price_ai_generator"
    private const val KEY_PRICE_IDCARD = "price_idcard"
    private const val KEY_PRICE_CONVERTERS = "price_converters"
    private const val KEY_PRICE_HD_TEXT = "hd_price_text"

    private const val KEY_OFFICIAL_WEB = "official_website_url"
    private const val KEY_UPI_ID = "upi_id"
    private const val KEY_HUB_NAME = "hub_name"
    private const val KEY_OWNER_NAME = "owner_name"
    private const val KEY_PHONE = "phone"
    private const val KEY_WHATSAPP = "whatsapp"
    private const val KEY_ADDRESS = "address"
    private const val KEY_TIMINGS = "timings"
    private const val KEY_BANNER = "announcement_banner"
    private const val KEY_THEME = "app_theme_color_id"

    private const val KEY_PAY_HD_TEXT = "pay_hd_button_text"
    private const val KEY_FREE_DL_TEXT = "free_download_button_text"
    private const val KEY_UNLOCKED_TEXT = "unlocked_button_text"
    private const val KEY_WATERMARK_TEXT = "watermark_text"

    private const val KEY_SERVICES_JSON = "admin_persisted_services_json"
    private const val KEY_JOBS_JSON = "admin_persisted_jobs_json"
    private const val KEY_NOTICES_JSON = "admin_persisted_notices_json"

    private var appContext: Context? = null

    fun init(context: Context) {
        appContext = context.applicationContext
    }

    private fun getPrefs(context: Context? = appContext): SharedPreferences? {
        val ctx = context ?: appContext ?: return null
        return ctx.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
    }

    fun saveServices(services: List<com.example.data.model.HubService>, context: Context? = appContext) {
        val prefs = getPrefs(context) ?: return
        try {
            val jsonArray = org.json.JSONArray()
            for (service in services) {
                val obj = org.json.JSONObject().apply {
                    put("id", service.id)
                    put("title", service.title)
                    put("category", service.category.name)
                    put("description", service.description)
                    val docsArr = org.json.JSONArray()
                    service.requiredDocuments.forEach { docsArr.put(it) }
                    put("requiredDocuments", docsArr)
                    put("processingTime", service.processingTime)
                    put("officialGovtFee", service.officialGovtFee)
                    put("centerCharge", service.centerCharge)
                    put("totalFee", service.totalFee)
                    put("isPopular", service.isPopular)
                    put("iconName", service.iconName)
                    put("officialPortalUrl", service.officialPortalUrl ?: "")
                }
                jsonArray.put(obj)
            }
            prefs.edit().putString(KEY_SERVICES_JSON, jsonArray.toString()).apply()
        } catch (e: Exception) {
            e.printStackTrace()
        }
    }

    fun loadServices(context: Context? = appContext): List<com.example.data.model.HubService>? {
        val prefs = getPrefs(context) ?: return null
        val jsonStr = prefs.getString(KEY_SERVICES_JSON, null) ?: return null
        return try {
            val jsonArray = org.json.JSONArray(jsonStr)
            val list = mutableListOf<com.example.data.model.HubService>()
            for (i in 0 until jsonArray.length()) {
                val obj = jsonArray.getJSONObject(i)
                val docsArr = obj.optJSONArray("requiredDocuments")
                val docsList = mutableListOf<String>()
                if (docsArr != null) {
                    for (j in 0 until docsArr.length()) {
                        docsList.add(docsArr.getString(j))
                    }
                }
                val catName = obj.optString("category", com.example.data.model.ServiceCategory.IDENTITY_GOVT.name)
                val cat = try {
                    com.example.data.model.ServiceCategory.valueOf(catName)
                } catch (_: Exception) {
                    com.example.data.model.ServiceCategory.IDENTITY_GOVT
                }
                val portalUrl = obj.optString("officialPortalUrl", "")
                list.add(
                    com.example.data.model.HubService(
                        id = obj.getString("id"),
                        title = obj.getString("title"),
                        category = cat,
                        description = obj.optString("description", ""),
                        requiredDocuments = docsList,
                        processingTime = obj.optString("processingTime", "1 - 3 Days"),
                        officialGovtFee = obj.optString("officialGovtFee", "₹0"),
                        centerCharge = obj.optString("centerCharge", "₹50"),
                        totalFee = obj.optString("totalFee", "₹50"),
                        isPopular = obj.optBoolean("isPopular", false),
                        iconName = obj.optString("iconName", "description"),
                        officialPortalUrl = if (portalUrl.isNotBlank()) portalUrl else null
                    )
                )
            }
            list
        } catch (e: Exception) {
            e.printStackTrace()
            null
        }
    }

    fun saveHubInfo(info: HubInfo, context: Context? = appContext) {
        val prefs = getPrefs(context) ?: return
        prefs.edit().apply {
            // Receipt Template
            putString(KEY_RECEIPT_HEADER, info.receiptHeader)
            putString(KEY_RECEIPT_SUBHEADER, info.receiptSubHeader)
            putString(KEY_RECEIPT_ADDRESS, info.receiptAddress)
            putString(KEY_RECEIPT_EMAIL, info.receiptEmail)
            putString(KEY_RECEIPT_NOTE, info.receiptCustomNote)
            putString(KEY_RECEIPT_SEAL, info.receiptSealText)

            // Shop status & broadcast
            putBoolean(KEY_IS_SHOP_OPEN, info.isShopOpen)
            putString(KEY_SHOP_CLOSED_MSG, info.shopClosedMessage)
            putBoolean(KEY_SHOW_POPUP, info.showPopupNotification)
            putString(KEY_POPUP_TITLE, info.popupNotificationTitle)
            putString(KEY_POPUP_MSG, info.popupNotificationMessage)
            putBoolean(KEY_POPUP_EMERGENCY, info.isEmergencyBroadcast)

            // Razorpay IDs
            putString(KEY_RZP_DEFAULT, info.razorpayButtonId)
            putString(KEY_RZP_PASSPORT, info.razorpayButtonIdPassport)
            putString(KEY_RZP_RESUME, info.razorpayButtonIdResume)
            putString(KEY_RZP_BIODATA, info.razorpayButtonIdBioData)
            putString(KEY_RZP_AI_GEN, info.razorpayButtonIdAiGenerator)
            putString(KEY_RZP_IDCARD, info.razorpayButtonIdIdCard)
            putString(KEY_RZP_CONVERTERS, info.razorpayButtonIdConverters)

            // Tool Prices
            putString(KEY_PRICE_PASSPORT, info.pricePassport)
            putString(KEY_PRICE_RESUME, info.priceResume)
            putString(KEY_PRICE_BIODATA, info.priceBioData)
            putString(KEY_PRICE_AI_GEN, info.priceAiGenerator)
            putString(KEY_PRICE_IDCARD, info.priceIdCard)
            putString(KEY_PRICE_CONVERTERS, info.priceConverters)
            putString(KEY_PRICE_HD_TEXT, info.hdPriceText)

            // Hub Details
            putString(KEY_OFFICIAL_WEB, info.officialWebsiteUrl)
            putString(KEY_UPI_ID, info.upiId)
            putString(KEY_HUB_NAME, info.hubName)
            putString(KEY_OWNER_NAME, info.ownerName)
            putString(KEY_PHONE, info.phone)
            putString(KEY_WHATSAPP, info.whatsapp)
            putString(KEY_ADDRESS, info.address)
            putString(KEY_TIMINGS, info.timings)
            putString(KEY_BANNER, info.announcementBanner)
            putString(KEY_THEME, info.appThemeColorId)

            // Button & Watermark Texts
            putString(KEY_PAY_HD_TEXT, info.payHdButtonText)
            putString(KEY_FREE_DL_TEXT, info.freeDownloadButtonText)
            putString(KEY_UNLOCKED_TEXT, info.unlockedButtonText)
            putString(KEY_WATERMARK_TEXT, info.watermarkText)

            apply()
        }
    }

    fun loadHubInfo(context: Context? = appContext): HubInfo {
        val prefs = getPrefs(context) ?: return HubInfo()
        val default = HubInfo()

        return HubInfo(
            hubName = prefs.getString(KEY_HUB_NAME, default.hubName) ?: default.hubName,
            ownerName = prefs.getString(KEY_OWNER_NAME, default.ownerName) ?: default.ownerName,
            phone = prefs.getString(KEY_PHONE, default.phone) ?: default.phone,
            whatsapp = prefs.getString(KEY_WHATSAPP, default.whatsapp) ?: default.whatsapp,
            address = prefs.getString(KEY_ADDRESS, default.address) ?: default.address,
            timings = prefs.getString(KEY_TIMINGS, default.timings) ?: default.timings,
            announcementBanner = prefs.getString(KEY_BANNER, default.announcementBanner) ?: default.announcementBanner,
            upiId = prefs.getString(KEY_UPI_ID, default.upiId) ?: default.upiId,
            isShopOpen = prefs.getBoolean(KEY_IS_SHOP_OPEN, default.isShopOpen),
            shopClosedMessage = prefs.getString(KEY_SHOP_CLOSED_MSG, default.shopClosedMessage) ?: default.shopClosedMessage,
            popupNotificationTitle = prefs.getString(KEY_POPUP_TITLE, default.popupNotificationTitle) ?: default.popupNotificationTitle,
            popupNotificationMessage = prefs.getString(KEY_POPUP_MSG, default.popupNotificationMessage) ?: default.popupNotificationMessage,
            showPopupNotification = prefs.getBoolean(KEY_SHOW_POPUP, default.showPopupNotification),
            isEmergencyBroadcast = prefs.getBoolean(KEY_POPUP_EMERGENCY, default.isEmergencyBroadcast),
            razorpayButtonId = prefs.getString(KEY_RZP_DEFAULT, default.razorpayButtonId) ?: default.razorpayButtonId,
            razorpayButtonIdPassport = prefs.getString(KEY_RZP_PASSPORT, default.razorpayButtonIdPassport) ?: default.razorpayButtonIdPassport,
            razorpayButtonIdResume = prefs.getString(KEY_RZP_RESUME, default.razorpayButtonIdResume) ?: default.razorpayButtonIdResume,
            razorpayButtonIdBioData = prefs.getString(KEY_RZP_BIODATA, default.razorpayButtonIdBioData) ?: default.razorpayButtonIdBioData,
            razorpayButtonIdAiGenerator = prefs.getString(KEY_RZP_AI_GEN, default.razorpayButtonIdAiGenerator) ?: default.razorpayButtonIdAiGenerator,
            razorpayButtonIdIdCard = prefs.getString(KEY_RZP_IDCARD, default.razorpayButtonIdIdCard) ?: default.razorpayButtonIdIdCard,
            razorpayButtonIdConverters = prefs.getString(KEY_RZP_CONVERTERS, default.razorpayButtonIdConverters) ?: default.razorpayButtonIdConverters,
            pricePassport = prefs.getString(KEY_PRICE_PASSPORT, default.pricePassport) ?: default.pricePassport,
            priceResume = prefs.getString(KEY_PRICE_RESUME, default.priceResume) ?: default.priceResume,
            priceBioData = prefs.getString(KEY_PRICE_BIODATA, default.priceBioData) ?: default.priceBioData,
            priceAiGenerator = prefs.getString(KEY_PRICE_AI_GEN, default.priceAiGenerator) ?: default.priceAiGenerator,
            priceIdCard = prefs.getString(KEY_PRICE_IDCARD, default.priceIdCard) ?: default.priceIdCard,
            priceConverters = prefs.getString(KEY_PRICE_CONVERTERS, default.priceConverters) ?: default.priceConverters,
            officialWebsiteUrl = prefs.getString(KEY_OFFICIAL_WEB, default.officialWebsiteUrl) ?: default.officialWebsiteUrl,
            receiptHeader = prefs.getString(KEY_RECEIPT_HEADER, default.receiptHeader) ?: default.receiptHeader,
            receiptSubHeader = prefs.getString(KEY_RECEIPT_SUBHEADER, default.receiptSubHeader) ?: default.receiptSubHeader,
            receiptAddress = prefs.getString(KEY_RECEIPT_ADDRESS, default.receiptAddress) ?: default.receiptAddress,
            receiptEmail = prefs.getString(KEY_RECEIPT_EMAIL, default.receiptEmail) ?: default.receiptEmail,
            receiptCustomNote = prefs.getString(KEY_RECEIPT_NOTE, default.receiptCustomNote) ?: default.receiptCustomNote,
            receiptSealText = prefs.getString(KEY_RECEIPT_SEAL, default.receiptSealText) ?: default.receiptSealText,
            payHdButtonText = prefs.getString(KEY_PAY_HD_TEXT, default.payHdButtonText) ?: default.payHdButtonText,
            freeDownloadButtonText = prefs.getString(KEY_FREE_DL_TEXT, default.freeDownloadButtonText) ?: default.freeDownloadButtonText,
            unlockedButtonText = prefs.getString(KEY_UNLOCKED_TEXT, default.unlockedButtonText) ?: default.unlockedButtonText,
            watermarkText = prefs.getString(KEY_WATERMARK_TEXT, default.watermarkText) ?: default.watermarkText,
            hdPriceText = prefs.getString(KEY_PRICE_HD_TEXT, default.hdPriceText) ?: default.hdPriceText,
            appThemeColorId = prefs.getString(KEY_THEME, default.appThemeColorId) ?: default.appThemeColorId
        )
    }
}
