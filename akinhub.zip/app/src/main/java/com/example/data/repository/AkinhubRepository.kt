package com.example.data.repository

import com.example.data.model.*
import com.example.data.preferences.AdminPreferencesManager
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.UUID

class AkinhubRepository {

    private val _hubInfo = MutableStateFlow(AdminPreferencesManager.loadHubInfo())
    val hubInfo: StateFlow<HubInfo> = _hubInfo.asStateFlow()

    private val _services = MutableStateFlow<List<HubService>>(emptyList())
    val services: StateFlow<List<HubService>> = _services.asStateFlow()

    private val _jobAlerts = MutableStateFlow<List<JobAlert>>(emptyList())
    val jobAlerts: StateFlow<List<JobAlert>> = _jobAlerts.asStateFlow()

    private val _applications = MutableStateFlow<List<ServiceApplication>>(emptyList())
    val applications: StateFlow<List<ServiceApplication>> = _applications.asStateFlow()

    private val _printOrders = MutableStateFlow<List<PrintOrder>>(emptyList())
    val printOrders: StateFlow<List<PrintOrder>> = _printOrders.asStateFlow()

    private val _notices = MutableStateFlow<List<NoticeAlert>>(emptyList())
    val notices: StateFlow<List<NoticeAlert>> = _notices.asStateFlow()

    private val _reviews = MutableStateFlow<List<HubReview>>(emptyList())
    val reviews: StateFlow<List<HubReview>> = _reviews.asStateFlow()

    init {
        loadInitialData()
    }

    private fun loadInitialData() {
        _services.value = listOf(
            HubService(
                id = "pan_new",
                title = "New PAN Card (Form 49A)",
                category = ServiceCategory.IDENTITY_GOVT,
                description = "Apply for fresh physical PAN card + e-PAN with Aadhaar e-KYC instant biometric/OTP verification.",
                requiredDocuments = listOf("Aadhaar Card copy", "2 Passport Photos", "Active Mobile linked to Aadhaar", "Signature specimen"),
                processingTime = "3 - 7 Working Days",
                officialGovtFee = "₹107",
                centerCharge = "₹93",
                totalFee = "₹200",
                isPopular = true,
                iconName = "badge",
                officialPortalUrl = "https://www.onlineservices.nsdl.com"
            ),
            HubService(
                id = "aadhaar_pvc",
                title = "Aadhaar PVC Smart Card (Orginal Government Wala)",
                category = ServiceCategory.IDENTITY_GOVT,
                description = "Get waterproof, pocket-sized genuine UIDAI hologram PVC smart card with QR code (Orginal Government Wala) delivered directly.",
                requiredDocuments = listOf("12-Digit Aadhaar Number or VID", "Registered Mobile Number for OTP"),
                processingTime = "5 - 10 Days by Speed Post",
                officialGovtFee = "₹50",
                centerCharge = "₹100",
                totalFee = "₹150",
                isPopular = true,
                iconName = "credit_card",
                officialPortalUrl = "https://myaadhaar.uidai.gov.in"
            ),
            HubService(
                id = "adre_job_apply",
                title = "ADRE Assam Direct Recruitment & All Govt Job Apply",
                category = ServiceCategory.JOBS_RECRUITMENT,
                description = "Error-free online form fillup, document resizing, post preference selection & acknowledgment printout for ADRE Grade III & IV and all jobs.",
                requiredDocuments = listOf("HSLC / HS / Degree Marksheets", "Employment Exchange Card (Online)", "Caste Certificate (if applicable)", "Passport Photo & Signature"),
                processingTime = "Instant Same-Day Submission",
                officialGovtFee = "As per notification",
                centerCharge = "₹150",
                totalFee = "₹150",
                isPopular = true,
                iconName = "work",
                officialPortalUrl = "https://assam.gov.in"
            ),
            HubService(
                id = "apdcl_bill",
                title = "APDCL Electricity Bill Payment",
                category = ServiceCategory.UTILITY_BILLS,
                description = "Pay Assam Power Distribution Company (APDCL) Prepaid & Postpaid electricity bills with instant computerized receipt.",
                requiredDocuments = listOf("Consumer Number (10 digits)", "Recent Bill Copy / SMS"),
                processingTime = "Instant Payment Confirmation",
                officialGovtFee = "As per Bill Amount",
                centerCharge = "₹10",
                totalFee = "Bill + ₹10",
                isPopular = true,
                iconName = "bolt",
                officialPortalUrl = "https://www.apdcl.org"
            ),
            HubService(
                id = "voter_card",
                title = "New Voter Registration / Correction (Form 6 / 8)",
                category = ServiceCategory.IDENTITY_GOVT,
                description = "New voter registration, address change, name correction, and EPIC digital download assistance.",
                requiredDocuments = listOf("Age Proof (Birth Certificate / 10th Admit)", "Address Proof (Aadhaar / Ration Card / Electricity Bill)", "1 Color Photo"),
                processingTime = "15 - 30 Days",
                officialGovtFee = "₹0 (Free Govt)",
                centerCharge = "₹100",
                totalFee = "₹100",
                isPopular = false,
                iconName = "how_to_vote",
                officialPortalUrl = "https://voters.eci.gov.in"
            ),
            HubService(
                id = "urgent_xerox_print",
                title = "B/W & Colour Print, Xerox & Automatic PC Print",
                category = ServiceCategory.PRINT_SCAN,
                description = "High-definition laser printouts (B/W Print ₹10, Colour Print ₹20), automatic PC server print, spiral binding, and lamination.",
                requiredDocuments = listOf("Softcopy PDF/Image via WhatsApp/App or PC Direct Server"),
                processingTime = "Instant (10:30 AM - 6:30 PM)",
                officialGovtFee = "₹0",
                centerCharge = "B/W: ₹10 | Colour: ₹20",
                totalFee = "₹10 / ₹20",
                isPopular = true,
                iconName = "print",
                officialPortalUrl = "https://akinhub.pagekite.me/"
            ),
            HubService(
                id = "e_district_certificates",
                title = "Sewa Setu / E-District Certificates (All Apply)",
                category = ServiceCategory.IDENTITY_GOVT,
                description = "Apply for Permanent Resident Certificate (PRC), Non-Creamy Layer (NCL), Caste, and Income Certificates on Assam Sewa Setu.",
                requiredDocuments = listOf("Aadhaar Card", "Land Revenue / Jamabandi / Ward Certificate", "Parents Voter Card copy", "Passport Photo"),
                processingTime = "7 - 14 Working Days",
                officialGovtFee = "₹30",
                centerCharge = "₹120",
                totalFee = "₹150",
                isPopular = true,
                iconName = "verified",
                officialPortalUrl = "https://sewasetu.assam.gov.in"
            ),
            HubService(
                id = "passport_seva",
                title = "Passport Seva Online Application & Slot Booking",
                category = ServiceCategory.IDENTITY_GOVT,
                description = "Fresh / Renewal Indian Passport online application, PSK/POPSK appointment booking (Guwahati / Dhubri POPSK) & document verification.",
                requiredDocuments = listOf("Aadhaar Card", "PAN Card", "10th Pass Certificate", "Bank Passbook with photo"),
                processingTime = "Appointment as per slot availability",
                officialGovtFee = "₹1,500",
                centerCharge = "₹1,000 (Application + Verification)",
                totalFee = "₹2,500",
                isPopular = false,
                iconName = "flight",
                officialPortalUrl = "https://www.passportindia.gov.in"
            ),
            HubService(
                id = "scholarship_nsp",
                title = "NSP & State Scholarship (All Apply)",
                category = ServiceCategory.EDUCATION_RESULTS,
                description = "Online submission for National Scholarship Portal (NSP), Pre/Post Matric, Ishan Uday, and Chief Minister Special Scholarships.",
                requiredDocuments = listOf("Bank Passbook linked to Aadhaar", "Previous Year Marksheet", "Income & Caste Certificate", "Bonafide Certificate from College"),
                processingTime = "Instant Submission + Acknowledgement",
                officialGovtFee = "₹0 (Govt Scheme)",
                centerCharge = "₹150",
                totalFee = "₹150",
                isPopular = true,
                iconName = "school",
                officialPortalUrl = "https://scholarships.gov.in"
            ),
            HubService(
                id = "aeps_cash_point",
                title = "Aadhaar Micro-ATM & Digipay AEPS",
                category = ServiceCategory.BANKING_FINANCE,
                description = "Cash withdrawal from any Indian bank account using Aadhaar biometric fingerprint authentication, balance enquiry & mini-statement.",
                requiredDocuments = listOf("Aadhaar Number", "Bank Account linked to Aadhaar", "Biometric Presence"),
                processingTime = "Instant 1-Minute Cash Disbursal",
                officialGovtFee = "₹0",
                centerCharge = "Nominal",
                totalFee = "Nominal",
                isPopular = true,
                iconName = "atm",
                officialPortalUrl = null
            )
        )

        _jobAlerts.value = listOf(
            JobAlert(
                id = "job_adre_2026",
                postTitle = "Assam Direct Recruitment (ADRE) Class III & IV",
                department = "State Level Recruitment Commission (SLRC Assam)",
                vacancies = "12,600+ Posts",
                qualification = "HSLC / HSSLC (12th) / Graduate with Computer Certificate",
                ageLimit = "18 to 40 Years (OBC: 43 yrs, SC/ST: 45 yrs)",
                lastDate = "15 September 2026",
                applicationFee = "Grade III: ₹250, Grade IV: ₹150 (SC/ST: Nil)",
                officialWebsite = "https://assam.gov.in",
                importantNotes = "Employment Exchange Registration is strictly mandatory before applying. Form fillup available at Akash Internet Hub.",
                isUrgent = true
            ),
            JobAlert(
                id = "job_assam_police",
                postTitle = "Assam Police Constable (AB/UB) & Commando",
                department = "SLPRB Assam",
                vacancies = "5,420 Posts",
                qualification = "10th Pass (AB) / 12th Pass (UB)",
                ageLimit = "18 to 25 Years (Relaxation as per norms)",
                lastDate = "28 August 2026",
                applicationFee = "Nil (No Application Fee)",
                officialWebsite = "https://slprbassam.in",
                importantNotes = "Physical standard verification and online computer-based exam. Fast photo-signature resizing available.",
                isUrgent = true
            ),
            JobAlert(
                id = "job_ssc_gd",
                postTitle = "SSC GD Constable (CAPFs, SSF, Assam Rifles)",
                department = "Staff Selection Commission (Govt of India)",
                vacancies = "26,146 Posts",
                qualification = "Matriculation (10th Class) from recognized board",
                ageLimit = "18 to 23 Years",
                lastDate = "30 September 2026",
                applicationFee = "₹100 (Women/SC/ST: Exempted)",
                officialWebsite = "https://ssc.gov.in",
                importantNotes = "Live webcam photo capture assistance available at Akash Internet Hub counter.",
                isUrgent = false
            ),
            JobAlert(
                id = "job_railway_rrb",
                postTitle = "Railway RRB Non-Technical (NTPC) & Technician",
                department = "Railway Recruitment Boards (Indian Railways)",
                vacancies = "11,558 Posts",
                qualification = "12th / ITI / Degree in any discipline",
                ageLimit = "18 to 33 Years (Special 3-yr age relaxation active)",
                lastDate = "10 October 2026",
                applicationFee = "₹500 (Refundable ₹400 on CBT-1 appearance)",
                officialWebsite = "https://indianrailways.gov.in",
                importantNotes = "NFR (Northeast Frontier Railway) zones preferred for Assam candidates.",
                isUrgent = false
            )
        )

        _applications.value = listOf(
            ServiceApplication(
                id = "AKN-2026-7002",
                serviceTitle = "New PAN Card (Form 49A)",
                category = ServiceCategory.IDENTITY_GOVT,
                applicantName = "Akash Internet Hub",
                phone = "+91 7002134700",
                email = "akashinternethub@gmail.com",
                dateSubmitted = "22 Aug 2026, 10:00 AM",
                status = ApplicationStatus.SUBMITTED,
                trackingRefNumber = "NSDL-PAN-700213",
                totalPaid = "₹200.00",
                uploadedDocuments = listOf("Aadhaar_Front_Back.pdf", "Passport_Photo.jpg", "Signature_Specimen.png"),
                remark = "Default Center Account. Application Received at Counter."
            )
        )

        _printOrders.value = listOf(
            PrintOrder(
                id = "PRN-8924",
                title = "ADRE Admit Card & Identity Documents",
                printType = "A4 Color High-Res",
                copies = 2,
                pages = 4,
                isLaminated = true,
                totalCost = 45.0,
                orderDate = "21 Aug 2026, 09:15 AM",
                status = "Ready for Pickup",
                customerName = "Anowar Hussain",
                customerPhone = "+91 99570 11223",
                pickupEstimate = "At Akash Internet Hub Counter"
            ),
            PrintOrder(
                id = "PRN-8920",
                title = "College Project Report & Spiral Binding",
                printType = "A4 Black & White Double-Sided",
                copies = 1,
                pages = 32,
                isLaminated = false,
                totalCost = 64.0,
                orderDate = "20 Aug 2026, 02:40 PM",
                status = "Completed",
                customerName = "Priyanka Roy",
                customerPhone = "+91 88765 44332",
                pickupEstimate = "Picked up on 20 Aug"
            )
        )

        _notices.value = listOf(
            NoticeAlert(
                id = "not_1",
                title = "ADRE 2026 Grade III & IV Form Fillup in Progress",
                tag = "Recruitment",
                date = "21 Aug 2026",
                description = "SLRC Assam Direct Recruitment active. Please bring your Employment Card, Marksheets, and Aadhaar to Akash Internet Hub for instant error-free submission.",
                isImportant = true
            ),
            NoticeAlert(
                id = "not_2",
                title = "Mandatory Aadhaar-PAN Linking Notification",
                tag = "Identity",
                date = "18 Aug 2026",
                description = "Ensure your PAN is linked with your Aadhaar to prevent PAN inoperability. Check status or link today at our center.",
                isImportant = false
            ),
            NoticeAlert(
                id = "not_3",
                title = "APDCL Smart Meter Recharge & Bill Payment",
                tag = "Utility",
                date = "15 Aug 2026",
                description = "Instant prepaid meter token generation and monthly postpaid bill settlement with 0% gateway downtime.",
                isImportant = false
            )
        )

        _reviews.value = listOf(
            HubReview(
                id = "rev_1",
                authorName = "Nurul Haque",
                location = "Geramari, Dhubri",
                rating = 5.0f,
                reviewText = "Best cyber cafe in Geramari! Filled my Assam Direct Recruitment form with complete photo and signature resize without any server error. Very polite staff and quick printouts.",
                date = "12 Aug 2026"
            ),
            HubReview(
                id = "rev_2",
                authorName = "Debojit Das",
                location = "Gauripur, Dhubri",
                rating = 5.0f,
                reviewText = "Applied for PAN card and got the e-PAN in just 3 days! The online tracking and customer service of Akash Internet Hub is top notch. Highly recommended.",
                date = "05 Aug 2026"
            ),
            HubReview(
                id = "rev_3",
                authorName = "Sultana Begum",
                location = "Dhubri Town",
                rating = 5.0f,
                reviewText = "Very convenient for APDCL electricity bills and SEWA SETU PRC certificate application. Clear receipt and transparent fees.",
                date = "28 Jul 2026"
            )
        )
    }

    fun submitServiceApplication(
        service: HubService,
        name: String,
        phone: String,
        email: String,
        attachedDocs: List<String>,
        notes: String
    ): ServiceApplication {
        val randomNum = (1000..9999).random()
        val appId = "AKN-2026-$randomNum"
        val refNum = "REF-${service.category.name.take(3)}-$randomNum"
        val sdf = SimpleDateFormat("dd MMM yyyy, hh:mm a", Locale.getDefault())
        val formattedDate = sdf.format(Date())

        val newApp = ServiceApplication(
            id = appId,
            serviceTitle = service.title,
            category = service.category,
            applicantName = name,
            phone = phone,
            email = email.ifBlank { "akashinternethub@gmail.com" },
            dateSubmitted = formattedDate,
            status = ApplicationStatus.SUBMITTED,
            trackingRefNumber = refNum,
            totalPaid = service.totalFee,
            uploadedDocuments = attachedDocs.ifEmpty { listOf("User_Provided_Credentials.pdf") },
            remark = if (notes.isNotBlank()) "Notes: $notes" else "Application received. Verification in progress."
        )

        _applications.value = listOf(newApp) + _applications.value
        return newApp
    }

    fun submitPrintOrder(
        title: String,
        printType: String,
        copies: Int,
        pages: Int,
        isLaminated: Boolean,
        customerName: String,
        customerPhone: String
    ): PrintOrder {
        val orderNum = (8950..9999).random()
        val orderId = "PRN-$orderNum"
        val sdf = SimpleDateFormat("dd MMM yyyy, hh:mm a", Locale.getDefault())
        val formattedDate = sdf.format(Date())

        // Calculate rate
        val baseRatePerPage = when {
            printType.contains("Color", ignoreCase = true) -> 20.0
            printType.contains("PVC", ignoreCase = true) -> 150.0
            printType.contains("Photo", ignoreCase = true) -> 30.0
            printType.contains("Legal", ignoreCase = true) -> 15.0
            else -> 10.0
        }
        var total = (pages * copies * baseRatePerPage)
        if (isLaminated) {
            total += (copies * 20.0)
        }

        val order = PrintOrder(
            id = orderId,
            title = title.ifBlank { "Document Print & Xerox" },
            printType = printType,
            copies = copies,
            pages = pages,
            isLaminated = isLaminated,
            totalCost = total,
            orderDate = formattedDate,
            status = "Order Placed - Counter Processing",
            customerName = customerName,
            customerPhone = customerPhone,
            pickupEstimate = "Ready in 15 mins at Akash Internet Hub"
        )

        _printOrders.value = listOf(order) + _printOrders.value
        return order
    }

    // ==================== ADMIN CRUD METHODS ====================

    fun updateHubInfo(info: HubInfo) {
        _hubInfo.value = info
        AdminPreferencesManager.saveHubInfo(info)
    }

    fun addOrUpdateService(service: HubService) {
        val current = _services.value.toMutableList()
        val index = current.indexOfFirst { it.id == service.id }
        if (index >= 0) {
            current[index] = service
        } else {
            current.add(0, service)
        }
        _services.value = current
    }

    fun deleteService(serviceId: String) {
        _services.value = _services.value.filter { it.id != serviceId }
    }

    fun addOrUpdateJob(job: JobAlert) {
        val current = _jobAlerts.value.toMutableList()
        val index = current.indexOfFirst { it.id == job.id }
        if (index >= 0) {
            current[index] = job
        } else {
            current.add(0, job)
        }
        _jobAlerts.value = current
    }

    fun deleteJob(jobId: String) {
        _jobAlerts.value = _jobAlerts.value.filter { it.id != jobId }
    }

    fun updateApplicationStatus(
        appId: String,
        newStatus: ApplicationStatus,
        newRemark: String? = null,
        newTrackingRef: String? = null
    ) {
        _applications.value = _applications.value.map { app ->
            if (app.id == appId) {
                app.copy(
                    status = newStatus,
                    remark = newRemark ?: app.remark,
                    trackingRefNumber = newTrackingRef ?: app.trackingRefNumber
                )
            } else {
                app
            }
        }
    }

    fun addOrUpdateApplication(application: ServiceApplication) {
        val current = _applications.value.toMutableList()
        val index = current.indexOfFirst { it.id == application.id }
        if (index >= 0) {
            current[index] = application
        } else {
            current.add(0, application)
        }
        _applications.value = current
    }

    fun deleteApplication(appId: String) {
        _applications.value = _applications.value.filter { it.id != appId }
    }

    fun addOrUpdateNotice(notice: NoticeAlert) {
        val current = _notices.value.toMutableList()
        val index = current.indexOfFirst { it.id == notice.id }
        if (index >= 0) {
            current[index] = notice
        } else {
            current.add(0, notice)
        }
        _notices.value = current
    }

    fun deleteNotice(noticeId: String) {
        _notices.value = _notices.value.filter { it.id != noticeId }
    }

    fun updatePrintOrderStatus(orderId: String, newStatus: String) {
        _printOrders.value = _printOrders.value.map { order ->
            if (order.id == orderId) {
                order.copy(status = newStatus)
            } else {
                order
            }
        }
    }

    fun deletePrintOrder(orderId: String) {
        _printOrders.value = _printOrders.value.filter { it.id != orderId }
    }
}
