package com.example.data.repository

import com.example.data.model.GovernmentScheme
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class GovernmentSchemesRepository {

    private val _schemes = MutableStateFlow<List<GovernmentScheme>>(emptyList())
    val schemes: StateFlow<List<GovernmentScheme>> = _schemes.asStateFlow()

    init {
        refreshDailySchemes()
    }

    /**
     * Automatically calculates the current daily date and syncs all active
     * Assam & Central Government Schemes so no manual updates are required.
     */
    fun refreshDailySchemes() {
        val todayStr = SimpleDateFormat("dd MMM yyyy", Locale.getDefault()).format(Date())

        val dailySchemes = listOf(
            GovernmentScheme(
                id = "scheme_nijut_moina",
                title = "Assam Nijut Moina Scheme 2026",
                titleHi = "असम निजुत मोईना योजना 2026",
                titleAs = "অসম নিজুত মইনা আঁচনি ২০২৬",
                department = "Higher Education Department, Govt of Assam",
                category = "Student & Youth",
                benefits = "₹1,000/month for HS (11th & 12th), ₹1,250/month for Degree (Graduation), ₹2,500/month for PG (Post Graduation)",
                eligibility = "Female students enrolled in Govt/Govt-aided schools, colleges & universities in Assam. Family income criteria as per norms.",
                requiredDocuments = listOf("Aadhaar Card", "College Admission Receipt / ID Card", "Active Bank Passbook (in student name)", "HSLC Marksheet & PRC/Certificate"),
                lastDateOrStatus = "Portal Active & Open Today",
                officialPortalUrl = "https://highereducation.assam.gov.in",
                isAssamStateGovt = true,
                isAutoUpdatedToday = true,
                lastUpdatedDate = todayStr
            ),
            GovernmentScheme(
                id = "scheme_orunodoi_3",
                title = "Orunodoi 3.0 (অৰুণোদয় ৩.০)",
                titleHi = "अरुणोदय 3.0 योजना असम",
                titleAs = "অৰুণোদয় ৩.০ আঁচনি",
                department = "Finance Department, Govt of Assam",
                category = "Direct Benefit (DBT)",
                benefits = "₹1,250 every month credited directly via Direct Benefit Transfer (DBT) into the bank account of the woman head of household.",
                eligibility = "Permanent residents of Assam with annual family income below ₹2 Lakh. Priority to Divyang, widows, unmarried/divorced women.",
                requiredDocuments = listOf("Aadhaar Card of Female Beneficiary", "Ration Card (NFSA) / Income Certificate", "Bank Passbook with DBT / Aadhaar seeding", "Voter ID Card"),
                lastDateOrStatus = "Verification & Phase 3 Active",
                officialPortalUrl = "https://finance.assam.gov.in",
                isAssamStateGovt = true,
                isAutoUpdatedToday = true,
                lastUpdatedDate = todayStr
            ),
            GovernmentScheme(
                id = "scheme_adre_recruitment",
                title = "ADRE Assam Direct Recruitment Class III & IV",
                titleHi = "असम डायरेक्ट रिक्रूटमेंट वर्ग 3 और 4",
                titleAs = "অসম ডাইৰেক্ট ৰিক্ৰুইটমেণ্ট ৩য় আৰু ৪র্থ বৰ্গ",
                department = "State Level Recruitment Commission (SLRC Assam)",
                category = "Govt Recruitment",
                benefits = "12,600+ Permanent Govt Vacancies in Assam State Departments. Fixed Pay Band + Grade Pay + DA.",
                eligibility = "HSLC (10th), HSSLC (12th), or Graduate degree with basic Computer Application certificate from recognized institute.",
                requiredDocuments = listOf("Employment Exchange Registration Card", "Aadhaar Card", "Educational Marksheets & Pass Certificates", "Passport Size Photo & Signature"),
                lastDateOrStatus = "Form Fillup Open at Akash Hub",
                officialPortalUrl = "https://assam.gov.in",
                isAssamStateGovt = true,
                isAutoUpdatedToday = true,
                lastUpdatedDate = todayStr
            ),
            GovernmentScheme(
                id = "scheme_pragyan_barati",
                title = "Pragyan Bharati Free Scooty & Admission Scheme",
                titleHi = "प्रज्ञान भारती मुफ्त स्कूटी और प्रवेश योजना",
                titleAs = "প্ৰজ্ঞান ভাৰতী বিনামূলীয়া স্কুটী আঁচনি",
                department = "Higher Education Department, Assam",
                category = "Student & Youth",
                benefits = "Free Petrol/Electric Scooty for meritorious Class 12 girls (60%+ marks) + 100% Free College/University Admission waiver for students.",
                eligibility = "Students securing specified cutoff marks in AHSEC Class 12 exams. Free admission for students with family income under ₹2 Lakh.",
                requiredDocuments = listOf("AHSEC 12th Admit & Marksheet", "Income Certificate / Ration Card", "Bank Account Details", "College Admission Proof"),
                lastDateOrStatus = "Current Academic Session Active",
                officialPortalUrl = "https://sewasetu.assam.gov.in",
                isAssamStateGovt = true,
                isAutoUpdatedToday = true,
                lastUpdatedDate = todayStr
            ),
            GovernmentScheme(
                id = "scheme_pm_surya_ghar",
                title = "PM Surya Ghar: Muft Bijli Yojana (Rooftop Solar)",
                titleHi = "पीएम सूर्य घर: मुफ्त बिजली योजना",
                titleAs = "পিএম সূৰ্য্য ঘৰ: বিনামূলীয়া বিদ্যুৎ যোজনা",
                department = "Ministry of New and Renewable Energy & APDCL",
                category = "Housing & Solar",
                benefits = "Up to ₹78,000 direct Govt central subsidy for residential solar installation + up to 300 units free electricity per month.",
                eligibility = "Residential households with electricity connection in their own name and suitable roof space.",
                requiredDocuments = listOf("Electricity Bill (APDCL Consumer Number)", "Rooftop Ownership Proof / Jamabandi", "Aadhaar Card & Bank Passbook", "Passport Photo"),
                lastDateOrStatus = "Daily Online Registrations Open",
                officialPortalUrl = "https://pmsuryaghar.gov.in",
                isAssamStateGovt = false,
                isAutoUpdatedToday = true,
                lastUpdatedDate = todayStr
            ),
            GovernmentScheme(
                id = "scheme_ayushman_bharat",
                title = "Ayushman Bharat PM-JAY & Ayushman Asom",
                titleHi = "आयुष्मान भारत पीएम-जय एवं आयुष्मान असम",
                titleAs = "আয়ুষ্মান ভাৰত আৰু আয়ুষ্মান অসম কাৰ্ড",
                department = "National Health Authority & Atal Amrit Abhiyan Society",
                category = "Healthcare",
                benefits = "₹5,00,000 (5 Lakh Rupees) cashless free medical treatment per family per year at all empanelled Govt & private hospitals across India.",
                eligibility = "Ration Card (NFSA) holders or SECC listed families in Assam. Instant biometric e-KYC available.",
                requiredDocuments = listOf("Ration Card (NFSA)", "Aadhaar Card of all family members", "Registered Mobile Number for OTP"),
                lastDateOrStatus = "Instant PVC Card Generation",
                officialPortalUrl = "https://beneficiary.nha.gov.in",
                isAssamStateGovt = true,
                isAutoUpdatedToday = true,
                lastUpdatedDate = todayStr
            ),
            GovernmentScheme(
                id = "scheme_sewa_setu",
                title = "Sewa Setu Assam (PRC, Caste, NCL & Income)",
                titleHi = "सेवा सेतु असम (पीआरसी, जाति, एनसीएल और आय प्रमाण पत्र)",
                titleAs = "সেৱা সেতু অসম (PRC, জাতি আৰু আয়ৰ প্ৰমাণপত্ৰ)",
                department = "Administrative Reforms & Training Dept, Govt of Assam",
                category = "Identity & Certs",
                benefits = "Guaranteed delivery of public services (PRC, Non-Creamy Layer, OBC/SC/ST Certificate, Bakijai Certificate) within official time limits.",
                eligibility = "All bona fide residents and citizens of Assam.",
                requiredDocuments = listOf("Aadhaar Card", "Land Revenue / Jamabandi / Ward Certificate", "Parents Voter Card / 1966-1971 NRC Proof", "Passport Photo"),
                lastDateOrStatus = "Continuous 24x7 Portal Processing",
                officialPortalUrl = "https://sewasetu.assam.gov.in",
                isAssamStateGovt = true,
                isAutoUpdatedToday = true,
                lastUpdatedDate = todayStr
            ),
            GovernmentScheme(
                id = "scheme_nsp_scholarship",
                title = "National Scholarship Portal (NSP 2026-27)",
                titleHi = "राष्ट्रीय छात्रवृत्ति पोर्टल (NSP 2026-27)",
                titleAs = "ৰাষ্ট্ৰীয় বৃত্তি প’ৰ্টেল (NSP ২০২৬-২৭)",
                department = "Ministry of Minority Affairs / Social Justice & Empowerment",
                category = "Student & Youth",
                benefits = "Up to ₹50,000 annual scholarship for Pre-Matric, Post-Matric, and Top-Class higher education.",
                eligibility = "Students from Class 1 to Post-Graduation belonging to Minority / SC / ST / OBC / Merit categories scoring 50%+ in last exam.",
                requiredDocuments = listOf("Aadhaar Card", "Previous Class Marksheet", "Income Certificate (below ₹2.5L)", "College/School Bonafide", "Bank Passbook"),
                lastDateOrStatus = "Active Biometric Authentication",
                officialPortalUrl = "https://scholarships.gov.in",
                isAssamStateGovt = false,
                isAutoUpdatedToday = true,
                lastUpdatedDate = todayStr
            ),
            GovernmentScheme(
                id = "scheme_mmua",
                title = "Mukhyamantri Mahila Udyamita Abhiyan (MMUA)",
                titleHi = "मुख्यमंत्री महिला उद्यमिता अभियान",
                titleAs = "মুখ্যমন্ত্ৰী মহিলা উদ্যমিতা অভিযান",
                department = "Assam State Rural Livelihoods Mission (ASRLM)",
                category = "Women Welfare",
                benefits = "₹35,000 total financial assistance (₹10,000 grant + ₹25,000 bank loan/subsidy) to turn Self-Help Group (SHG) women into micro-entrepreneurs.",
                eligibility = "Active female members of registered Rural Self Help Groups (SHGs) complying with child limitation guidelines.",
                requiredDocuments = listOf("SHG Passbook & Member ID", "Aadhaar Card", "Bank Account linked to Aadhaar", "Business Plan Format"),
                lastDateOrStatus = "District Mission Verifications Open",
                officialPortalUrl = "https://asrlms.assam.gov.in",
                isAssamStateGovt = true,
                isAutoUpdatedToday = true,
                lastUpdatedDate = todayStr
            )
        )

        _schemes.value = dailySchemes
    }
}
