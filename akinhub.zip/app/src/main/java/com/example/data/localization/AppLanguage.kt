package com.example.data.localization

enum class AppLanguage(val code: String, val displayName: String, val nativeName: String) {
    ENGLISH("en", "English", "English"),
    HINDI("hi", "Hindi", "हिन्दी"),
    HINGLISH("hi-Latn", "Hinglish", "Hinglish"),
    BENGALI("bn", "Bengali", "বাংলা"),
    ASSAMESE("as", "Assamese", "অসমীয়া")
}

object LocalizedStrings {
    fun getAppName(lang: AppLanguage): String = when (lang) {
        AppLanguage.ENGLISH -> "Akash Internet Hub"
        AppLanguage.HINDI -> "आकाश इंटरनेट हब"
        AppLanguage.HINGLISH -> "Akash Internet Hub"
        AppLanguage.BENGALI -> "আকাশ ইন্টারনেট হাব"
        AppLanguage.ASSAMESE -> "আকাশ ইন্টাৰনেট হাব"
    }

    fun getSubtitle(lang: AppLanguage): String = when (lang) {
        AppLanguage.ENGLISH -> "Near Saba Petrol Pump, Geramari, Dhubri (Assam)"
        AppLanguage.HINDI -> "साबा पेट्रोल पंप के पास, गेरामारी, धुबरी (असम)"
        AppLanguage.HINGLISH -> "Saba Petrol Pump ke paas, Geramari, Dhubri (Assam)"
        AppLanguage.BENGALI -> "সাবা পেট্রোল পাম্পের কাছে, গেরামারি, ধুবড়ি (আসাম)"
        AppLanguage.ASSAMESE -> "চাবা পেট্ৰল পাম্পৰ ওচৰত, গেৰামাৰী, ধুবুৰী (অসম)"
    }

    fun getNavExplore(lang: AppLanguage): String = when (lang) {
        AppLanguage.ENGLISH -> "Services"
        AppLanguage.HINDI -> "सेवाएं"
        AppLanguage.HINGLISH -> "Services"
        AppLanguage.BENGALI -> "সেবাসমূহ"
        AppLanguage.ASSAMESE -> "সেৱাসমূহ"
    }

    fun getNavJobs(lang: AppLanguage): String = when (lang) {
        AppLanguage.ENGLISH -> "Govt Jobs"
        AppLanguage.HINDI -> "सरकारी नौकरी"
        AppLanguage.HINGLISH -> "Govt Jobs"
        AppLanguage.BENGALI -> "সরকারি চাকরি"
        AppLanguage.ASSAMESE -> "চৰকাৰী চাকৰি"
    }

    fun getNavSchemes(lang: AppLanguage): String = when (lang) {
        AppLanguage.ENGLISH -> "Govt Schemes"
        AppLanguage.HINDI -> "सरकारी योजनाएं"
        AppLanguage.HINGLISH -> "Govt Schemes"
        AppLanguage.BENGALI -> "সরকারি স্কিম"
        AppLanguage.ASSAMESE -> "চৰকাৰী আঁচনি"
    }

    fun getNavTracker(lang: AppLanguage): String = when (lang) {
        AppLanguage.ENGLISH -> "Tracker"
        AppLanguage.HINDI -> "ट्रैकर"
        AppLanguage.HINGLISH -> "Tracker"
        AppLanguage.BENGALI -> "ট্র্যাকার"
        AppLanguage.ASSAMESE -> "ট্ৰেকাৰ"
    }

    fun getNavTools(lang: AppLanguage): String = when (lang) {
        AppLanguage.ENGLISH -> "AI Tools"
        AppLanguage.HINDI -> "एआई टूल्स"
        AppLanguage.HINGLISH -> "AI Tools"
        AppLanguage.BENGALI -> "এআই টুলস"
        AppLanguage.ASSAMESE -> "এআই সঁজুলি"
    }

    fun getNavAbout(lang: AppLanguage): String = when (lang) {
        AppLanguage.ENGLISH -> "About Hub"
        AppLanguage.HINDI -> "हब के बारे में"
        AppLanguage.HINGLISH -> "About Hub"
        AppLanguage.BENGALI -> "হাব সম্পর্কে"
        AppLanguage.ASSAMESE -> "কেন্দ্ৰৰ বিষয়ে"
    }

    fun getPrintOrderCta(lang: AppLanguage): String = when (lang) {
        AppLanguage.ENGLISH -> "Order Printout / Xerox"
        AppLanguage.HINDI -> "प्रिंट / ज़ेरॉक्स आर्डर करें"
        AppLanguage.HINGLISH -> "Print / Xerox Order Karein"
        AppLanguage.BENGALI -> "প্রিন্ট / জেরক্স অর্ডার করুন"
        AppLanguage.ASSAMESE -> "প্ৰিণ্ট / জেৰক্স অৰ্ডাৰ কৰক"
    }

    fun getFreeDownloadWithWatermark(lang: AppLanguage): String = when (lang) {
        AppLanguage.ENGLISH -> "Free Download (With Watermark)"
        AppLanguage.HINDI -> "फ्री डाउनलोड (वॉटरमार्क सहित)"
        AppLanguage.HINGLISH -> "Free Download (With Watermark)"
        AppLanguage.BENGALI -> "বিনামূল্যে ডাউনলোড (ওয়াটারমার্ক সহ)"
        AppLanguage.ASSAMESE -> "বিনামূলীয়া ডাউনলোড (ৱাটাৰমাৰ্ক সহ)"
    }

    fun getVoiceGreetingText(lang: AppLanguage): String = when (lang) {
        AppLanguage.ENGLISH -> "Thank you for visiting Akash Internet Hub!"
        AppLanguage.HINDI -> "आपको धन्यवाद आकाश इंटरनेट हब पे विजिट करने के लिए"
        AppLanguage.HINGLISH -> "Aapko Dhanyawaad Akash Internet Hub me visit karne ke liye!"
        AppLanguage.BENGALI -> "আকাশ ইন্টারনেট হাবে আসার জন্য আপনাকে ধন্যবাদ!"
        AppLanguage.ASSAMESE -> "আকাশ ইন্টাৰনেট হাবলৈ অহাৰ বাবে আপোনাক ধন্যবাদ"
    }
}
