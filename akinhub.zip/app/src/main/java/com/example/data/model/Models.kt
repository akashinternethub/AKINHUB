package com.example.data.model

enum class ServiceCategory(val displayName: String, val iconEmoji: String) {
    ALL("All Services", "✨"),
    IDENTITY_GOVT("Identity & Govt", "🆔"),
    JOBS_RECRUITMENT("Jobs & Recruitment", "💼"),
    UTILITY_BILLS("Bills & Recharge", "⚡"),
    EDUCATION_RESULTS("Education & Results", "🎓"),
    PRINT_SCAN("Print & Xerox Hub", "🖨️"),
    BANKING_FINANCE("Banking & Insurance", "🏛️")
}

data class HubService(
    val id: String,
    val title: String,
    val category: ServiceCategory,
    val description: String,
    val requiredDocuments: List<String>,
    val processingTime: String,
    val officialGovtFee: String,
    val centerCharge: String,
    val totalFee: String,
    val isPopular: Boolean = false,
    val iconName: String = "description",
    val officialPortalUrl: String? = null
)

data class JobAlert(
    val id: String,
    val postTitle: String,
    val department: String,
    val vacancies: String,
    val qualification: String,
    val ageLimit: String,
    val lastDate: String,
    val applicationFee: String,
    val officialWebsite: String,
    val importantNotes: String,
    val isUrgent: Boolean = false
)

enum class ApplicationStatus(val title: String, val stepNumber: Int) {
    SUBMITTED("Application Received", 1),
    DOCUMENT_VERIFIED("Documents Verified", 2),
    PROCESSING_AT_HUB("Processing at Cyber Center", 3),
    COMPLETED_READY("Completed & Ready", 4),
    ACTION_REQUIRED("Needs Customer Attention", 2)
}

data class ServiceApplication(
    val id: String,
    val serviceTitle: String,
    val category: ServiceCategory,
    val applicantName: String,
    val phone: String,
    val email: String,
    val dateSubmitted: String,
    val status: ApplicationStatus,
    val trackingRefNumber: String,
    val totalPaid: String,
    val uploadedDocuments: List<String>,
    val remark: String = ""
)

data class PrintOrder(
    val id: String,
    val title: String,
    val printType: String,
    val copies: Int,
    val pages: Int,
    val isLaminated: Boolean,
    val totalCost: Double,
    val orderDate: String,
    val status: String,
    val customerName: String,
    val customerPhone: String,
    val pickupEstimate: String
)

data class NoticeAlert(
    val id: String,
    val title: String,
    val tag: String,
    val date: String,
    val description: String,
    val isImportant: Boolean = false
)

data class HubReview(
    val id: String,
    val authorName: String,
    val location: String,
    val rating: Float,
    val reviewText: String,
    val date: String
)

data class HubInfo(
    val hubName: String = "Akash Internet Hub",
    val ownerName: String = "Akash",
    val phone: String = "+91 7002134700",
    val whatsapp: String = "+91 7002134700",
    val address: String = "Near Saba Petrol Pump, Geramari Part-II, P.O. Geramari, Dist: Dhubri, Assam - 783339",
    val timings: String = "Open 7 Days • 08:00 AM - 09:30 PM",
    val announcementBanner: String = "🚀 ADRE 2026, Voter ID Print, PAN Card & All Online Assam Govt Services Active! Call/WhatsApp: +91 7002134700",
    val upiId: String = "7002134700@okbizaxis",
    val adminUsername: String = "Awyez786",
    val adminPassword: String = "786786",
    val isShopOpen: Boolean = true,
    val shopClosedMessage: String = "Bhai kisi problem Ki karan Abhi dukan band huwa hai  Jab khulega To Notification Mil jayga",
    val popupNotificationTitle: String = "Notice from Akash Internet Hub",
    val popupNotificationMessage: String = "",
    val showPopupNotification: Boolean = false,
    val isEmergencyBroadcast: Boolean = false,
    val razorpayButtonId: String = "pl_Q3i6h1QvG9uP4v",
    val receiptHeader: String = "AKASH INTERNET HUB",
    val receiptSubHeader: String = "Common Services Center & Cyber Portal",
    val receiptAddress: String = "Geramari, Near Saba Petrol Pump, Dhubri, Assam",
    val receiptEmail: String = "akashinternethub@gmail.com",
    val receiptCustomNote: String = "This is a computerized official acknowledgement receipt. Keep safely for future reference.",
    val receiptSealText: String = "AKASH HUB\nDIGITALLY VERIFIED",
    val payHdButtonText: String = "Pay ₹10 & Download HD (No Watermark)",
    val freeDownloadButtonText: String = "Free Download (With Watermark)",
    val unlockedButtonText: String = "✨ Download Clean HD File (Unlocked)",
    val watermarkText: String = "Downloaded From Akash Internet Hub",
    val hdPriceText: String = "10",
    val appThemeColorId: String = "navy_amber"
)
