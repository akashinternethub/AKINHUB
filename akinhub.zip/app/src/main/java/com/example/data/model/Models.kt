package com.example.data.model

enum class ServiceCategory(val displayName: String, val iconEmoji: String) {
    ALL("All Services", "✨"),
    IDENTITY_GOVT("Identity & Govt", "🆔"),
    JOBS_RECRUITMENT("Jobs & Recruitment", "💼"),
    UTILITY_BILLS("Bills & Recharge", "⚡"),
    EDUCATION_RESULTS("Education & Results", "🎓"),
    PRINT_SCAN("Print & Xerox Hub", "🖨️"),
    BANKING_FINANCE("Banking & Insurance", "🏛️")
}

data class HubService(
    val id: String,
    val title: String,
    val category: ServiceCategory,
    val description: String,
    val requiredDocuments: List<String>,
    val processingTime: String,
    val officialGovtFee: String,
    val centerCharge: String,
    val totalFee: String,
    val isPopular: Boolean = false,
    val iconName: String = "description",
    val officialPortalUrl: String? = null
)

data class JobAlert(
    val id: String,
    val postTitle: String,
    val department: String,
    val vacancies: String,
    val qualification: String,
    val ageLimit: String,
    val lastDate: String,
    val applicationFee: String,
    val officialWebsite: String,
    val importantNotes: String,
    val isUrgent: Boolean = false
)

enum class ApplicationStatus(val title: String, val stepNumber: Int) {
    SUBMITTED("Application Received", 1),
    DOCUMENT_VERIFIED("Documents Verified", 2),
    PROCESSING_AT_HUB("Processing at Cyber Center", 3),
    COMPLETED_READY("Completed & Ready", 4),
    ACTION_REQUIRED("Needs Customer Attention", 2)
}

data class ServiceApplication(
    val id: String,
    val serviceTitle: String,
    val category: ServiceCategory,
    val applicantName: String,
    val phone: String,
    val email: String,
    val dateSubmitted: String,
    val status: ApplicationStatus,
    val trackingRefNumber: String,
    val totalPaid: String,
    val uploadedDocuments: List<String>,
    val remark: String = ""
)

data class PrintOrder(
    val id: String,
    val title: String,
    val printType: String,
    val copies: Int,
    val pages: Int,
    val isLaminated: Boolean,
    val totalCost: Double,
    val orderDate: String,
    val status: String,
    val customerName: String,
    val customerPhone: String,
    val pickupEstimate: String
)

data class NoticeAlert(
    val id: String,
    val title: String,
    val tag: String,
    val date: String,
    val description: String,
    val isImportant: Boolean = false
)

data class HubReview(
    val id: String,
    val authorName: String,
    val location: String,
    val rating: Float,
    val reviewText: String,
    val date: String
)
