package com.example.data.model

import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

data class GovernmentScheme(
    val id: String,
    val title: String,
    val titleHi: String,
    val titleAs: String,
    val department: String,
    val category: String, // e.g. "Direct Benefit (DBT)", "Student & Youth", "Housing & Solar", "Healthcare", "Women Welfare"
    val benefits: String,
    val eligibility: String,
    val requiredDocuments: List<String>,
    val lastDateOrStatus: String,
    val officialPortalUrl: String,
    val isAssamStateGovt: Boolean = true,
    val isAutoUpdatedToday: Boolean = true,
    val lastUpdatedDate: String = SimpleDateFormat("dd MMM yyyy", Locale.getDefault()).format(Date())
)
