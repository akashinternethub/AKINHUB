package com.example

import android.os.Bundle
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.viewModels
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material.icons.outlined.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.data.localization.AppLanguage
import com.example.data.localization.LocalizedStrings
import com.example.data.model.NoticeAlert
import com.example.ui.dialogs.*
import com.example.ui.screens.*
import com.example.ui.theme.AkinAmberAccent
import com.example.ui.theme.AkinGreenSuccess
import com.example.ui.theme.MyApplicationTheme
import com.example.ui.viewmodel.AkinhubViewModel
import com.example.ui.viewmodel.AppTab
import com.example.utils.VoiceGreetingHelper

class MainActivity : ComponentActivity() {

    private val viewModel: AkinhubViewModel by viewModels()
    private lateinit var voiceGreetingHelper: VoiceGreetingHelper

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()

        voiceGreetingHelper = VoiceGreetingHelper(this)

        setContent {
            MyApplicationTheme {
                AkinhubMainScreen(
                    viewModel = viewModel,
                    voiceGreetingHelper = voiceGreetingHelper
                )
            }
        }
    }

    override fun onDestroy() {
        super.onDestroy()
        voiceGreetingHelper.shutdown()
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun AkinhubMainScreen(
    viewModel: AkinhubViewModel,
    voiceGreetingHelper: VoiceGreetingHelper,
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    val uiState by viewModel.uiState.collectAsStateWithLifecycle()
    val snackbarHostState = remember { SnackbarHostState() }
    var activeNoticeForDialog by remember { mutableStateOf<NoticeAlert?>(null) }
    var showLanguageMenu by remember { mutableStateOf(false) }

    // Play Voice Greeting once when app opens if enabled
    LaunchedEffect(Unit) {
        if (voiceGreetingHelper.isVoiceEnabled()) {
            voiceGreetingHelper.playGreeting()
        }
    }

    LaunchedEffect(uiState.successSnackbarMessage) {
        uiState.successSnackbarMessage?.let { message ->
            snackbarHostState.showSnackbar(message)
            viewModel.clearSnackbarMessage()
        }
    }

    Scaffold(
        modifier = modifier
            .fillMaxSize()
            .testTag("akinhub_main_scaffold"),
        contentWindowInsets = WindowInsets.safeDrawing,
        topBar = {
            TopAppBar(
                title = {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Surface(
                            modifier = Modifier
                                .size(34.dp)
                                .clip(RoundedCornerShape(8.dp)),
                            color = MaterialTheme.colorScheme.primary
                        ) {
                            Box(contentAlignment = Alignment.Center) {
                                Text(
                                    text = "⚡",
                                    fontSize = 18.sp
                                )
                            }
                        }
                        Spacer(modifier = Modifier.width(8.dp))
                        Column {
                            Text(
                                text = "Akash Internet Hub",
                                fontSize = 15.sp,
                                fontWeight = FontWeight.Bold
                            )
                            Text(
                                text = "Geramari • CSC & Cyber Specialist",
                                fontSize = 10.sp,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                    }
                },
                actions = {
                    // Voice Greeting Audio Toggle Button
                    IconButton(
                        onClick = {
                            val newStatus = !voiceGreetingHelper.isVoiceEnabled()
                            voiceGreetingHelper.setVoiceEnabled(newStatus)
                            viewModel.setVoiceGreetingEnabled(newStatus)
                            if (newStatus) {
                                voiceGreetingHelper.playGreeting(force = true)
                                Toast.makeText(context, "🔊 Voice Greeting Enabled (Adam Voice)", Toast.LENGTH_SHORT).show()
                            } else {
                                Toast.makeText(context, "🔇 Voice Greeting Muted (Band Kar Diya)", Toast.LENGTH_SHORT).show()
                            }
                        },
                        modifier = Modifier.testTag("voice_greeting_toggle_button")
                    ) {
                        Icon(
                            imageVector = if (uiState.isVoiceGreetingEnabled) Icons.Default.VolumeUp else Icons.Default.VolumeOff,
                            contentDescription = "Voice Greeting Toggle",
                            tint = if (uiState.isVoiceGreetingEnabled) AkinAmberAccent else MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }

                    // Language Switcher Dropdown (English / Hindi / Assamese)
                    Box {
                        Surface(
                            modifier = Modifier
                                .clip(RoundedCornerShape(20.dp))
                                .clickable { showLanguageMenu = true }
                                .testTag("language_switcher_button"),
                            color = MaterialTheme.colorScheme.secondaryContainer
                        ) {
                            Row(
                                modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Icon(
                                    imageVector = Icons.Default.Translate,
                                    contentDescription = "Language",
                                    tint = MaterialTheme.colorScheme.onSecondaryContainer,
                                    modifier = Modifier.size(16.dp)
                                )
                                Spacer(modifier = Modifier.width(4.dp))
                                Text(
                                    text = uiState.currentLanguage.nativeName,
                                    fontSize = 12.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = MaterialTheme.colorScheme.onSecondaryContainer
                                )
                            }
                        }

                        DropdownMenu(
                            expanded = showLanguageMenu,
                            onDismissRequest = { showLanguageMenu = false }
                        ) {
                            AppLanguage.values().forEach { lang ->
                                DropdownMenuItem(
                                    text = {
                                        Row(
                                            modifier = Modifier.fillMaxWidth(),
                                            horizontalArrangement = Arrangement.SpaceBetween,
                                            verticalAlignment = Alignment.CenterVertically
                                        ) {
                                            Text(
                                                text = "${lang.nativeName} (${lang.displayName})",
                                                fontWeight = if (uiState.currentLanguage == lang) FontWeight.Bold else FontWeight.Normal
                                            )
                                            if (uiState.currentLanguage == lang) {
                                                Icon(
                                                    imageVector = Icons.Default.Check,
                                                    contentDescription = "Selected",
                                                    tint = MaterialTheme.colorScheme.primary,
                                                    modifier = Modifier.size(16.dp)
                                                )
                                            }
                                        }
                                    },
                                    onClick = {
                                        viewModel.setLanguage(lang)
                                        showLanguageMenu = false
                                        Toast.makeText(context, "Language switched to ${lang.displayName}", Toast.LENGTH_SHORT).show()
                                    }
                                )
                            }
                        }
                    }
                    Spacer(modifier = Modifier.width(6.dp))
                },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = MaterialTheme.colorScheme.surface
                )
            )
        },
        snackbarHost = { SnackbarHost(snackbarHostState) },
        bottomBar = {
            NavigationBar(
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("akinhub_bottom_nav_bar")
            ) {
                AppTab.values().forEach { tab ->
                    val isSelected = uiState.selectedTab == tab
                    val icon: ImageVector = when (tab) {
                        AppTab.EXPLORE -> if (isSelected) Icons.Filled.Home else Icons.Outlined.Home
                        AppTab.SCHEMES -> if (isSelected) Icons.Filled.AccountBalance else Icons.Outlined.AccountBalance
                        AppTab.JOBS -> if (isSelected) Icons.Filled.Work else Icons.Outlined.Work
                        AppTab.TRACKER -> if (isSelected) Icons.Filled.Assignment else Icons.Outlined.Assignment
                        AppTab.TOOLS -> if (isSelected) Icons.Filled.Build else Icons.Outlined.Build
                        AppTab.ABOUT -> if (isSelected) Icons.Filled.Storefront else Icons.Outlined.Storefront
                    }

                    val localizedLabel = when (tab) {
                        AppTab.EXPLORE -> LocalizedStrings.getNavExplore(uiState.currentLanguage)
                        AppTab.SCHEMES -> LocalizedStrings.getNavSchemes(uiState.currentLanguage)
                        AppTab.JOBS -> LocalizedStrings.getNavJobs(uiState.currentLanguage)
                        AppTab.TRACKER -> LocalizedStrings.getNavTracker(uiState.currentLanguage)
                        AppTab.TOOLS -> LocalizedStrings.getNavTools(uiState.currentLanguage)
                        AppTab.ABOUT -> LocalizedStrings.getNavAbout(uiState.currentLanguage)
                    }

                    NavigationBarItem(
                        selected = isSelected,
                        onClick = { viewModel.selectTab(tab) },
                        icon = { Icon(imageVector = icon, contentDescription = tab.title) },
                        label = { Text(localizedLabel, fontSize = 10.sp, maxLines = 1) },
                        modifier = Modifier.testTag("nav_item_${tab.name.lowercase()}")
                    )
                }
            }
        }
    ) { innerPadding ->
        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
        ) {
            when (uiState.selectedTab) {
                AppTab.EXPLORE -> {
                    ExploreScreen(
                        services = uiState.services,
                        notices = uiState.notices,
                        reviews = uiState.reviews,
                        selectedCategory = uiState.selectedCategory,
                        searchQuery = uiState.searchQuery,
                        onCategorySelected = { viewModel.selectCategory(it) },
                        onSearchQueryChange = { viewModel.updateSearchQuery(it) },
                        onServiceClick = { viewModel.showServiceDetail(it) },
                        onApplyClick = { viewModel.openApplyDialog(it) },
                        onBookPrintClick = { viewModel.openPrintOrderDialog(true) },
                        onNoticeClick = { activeNoticeForDialog = it }
                    )
                }
                AppTab.SCHEMES -> {
                    SchemesScreen(
                        schemes = uiState.governmentSchemes,
                        currentLanguage = uiState.currentLanguage,
                        onApplyScheme = { scheme ->
                            val matchingService = uiState.services.find { it.id == "ration_card_apply" || it.id == "adre_job_apply" } ?: uiState.services.first()
                            viewModel.openApplyDialog(matchingService)
                        }
                    )
                }
                AppTab.JOBS -> {
                    JobsScreen(
                        jobs = uiState.jobAlerts,
                        onJobClick = { viewModel.showJobDetail(it) },
                        onRequestApplyClick = { job ->
                            val matchingService = uiState.services.find { it.id == "adre_job_apply" } ?: uiState.services.first()
                            viewModel.openApplyDialog(matchingService)
                        }
                    )
                }
                AppTab.TRACKER -> {
                    TrackerScreen(
                        applications = uiState.applications,
                        printOrders = uiState.printOrders,
                        searchQuery = uiState.trackerSearchQuery,
                        onSearchQueryChange = { viewModel.updateTrackerSearchQuery(it) },
                        onViewReceipt = { viewModel.viewApplicationReceipt(it) },
                        onBookNewService = { viewModel.selectTab(AppTab.EXPLORE) },
                        onBookNewPrint = { viewModel.openPrintOrderDialog(true) }
                    )
                }
                AppTab.TOOLS -> {
                    ToolsScreen(
                        ageResult = uiState.ageResult,
                        billResult = uiState.billResult,
                        onCalculateAge = { dobY, dobM, dobD, cutY, cutM, cutD ->
                            viewModel.calculateAge(dobY, dobM, dobD, cutY, cutM, cutD)
                        },
                        onCalculateBill = { units ->
                            viewModel.calculateElectricityBill(units)
                        },
                        onPayElectricityBillClick = {
                            val billService = uiState.services.find { it.id == "apdcl_bill" }
                            if (billService != null) {
                                viewModel.openApplyDialog(billService)
                            }
                        }
                    )
                }
                AppTab.ABOUT -> {
                    AboutHubScreen(
                        onBookPrintClick = { viewModel.handlePrintButtonClick() }
                    )
                }
            }
        }
    }

    // Modal Dialogs
    if (uiState.showPrintClosedDialog) {
        PrintClosedDialog(
            onDismiss = { viewModel.closePrintClosedDialog() }
        )
    }

    uiState.showApplyDialogForService?.let { service ->
        ApplyServiceDialog(
            service = service,
            onDismiss = { viewModel.closeApplyDialog() },
            onSubmit = { name, phone, email, docs, notes ->
                viewModel.submitServiceApplication(
                    service = service,
                    applicantName = name,
                    phone = phone,
                    email = email,
                    attachedDocs = docs,
                    notes = notes
                )
            }
        )
    }

    if (uiState.showPrintOrderDialog) {
        PrintOrderDialog(
            onDismiss = { viewModel.openPrintOrderDialog(false) },
            onSubmitOrder = { title, printType, copies, pages, isLaminated, customerName, customerPhone ->
                viewModel.submitPrintOrder(
                    title = title,
                    printType = printType,
                    copies = copies,
                    pages = pages,
                    isLaminated = isLaminated,
                    customerName = customerName,
                    customerPhone = customerPhone
                )
            },
            onDirectAutomaticPrint = {
                if (com.example.ui.components.ContactHelper.isPrintHoursActive()) {
                    com.example.ui.components.ContactHelper.openAutomaticPrint(context)
                } else {
                    viewModel.handlePrintButtonClick()
                }
            }
        )
    }

    uiState.selectedServiceForDetail?.let { service ->
        ServiceDetailDialog(
            service = service,
            onDismiss = { viewModel.showServiceDetail(null) },
            onApplyClick = {
                viewModel.openApplyDialog(service)
            }
        )
    }

    uiState.selectedJobForDetail?.let { job ->
        JobDetailDialog(
            job = job,
            onDismiss = { viewModel.showJobDetail(null) },
            onRequestApply = {
                viewModel.showJobDetail(null)
                val matchingService = uiState.services.find { it.id == "adre_job_apply" } ?: uiState.services.first()
                viewModel.openApplyDialog(matchingService)
            }
        )
    }

    uiState.activeApplicationForReceipt?.let { app ->
        ReceiptViewerDialog(
            application = app,
            onDismiss = { viewModel.viewApplicationReceipt(null) }
        )
    }

    activeNoticeForDialog?.let { notice ->
        NoticeDetailDialog(
            notice = notice,
            onDismiss = { activeNoticeForDialog = null }
        )
    }
}

