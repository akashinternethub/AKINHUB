package com.example

import android.os.Bundle
import android.widget.Toast
import android.util.Log
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.viewModels
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material.icons.outlined.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.tooling.preview.Preview
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.lifecycleScope
import com.example.data.localization.AppLanguage
import com.example.data.localization.LocalizedStrings
import com.example.data.model.NoticeAlert
import com.example.ui.components.FloatingVoiceHelpButton
import com.example.ui.dialogs.*
import com.example.ui.screens.*
import com.example.ui.theme.AkinAmberAccent
import com.example.ui.theme.AkinGreenSuccess
import com.example.ui.theme.MyApplicationTheme
import com.example.ui.viewmodel.AkinhubViewModel
import com.example.ui.viewmodel.AppTab
import com.example.utils.GeminiVoiceAssistantHelper
import com.example.utils.VoiceGreetingHelper

class MainActivity : ComponentActivity() {

    private val viewModel: AkinhubViewModel by viewModels()
    private var voiceGreetingHelper: VoiceGreetingHelper? = null
    private var geminiVoiceHelper: GeminiVoiceAssistantHelper? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()

        try {
            voiceGreetingHelper = VoiceGreetingHelper(this)
        } catch (e: Throwable) {
            Log.e("MainActivity", "VoiceGreetingHelper init error", e)
        }

        try {
            geminiVoiceHelper = GeminiVoiceAssistantHelper(this, lifecycleScope)
        } catch (e: Throwable) {
            Log.e("MainActivity", "GeminiVoiceAssistantHelper init error", e)
        }

        setContent {
            val hubInfo by viewModel.hubInfo.collectAsStateWithLifecycle()
            MyApplicationTheme(themeId = hubInfo.appThemeColorId) {
                AkinhubMainScreen(
                    viewModel = viewModel,
                    voiceGreetingHelper = voiceGreetingHelper,
                    geminiVoiceHelper = geminiVoiceHelper
                )
            }
        }
    }

    override fun onDestroy() {
        super.onDestroy()
        try {
            voiceGreetingHelper?.shutdown()
        } catch (e: Throwable) {
            Log.e("MainActivity", "VoiceGreetingHelper shutdown error", e)
        }
        try {
            geminiVoiceHelper?.shutdown()
        } catch (e: Throwable) {
            Log.e("MainActivity", "GeminiVoiceAssistantHelper shutdown error", e)
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun AkinhubMainScreen(
    viewModel: AkinhubViewModel = androidx.lifecycle.viewmodel.compose.viewModel(),
    voiceGreetingHelper: VoiceGreetingHelper? = null,
    geminiVoiceHelper: GeminiVoiceAssistantHelper? = null,
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    val uiState by viewModel.uiState.collectAsStateWithLifecycle()
    val hubInfo by viewModel.hubInfo.collectAsStateWithLifecycle()
    val voiceState by geminiVoiceHelper?.state?.collectAsStateWithLifecycle() ?: remember {
        mutableStateOf(com.example.utils.VoiceAssistantState())
    }
    val snackbarHostState = remember { SnackbarHostState() }
    val exploreLazyListState = androidx.compose.foundation.lazy.rememberLazyListState()
    var activeNoticeForDialog by remember { mutableStateOf<NoticeAlert?>(null) }
    var showLanguageMenu by remember { mutableStateOf(false) }

    // Broadcast Popup Dialog state (triggered on app start if enabled)
    var showBroadcastPopupDialog by remember { mutableStateOf(true) }

    // Voice Chat Dialog State
    var showVoiceChatDialog by remember { mutableStateOf(false) }

    // Admin App Mode State (Firebase Authentication)
    var isAdminModeActive by remember { mutableStateOf(false) }
    var showAdminAuthDialog by remember { mutableStateOf(false) }
    var enteredAdminEmail by remember { mutableStateOf("akashinternethub@gmail.com") }
    var enteredAdminPassword by remember { mutableStateOf("") }
    var showAdminPasswordVisual by remember { mutableStateOf(false) }
    var isAdminAuthenticating by remember { mutableStateOf(false) }
    var authErrorMessage by remember { mutableStateOf<String?>(null) }

    // Shop Closed alert state for user actions
    var showShopClosedAlert by remember { mutableStateOf(false) }

    // Check if user is scrolling to shrink voice help button ("sota ho jayega")
    val isHelpButtonCompact by remember {
        derivedStateOf {
            exploreLazyListState.firstVisibleItemIndex > 0 || exploreLazyListState.isScrollInProgress
        }
    }

    // Play Voice Greeting once when app opens if enabled
    LaunchedEffect(Unit) {
        try {
            if (voiceGreetingHelper?.isVoiceEnabled() == true) {
                voiceGreetingHelper.playGreeting()
            }
        } catch (e: Throwable) {
            Log.e("MainActivity", "Voice greeting error", e)
        }
    }

    LaunchedEffect(uiState.successSnackbarMessage) {
        uiState.successSnackbarMessage?.let { message ->
            snackbarHostState.showSnackbar(message)
            viewModel.clearSnackbarMessage()
        }
    }

    // If Admin Mode is active, show the Master Admin Console
    if (isAdminModeActive) {
        AdminControlCenterScreen(
            viewModel = viewModel,
            onExitAdmin = {
                isAdminModeActive = false
                Toast.makeText(context, "Returned to Customer View", Toast.LENGTH_SHORT).show()
            }
        )
        return
    }

    // BackHandler: Pressing system back button outside Explore tab returns to Home/Explore tab
    BackHandler(enabled = uiState.selectedTab != AppTab.EXPLORE) {
        viewModel.selectTab(AppTab.EXPLORE)
    }

    Scaffold(
        modifier = modifier
            .fillMaxSize()
            .testTag("akinhub_main_scaffold"),
        contentWindowInsets = WindowInsets.safeDrawing,
        topBar = {
            TopAppBar(
                navigationIcon = {
                    if (uiState.selectedTab != AppTab.EXPLORE) {
                        IconButton(
                            onClick = { viewModel.selectTab(AppTab.EXPLORE) },
                            modifier = Modifier.testTag("top_bar_back_to_home")
                        ) {
                            Icon(
                                imageVector = Icons.Default.ArrowBack,
                                contentDescription = "Back to Home",
                                tint = MaterialTheme.colorScheme.primary
                            )
                        }
                    }
                },
                title = {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Surface(
                            modifier = Modifier
                                .size(34.dp)
                                .clip(RoundedCornerShape(8.dp)),
                            color = MaterialTheme.colorScheme.primary
                        ) {
                            Box(contentAlignment = Alignment.Center) {
                                Text(
                                    text = "⚡",
                                    fontSize = 18.sp
                                )
                            }
                        }
                        Spacer(modifier = Modifier.width(8.dp))
                        Column {
                            Text(
                                text = "Akash Internet Hub",
                                fontSize = 15.sp,
                                fontWeight = FontWeight.Bold
                            )
                            Text(
                                text = "Geramari • CSC & Cyber Specialist",
                                fontSize = 10.sp,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                    }
                },
                actions = {
                    // Admin Console Quick Entry Icon (Secure Auth)
                    IconButton(
                        onClick = { showAdminAuthDialog = true },
                        modifier = Modifier.testTag("top_bar_admin_button")
                    ) {
                        Icon(
                            imageVector = Icons.Default.AdminPanelSettings,
                            contentDescription = "Admin Console",
                            tint = Color(0xFFEF4444)
                        )
                    }

                    // Voice Greeting Audio Toggle Button
                    IconButton(
                        onClick = {
                            val currentStatus = voiceGreetingHelper?.isVoiceEnabled() ?: uiState.isVoiceGreetingEnabled
                            val newStatus = !currentStatus
                            voiceGreetingHelper?.setVoiceEnabled(newStatus)
                            viewModel.setVoiceGreetingEnabled(newStatus)
                            if (newStatus) {
                                voiceGreetingHelper?.playGreeting(force = true)
                                Toast.makeText(context, "🔊 Voice Greeting Enabled (Adam Voice)", Toast.LENGTH_SHORT).show()
                            } else {
                                Toast.makeText(context, "🔇 Voice Greeting Muted", Toast.LENGTH_SHORT).show()
                            }
                        },
                        modifier = Modifier.testTag("voice_greeting_toggle_button")
                    ) {
                        Icon(
                            imageVector = if (uiState.isVoiceGreetingEnabled) Icons.Default.VolumeUp else Icons.Default.VolumeOff,
                            contentDescription = "Voice Greeting Toggle",
                            tint = if (uiState.isVoiceGreetingEnabled) AkinAmberAccent else MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }

                    // Language Switcher Dropdown (English / Hindi / Bengali / Assamese / Hinglish)
                    Box {
                        Surface(
                            modifier = Modifier
                                .clip(RoundedCornerShape(20.dp))
                                .clickable { showLanguageMenu = true }
                                .testTag("language_switcher_button"),
                            color = MaterialTheme.colorScheme.secondaryContainer
                        ) {
                            Row(
                                modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Icon(
                                    imageVector = Icons.Default.Translate,
                                    contentDescription = "Language",
                                    tint = MaterialTheme.colorScheme.onSecondaryContainer,
                                    modifier = Modifier.size(16.dp)
                                )
                                Spacer(modifier = Modifier.width(4.dp))
                                Text(
                                    text = uiState.currentLanguage.nativeName,
                                    fontSize = 12.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = MaterialTheme.colorScheme.onSecondaryContainer
                                )
                            }
                        }

                        DropdownMenu(
                            expanded = showLanguageMenu,
                            onDismissRequest = { showLanguageMenu = false }
                        ) {
                            AppLanguage.values().forEach { lang ->
                                DropdownMenuItem(
                                    text = {
                                        Row(
                                            modifier = Modifier.fillMaxWidth(),
                                            horizontalArrangement = Arrangement.SpaceBetween,
                                            verticalAlignment = Alignment.CenterVertically
                                        ) {
                                            Text(
                                                text = "${lang.nativeName} (${lang.displayName})",
                                                fontWeight = if (uiState.currentLanguage == lang) FontWeight.Bold else FontWeight.Normal
                                            )
                                            if (uiState.currentLanguage == lang) {
                                                Icon(
                                                    imageVector = Icons.Default.Check,
                                                    contentDescription = "Selected",
                                                    tint = MaterialTheme.colorScheme.primary,
                                                    modifier = Modifier.size(16.dp)
                                                )
                                            }
                                        }
                                    },
                                    onClick = {
                                        viewModel.setLanguage(lang)
                                        geminiVoiceHelper?.setSelectedLanguage(lang)
                                        showLanguageMenu = false
                                        Toast.makeText(context, "Language switched to ${lang.displayName}", Toast.LENGTH_SHORT).show()
                                    }
                                )
                            }
                        }
                    }
                    Spacer(modifier = Modifier.width(6.dp))
                },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = MaterialTheme.colorScheme.surface
                )
            )
        },
        snackbarHost = { SnackbarHost(snackbarHostState) },
        bottomBar = {
            NavigationBar(
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("akinhub_bottom_nav_bar")
            ) {
                AppTab.values().forEach { tab ->
                    val isSelected = uiState.selectedTab == tab
                    val icon: ImageVector = when (tab) {
                        AppTab.EXPLORE -> if (isSelected) Icons.Filled.Home else Icons.Outlined.Home
                        AppTab.SCHEMES -> if (isSelected) Icons.Filled.AccountBalance else Icons.Outlined.AccountBalance
                        AppTab.JOBS -> if (isSelected) Icons.Filled.Work else Icons.Outlined.Work
                        AppTab.TRACKER -> if (isSelected) Icons.Filled.Assignment else Icons.Outlined.Assignment
                        AppTab.TOOLS -> if (isSelected) Icons.Filled.Build else Icons.Outlined.Build
                        AppTab.ABOUT -> if (isSelected) Icons.Filled.Storefront else Icons.Outlined.Storefront
                    }

                    val localizedLabel = when (tab) {
                        AppTab.EXPLORE -> LocalizedStrings.getNavExplore(uiState.currentLanguage)
                        AppTab.SCHEMES -> LocalizedStrings.getNavSchemes(uiState.currentLanguage)
                        AppTab.JOBS -> LocalizedStrings.getNavJobs(uiState.currentLanguage)
                        AppTab.TRACKER -> LocalizedStrings.getNavTracker(uiState.currentLanguage)
                        AppTab.TOOLS -> LocalizedStrings.getNavTools(uiState.currentLanguage)
                        AppTab.ABOUT -> LocalizedStrings.getNavAbout(uiState.currentLanguage)
                    }

                    NavigationBarItem(
                        selected = isSelected,
                        onClick = { viewModel.selectTab(tab) },
                        icon = { Icon(imageVector = icon, contentDescription = tab.title) },
                        label = { Text(localizedLabel, fontSize = 9.5.sp, maxLines = 1) },
                        alwaysShowLabel = isSelected,
                        modifier = Modifier.testTag("nav_item_${tab.name.lowercase()}")
                    )
                }
            }
        }
    ) { innerPadding ->
        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
        ) {
            when (uiState.selectedTab) {
                AppTab.EXPLORE -> {
                    ExploreScreen(
                        services = uiState.services,
                        notices = uiState.notices,
                        reviews = uiState.reviews,
                        selectedCategory = uiState.selectedCategory,
                        searchQuery = uiState.searchQuery,
                        hubInfo = hubInfo,
                        lazyListState = exploreLazyListState,
                        onCategorySelected = { viewModel.selectCategory(it) },
                        onSearchQueryChange = { viewModel.updateSearchQuery(it) },
                        onServiceClick = { viewModel.showServiceDetail(it) },
                        onApplyClick = {
                            if (!hubInfo.isShopOpen) {
                                showShopClosedAlert = true
                            } else {
                                viewModel.openApplyDialog(it)
                            }
                        },
                        onBookPrintClick = {
                            if (!hubInfo.isShopOpen) {
                                showShopClosedAlert = true
                            } else {
                                viewModel.openPrintOrderDialog(true)
                            }
                        },
                        onNoticeClick = { activeNoticeForDialog = it }
                    )
                }
                AppTab.SCHEMES -> {
                    SchemesScreen(
                        schemes = uiState.governmentSchemes,
                        currentLanguage = uiState.currentLanguage,
                        onApplyScheme = { scheme ->
                            if (!hubInfo.isShopOpen) {
                                showShopClosedAlert = true
                            } else {
                                val matchingService = uiState.services.find { it.id == "ration_card_apply" || it.id == "adre_job_apply" } ?: uiState.services.first()
                                viewModel.openApplyDialog(matchingService)
                            }
                        }
                    )
                }
                AppTab.JOBS -> {
                    JobsScreen(
                        jobs = uiState.jobAlerts,
                        onJobClick = { viewModel.showJobDetail(it) },
                        onRequestApplyClick = { job ->
                            if (!hubInfo.isShopOpen) {
                                showShopClosedAlert = true
                            } else {
                                val matchingService = uiState.services.find { it.id == "adre_job_apply" } ?: uiState.services.first()
                                viewModel.openApplyDialog(matchingService)
                            }
                        }
                    )
                }
                AppTab.TRACKER -> {
                    TrackerScreen(
                        applications = uiState.applications,
                        printOrders = uiState.printOrders,
                        searchQuery = uiState.trackerSearchQuery,
                        onSearchQueryChange = { viewModel.updateTrackerSearchQuery(it) },
                        onViewReceipt = { viewModel.viewApplicationReceipt(it) },
                        onBookNewService = { viewModel.selectTab(AppTab.EXPLORE) },
                        onBookNewPrint = {
                            if (!hubInfo.isShopOpen) {
                                showShopClosedAlert = true
                            } else {
                                viewModel.openPrintOrderDialog(true)
                            }
                        }
                    )
                }
                AppTab.TOOLS -> {
                    ToolsScreen(
                        ageResult = uiState.ageResult,
                        billResult = uiState.billResult,
                        hubInfo = hubInfo,
                        onCalculateAge = { dobY, dobM, dobD, cutY, cutM, cutD ->
                            viewModel.calculateAge(dobY, dobM, dobD, cutY, cutM, cutD)
                        },
                        onCalculateBill = { units ->
                            viewModel.calculateElectricityBill(units)
                        },
                        onPayElectricityBillClick = {
                            val billService = uiState.services.find { it.id == "apdcl_bill" }
                            if (billService != null) {
                                if (!hubInfo.isShopOpen) {
                                    showShopClosedAlert = true
                                } else {
                                    viewModel.openApplyDialog(billService)
                                }
                            }
                        },
                        onBackToHome = {
                            viewModel.selectTab(AppTab.EXPLORE)
                        }
                    )
                }
                AppTab.ABOUT -> {
                    AboutHubScreen(
                        onBookPrintClick = {
                            if (!hubInfo.isShopOpen) {
                                showShopClosedAlert = true
                            } else {
                                viewModel.handlePrintButtonClick()
                            }
                        },
                        onOpenAdminMode = { showAdminAuthDialog = true }
                    )
                }
            }

            // Floating Help Chat & Voice Button (Scroll-aware compact shrink)
            FloatingVoiceHelpButton(
                onClick = { showVoiceChatDialog = true },
                isSpeakingOrListening = voiceState.isListening || voiceState.isSpeaking,
                isCompact = isHelpButtonCompact,
                modifier = Modifier.align(Alignment.BottomEnd)
            )
        }
    }

    // Voice Help Chat Dialog
    if (showVoiceChatDialog && geminiVoiceHelper != null) {
        VoiceHelpChatDialog(
            voiceHelper = geminiVoiceHelper,
            onDismiss = { showVoiceChatDialog = false }
        )
    }

    // Broadcast Popup Notification Modal (from Admin)
    if (hubInfo.showPopupNotification && showBroadcastPopupDialog) {
        Dialog(onDismissRequest = { showBroadcastPopupDialog = false }) {
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(16.dp)
                    .testTag("broadcast_popup_dialog"),
                shape = RoundedCornerShape(22.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
            ) {
                Column(
                    modifier = Modifier.padding(20.dp),
                    horizontalAlignment = Alignment.CenterHorizontally,
                    verticalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    Surface(
                        shape = CircleShape,
                        color = if (hubInfo.isEmergencyBroadcast) Color(0xFFEF4444) else AkinAmberAccent,
                        modifier = Modifier.size(54.dp)
                    ) {
                        Box(contentAlignment = Alignment.Center) {
                            Icon(
                                imageVector = if (hubInfo.isEmergencyBroadcast) Icons.Default.Warning else Icons.Default.Campaign,
                                contentDescription = null,
                                tint = if (hubInfo.isEmergencyBroadcast) Color.White else Color(0xFF0F172A),
                                modifier = Modifier.size(28.dp)
                            )
                        }
                    }

                    Text(
                        text = hubInfo.popupNotificationTitle.ifBlank { "Important Center Notice" },
                        fontSize = 17.sp,
                        fontWeight = FontWeight.Bold,
                        color = if (hubInfo.isEmergencyBroadcast) Color(0xFFEF4444) else MaterialTheme.colorScheme.primary,
                        textAlign = androidx.compose.ui.text.style.TextAlign.Center
                    )

                    Text(
                        text = hubInfo.popupNotificationMessage.ifBlank { "Welcome to Akash Internet Hub." },
                        fontSize = 13.5.sp,
                        color = MaterialTheme.colorScheme.onSurface,
                        lineHeight = 19.sp,
                        textAlign = androidx.compose.ui.text.style.TextAlign.Center
                    )

                    Button(
                        onClick = { showBroadcastPopupDialog = false },
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(44.dp),
                        shape = RoundedCornerShape(12.dp),
                        colors = ButtonDefaults.buttonColors(
                            containerColor = if (hubInfo.isEmergencyBroadcast) Color(0xFFEF4444) else MaterialTheme.colorScheme.primary
                        )
                    ) {
                        Text("Got it / Theek Hai", fontWeight = FontWeight.Bold)
                    }
                }
            }
        }
    }

    // Shop Closed Alert Modal
    if (showShopClosedAlert) {
        Dialog(onDismissRequest = { showShopClosedAlert = false }) {
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(16.dp)
                    .testTag("shop_closed_alert_dialog"),
                shape = RoundedCornerShape(20.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
            ) {
                Column(
                    modifier = Modifier.padding(20.dp),
                    horizontalAlignment = Alignment.CenterHorizontally,
                    verticalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    Surface(
                        shape = CircleShape,
                        color = Color(0xFFEF4444),
                        modifier = Modifier.size(54.dp)
                    ) {
                        Box(contentAlignment = Alignment.Center) {
                            Icon(Icons.Default.Storefront, contentDescription = null, tint = Color.White, modifier = Modifier.size(30.dp))
                        }
                    }

                    Text(
                        text = "Dukan Filhal Band Hai",
                        fontSize = 17.sp,
                        fontWeight = FontWeight.Bold,
                        color = Color(0xFFB91C1C)
                    )

                    Text(
                        text = hubInfo.shopClosedMessage,
                        fontSize = 13.5.sp,
                        color = MaterialTheme.colorScheme.onSurface,
                        lineHeight = 18.sp,
                        textAlign = androidx.compose.ui.text.style.TextAlign.Center
                    )

                    Button(
                        onClick = { showShopClosedAlert = false },
                        modifier = Modifier.fillMaxWidth(),
                        shape = RoundedCornerShape(10.dp),
                        colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF0F172A))
                    ) {
                        Text("Okay / Theek Hai")
                    }
                }
            }
        }
    }

    // Admin Security Auth Dialog via Firebase Authentication Backend
    if (showAdminAuthDialog) {
        val firebaseAuth = remember { com.google.firebase.auth.FirebaseAuth.getInstance() }

        Dialog(onDismissRequest = {
            if (!isAdminAuthenticating) {
                showAdminAuthDialog = false
                enteredAdminPassword = ""
                authErrorMessage = null
            }
        }) {
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("admin_auth_dialog"),
                shape = RoundedCornerShape(20.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
            ) {
                Column(
                    modifier = Modifier.padding(20.dp),
                    horizontalAlignment = Alignment.CenterHorizontally,
                    verticalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    Surface(
                        shape = CircleShape,
                        color = Color(0xFF0F172A),
                        modifier = Modifier.size(50.dp)
                    ) {
                        Box(contentAlignment = Alignment.Center) {
                            Icon(Icons.Default.AdminPanelSettings, contentDescription = "Admin", tint = AkinAmberAccent, modifier = Modifier.size(26.dp))
                        }
                    }

                    Text(
                        text = "Akash Hub Admin Portal",
                        fontSize = 17.sp,
                        fontWeight = FontWeight.Bold
                    )

                    Text(
                        text = "Sign in securely with your Firebase Administrator credentials",
                        fontSize = 12.sp,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                        textAlign = androidx.compose.ui.text.style.TextAlign.Center
                    )

                    OutlinedTextField(
                        value = enteredAdminEmail,
                        onValueChange = {
                            enteredAdminEmail = it
                            authErrorMessage = null
                        },
                        label = { Text("Admin Email") },
                        placeholder = { Text("admin@example.com") },
                        singleLine = true,
                        enabled = !isAdminAuthenticating,
                        isError = authErrorMessage != null,
                        modifier = Modifier.fillMaxWidth()
                    )

                    OutlinedTextField(
                        value = enteredAdminPassword,
                        onValueChange = {
                            enteredAdminPassword = it
                            authErrorMessage = null
                        },
                        label = { Text("Password") },
                        singleLine = true,
                        enabled = !isAdminAuthenticating,
                        isError = authErrorMessage != null,
                        visualTransformation = if (showAdminPasswordVisual) androidx.compose.ui.text.input.VisualTransformation.None else androidx.compose.ui.text.input.PasswordVisualTransformation(),
                        trailingIcon = {
                            IconButton(onClick = { showAdminPasswordVisual = !showAdminPasswordVisual }) {
                                Icon(
                                    imageVector = if (showAdminPasswordVisual) Icons.Default.Visibility else Icons.Default.VisibilityOff,
                                    contentDescription = "Toggle Password"
                                )
                            }
                        },
                        modifier = Modifier.fillMaxWidth()
                    )

                    if (authErrorMessage != null) {
                        Surface(
                            shape = RoundedCornerShape(8.dp),
                            color = MaterialTheme.colorScheme.errorContainer.copy(alpha = 0.5f),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Row(
                                modifier = Modifier.padding(8.dp),
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(6.dp)
                            ) {
                                Icon(
                                    Icons.Default.ErrorOutline,
                                    contentDescription = "Error",
                                    tint = MaterialTheme.colorScheme.error,
                                    modifier = Modifier.size(16.dp)
                                )
                                Text(
                                    text = authErrorMessage ?: "Authentication failed",
                                    color = MaterialTheme.colorScheme.error,
                                    fontSize = 11.5.sp,
                                    lineHeight = 14.sp
                                )
                            }
                        }
                    }

                    // Forgot Password option
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.End
                    ) {
                        Text(
                            text = "Forgot Password?",
                            fontSize = 11.sp,
                            color = AkinAmberAccent,
                            fontWeight = FontWeight.SemiBold,
                            modifier = Modifier
                                .clip(RoundedCornerShape(4.dp))
                                .clickable {
                                    val email = enteredAdminEmail.trim()
                                    if (email.isBlank()) {
                                        Toast.makeText(context, "Please enter your Admin Email above first.", Toast.LENGTH_LONG).show()
                                    } else {
                                        firebaseAuth.sendPasswordResetEmail(email)
                                            .addOnSuccessListener {
                                                Toast.makeText(context, "Password reset email sent to $email! Please check your inbox.", Toast.LENGTH_LONG).show()
                                            }
                                            .addOnFailureListener {
                                                Toast.makeText(context, "Error sending reset email: ${it.localizedMessage}", Toast.LENGTH_LONG).show()
                                            }
                                    }
                                }
                                .padding(4.dp)
                        )
                    }

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        OutlinedButton(
                            onClick = {
                                showAdminAuthDialog = false
                                enteredAdminPassword = ""
                                authErrorMessage = null
                            },
                            enabled = !isAdminAuthenticating,
                            modifier = Modifier.weight(1f)
                        ) {
                            Text("Cancel")
                        }

                        Button(
                            onClick = {
                                val email = enteredAdminEmail.trim()
                                val password = enteredAdminPassword

                                if (email.isBlank() || password.isBlank()) {
                                    authErrorMessage = "Please enter both Admin Email and Password."
                                    Toast.makeText(context, "Please enter both Email and Password", Toast.LENGTH_SHORT).show()
                                    return@Button
                                }

                                isAdminAuthenticating = true
                                authErrorMessage = null

                                firebaseAuth.signInWithEmailAndPassword(email, password)
                                    .addOnSuccessListener { authResult ->
                                        isAdminAuthenticating = false
                                        showAdminAuthDialog = false
                                        enteredAdminPassword = ""
                                        authErrorMessage = null
                                        isAdminModeActive = true
                                        val userEmail = authResult.user?.email ?: email
                                        Toast.makeText(context, "Welcome Admin! Logged in as $userEmail", Toast.LENGTH_SHORT).show()
                                    }
                                    .addOnFailureListener { exception ->
                                        isAdminAuthenticating = false
                                        val errorMsg = when {
                                            exception.message?.contains("network", ignoreCase = true) == true -> "Network error. Please check your internet connection."
                                            exception.message?.contains("password", ignoreCase = true) == true -> "Invalid credentials. Please check your password."
                                            exception.message?.contains("user-not-found", ignoreCase = true) == true || exception.message?.contains("no user", ignoreCase = true) == true -> "Admin user not found for this email."
                                            exception.message?.contains("badly formatted", ignoreCase = true) == true -> "Invalid email address format."
                                            else -> exception.localizedMessage ?: "Authentication failed. Please verify credentials."
                                        }
                                        authErrorMessage = errorMsg
                                        Toast.makeText(context, "Login Failed: $errorMsg", Toast.LENGTH_LONG).show()
                                    }
                            },
                            enabled = !isAdminAuthenticating,
                            modifier = Modifier.weight(1f),
                            colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF0F172A))
                        ) {
                            if (isAdminAuthenticating) {
                                CircularProgressIndicator(
                                    modifier = Modifier.size(16.dp),
                                    color = Color.White,
                                    strokeWidth = 2.dp
                                )
                                Spacer(modifier = Modifier.width(6.dp))
                                Text("Verifying...", fontSize = 12.sp)
                            } else {
                                Icon(Icons.Default.Lock, contentDescription = null, modifier = Modifier.size(16.dp))
                                Spacer(modifier = Modifier.width(4.dp))
                                Text("Login")
                            }
                        }
                    }
                }
            }
        }
    }

    // Modal Dialogs
    if (uiState.showPrintClosedDialog) {
        PrintClosedDialog(
            onDismiss = { viewModel.closePrintClosedDialog() }
        )
    }

    uiState.showApplyDialogForService?.let { service ->
        ApplyServiceDialog(
            service = service,
            onDismiss = { viewModel.closeApplyDialog() },
            onSubmit = { name, phone, email, docs, notes ->
                viewModel.submitServiceApplication(
                    service = service,
                    applicantName = name,
                    phone = phone,
                    email = email,
                    attachedDocs = docs,
                    notes = notes
                )
                // Send application receipt directly to Akash Internet Hub WhatsApp (+917002134700)
                val attachedStr = if (docs.isNotEmpty()) docs.joinToString(", ") else "Standard IDs"
                val notesStr = if (notes.isNotBlank()) notes else "Standard Processing"
                val receiptWhatsAppMsg = """
                    📋 *NEW APPLICATION RECEIPT - AKASH INTERNET HUB*
                    -----------------------------------------
                    *Service:* ${service.title} (${service.category.displayName})
                    *Applicant Name:* $name
                    *Applicant Mobile:* $phone
                    *Email:* ${if (email.isNotBlank()) email else "N/A"}
                    *Charges:* Govt Fee: ${service.officialGovtFee} + Center: ${service.centerCharge} (Total: ${service.totalFee})
                    *Attached Docs:* $attachedStr
                    *Special Notes:* $notesStr
                    -----------------------------------------
                    _Automated Receipt from Akash Internet Hub App_
                """.trimIndent()
                com.example.ui.components.ContactHelper.openWhatsApp(context, receiptWhatsAppMsg)
            }
        )
    }

    if (uiState.showPrintOrderDialog) {
        PrintOrderDialog(
            onDismiss = { viewModel.openPrintOrderDialog(false) },
            onSubmitOrder = { title, printType, copies, pages, isLaminated, customerName, customerPhone ->
                viewModel.submitPrintOrder(
                    title = title,
                    printType = printType,
                    copies = copies,
                    pages = pages,
                    isLaminated = isLaminated,
                    customerName = customerName,
                    customerPhone = customerPhone
                )
            },
            onDirectAutomaticPrint = {
                if (com.example.ui.components.ContactHelper.isPrintHoursActive()) {
                    com.example.ui.components.ContactHelper.openAutomaticPrint(context)
                } else {
                    viewModel.handlePrintButtonClick()
                }
            }
        )
    }

    uiState.selectedServiceForDetail?.let { service ->
        ServiceDetailDialog(
            service = service,
            onDismiss = { viewModel.showServiceDetail(null) },
            onApplyClick = {
                viewModel.openApplyDialog(service)
            }
        )
    }

    uiState.selectedJobForDetail?.let { job ->
        JobDetailDialog(
            job = job,
            onDismiss = { viewModel.showJobDetail(null) },
            onRequestApply = {
                viewModel.showJobDetail(null)
                val matchingService = uiState.services.find { it.id == "adre_job_apply" } ?: uiState.services.first()
                viewModel.openApplyDialog(matchingService)
            }
        )
    }

    uiState.activeApplicationForReceipt?.let { app ->
        ReceiptViewerDialog(
            application = app,
            hubInfo = hubInfo,
            onDismiss = { viewModel.viewApplicationReceipt(null) }
        )
    }

    activeNoticeForDialog?.let { notice ->
        NoticeDetailDialog(
            notice = notice,
            onDismiss = { activeNoticeForDialog = null }
        )
    }
}

@Preview(showBackground = true, name = "Akinhub Main Screen Preview")
@Composable
fun AkinhubMainScreenPreview() {
    MyApplicationTheme {
        AkinhubMainScreen()
    }
}

