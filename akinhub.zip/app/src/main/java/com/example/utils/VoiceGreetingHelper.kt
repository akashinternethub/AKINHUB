package com.example.utils

import android.content.Context
import android.content.SharedPreferences
import android.speech.tts.TextToSpeech
import android.util.Log
import java.util.Locale

class VoiceGreetingHelper(private val context: Context) : TextToSpeech.OnInitListener {

    private var tts: TextToSpeech? = null
    private var isInitialized = false
    private val prefs: SharedPreferences = context.getSharedPreferences("akash_hub_voice_prefs", Context.MODE_PRIVATE)

    companion object {
        const val PREF_VOICE_ENABLED = "voice_greeting_enabled"
        const val GREETING_TEXT = "Aapko Dhanyawaad, Akash Internet Hub me visit karne ke liye!"
    }

    init {
        try {
            tts = TextToSpeech(context.applicationContext, this)
        } catch (e: Exception) {
            Log.e("VoiceGreetingHelper", "TTS init error", e)
        }
    }

    override fun onInit(status: Int) {
        if (status == TextToSpeech.SUCCESS) {
            isInitialized = true
            // Prefer Hindi or Indian English locale for natural phrasing
            val result = tts?.setLanguage(Locale("hi", "IN"))
            if (result == TextToSpeech.LANG_MISSING_DATA || result == TextToSpeech.LANG_NOT_SUPPORTED) {
                tts?.setLanguage(Locale("en", "IN"))
            }
            // Configure deep/rough male voice characteristics (Adam rough style)
            tts?.setPitch(0.75f) // Deeper/rougher pitch
            tts?.setSpeechRate(0.90f) // Deliberate and clear pace
        }
    }

    fun isVoiceEnabled(): Boolean {
        return prefs.getBoolean(PREF_VOICE_ENABLED, true)
    }

    fun setVoiceEnabled(enabled: Boolean) {
        prefs.edit().putBoolean(PREF_VOICE_ENABLED, enabled).apply()
        if (!enabled) {
            stop()
        }
    }

    fun playGreeting(force: Boolean = false) {
        if (!force && !isVoiceEnabled()) return

        if (isInitialized && tts != null) {
            try {
                tts?.stop()
                tts?.speak(GREETING_TEXT, TextToSpeech.QUEUE_FLUSH, null, "akash_hub_welcome_id")
            } catch (e: Exception) {
                Log.e("VoiceGreetingHelper", "TTS speak error", e)
            }
        }
    }

    fun stop() {
        try {
            tts?.stop()
        } catch (e: Exception) {
            // ignore
        }
    }

    fun shutdown() {
        try {
            tts?.stop()
            tts?.shutdown()
        } catch (e: Exception) {
            // ignore
        }
    }
}
