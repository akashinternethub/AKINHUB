package com.example.utils

import android.content.Context
import android.content.Intent
import android.os.Bundle
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.speech.tts.TextToSpeech
import android.speech.tts.UtteranceProgressListener
import android.util.Log
import com.example.BuildConfig
import com.example.data.localization.AppLanguage
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONArray
import org.json.JSONObject
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.concurrent.TimeUnit

data class ChatMessage(
    val id: String = java.util.UUID.randomUUID().toString(),
    val isUser: Boolean,
    val message: String,
    val timestamp: String = SimpleDateFormat("hh:mm a", Locale.getDefault()).format(Date()),
    val detectedLanguage: String = "Auto"
)

data class VoiceAssistantState(
    val isListening: Boolean = false,
    val isSpeaking: Boolean = false,
    val isLoading: Boolean = false,
    val speechError: String? = null,
    val messages: List<ChatMessage> = emptyList(),
    val selectedLanguage: AppLanguage = AppLanguage.HINGLISH,
    val isTtsEnabled: Boolean = true
)

class GeminiVoiceAssistantHelper(
    private val context: Context,
    private val coroutineScope: CoroutineScope
) : TextToSpeech.OnInitListener {

    private val _state = MutableStateFlow(VoiceAssistantState())
    val state: StateFlow<VoiceAssistantState> = _state.asStateFlow()

    private var speechRecognizer: SpeechRecognizer? = null
    private var tts: TextToSpeech? = null
    private var isTtsReady = false

    private val okHttpClient = OkHttpClient.Builder()
        .connectTimeout(30, TimeUnit.SECONDS)
        .readTimeout(30, TimeUnit.SECONDS)
        .writeTimeout(30, TimeUnit.SECONDS)
        .build()

    init {
        initTTS()
        initDefaultWelcomeMessage()
    }

    private fun initTTS() {
        try {
            tts = TextToSpeech(context.applicationContext, this)
        } catch (e: Exception) {
            Log.e("GeminiVoiceAssistant", "TTS initialization failed", e)
        }
    }

    private fun initDefaultWelcomeMessage() {
        _state.update {
            it.copy(
                messages = listOf(
                    ChatMessage(
                        isUser = false,
                        message = "👋 Namaste! Welcome to Akash Internet Hub Voice Assistant. " +
                                "Aap mujhse Hindi, English, Bengali (বাংলা), Hinglish ya Assamese (অসমীয়া) me kuch bhi puch sakte hain! Tap the Mic to speak."
                    )
                )
            )
        }
    }

    override fun onInit(status: Int) {
        if (status == TextToSpeech.SUCCESS) {
            isTtsReady = true
            setTTSLocaleForLanguage(_state.value.selectedLanguage)
            tts?.setPitch(0.85f)
            tts?.setSpeechRate(0.95f)

            tts?.setOnUtteranceProgressListener(object : UtteranceProgressListener() {
                override fun onStart(utteranceId: String?) {
                    _state.update { it.copy(isSpeaking = true) }
                }

                override fun onDone(utteranceId: String?) {
                    _state.update { it.copy(isSpeaking = false) }
                }

                override fun onError(utteranceId: String?) {
                    _state.update { it.copy(isSpeaking = false) }
                }
            })
        }
    }

    fun setSelectedLanguage(language: AppLanguage) {
        _state.update { it.copy(selectedLanguage = language) }
        setTTSLocaleForLanguage(language)
    }

    fun toggleTts(enabled: Boolean) {
        _state.update { it.copy(isTtsEnabled = enabled) }
        if (!enabled) {
            stopSpeaking()
        }
    }

    private fun setTTSLocaleForLanguage(language: AppLanguage) {
        if (!isTtsReady || tts == null) return
        val targetLocale = when (language) {
            AppLanguage.HINDI -> Locale("hi", "IN")
            AppLanguage.BENGALI -> Locale("bn", "IN")
            AppLanguage.ASSAMESE -> Locale("as", "IN")
            AppLanguage.ENGLISH -> Locale.ENGLISH
            AppLanguage.HINGLISH -> Locale("hi", "IN")
        }
        val result = tts?.setLanguage(targetLocale)
        if (result == TextToSpeech.LANG_MISSING_DATA || result == TextToSpeech.LANG_NOT_SUPPORTED) {
            // Fallback to Hindi or Indian English
            val hiResult = tts?.setLanguage(Locale("hi", "IN"))
            if (hiResult == TextToSpeech.LANG_MISSING_DATA || hiResult == TextToSpeech.LANG_NOT_SUPPORTED) {
                tts?.setLanguage(Locale("en", "IN"))
            }
        }
    }

    fun startListening() {
        stopSpeaking()
        _state.update { it.copy(isListening = true, speechError = null) }

        coroutineScope.launch(Dispatchers.Main) {
            try {
                if (speechRecognizer == null) {
                    speechRecognizer = SpeechRecognizer.createSpeechRecognizer(context)
                }

                val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
                    putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
                    putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, true)
                    putExtra(RecognizerIntent.EXTRA_MAX_RESULTS, 3)

                    // Target language hint based on selected language
                    when (_state.value.selectedLanguage) {
                        AppLanguage.HINDI -> putExtra(RecognizerIntent.EXTRA_LANGUAGE, "hi-IN")
                        AppLanguage.BENGALI -> putExtra(RecognizerIntent.EXTRA_LANGUAGE, "bn-IN")
                        AppLanguage.ASSAMESE -> putExtra(RecognizerIntent.EXTRA_LANGUAGE, "as-IN")
                        AppLanguage.ENGLISH -> putExtra(RecognizerIntent.EXTRA_LANGUAGE, "en-IN")
                        AppLanguage.HINGLISH -> {
                            putExtra(RecognizerIntent.EXTRA_LANGUAGE, "hi-IN")
                            putExtra(RecognizerIntent.EXTRA_SUPPORTED_LANGUAGES, arrayListOf("hi-IN", "en-IN", "as-IN", "bn-IN"))
                        }
                    }
                    putExtra(RecognizerIntent.EXTRA_PROMPT, "Boliyye / Speak now (Hindi, English, Bengali, Assamese)...")
                }

                speechRecognizer?.setRecognitionListener(object : RecognitionListener {
                    override fun onReadyForSpeech(params: Bundle?) {}
                    override fun onBeginningOfSpeech() {}
                    override fun onRmsChanged(rmsdB: Float) {}
                    override fun onBufferReceived(buffer: ByteArray?) {}
                    override fun onEndOfSpeech() {
                        _state.update { it.copy(isListening = false) }
                    }

                    override fun onError(error: Int) {
                        val errorMsg = when (error) {
                            SpeechRecognizer.ERROR_NO_MATCH -> "No speech detected. Please try again."
                            SpeechRecognizer.ERROR_SPEECH_TIMEOUT -> "Speech timed out. Please tap mic again."
                            SpeechRecognizer.ERROR_AUDIO -> "Audio recording error."
                            SpeechRecognizer.ERROR_NETWORK -> "Network issue. Using fast offline assistant."
                            else -> "Mic error ($error). Please try again."
                        }
                        _state.update { it.copy(isListening = false, speechError = errorMsg) }
                    }

                    override fun onResults(results: Bundle?) {
                        val matches = results?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)
                        val spokenText = matches?.firstOrNull()
                        _state.update { it.copy(isListening = false) }

                        if (!spokenText.isNullOrBlank()) {
                            sendMessage(spokenText)
                        }
                    }

                    override fun onPartialResults(partialResults: Bundle?) {}
                    override fun onEvent(eventType: Int, params: Bundle?) {}
                })

                speechRecognizer?.startListening(intent)
            } catch (e: Exception) {
                Log.e("GeminiVoiceAssistant", "Error starting speech recognition", e)
                _state.update {
                    it.copy(
                        isListening = false,
                        speechError = "Microphone error: ${e.localizedMessage ?: "Please type your question."}"
                    )
                }
            }
        }
    }

    fun stopListening() {
        try {
            speechRecognizer?.stopListening()
        } catch (e: Exception) {
            // ignore
        }
        _state.update { it.copy(isListening = false) }
    }

    fun sendMessage(userText: String) {
        if (userText.isBlank()) return

        stopSpeaking()
        val userMsg = ChatMessage(isUser = true, message = userText)
        _state.update {
            it.copy(
                messages = it.messages + userMsg,
                isLoading = true,
                speechError = null
            )
        }

        coroutineScope.launch {
            val responseText = generateGeminiResponse(userText, _state.value.messages)
            val assistantMsg = ChatMessage(isUser = false, message = responseText)

            _state.update {
                it.copy(
                    messages = it.messages + assistantMsg,
                    isLoading = false
                )
            }

            // Speak out response if TTS is enabled
            if (_state.value.isTtsEnabled) {
                speakText(responseText)
            }
        }
    }

    fun speakText(text: String) {
        if (!isTtsReady || tts == null) return
        try {
            tts?.stop()
            // Clean markdown asterisks or code ticks for smooth speech
            val cleanTextForSpeech = text
                .replace("*", "")
                .replace("#", "")
                .replace("`", "")
                .replace("₹", "Rupees ")
                .replace("+91 7002134700", "7002134700")

            tts?.speak(cleanTextForSpeech, TextToSpeech.QUEUE_FLUSH, null, "gemini_voice_response_${System.currentTimeMillis()}")
        } catch (e: Exception) {
            Log.e("GeminiVoiceAssistant", "TTS error", e)
        }
    }

    fun stopSpeaking() {
        try {
            tts?.stop()
        } catch (e: Exception) {
            // ignore
        }
        _state.update { it.copy(isSpeaking = false) }
    }

    fun clearChat() {
        stopSpeaking()
        stopListening()
        initDefaultWelcomeMessage()
    }

    private suspend fun generateGeminiResponse(prompt: String, conversationHistory: List<ChatMessage>): String = withContext(Dispatchers.IO) {
        val apiKey = BuildConfig.GEMINI_API_KEY
        val systemInstruction = """
            You are the official Smart Multilingual AI Voice & Chat Assistant for 'Akash Internet Hub' (CSC & Cyber Center in Geramari Part-II, Dhubri, Assam - 783339).
            Owner: Akash. Contact & WhatsApp: +91 7002134700.
            
            KEY CAPABILITIES & INFORMATION:
            1. Multilingual: You fluently understand and reply in Hindi, English, Bengali (বাংলা), Hinglish, or Assamese (অসমীয়া).
            2. Match Language: ALWAYS reply in the exact same language or dialect that the user used. If user speaks Assamese, reply in clean Assamese. If user speaks Bengali, reply in Bengali. If user speaks Hindi/Hinglish, reply in Hindi/Hinglish.
            3. Instant Direct Answers: Keep answers crisp, warm, helpful, and under 3-4 sentences so it is pleasant to listen via voice.
            4. Hub Services & Pricing:
               - New PAN Card: Form 49A, Govt ₹107 + Center ₹93 = Total ₹200 (Physical + e-PAN, 3-7 days).
               - Voter ID Card: Front & Back vertical A4 side-by-side format print & lamination (₹100).
               - Aadhaar Smart PVC: Original UIDAI Govt Wala speed post delivery (₹150).
               - ADRE & Assam Govt Jobs: Form fillup, doc resize, admit card print (₹150 center fee).
               - APDCL Electricity Bills: Instant online receipt (₹10 center fee).
               - Orunodoi 3.0, Ration Card, SEWA SETU PRC & Caste Certificates.
               - Print & Xerox: High speed black & white, color, photo, PVC cards.
            5. Center Address: Near Saba Petrol Pump, Geramari Part-II, P.O. Geramari, Dist: Dhubri, Assam.
            6. Working Hours: 08:00 AM - 09:30 PM (All 7 Days Open).
        """.trimIndent()

        // Fast offline rule-based knowledge engine fallback
        val offlineAnswer = getFastKnowledgeAnswer(prompt)

        if (apiKey.isBlank() || apiKey == "MY_GEMINI_API_KEY") {
            return@withContext offlineAnswer
        }

        try {
            val url = "https://generativelanguage.googleapis.com/v1beta/models/gemini-2.5-flash:generateContent?key=$apiKey"

            val contentsArray = JSONArray()

            // System prompt
            val systemPart = JSONObject().put("text", systemInstruction)
            val systemContent = JSONObject()
                .put("role", "user")
                .put("parts", JSONArray().put(systemPart))
            contentsArray.put(systemContent)

            val modelAck = JSONObject()
                .put("role", "model")
                .put("parts", JSONArray().put(JSONObject().put("text", "Understood! I will act as the official multilingual AI assistant for Akash Internet Hub.")))
            contentsArray.put(modelAck)

            // Add last 4 turns of history
            val recentHistory = conversationHistory.takeLast(4)
            for (msg in recentHistory) {
                val part = JSONObject().put("text", msg.message)
                val turn = JSONObject()
                    .put("role", if (msg.isUser) "user" else "model")
                    .put("parts", JSONArray().put(part))
                contentsArray.put(turn)
            }

            // Current prompt
            val currentTurn = JSONObject()
                .put("role", "user")
                .put("parts", JSONArray().put(JSONObject().put("text", prompt)))
            contentsArray.put(currentTurn)

            val requestBodyJson = JSONObject()
                .put("contents", contentsArray)

            val request = Request.Builder()
                .url(url)
                .post(requestBodyJson.toString().toRequestBody("application/json".toMediaType()))
                .build()

            val response = okHttpClient.newCall(request).execute()
            if (response.isSuccessful) {
                val responseBodyStr = response.body?.string()
                if (!responseBodyStr.isNullOrBlank()) {
                    val root = JSONObject(responseBodyStr)
                    val text = root.optJSONArray("candidates")
                        ?.optJSONObject(0)
                        ?.optJSONObject("content")
                        ?.optJSONArray("parts")
                        ?.optJSONObject(0)
                        ?.optString("text")

                    if (!text.isNullOrBlank()) {
                        return@withContext text.trim()
                    }
                }
            }
            return@withContext offlineAnswer
        } catch (e: Exception) {
            Log.e("GeminiVoiceAssistant", "Gemini API call failed, using local engine", e)
            return@withContext offlineAnswer
        }
    }

    private fun getFastKnowledgeAnswer(query: String): String {
        val q = query.lowercase(Locale.getDefault())

        return when {
            // PAN Card
            q.contains("pan") -> {
                if (q.contains("দাম") || q.contains("টকা") || q.contains("খরচ") || q.contains("কত")) {
                    "নমস্কাৰ! আকাশ ইন্টাৰনেট হাবত নতুন PAN Card (Form 49A)ৰ মুঠ ফি ₹200 (Govt Fee ₹107 + হাব চাৰ্জ ₹93)। 3-7 দিনৰ ভিতৰত ই-পেন আৰু ঘৰলৈ অৰিজিনেল কাৰ্ড আহি যাব।"
                } else if (q.contains("টাকা") || q.contains("খরচ") || q.contains("কত টাকা")) {
                    "নমস্কার! আকাশ ইন্টারনেট হাবে নতুন প্যান কার্ড (PAN Card Form 49A) এর মোট খরচ ₹200। আধার কার্ড ও ২ কপি পাসপোর্ট ফটো নিয়ে চলে আসুন।"
                } else {
                    "Akash Internet Hub me New PAN Card apply karne ka total charge ₹200 hai (Govt Fee ₹107 + Center Charge ₹93). Documents: Aadhaar Card, 2 Photo & Mobile for OTP. 3-7 days me ready ho jata hai!"
                }
            }
            // Voter Card
            q.contains("voter") || q.contains("epic") || q.contains("ভোটার") -> {
                if (q.contains("অসম") || q.contains("বৰ্তমান") || q.contains("প্ৰিণ্ট")) {
                    "আকাশ ইন্টাৰনেট হাবত ভোটাৰ কাৰ্ড (e-EPIC) অসমৰ নতুন vertical A4 ফৰ্মাটত হাই-কোৱালিটি কালৰ প্ৰিণ্ট আৰু লেমিনেশন উপলব্ধ! মূল্য মাত্ৰ ₹100।"
                } else if (q.contains("প্রিন্ট") || q.contains("লেমিনেশন")) {
                    "আকাশ ইন্টারনেট হাবে ভোটার আইডি কার্ড নতুন ভার্টিক্যাল A4 ফরম্যাটে ফ্রন্ট ও ব্যাক সাইড প্রিন্ট এবং লেমিনেশন করা হয় মাত্র ₹100 এ।"
                } else {
                    "Voter ID card ka official e-EPIC Vertical A4 layout Front & Back Side-by-Side HD Color Print & High-Micron Lamination sirf ₹100 me milta hai!"
                }
            }
            // ADRE or Govt Jobs
            q.contains("adre") || q.contains("job") || q.contains("চাকৰি") || q.contains("চাকরি") || q.contains("recruitment") -> {
                if (q.contains("চাকৰি") || q.contains("অসম")) {
                    "ADRE 2026 গ্ৰেড ৩ আৰু ৪ তথা অসম আৰক্ষীৰ ফৰ্ম ফিল-আপ আকাশ ইন্টাৰনেট হাবত 100% নিৰ্ভুলভাৱে কৰা হয়। অনলাইন ফৰ্ম চাৰ্জ ₹150।"
                } else {
                    "ADRE Grade III & IV, Assam Police, Railway aur sabhi Govt Job form fill-up Akash Internet Hub me error-free submit hota hai with photo/sign resize. Center charge: ₹150."
                }
            }
            // Aadhaar PVC
            q.contains("aadhaar") || q.contains("pvc") || q.contains("আধাৰ") || q.contains("আধার") -> {
                "UIDAI Original Waterproof Hologram Aadhaar PVC Smart Card Akash Internet Hub se order kar sakte hain. Total fee ₹150. Speed post se ghar pe deliver hoga!"
            }
            // Electricity Bill (APDCL)
            q.contains("apdcl") || q.contains("bijli") || q.contains("bill") || q.contains("বিদ্যুৎ") || q.contains("কাৰেন্ট") -> {
                "APDCL Prepaid Smart Meter recharge aur Postpaid electricity bill payment instant computerized receipt ke saath hota hai. Hub service charge sirf ₹10 hai."
            }
            // Location / Address
            q.contains("kaha") || q.contains("address") || q.contains("location") || q.contains("কোথায়") || q.contains("ক'ত") || q.contains("ঠিকনা") -> {
                "📍 Akash Internet Hub Address: Near Saba Petrol Pump, Geramari Part-II, P.O. Geramari, Dist: Dhubri, Assam - 783339. Contact/WhatsApp: +91 7002134700."
            }
            // Timing / Hours
            q.contains("time") || q.contains("open") || q.contains("kab") || q.contains("খোলা") || q.contains("সময়") -> {
                "🕒 Akash Internet Hub is Open 7 Days a week from 08:00 AM to 09:30 PM."
            }
            // Phone / Contact / WhatsApp
            q.contains("phone") || q.contains("number") || q.contains("contact") || q.contains("whatsapp") || q.contains("নম্বৰ") -> {
                "📞 Akash Internet Hub Direct Contact & WhatsApp Number: +91 7002134700 (Akash)."
            }
            // Greetings
            q.contains("hi") || q.contains("hello") || q.contains("namaste") || q.contains("নমস্কাৰ") || q.contains("নমস্কার") -> {
                "Namaste! Welcome to Akash Internet Hub! Main aapki PAN, Voter ID, ADRE Jobs, Electricity bill ya online CSC services me kya madad kar sakta hu?"
            }
            else -> {
                "Akash Internet Hub (Geramari, Dhubri) me sabhi Online CSC, Govt Jobs, PAN, Voter Card print, PVC smart cards, aur Xerox services uplabdh hain. Call/WhatsApp karein: +91 7002134700."
            }
        }
    }

    fun shutdown() {
        try {
            speechRecognizer?.destroy()
            speechRecognizer = null
            tts?.stop()
            tts?.shutdown()
            tts = null
        } catch (e: Exception) {
            // ignore
        }
    }
}
