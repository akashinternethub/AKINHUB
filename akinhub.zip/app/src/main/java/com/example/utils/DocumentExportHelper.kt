package com.example.utils

import android.content.Context
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Matrix
import android.graphics.Paint
import android.graphics.Rect
import android.graphics.RectF
import android.graphics.Typeface
import android.graphics.pdf.PdfDocument
import android.net.Uri
import android.os.Environment
import android.widget.Toast
import androidx.core.content.FileProvider
import android.media.ExifInterface
import java.io.File
import java.io.FileOutputStream
import kotlinx.coroutines.delay

object DocumentExportHelper {

    const val UNIVERSAL_FOOTER = "Printed from Akash Internet Hub • Near Saba Petrol Pump, Geramari, Dhubri • Contact: 7002134700"

    /**
     * Draw the mandatory universal footer across all generated A4 documents
     */
    private fun drawUniversalFooter(canvas: Canvas, pageWidth: Int, pageHeight: Int) {
        val footerPaint = Paint().apply {
            color = Color.parseColor("#475569")
            textSize = 8.5f
            typeface = Typeface.create(Typeface.DEFAULT, Typeface.NORMAL)
            isAntiAlias = true
            textAlign = Paint.Align.CENTER
        }
        canvas.drawText(UNIVERSAL_FOOTER, (pageWidth / 2f), (pageHeight - 20f), footerPaint)
    }

    private fun rotateBitmap(bitmap: Bitmap, degrees: Float): Bitmap {
        val matrix = Matrix().apply { postRotate(degrees) }
        return Bitmap.createBitmap(bitmap, 0, 0, bitmap.width, bitmap.height, matrix, true)
    }

    /**
     * Helper to safely load, orientation-correct and scale Bitmap from Uri
     */
    fun loadBitmapFromUri(context: Context, uri: Uri?, targetWidth: Int = 400, targetHeight: Int = 500): Bitmap? {
        if (uri == null) return null
        return try {
            val bytes = context.contentResolver.openInputStream(uri)?.use { it.readBytes() } ?: return null
            val boundsOptions = android.graphics.BitmapFactory.Options().apply { inJustDecodeBounds = true }
            android.graphics.BitmapFactory.decodeByteArray(bytes, 0, bytes.size, boundsOptions)

            var inSampleSize = 1
            if (boundsOptions.outHeight > targetHeight || boundsOptions.outWidth > targetWidth) {
                val halfHeight = boundsOptions.outHeight / 2
                val halfWidth = boundsOptions.outWidth / 2
                while ((halfHeight / inSampleSize) >= targetHeight && (halfWidth / inSampleSize) >= targetWidth) {
                    inSampleSize *= 2
                }
            }

            val decodeOptions = android.graphics.BitmapFactory.Options().apply {
                this.inSampleSize = inSampleSize
                inPreferredConfig = Bitmap.Config.ARGB_8888
            }
            val decoded = android.graphics.BitmapFactory.decodeByteArray(bytes, 0, bytes.size, decodeOptions) ?: return null

            val rotated = try {
                val exif = ExifInterface(bytes.inputStream())
                val orientation = exif.getAttributeInt(ExifInterface.TAG_ORIENTATION, ExifInterface.ORIENTATION_NORMAL)
                when (orientation) {
                    ExifInterface.ORIENTATION_ROTATE_90 -> rotateBitmap(decoded, 90f)
                    ExifInterface.ORIENTATION_ROTATE_180 -> rotateBitmap(decoded, 180f)
                    ExifInterface.ORIENTATION_ROTATE_270 -> rotateBitmap(decoded, 270f)
                    else -> decoded
                }
            } catch (_: Exception) {
                decoded
            }

            Bitmap.createScaledBitmap(rotated, targetWidth, targetHeight, true)
        } catch (e: Exception) {
            e.printStackTrace()
            null
        }
    }

    /**
     * Generate and save Resume / CV PDF with candidate photo
     */
    suspend fun generateAndSaveResumePdf(
        context: Context,
        fullName: String,
        jobRole: String,
        phone: String,
        email: String,
        address: String,
        careerObjective: String,
        educationDegree: String,
        educationHs: String,
        educationHslc: String,
        technicalSkills: String,
        experienceText: String,
        languagesKnown: String,
        photoUri: Uri? = null,
        isWatermarked: Boolean,
        watermarkText: String = "Downloaded From Akash Internet Hub",
        onProgressUpdate: (String) -> Unit
    ): File? {
        onProgressUpdate("Preparing Vector Resume Layout...")
        delay(300)

        val pageWidth = 595 // A4 standard pt at 72dpi
        val pageHeight = 842
        val document = PdfDocument()
        val pageInfo = PdfDocument.PageInfo.Builder(pageWidth, pageHeight, 1).create()
        val page = document.startPage(pageInfo)
        val canvas = page.canvas

        onProgressUpdate("Rendering Professional Typography & Styles...")
        delay(300)

        // Background
        val bgPaint = Paint().apply { color = Color.WHITE }
        canvas.drawRect(0f, 0f, pageWidth.toFloat(), pageHeight.toFloat(), bgPaint)

        // Header Background Banner
        val headerPaint = Paint().apply { color = Color.parseColor("#0F2B48") } // Navy
        canvas.drawRect(0f, 0f, pageWidth.toFloat(), 110f, headerPaint)

        // Header Accent Gold Strip
        val goldPaint = Paint().apply { color = Color.parseColor("#F59E0B") }
        canvas.drawRect(0f, 110f, pageWidth.toFloat(), 115f, goldPaint)

        // Draw Candidate Photo (Top-Right of Header)
        val photoWidth = 72f
        val photoHeight = 86f
        val photoLeft = (pageWidth - 30f - photoWidth)
        val photoTop = 12f
        val photoRight = photoLeft + photoWidth
        val photoBottom = photoTop + photoHeight
        val photoDstRect = RectF(photoLeft, photoTop, photoRight, photoBottom)

        val candidateBitmap = loadBitmapFromUri(context, photoUri, 200, 240)
        if (candidateBitmap != null) {
            val srcRect = Rect(0, 0, candidateBitmap.width, candidateBitmap.height)
            canvas.drawBitmap(candidateBitmap, srcRect, photoDstRect, Paint().apply { isFilterBitmap = true })
            val borderPaint = Paint().apply {
                color = Color.WHITE
                style = Paint.Style.STROKE
                strokeWidth = 2f
            }
            canvas.drawRect(photoDstRect, borderPaint)
        } else {
            val boxPaint = Paint().apply {
                color = Color.parseColor("#1E3A5F")
                style = Paint.Style.FILL
            }
            val borderPaint = Paint().apply {
                color = Color.parseColor("#F59E0B")
                style = Paint.Style.STROKE
                strokeWidth = 1f
            }
            canvas.drawRect(photoDstRect, boxPaint)
            canvas.drawRect(photoDstRect, borderPaint)

            val txtPaint = Paint().apply {
                color = Color.parseColor("#F59E0B")
                textSize = 7.5f
                typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
                textAlign = Paint.Align.CENTER
                isAntiAlias = true
            }
            canvas.drawText("PASSPORT", photoLeft + photoWidth / 2, photoTop + photoHeight / 2 - 2f, txtPaint)
            canvas.drawText("PHOTO", photoLeft + photoWidth / 2, photoTop + photoHeight / 2 + 8f, txtPaint)
        }

        // Name & Role Text
        val titlePaint = Paint().apply {
            color = Color.WHITE
            textSize = 21f
            typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
            isAntiAlias = true
        }
        canvas.drawText(fullName.ifBlank { "Akash Internet Hub" }, 30f, 42f, titlePaint)

        val rolePaint = Paint().apply {
            color = Color.parseColor("#F59E0B")
            textSize = 12f
            typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
            isAntiAlias = true
        }
        canvas.drawText(jobRole.ifBlank { "Computer Operator & Online Services Associate" }, 30f, 64f, rolePaint)

        val contactPaint = Paint().apply {
            color = Color.parseColor("#E0F2FE")
            textSize = 9f
            isAntiAlias = true
        }
        val contactLine = "📞 $phone   |   ✉️ $email"
        canvas.drawText(contactLine, 30f, 84f, contactPaint)
        canvas.drawText("📍 $address", 30f, 98f, contactPaint)

        var currentY = 140f

        // Helper to draw section header
        fun drawSection(title: String) {
            val secTitlePaint = Paint().apply {
                color = Color.parseColor("#0F2B48")
                textSize = 13f
                typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
                isAntiAlias = true
            }
            canvas.drawText(title.uppercase(), 30f, currentY, secTitlePaint)

            val linePaint = Paint().apply {
                color = Color.parseColor("#CBD5E1")
                strokeWidth = 1.5f
            }
            canvas.drawLine(30f, currentY + 4f, (pageWidth - 30).toFloat(), currentY + 4f, linePaint)
            currentY += 20f
        }

        // Helper to draw body text with line wrap
        fun drawParagraph(text: String, indent: Float = 30f, isBold: Boolean = false, textSize: Float = 9.5f) {
            val pPaint = Paint().apply {
                color = Color.parseColor("#334155")
                this.textSize = textSize
                typeface = if (isBold) Typeface.create(Typeface.DEFAULT, Typeface.BOLD) else Typeface.DEFAULT
                isAntiAlias = true
            }
            val maxLineWidth = (pageWidth - 60).toFloat()
            val words = text.split(" ")
            var currentLine = ""
            for (word in words) {
                val testLine = if (currentLine.isEmpty()) word else "$currentLine $word"
                if (pPaint.measureText(testLine) < maxLineWidth) {
                    currentLine = testLine
                } else {
                    canvas.drawText(currentLine, indent, currentY, pPaint)
                    currentY += 14f
                    currentLine = word
                }
            }
            if (currentLine.isNotEmpty()) {
                canvas.drawText(currentLine, indent, currentY, pPaint)
                currentY += 14f
            }
            currentY += 6f
        }

        // 1. Career Objective
        drawSection("Career Objective")
        drawParagraph(careerObjective)

        // 2. Education
        drawSection("Educational Qualifications")
        drawParagraph("• $educationDegree", isBold = true)
        drawParagraph("• $educationHs")
        drawParagraph("• $educationHslc")

        // 3. Technical Skills
        drawSection("Technical Skills & Computer Proficiency")
        drawParagraph(technicalSkills)

        // 4. Work Experience
        drawSection("Work Experience & Practical Knowledge")
        drawParagraph(experienceText)

        // 5. Personal Details & Languages
        drawSection("Personal Details")
        drawParagraph("• Languages Known: $languagesKnown")
        drawParagraph("• Permanent Address: $address")
        drawParagraph("• Declaration: I hereby declare that all the information mentioned above is true and correct to the best of my knowledge.")

        // Watermark if requested
        if (isWatermarked) {
            onProgressUpdate("Applying Center Watermark...")
            val wmPaint = Paint().apply {
                color = Color.parseColor("#22000000")
                this.textSize = 28f
                typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
                isAntiAlias = true
            }
            canvas.save()
            canvas.rotate(-35f, (pageWidth / 2).toFloat(), (pageHeight / 2).toFloat())
            val text = watermarkText
            val textWidth = wmPaint.measureText(text)
            canvas.drawText(text, (pageWidth / 2 - textWidth / 2), (pageHeight / 2).toFloat(), wmPaint)
            canvas.restore()
        }

        // Mandatory Universal Footer
        drawUniversalFooter(canvas, pageWidth, pageHeight)

        document.finishPage(page)

        onProgressUpdate("Writing PDF Document to Storage...")
        delay(300)

        val cleanName = fullName.replace(" ", "_").replace(Regex("[^a-zA-Z0-9_]"), "")
        val suffix = if (isWatermarked) "_Free_Watermark" else "_Pro_HD"
        val fileName = "Resume_${cleanName.ifBlank { "Akash_Hub" }}$suffix.pdf"

        return savePdfDocument(context, document, fileName)
    }

    /**
     * Generate and save Marriage Bio Data PDF with optional candidate photo
     */
    suspend fun generateAndSaveBioDataPdf(
        context: Context,
        fullName: String,
        dob: String,
        birthTime: String,
        birthPlace: String,
        height: String,
        complexion: String,
        religionCaste: String,
        gotraRashi: String,
        qualification: String,
        occupation: String,
        annualIncome: String,
        fatherName: String,
        motherName: String,
        siblings: String,
        permanentAddress: String,
        contactNumber: String,
        photoUri: Uri? = null,
        isWatermarked: Boolean,
        watermarkText: String = "Downloaded From Akash Internet Hub",
        onProgressUpdate: (String) -> Unit
    ): File? {
        onProgressUpdate("Preparing Marriage Bio Data Template...")
        delay(300)

        val pageWidth = 595
        val pageHeight = 842
        val document = PdfDocument()
        val pageInfo = PdfDocument.PageInfo.Builder(pageWidth, pageHeight, 1).create()
        val page = document.startPage(pageInfo)
        val canvas = page.canvas

        onProgressUpdate("Rendering Decorative Borders & Details...")
        delay(300)

        // Background Warm Ivory
        val bgPaint = Paint().apply { color = Color.parseColor("#FFFDF8") }
        canvas.drawRect(0f, 0f, pageWidth.toFloat(), pageHeight.toFloat(), bgPaint)

        // Ornamental Maroon Outer Border
        val borderPaint = Paint().apply {
            color = Color.parseColor("#991B1B") // Rich Maroon
            style = Paint.Style.STROKE
            strokeWidth = 3f
        }
        canvas.drawRect(20f, 20f, (pageWidth - 20).toFloat(), (pageHeight - 20).toFloat(), borderPaint)

        // Inner Gold Border
        val goldBorderPaint = Paint().apply {
            color = Color.parseColor("#D97706") // Rich Gold
            style = Paint.Style.STROKE
            strokeWidth = 1.2f
        }
        canvas.drawRect(25f, 25f, (pageWidth - 25).toFloat(), (pageHeight - 25).toFloat(), goldBorderPaint)

        // Draw Candidate Photo with Golden Frame (Top-Right)
        val photoWidth = 80f
        val photoHeight = 96f
        val photoLeft = (pageWidth - 38f - photoWidth)
        val photoTop = 38f
        val photoRight = photoLeft + photoWidth
        val photoBottom = photoTop + photoHeight
        val photoDstRect = RectF(photoLeft, photoTop, photoRight, photoBottom)

        val candidateBitmap = loadBitmapFromUri(context, photoUri, 220, 260)
        if (candidateBitmap != null) {
            val srcRect = Rect(0, 0, candidateBitmap.width, candidateBitmap.height)
            canvas.drawBitmap(candidateBitmap, srcRect, photoDstRect, Paint().apply { isFilterBitmap = true })
        } else {
            val bgBoxPaint = Paint().apply { color = Color.parseColor("#FEF3C7") }
            canvas.drawRect(photoDstRect, bgBoxPaint)
            val textPaint = Paint().apply {
                color = Color.parseColor("#B45309")
                textSize = 7.5f
                typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
                textAlign = Paint.Align.CENTER
                isAntiAlias = true
            }
            canvas.drawText("CANDIDATE", photoLeft + photoWidth / 2, photoTop + photoHeight / 2 - 2f, textPaint)
            canvas.drawText("PHOTO", photoLeft + photoWidth / 2, photoTop + photoHeight / 2 + 8f, textPaint)
        }

        // Golden photo frame stroke
        val frameStrokePaint = Paint().apply {
            color = Color.parseColor("#D97706")
            style = Paint.Style.STROKE
            strokeWidth = 2f
        }
        canvas.drawRect(photoDstRect, frameStrokePaint)

        // Clean Header (English Standard - Centered in Left/Middle Area)
        val headerCenterX = (photoLeft / 2) + 15f
        val headerSubPaint = Paint().apply {
            color = Color.parseColor("#991B1B")
            textSize = 10.5f
            typeface = Typeface.create(Typeface.SERIF, Typeface.BOLD)
            isAntiAlias = true
            textAlign = Paint.Align.CENTER
            letterSpacing = 0.12f
        }
        canvas.drawText("✦ CURRICULUM VITAE ✦", headerCenterX, 56f, headerSubPaint)

        val titlePaint = Paint().apply {
            color = Color.parseColor("#B45309")
            textSize = 20f
            typeface = Typeface.create(Typeface.SERIF, Typeface.BOLD)
            isAntiAlias = true
            textAlign = Paint.Align.CENTER
            letterSpacing = 0.08f
        }
        canvas.drawText("MARRIAGE BIODATA", headerCenterX, 84f, titlePaint)

        val tagPaint = Paint().apply {
            color = Color.parseColor("#78350F")
            textSize = 8.5f
            typeface = Typeface.create(Typeface.DEFAULT, Typeface.NORMAL)
            isAntiAlias = true
            textAlign = Paint.Align.CENTER
        }
        canvas.drawText("Complete Profile & Astrological Information", headerCenterX, 104f, tagPaint)

        var currentY = 148f

        fun drawCategoryHeader(title: String) {
            val catBgPaint = Paint().apply { color = Color.parseColor("#FEF3C7") }
            canvas.drawRoundRect(35f, currentY - 14f, (pageWidth - 35).toFloat(), currentY + 6f, 6f, 6f, catBgPaint)

            val catTextPaint = Paint().apply {
                color = Color.parseColor("#92400E")
                textSize = 11f
                typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
                isAntiAlias = true
            }
            canvas.drawText("✦ $title", 45f, currentY, catTextPaint)
            currentY += 20f
        }

        fun drawField(label: String, value: String) {
            val lblPaint = Paint().apply {
                color = Color.parseColor("#78350F")
                textSize = 9.5f
                typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
                isAntiAlias = true
            }
            val valPaint = Paint().apply {
                color = Color.parseColor("#1E293B")
                textSize = 9.5f
                isAntiAlias = true
            }
            canvas.drawText("$label :", 45f, currentY, lblPaint)
            canvas.drawText(value, 180f, currentY, valPaint)
            currentY += 16f
        }

        // 1. Personal
        drawCategoryHeader("PERSONAL DETAILS")
        drawField("Full Name", fullName.ifBlank { "Akash Internet Hub" })
        drawField("Date of Birth", dob)
        drawField("Time & Place", "$birthTime • $birthPlace")
        drawField("Height & Complexion", "$height • $complexion")
        drawField("Religion / Caste", religionCaste)
        drawField("Gotra / Rashi", gotraRashi)

        currentY += 6f
        // 2. Education & Career
        drawCategoryHeader("EDUCATION & OCCUPATION")
        drawField("Highest Degree", qualification)
        drawField("Current Occupation", occupation)
        drawField("Annual Income", annualIncome)

        currentY += 6f
        // 3. Family Details
        drawCategoryHeader("FAMILY BACKGROUND")
        drawField("Father's Name", fatherName)
        drawField("Mother's Name", motherName)
        drawField("Siblings Details", siblings)
        drawField("Native Address", permanentAddress)

        currentY += 6f
        // 4. Contact
        drawCategoryHeader("CONTACT INFORMATION")
        drawField("Mobile Number", contactNumber)
        drawField("Alternate / WhatsApp", "+91 7002134700")

        // Watermark if free
        if (isWatermarked) {
            onProgressUpdate("Applying Watermark Stamp...")
            val wmPaint = Paint().apply {
                color = Color.parseColor("#22991B1B")
                this.textSize = 26f
                typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
                isAntiAlias = true
            }
            canvas.save()
            canvas.rotate(-35f, (pageWidth / 2).toFloat(), (pageHeight / 2).toFloat())
            val text = watermarkText
            val textWidth = wmPaint.measureText(text)
            canvas.drawText(text, (pageWidth / 2 - textWidth / 2), (pageHeight / 2).toFloat(), wmPaint)
            canvas.restore()
        }

        // Universal Footer
        drawUniversalFooter(canvas, pageWidth, pageHeight)

        document.finishPage(page)

        onProgressUpdate("Writing Marriage Bio Data to Storage...")
        delay(300)

        val cleanName = fullName.replace(" ", "_").replace(Regex("[^a-zA-Z0-9_]"), "")
        val suffix = if (isWatermarked) "_Free_Watermark" else "_Pro_HD"
        val fileName = "Marriage_BioData_${cleanName.ifBlank { "Akash_Hub" }}$suffix.pdf"

        return savePdfDocument(context, document, fileName)
    }

    /**
     * Generate and save Simple Professional Bio Data PDF for Job / Employment
     */
    suspend fun generateAndSaveSimpleJobBioDataPdf(
        context: Context,
        fullName: String,
        fatherName: String,
        motherName: String,
        dob: String,
        gender: String,
        maritalStatus: String,
        nationality: String,
        religionCategory: String,
        contactNumber: String,
        emailAddress: String,
        presentAddress: String,
        permanentAddress: String,
        careerObjective: String,
        qualification: String,
        technicalSkills: String,
        workExperience: String,
        languagesKnown: String,
        photoUri: Uri? = null,
        isWatermarked: Boolean,
        watermarkText: String = "Downloaded From Akash Internet Hub",
        onProgressUpdate: (String) -> Unit
    ): File? {
        onProgressUpdate("Preparing Job Bio Data Template...")
        delay(300)

        val pageWidth = 595
        val pageHeight = 842
        val document = PdfDocument()
        val pageInfo = PdfDocument.PageInfo.Builder(pageWidth, pageHeight, 1).create()
        val page = document.startPage(pageInfo)
        val canvas = page.canvas

        onProgressUpdate("Rendering Clean Formal Layout...")
        delay(300)

        // Background Clean White
        val bgPaint = Paint().apply { color = Color.WHITE }
        canvas.drawRect(0f, 0f, pageWidth.toFloat(), pageHeight.toFloat(), bgPaint)

        // Outer Clean Border (Navy / Charcoal)
        val borderPaint = Paint().apply {
            color = Color.parseColor("#1E3A8A")
            style = Paint.Style.STROKE
            strokeWidth = 2f
        }
        canvas.drawRect(24f, 24f, (pageWidth - 24).toFloat(), (pageHeight - 24).toFloat(), borderPaint)

        // Header Title Box
        val headerBoxPaint = Paint().apply { color = Color.parseColor("#1E3A8A") }
        canvas.drawRect(24f, 24f, (pageWidth - 24).toFloat(), 64f, headerBoxPaint)

        val headerTextPaint = Paint().apply {
            color = Color.WHITE
            textSize = 16f
            typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
            isAntiAlias = true
            textAlign = Paint.Align.CENTER
            letterSpacing = 0.1f
        }
        canvas.drawText("BIO-DATA FOR EMPLOYMENT", (pageWidth / 2).toFloat(), 48f, headerTextPaint)

        // Candidate Photo (Top-Right)
        val photoWidth = 75f
        val photoHeight = 90f
        val photoLeft = (pageWidth - 36f - photoWidth)
        val photoTop = 74f
        val photoRight = photoLeft + photoWidth
        val photoBottom = photoTop + photoHeight
        val photoDstRect = RectF(photoLeft, photoTop, photoRight, photoBottom)

        val candidateBitmap = loadBitmapFromUri(context, photoUri, 200, 240)
        if (candidateBitmap != null) {
            val srcRect = Rect(0, 0, candidateBitmap.width, candidateBitmap.height)
            canvas.drawBitmap(candidateBitmap, srcRect, photoDstRect, Paint().apply { isFilterBitmap = true })
            val photoBorderPaint = Paint().apply {
                color = Color.parseColor("#1E3A8A")
                style = Paint.Style.STROKE
                strokeWidth = 1.5f
            }
            canvas.drawRect(photoDstRect, photoBorderPaint)
        } else {
            val bgBoxPaint = Paint().apply { color = Color.parseColor("#F1F5F9") }
            canvas.drawRect(photoDstRect, bgBoxPaint)
            val textPaint = Paint().apply {
                color = Color.parseColor("#64748B")
                textSize = 7.5f
                typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
                textAlign = Paint.Align.CENTER
                isAntiAlias = true
            }
            canvas.drawText("AFFIX", photoLeft + photoWidth / 2, photoTop + photoHeight / 2 - 2f, textPaint)
            canvas.drawText("PHOTO", photoLeft + photoWidth / 2, photoTop + photoHeight / 2 + 8f, textPaint)
            val photoBorderPaint = Paint().apply {
                color = Color.parseColor("#94A3B8")
                style = Paint.Style.STROKE
                strokeWidth = 1f
            }
            canvas.drawRect(photoDstRect, photoBorderPaint)
        }

        var currentY = 82f

        fun drawSectionHeader(title: String) {
            val barPaint = Paint().apply { color = Color.parseColor("#E0E7FF") }
            canvas.drawRect(34f, currentY - 12f, (pageWidth - 34).toFloat(), currentY + 4f, barPaint)

            val textPaint = Paint().apply {
                color = Color.parseColor("#1E3A8A")
                textSize = 10.5f
                typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
                isAntiAlias = true
            }
            canvas.drawText(title, 40f, currentY, textPaint)
            currentY += 18f
        }

        fun drawFieldLine(label: String, value: String) {
            val lblPaint = Paint().apply {
                color = Color.parseColor("#334155")
                textSize = 9.5f
                typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
                isAntiAlias = true
            }
            val valPaint = Paint().apply {
                color = Color.parseColor("#0F172A")
                textSize = 9.5f
                isAntiAlias = true
            }
            canvas.drawText("$label :", 40f, currentY, lblPaint)
            canvas.drawText(value, 175f, currentY, valPaint)
            currentY += 15.5f
        }

        // Section 1: Personal Details
        drawSectionHeader("1. PERSONAL DETAILS")
        drawFieldLine("Name of Candidate", fullName.ifBlank { "Akash Internet Hub" })
        drawFieldLine("Father's Name", fatherName)
        drawFieldLine("Mother's Name", motherName)
        drawFieldLine("Date of Birth", dob)
        drawFieldLine("Gender / Marital Status", "$gender / $maritalStatus")
        drawFieldLine("Nationality / Category", "$nationality / $religionCategory")

        currentY += 4f
        // Section 2: Contact Details
        drawSectionHeader("2. CONTACT & ADDRESS")
        drawFieldLine("Mobile Number", contactNumber)
        drawFieldLine("Email Address", emailAddress)
        drawFieldLine("Present Address", presentAddress)
        drawFieldLine("Permanent Address", permanentAddress)

        currentY += 4f
        // Section 3: Career Objective
        drawSectionHeader("3. CAREER OBJECTIVE")
        val objPaint = Paint().apply {
            color = Color.parseColor("#334155")
            textSize = 9f
            isAntiAlias = true
        }
        val objLines = if (careerObjective.length > 70) {
            val mid = careerObjective.indexOf(" ", 60).let { if (it == -1) 60 else it }
            listOf(careerObjective.substring(0, mid), careerObjective.substring(mid).trim())
        } else {
            listOf(careerObjective)
        }
        objLines.forEach { l ->
            canvas.drawText(l, 40f, currentY, objPaint)
            currentY += 13f
        }

        currentY += 4f
        // Section 4: Educational Qualifications
        drawSectionHeader("4. ACADEMIC QUALIFICATION")
        drawFieldLine("Educational Degree", qualification)

        currentY += 4f
        // Section 5: Technical Skills & Experience
        drawSectionHeader("5. TECHNICAL SKILLS & EXPERIENCE")
        drawFieldLine("Technical / Computer Skills", technicalSkills)
        drawFieldLine("Working Experience", workExperience)
        drawFieldLine("Languages Known", languagesKnown)

        currentY += 6f
        // Section 6: Declaration
        drawSectionHeader("6. DECLARATION")
        val decPaint = Paint().apply {
            color = Color.parseColor("#475569")
            textSize = 8.5f
            isAntiAlias = true
        }
        canvas.drawText("I hereby declare that all the information furnished above is true and correct to the best of my knowledge.", 40f, currentY, decPaint)
        currentY += 30f

        // Date & Signature
        val signPaint = Paint().apply {
            color = Color.parseColor("#1E293B")
            textSize = 9f
            typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
            isAntiAlias = true
        }
        canvas.drawText("Date: ___/___/2026", 40f, currentY, signPaint)
        canvas.drawText("Place: Dhubri, Assam", 40f, currentY + 14f, signPaint)

        canvas.drawText("(Signature of Candidate)", (pageWidth - 180).toFloat(), currentY + 14f, signPaint)

        // Watermark if free
        if (isWatermarked) {
            onProgressUpdate("Applying Watermark Stamp...")
            val wmPaint = Paint().apply {
                color = Color.parseColor("#221E3A8A")
                this.textSize = 26f
                typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
                isAntiAlias = true
            }
            canvas.save()
            canvas.rotate(-35f, (pageWidth / 2).toFloat(), (pageHeight / 2).toFloat())
            val text = watermarkText
            val textWidth = wmPaint.measureText(text)
            canvas.drawText(text, (pageWidth / 2 - textWidth / 2), (pageHeight / 2).toFloat(), wmPaint)
            canvas.restore()
        }

        // Universal Footer
        drawUniversalFooter(canvas, pageWidth, pageHeight)

        document.finishPage(page)

        onProgressUpdate("Writing Job Bio Data to Storage...")
        delay(300)

        val cleanName = fullName.replace(" ", "_").replace(Regex("[^a-zA-Z0-9_]"), "")
        val suffix = if (isWatermarked) "_Free_Watermark" else "_Pro_HD"
        val fileName = "Job_BioData_${cleanName.ifBlank { "Akash_Hub" }}$suffix.pdf"

        return savePdfDocument(context, document, fileName)
    }

    /**
     * Generate and save Passport Photos on A4 Print Sheet or Single Passport HD
     * Fixes: No top headers, accurately draws real loaded bitmap on all copies, applies universal footer.
     */
    suspend fun generateAndSavePassportA4Pdf(
        context: Context,
        photoUri: Uri? = null,
        directBitmap: Bitmap? = null,
        copies: Int = 8,
        suitName: String = "No Suit",
        suitColorHex: String? = null,
        lapelColorHex: String? = null,
        shirtColorHex: String? = null,
        tieColorHex: String? = null,
        hasTie: Boolean = false,
        bgColorHex: String = "#90CAF9",
        isA4Mode: Boolean = true,
        strokeColorHex: String = "#000000",
        strokeWidthPx: Float = 2f,
        isWatermarked: Boolean,
        watermarkText: String = "Downloaded From Akash Internet Hub",
        onProgressUpdate: (String) -> Unit
    ): File? {
        onProgressUpdate("Preparing 300 DPI Passport Studio Canvas...")
        delay(250)

        val pageWidth = 595 // A4 standard pt
        val pageHeight = 842
        val document = PdfDocument()
        val pageInfo = PdfDocument.PageInfo.Builder(pageWidth, pageHeight, 1).create()
        val page = document.startPage(pageInfo)
        val canvas = page.canvas

        // Background Clean White A4 Paper
        val bgPaint = Paint().apply { color = Color.WHITE }
        canvas.drawRect(0f, 0f, pageWidth.toFloat(), pageHeight.toFloat(), bgPaint)

        onProgressUpdate("Processing Photo & Studio Lighting...")
        delay(250)

        // Load Bitmap accurately (or use direct passed bitmap)
        val userBitmap = directBitmap ?: loadBitmapFromUri(context, photoUri, 350, 450)

        val parsedBgColor = try { Color.parseColor(bgColorHex) } catch (_: Exception) { Color.parseColor("#90CAF9") }
        val parsedStrokeColor = try { Color.parseColor(strokeColorHex) } catch (_: Exception) { Color.BLACK }

        fun drawSinglePassportItem(destRect: RectF) {
            // 1. Draw passport slot background color
            val slotBgPaint = Paint().apply {
                color = parsedBgColor
                style = Paint.Style.FILL
            }
            canvas.drawRect(destRect, slotBgPaint)

            // 2. Draw Photo accurately
            if (userBitmap != null) {
                val srcRect = Rect(0, 0, userBitmap.width, userBitmap.height)
                val photoPaint = Paint().apply {
                    isFilterBitmap = true
                    isDither = true
                }
                canvas.drawBitmap(userBitmap, srcRect, destRect, photoPaint)
            } else {
                // Stylized silhouette avatar if no photo uploaded
                val avatarPaint = Paint().apply {
                    color = Color.parseColor("#1E3A5F")
                    style = Paint.Style.FILL
                    isAntiAlias = true
                }
                val centerX = destRect.centerX()
                val centerY = destRect.centerY()
                // Head circle
                canvas.drawCircle(centerX, centerY - destRect.height() * 0.12f, destRect.width() * 0.22f, avatarPaint)
                // Shoulders
                val shoulderRect = RectF(
                    destRect.left + destRect.width() * 0.15f,
                    centerY + destRect.height() * 0.05f,
                    destRect.right - destRect.width() * 0.15f,
                    destRect.bottom
                )
                canvas.drawRoundRect(shoulderRect, 14f, 14f, avatarPaint)
            }

            // 3. Draw Suit Overlay if not "No Suit"
            if (suitName != "No Suit" && suitColorHex != null) {
                val suitPaint = Paint().apply {
                    color = try { Color.parseColor(suitColorHex) } catch (_: Exception) { Color.parseColor("#1E3A8A") }
                    style = Paint.Style.FILL
                    isAntiAlias = true
                }
                val suitHeight = destRect.height() * 0.32f
                val suitRect = RectF(
                    destRect.left + destRect.width() * 0.04f,
                    destRect.bottom - suitHeight,
                    destRect.right - destRect.width() * 0.04f,
                    destRect.bottom
                )
                canvas.drawRoundRect(suitRect, 10f, 10f, suitPaint)

                // Shirt Collar
                if (shirtColorHex != null) {
                    val shirtPaint = Paint().apply {
                        color = try { Color.parseColor(shirtColorHex) } catch (_: Exception) { Color.WHITE }
                        style = Paint.Style.FILL
                        isAntiAlias = true
                    }
                    val collarWidth = destRect.width() * 0.28f
                    val collarHeight = destRect.height() * 0.18f
                    val collarRect = RectF(
                        destRect.centerX() - collarWidth / 2,
                        destRect.bottom - suitHeight,
                        destRect.centerX() + collarWidth / 2,
                        destRect.bottom - suitHeight + collarHeight
                    )
                    canvas.drawRoundRect(collarRect, 6f, 6f, shirtPaint)
                }

                // Tie
                if (hasTie && tieColorHex != null) {
                    val tiePaint = Paint().apply {
                        color = try { Color.parseColor(tieColorHex) } catch (_: Exception) { Color.parseColor("#DC2626") }
                        style = Paint.Style.FILL
                        isAntiAlias = true
                    }
                    val tieWidth = destRect.width() * 0.08f
                    val tieHeight = destRect.height() * 0.16f
                    val tieRect = RectF(
                        destRect.centerX() - tieWidth / 2,
                        destRect.bottom - suitHeight + 2f,
                        destRect.centerX() + tieWidth / 2,
                        destRect.bottom - suitHeight + tieHeight
                    )
                    canvas.drawRoundRect(tieRect, 4f, 4f, tiePaint)
                }
            }

            // 4. Draw Border / Stroke
            if (strokeColorHex != "transparent" && strokeWidthPx > 0f) {
                val borderPaint = Paint().apply {
                    color = parsedStrokeColor
                    style = Paint.Style.STROKE
                    strokeWidth = strokeWidthPx
                }
                canvas.drawRect(destRect, borderPaint)
            }
        }

        if (isA4Mode) {
            onProgressUpdate("Arranging $copies Copies on A4 Paper Sheet...")
            delay(250)

            // NO TOP HEADER - direct clean grid layout on paper
            val cols = when {
                copies <= 4 -> 2
                copies <= 8 -> 2
                copies <= 16 -> 4
                copies <= 24 -> 4
                copies <= 32 -> 4
                else -> 6
            }
            val rows = (copies + cols - 1) / cols

            val marginX = 35f
            val startY = 40f
            val availableW = pageWidth - (marginX * 2)
            val gapX = 14f
            val gapY = 14f
            val slotW = (availableW - ((cols - 1) * gapX)) / cols
            val slotH = slotW * (4.5f / 3.5f)

            // Scissor guideline paint
            val cutLinePaint = Paint().apply {
                color = Color.parseColor("#CBD5E1")
                style = Paint.Style.STROKE
                strokeWidth = 0.8f
            }

            var count = 0
            for (r in 0 until rows) {
                for (c in 0 until cols) {
                    if (count >= copies) break
                    val left = marginX + c * (slotW + gapX)
                    val top = startY + r * (slotH + gapY)
                    val right = left + slotW
                    val bottom = top + slotH
                    val rect = RectF(left, top, right, bottom)

                    // Draw cutting corner tick marks
                    canvas.drawLine(left - 4f, top, left + slotW + 4f, top, cutLinePaint)
                    canvas.drawLine(left, top - 4f, left, top + slotH + 4f, cutLinePaint)

                    drawSinglePassportItem(rect)
                    count++
                }
            }
        } else {
            // Single High-Definition Passport Photo
            onProgressUpdate("Generating Single HD Passport Card...")
            delay(250)

            // NO TOP HEADER - Center large passport photo
            val cardW = 280f
            val cardH = cardW * (4.5f / 3.5f)
            val cardLeft = (pageWidth - cardW) / 2f
            val cardTop = 140f
            val cardRect = RectF(cardLeft, cardTop, cardLeft + cardW, cardTop + cardH)

            drawSinglePassportItem(cardRect)

            // Specifications text below photo
            val specPaint = Paint().apply {
                color = Color.parseColor("#334155")
                textSize = 11f
                typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
                textAlign = Paint.Align.CENTER
                isAntiAlias = true
            }
            canvas.drawText("PASSPORT SIZE: 35mm × 45mm (300 DPI)", (pageWidth / 2).toFloat(), cardTop + cardH + 36f, specPaint)
        }

        // Watermark if free
        if (isWatermarked) {
            onProgressUpdate("Applying Center Watermark...")
            val wmPaint = Paint().apply {
                color = Color.parseColor("#25000000")
                this.textSize = 26f
                typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
                isAntiAlias = true
            }
            canvas.save()
            canvas.rotate(-35f, (pageWidth / 2).toFloat(), (pageHeight / 2).toFloat())
            val text = watermarkText
            val textWidth = wmPaint.measureText(text)
            canvas.drawText(text, (pageWidth / 2 - textWidth / 2), (pageHeight / 2).toFloat(), wmPaint)
            canvas.restore()
        }

        // Universal Footer
        drawUniversalFooter(canvas, pageWidth, pageHeight)

        document.finishPage(page)

        onProgressUpdate("Writing Passport File to Storage...")
        delay(250)

        val modeTag = if (isA4Mode) "A4Sheet_${copies}Copies" else "SingleHD"
        val suffix = if (isWatermarked) "_Free_Watermark" else "_Clean_HD"
        val fileName = "PassportPhoto_${modeTag}$suffix.pdf"

        return savePdfDocument(context, document, fileName)
    }

    /**
     * Generate and save AI Background Removal Output Image/PDF (No top headers)
     */
    suspend fun generateAndSaveCutoutImagePdf(
        context: Context,
        photoUri: Uri? = null,
        directBitmap: Bitmap? = null,
        bgColorHex: String = "#90CAF9",
        isWatermarked: Boolean,
        watermarkText: String = "Downloaded From Akash Internet Hub",
        onProgressUpdate: (String) -> Unit
    ): File? {
        onProgressUpdate("Processing AI Background Removal Export...")
        delay(300)

        val pageWidth = 595
        val pageHeight = 842
        val document = PdfDocument()
        val pageInfo = PdfDocument.PageInfo.Builder(pageWidth, pageHeight, 1).create()
        val page = document.startPage(pageInfo)
        val canvas = page.canvas

        // Background
        val bgPaint = Paint().apply { color = Color.WHITE }
        canvas.drawRect(0f, 0f, pageWidth.toFloat(), pageHeight.toFloat(), bgPaint)

        onProgressUpdate("Rendering Clean Cutout on Studio Canvas...")
        delay(250)

        // NO TOP HEADER - Center card directly
        val cardW = 340f
        val cardH = 440f
        val cardLeft = (pageWidth - cardW) / 2f
        val cardTop = 100f
        val cardRect = RectF(cardLeft, cardTop, cardLeft + cardW, cardTop + cardH)

        val studioColor = try { Color.parseColor(bgColorHex) } catch (_: Exception) { Color.parseColor("#90CAF9") }
        val studioPaint = Paint().apply {
            color = studioColor
            style = Paint.Style.FILL
        }
        canvas.drawRoundRect(cardRect, 12f, 12f, studioPaint)

        val photoBitmap = directBitmap ?: loadBitmapFromUri(context, photoUri, 400, 500)
        if (photoBitmap != null) {
            val srcRect = Rect(0, 0, photoBitmap.width, photoBitmap.height)
            canvas.drawBitmap(photoBitmap, srcRect, cardRect, Paint().apply { isFilterBitmap = true })
        } else {
            val avatarPaint = Paint().apply {
                color = Color.parseColor("#1E3A5F")
                style = Paint.Style.FILL
                isAntiAlias = true
            }
            canvas.drawCircle(cardRect.centerX(), cardRect.centerY() - 40f, 70f, avatarPaint)
            val bodyRect = RectF(cardRect.left + 50f, cardRect.centerY() + 20f, cardRect.right - 50f, cardRect.bottom)
            canvas.drawRoundRect(bodyRect, 20f, 20f, avatarPaint)
        }

        // Stroke Border
        val borderPaint = Paint().apply {
            color = Color.parseColor("#1E293B")
            style = Paint.Style.STROKE
            strokeWidth = 2f
        }
        canvas.drawRoundRect(cardRect, 12f, 12f, borderPaint)

        // Watermark if free
        if (isWatermarked) {
            onProgressUpdate("Applying Center Watermark...")
            val wmPaint = Paint().apply {
                color = Color.parseColor("#25000000")
                this.textSize = 26f
                typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
                isAntiAlias = true
            }
            canvas.save()
            canvas.rotate(-35f, (pageWidth / 2).toFloat(), (pageHeight / 2).toFloat())
            val text = watermarkText
            val textWidth = wmPaint.measureText(text)
            canvas.drawText(text, (pageWidth / 2 - textWidth / 2), (pageHeight / 2).toFloat(), wmPaint)
            canvas.restore()
        }

        // Universal Footer
        drawUniversalFooter(canvas, pageWidth, pageHeight)

        document.finishPage(page)

        onProgressUpdate("Saving Background Cutout File...")
        delay(250)

        val suffix = if (isWatermarked) "_Free_Watermark" else "_Clean_HD"
        val fileName = "Ai_Background_Cutout$suffix.pdf"

        return savePdfDocument(context, document, fileName)
    }

    /**
     * Generate and save Cropped Photo by Marker & Size (No top headers)
     */
    suspend fun generateAndSaveCroppedPhotoPdf(
        context: Context,
        photoUri: Uri? = null,
        directBitmap: Bitmap? = null,
        widthValue: String = "3.5",
        heightValue: String = "4.5",
        unit: String = "cm",
        dpi: String = "300",
        isWatermarked: Boolean,
        watermarkText: String = "Downloaded From Akash Internet Hub",
        onProgressUpdate: (String) -> Unit
    ): File? {
        onProgressUpdate("Cropping Photo by Exact Marker & Dimension...")
        delay(300)

        val pageWidth = 595
        val pageHeight = 842
        val document = PdfDocument()
        val pageInfo = PdfDocument.PageInfo.Builder(pageWidth, pageHeight, 1).create()
        val page = document.startPage(pageInfo)
        val canvas = page.canvas

        // Background
        val bgPaint = Paint().apply { color = Color.WHITE }
        canvas.drawRect(0f, 0f, pageWidth.toFloat(), pageHeight.toFloat(), bgPaint)

        // NO TOP HEADER - Center card directly
        val cardW = 320f
        val wNum = widthValue.toFloatOrNull() ?: 3.5f
        val hNum = heightValue.toFloatOrNull() ?: 4.5f
        val cardH = (cardW * (hNum / wNum.coerceAtLeast(0.1f))).coerceIn(150f, 480f)
        val cardLeft = (pageWidth - cardW) / 2f
        val cardTop = 110f
        val cardRect = RectF(cardLeft, cardTop, cardLeft + cardW, cardTop + cardH)

        val photoBitmap = directBitmap ?: loadBitmapFromUri(context, photoUri, 400, 500)
        if (photoBitmap != null) {
            val srcRect = Rect(0, 0, photoBitmap.width, photoBitmap.height)
            canvas.drawBitmap(photoBitmap, srcRect, cardRect, Paint().apply { isFilterBitmap = true })
        } else {
            val bgSlot = Paint().apply {
                color = Color.parseColor("#F1F5F9")
                style = Paint.Style.FILL
            }
            canvas.drawRect(cardRect, bgSlot)
            val avPaint = Paint().apply {
                color = Color.parseColor("#1E3A5F")
                style = Paint.Style.FILL
                isAntiAlias = true
            }
            canvas.drawCircle(cardRect.centerX(), cardRect.centerY() - 30f, 50f, avPaint)
            val bodyRect = RectF(cardRect.left + 40f, cardRect.centerY() + 15f, cardRect.right - 40f, cardRect.bottom)
            canvas.drawRoundRect(bodyRect, 16f, 16f, avPaint)
        }

        // Red Cutting Line
        val cutPaint = Paint().apply {
            color = Color.parseColor("#DC2626")
            style = Paint.Style.STROKE
            strokeWidth = 1.5f
        }
        canvas.drawRect(cardRect, cutPaint)

        // Dimension spec
        val specPaint = Paint().apply {
            color = Color.parseColor("#475569")
            textSize = 10.5f
            typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
            textAlign = Paint.Align.CENTER
            isAntiAlias = true
        }
        canvas.drawText("Dimension: $widthValue × $heightValue $unit ($dpi DPI)", (pageWidth / 2).toFloat(), cardTop + cardH + 34f, specPaint)

        // Watermark if free
        if (isWatermarked) {
            onProgressUpdate("Applying Watermark...")
            val wmPaint = Paint().apply {
                color = Color.parseColor("#25000000")
                this.textSize = 26f
                typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
                isAntiAlias = true
            }
            canvas.save()
            canvas.rotate(-35f, (pageWidth / 2).toFloat(), (pageHeight / 2).toFloat())
            val text = watermarkText
            val textWidth = wmPaint.measureText(text)
            canvas.drawText(text, (pageWidth / 2 - textWidth / 2), (pageHeight / 2).toFloat(), wmPaint)
            canvas.restore()
        }

        // Universal Footer
        drawUniversalFooter(canvas, pageWidth, pageHeight)

        document.finishPage(page)

        onProgressUpdate("Writing Cropped Photo File...")
        delay(250)

        val suffix = if (isWatermarked) "_Free_Watermark" else "_Clean_HD"
        val fileName = "Cropped_${widthValue}x${heightValue}${unit}$suffix.pdf"

        return savePdfDocument(context, document, fileName)
    }

    /**
     * Generate and save 1-Page Merged ID Card (Aadhaar horizontal / Voter ID vertical) PDF (No top headers)
     */
    suspend fun generateAndSaveIdCardMergedPdf(
        context: Context,
        frontPhotoUri: Uri?,
        backPhotoUri: Uri?,
        idCardType: String = "Aadhaar Card",
        isWatermarked: Boolean,
        watermarkText: String = "Downloaded From Akash Internet Hub",
        onProgressUpdate: (String) -> Unit
    ): File? {
        onProgressUpdate("Setting up A4 ID Card Print Sheet...")
        delay(300)

        val pageWidth = 595
        val pageHeight = 842
        val document = PdfDocument()
        val pageInfo = PdfDocument.PageInfo.Builder(pageWidth, pageHeight, 1).create()
        val page = document.startPage(pageInfo)
        val canvas = page.canvas

        // Background
        val bgPaint = Paint().apply { color = Color.WHITE }
        canvas.drawRect(0f, 0f, pageWidth.toFloat(), pageHeight.toFloat(), bgPaint)

        onProgressUpdate("Rendering Front & Back ID Card Artwork...")
        delay(250)

        // NO TOP HEADER - Directly arrange cards on clean A4 page
        val isVerticalLayout = (idCardType == "Voter ID Card")
        val frontBitmap = loadBitmapFromUri(context, frontPhotoUri, 600, 400)
        val backBitmap = loadBitmapFromUri(context, backPhotoUri, 600, 400)

        val cutBorderPaint = Paint().apply {
            color = Color.parseColor("#DC2626")
            style = Paint.Style.STROKE
            strokeWidth = 1.2f
        }
        val labelPaint = Paint().apply {
            color = Color.parseColor("#1E3A8A")
            textSize = 9f
            typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
            isAntiAlias = true
        }

        if (isVerticalLayout) {
            val cardW = 180f
            val cardH = 270f
            val left = (pageWidth - cardW) / 2f

            // Front Card
            val frontTop = 50f
            val frontRect = RectF(left, frontTop, left + cardW, frontTop + cardH)
            if (frontBitmap != null) {
                canvas.drawBitmap(frontBitmap, Rect(0, 0, frontBitmap.width, frontBitmap.height), frontRect, Paint().apply { isFilterBitmap = true })
            } else {
                val phPaint = Paint().apply { color = Color.parseColor("#F1F5F9") }
                canvas.drawRoundRect(frontRect, 6f, 6f, phPaint)
                canvas.drawText("FRONT SIDE (VOTER ID)", left + 20f, frontTop + cardH / 2, labelPaint)
            }
            canvas.drawRoundRect(frontRect, 6f, 6f, cutBorderPaint)
            canvas.drawText("✂️ Cut Along Red Line (FRONT)", left, frontTop - 5f, labelPaint)

            // Back Card
            val backTop = frontTop + cardH + 30f
            val backRect = RectF(left, backTop, left + cardW, backTop + cardH)
            if (backBitmap != null) {
                canvas.drawBitmap(backBitmap, Rect(0, 0, backBitmap.width, backBitmap.height), backRect, Paint().apply { isFilterBitmap = true })
            } else {
                val phPaint = Paint().apply { color = Color.parseColor("#F1F5F9") }
                canvas.drawRoundRect(backRect, 6f, 6f, phPaint)
                canvas.drawText("BACK SIDE (VOTER ID)", left + 20f, backTop + cardH / 2, labelPaint)
            }
            canvas.drawRoundRect(backRect, 6f, 6f, cutBorderPaint)
            canvas.drawText("✂️ Cut Along Red Line (BACK)", left, backTop - 5f, labelPaint)
        } else {
            // Horizontal layout (Aadhaar Card)
            val cardW = 240f
            val cardH = 152f

            // Front Card
            val frontLeft = 30f
            val frontTop = 60f
            val frontRect = RectF(frontLeft, frontTop, frontLeft + cardW, frontTop + cardH)
            if (frontBitmap != null) {
                canvas.drawBitmap(frontBitmap, Rect(0, 0, frontBitmap.width, frontBitmap.height), frontRect, Paint().apply { isFilterBitmap = true })
            } else {
                val phPaint = Paint().apply { color = Color.parseColor("#F1F5F9") }
                canvas.drawRoundRect(frontRect, 6f, 6f, phPaint)
                canvas.drawText("FRONT SIDE ($idCardType)", frontLeft + 20f, frontTop + cardH / 2, labelPaint)
            }
            canvas.drawRoundRect(frontRect, 6f, 6f, cutBorderPaint)
            canvas.drawText("✂️ Cut Along Red Line (FRONT)", frontLeft, frontTop - 5f, labelPaint)

            // Back Card (Side by Side)
            val backLeft = frontLeft + cardW + 25f
            val backRect = RectF(backLeft, frontTop, backLeft + cardW, frontTop + cardH)
            if (backBitmap != null) {
                canvas.drawBitmap(backBitmap, Rect(0, 0, backBitmap.width, backBitmap.height), backRect, Paint().apply { isFilterBitmap = true })
            } else {
                val phPaint = Paint().apply { color = Color.parseColor("#F1F5F9") }
                canvas.drawRoundRect(backRect, 6f, 6f, phPaint)
                canvas.drawText("BACK SIDE ($idCardType)", backLeft + 20f, frontTop + cardH / 2, labelPaint)
            }
            canvas.drawRoundRect(backRect, 6f, 6f, cutBorderPaint)
            canvas.drawText("✂️ Cut Along Red Line (BACK)", backLeft, frontTop - 5f, labelPaint)
        }

        if (isWatermarked) {
            onProgressUpdate("Applying Center Watermark...")
            val wmPaint = Paint().apply {
                color = Color.parseColor("#25000000")
                this.textSize = 26f
                typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
                isAntiAlias = true
            }
            canvas.save()
            canvas.rotate(-35f, (pageWidth / 2).toFloat(), (pageHeight / 2).toFloat())
            val text = watermarkText
            val textWidth = wmPaint.measureText(text)
            canvas.drawText(text, (pageWidth / 2 - textWidth / 2), (pageHeight / 2).toFloat(), wmPaint)
            canvas.restore()
        }

        // Universal Footer
        drawUniversalFooter(canvas, pageWidth, pageHeight)

        document.finishPage(page)

        onProgressUpdate("Saving to Device...")
        delay(250)

        val cleanTitle = idCardType.replace(" ", "_").replace(Regex("[^a-zA-Z0-9_]"), "")
        val suffix = if (isWatermarked) "_Free_Watermark" else "_Clean_HD"
        val fileName = "IDCard_${cleanTitle}_Merged$suffix.pdf"

        return savePdfDocument(context, document, fileName)
    }

    /**
     * Automated Converter: JPG to A4 PDF
     */
    suspend fun generateAndSaveJpgToPdf(
        context: Context,
        imageUri: Uri?,
        isWatermarked: Boolean,
        watermarkText: String = "Downloaded From Akash Internet Hub",
        onProgressUpdate: (String) -> Unit
    ): File? {
        onProgressUpdate("Converting Image to 300 DPI A4 PDF...")
        delay(300)

        val pageWidth = 595
        val pageHeight = 842
        val document = PdfDocument()
        val pageInfo = PdfDocument.PageInfo.Builder(pageWidth, pageHeight, 1).create()
        val page = document.startPage(pageInfo)
        val canvas = page.canvas

        // Background
        val bgPaint = Paint().apply { color = Color.WHITE }
        canvas.drawRect(0f, 0f, pageWidth.toFloat(), pageHeight.toFloat(), bgPaint)

        val imageBitmap = loadBitmapFromUri(context, imageUri, 550, 750)
        if (imageBitmap != null) {
            val margin = 30f
            val maxW = pageWidth - (margin * 2)
            val maxH = pageHeight - (margin * 2) - 40f // Leave space for footer

            val aspect = imageBitmap.width.toFloat() / imageBitmap.height.toFloat()
            var destW = maxW
            var destH = destW / aspect
            if (destH > maxH) {
                destH = maxH
                destW = destH * aspect
            }

            val left = (pageWidth - destW) / 2f
            val top = 30f + (maxH - destH) / 2f
            val destRect = RectF(left, top, left + destW, top + destH)
            val srcRect = Rect(0, 0, imageBitmap.width, imageBitmap.height)
            canvas.drawBitmap(imageBitmap, srcRect, destRect, Paint().apply { isFilterBitmap = true })
        } else {
            val placeholderPaint = Paint().apply {
                color = Color.parseColor("#64748B")
                textSize = 14f
                textAlign = Paint.Align.CENTER
                isAntiAlias = true
            }
            canvas.drawText("No Image Loaded", pageWidth / 2f, pageHeight / 2f, placeholderPaint)
        }

        // Watermark if free
        if (isWatermarked) {
            onProgressUpdate("Applying Center Watermark...")
            val wmPaint = Paint().apply {
                color = Color.parseColor("#25000000")
                this.textSize = 28f
                typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
                isAntiAlias = true
            }
            canvas.save()
            canvas.rotate(-35f, (pageWidth / 2).toFloat(), (pageHeight / 2).toFloat())
            val text = watermarkText
            val textWidth = wmPaint.measureText(text)
            canvas.drawText(text, (pageWidth / 2 - textWidth / 2), (pageHeight / 2).toFloat(), wmPaint)
            canvas.restore()
        }

        // Universal Footer
        drawUniversalFooter(canvas, pageWidth, pageHeight)

        document.finishPage(page)

        onProgressUpdate("Saving Converted A4 PDF...")
        delay(250)

        val suffix = if (isWatermarked) "_Free_Watermark" else "_HD"
        val fileName = "Converted_Document$suffix.pdf"

        return savePdfDocument(context, document, fileName)
    }

    /**
     * Automated Converter: TXT / Notice to formatted high-definition JPG Image
     */
    suspend fun generateAndSaveTxtToJpg(
        context: Context,
        text: String,
        title: String = "OFFICIAL NOTICE",
        isWatermarked: Boolean,
        watermarkText: String = "Downloaded From Akash Internet Hub",
        onProgressUpdate: (String) -> Unit
    ): File? {
        onProgressUpdate("Rendering High-Resolution Notice JPG...")
        delay(300)

        val width = 1200
        val height = 1600
        val bitmap = Bitmap.createBitmap(width, height, Bitmap.Config.ARGB_8888)
        val canvas = Canvas(bitmap)

        // Navy Blue Background
        canvas.drawColor(Color.parseColor("#0F172A"))

        // Border
        val borderPaint = Paint().apply {
            color = Color.parseColor("#F59E0B")
            style = Paint.Style.STROKE
            strokeWidth = 6f
        }
        canvas.drawRect(40f, 40f, width - 40f, height - 40f, borderPaint)

        // Header Title
        val titlePaint = Paint().apply {
            color = Color.parseColor("#F59E0B")
            textSize = 50f
            typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
            textAlign = Paint.Align.CENTER
            isAntiAlias = true
        }
        canvas.drawText(title, width / 2f, 150f, titlePaint)

        // Subtitle
        val subPaint = Paint().apply {
            color = Color.WHITE
            textSize = 30f
            textAlign = Paint.Align.CENTER
            isAntiAlias = true
        }
        canvas.drawText("AKASH INTERNET HUB • GERAMARI, DHUBRI", width / 2f, 210f, subPaint)

        val divPaint = Paint().apply {
            color = Color.parseColor("#334155")
            strokeWidth = 3f
        }
        canvas.drawLine(80f, 250f, width - 80f, 250f, divPaint)

        // Body Text wrapped
        val bodyPaint = Paint().apply {
            color = Color.parseColor("#F8FAFC")
            textSize = 34f
            isAntiAlias = true
        }
        val maxLineWidth = width - 160f
        var currentY = 320f
        val words = text.split(" ")
        var currentLine = ""
        for (word in words) {
            val testLine = if (currentLine.isEmpty()) word else "$currentLine $word"
            if (bodyPaint.measureText(testLine) < maxLineWidth) {
                currentLine = testLine
            } else {
                canvas.drawText(currentLine, 80f, currentY, bodyPaint)
                currentY += 50f
                currentLine = word
            }
        }
        if (currentLine.isNotEmpty()) {
            canvas.drawText(currentLine, 80f, currentY, bodyPaint)
        }

        // Watermark if free
        if (isWatermarked) {
            val wmPaint = Paint().apply {
                color = Color.parseColor("#33FFFFFF")
                textSize = 55f
                typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
                isAntiAlias = true
            }
            canvas.save()
            canvas.rotate(-35f, width / 2f, height / 2f)
            val wmWidth = wmPaint.measureText(watermarkText)
            canvas.drawText(watermarkText, width / 2f - wmWidth / 2f, height / 2f, wmPaint)
            canvas.restore()
        }

        // Universal Footer
        val footPaint = Paint().apply {
            color = Color.parseColor("#94A3B8")
            textSize = 24f
            textAlign = Paint.Align.CENTER
            isAntiAlias = true
        }
        canvas.drawText(UNIVERSAL_FOOTER, width / 2f, height - 80f, footPaint)

        return saveBitmapAsJpg(context, bitmap, "Notice_${System.currentTimeMillis()}.jpg")
    }

    /**
     * Save OCR extracted text as clean A4 PDF with universal footer
     */
    suspend fun generateAndSaveOcrResultPdf(
        context: Context,
        ocrText: String,
        isWatermarked: Boolean,
        watermarkText: String = "Downloaded From Akash Internet Hub",
        onProgressUpdate: (String) -> Unit
    ): File? {
        onProgressUpdate("Generating Vector OCR Text PDF...")
        delay(300)

        val pageWidth = 595
        val pageHeight = 842
        val document = PdfDocument()
        val pageInfo = PdfDocument.PageInfo.Builder(pageWidth, pageHeight, 1).create()
        val page = document.startPage(pageInfo)
        val canvas = page.canvas

        // Background
        val bgPaint = Paint().apply { color = Color.WHITE }
        canvas.drawRect(0f, 0f, pageWidth.toFloat(), pageHeight.toFloat(), bgPaint)

        // Body Text
        val textPaint = Paint().apply {
            color = Color.parseColor("#0F172A")
            textSize = 10.5f
            typeface = Typeface.create(Typeface.MONOSPACE, Typeface.NORMAL)
            isAntiAlias = true
        }

        val margin = 35f
        var currentY = 50f
        val maxLineWidth = pageWidth - (margin * 2)

        val paragraphs = ocrText.split("\n")
        for (para in paragraphs) {
            val words = para.split(" ")
            var currentLine = ""
            for (word in words) {
                val test = if (currentLine.isEmpty()) word else "$currentLine $word"
                if (textPaint.measureText(test) < maxLineWidth) {
                    currentLine = test
                } else {
                    canvas.drawText(currentLine, margin, currentY, textPaint)
                    currentY += 16f
                    currentLine = word
                }
            }
            if (currentLine.isNotEmpty()) {
                canvas.drawText(currentLine, margin, currentY, textPaint)
                currentY += 16f
            }
            currentY += 6f
        }

        // Watermark if free
        if (isWatermarked) {
            val wmPaint = Paint().apply {
                color = Color.parseColor("#25000000")
                textSize = 28f
                typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
                isAntiAlias = true
            }
            canvas.save()
            canvas.rotate(-35f, (pageWidth / 2).toFloat(), (pageHeight / 2).toFloat())
            val textWidth = wmPaint.measureText(watermarkText)
            canvas.drawText(watermarkText, (pageWidth / 2 - textWidth / 2), (pageHeight / 2).toFloat(), wmPaint)
            canvas.restore()
        }

        // Universal Footer
        drawUniversalFooter(canvas, pageWidth, pageHeight)

        document.finishPage(page)

        val suffix = if (isWatermarked) "_Free_Watermark" else "_HD"
        return savePdfDocument(context, document, "OCR_Extracted_Text$suffix.pdf")
    }

    /**
     * Save OCR text to a standard .txt file
     */
    fun saveOcrTextFile(context: Context, text: String): File? {
        return try {
            val targetDir = context.getExternalFilesDir(Environment.DIRECTORY_DOCUMENTS) ?: context.filesDir
            if (!targetDir.exists()) targetDir.mkdirs()
            val targetFile = File(targetDir, "Extracted_Text_${System.currentTimeMillis()}.txt")
            targetFile.writeText(text + "\n\n---\n" + UNIVERSAL_FOOTER)
            targetFile
        } catch (e: Exception) {
            e.printStackTrace()
            null
        }
    }

    /**
     * Save any Bitmap as a high resolution JPG image in Documents
     */
    fun saveBitmapAsJpg(context: Context, bitmap: Bitmap, fileName: String): File? {
        return try {
            val targetDir = context.getExternalFilesDir(Environment.DIRECTORY_PICTURES) ?: context.filesDir
            if (!targetDir.exists()) targetDir.mkdirs()
            val targetFile = File(targetDir, fileName)
            val out = FileOutputStream(targetFile)
            bitmap.compress(Bitmap.CompressFormat.JPEG, 95, out)
            out.flush()
            out.close()
            targetFile
        } catch (e: Exception) {
            e.printStackTrace()
            null
        }
    }

    /**
     * Generate and save generic Image or PDF Document (No top headers)
     */
    suspend fun generateAndSaveGenericToolPdf(
        context: Context,
        toolTitle: String,
        description: String,
        isWatermarked: Boolean,
        watermarkText: String = "Downloaded From Akash Internet Hub",
        onProgressUpdate: (String) -> Unit
    ): File? {
        onProgressUpdate("Generating High Definition Document...")
        delay(300)

        val pageWidth = 595
        val pageHeight = 842
        val document = PdfDocument()
        val pageInfo = PdfDocument.PageInfo.Builder(pageWidth, pageHeight, 1).create()
        val page = document.startPage(pageInfo)
        val canvas = page.canvas

        // Background
        val bgPaint = Paint().apply { color = Color.WHITE }
        canvas.drawRect(0f, 0f, pageWidth.toFloat(), pageHeight.toFloat(), bgPaint)

        // NO TOP HEADER - Center main content box cleanly
        val boxBorder = Paint().apply {
            color = Color.parseColor("#DC2626")
            style = Paint.Style.STROKE
            strokeWidth = 1.5f
        }
        canvas.drawRoundRect(30f, 80f, (pageWidth - 30).toFloat(), 480f, 8f, 8f, boxBorder)

        val labelPaint = Paint().apply {
            color = Color.parseColor("#1E293B")
            textSize = 12f
            typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
            isAntiAlias = true
            textAlign = Paint.Align.CENTER
        }
        canvas.drawText("READY FOR HIGH-PRECISION LASER PRINT / DIGITAL SUBMISSION", (pageWidth / 2).toFloat(), 260f, labelPaint)

        val descPaint = Paint().apply {
            color = Color.parseColor("#64748B")
            textSize = 10f
            isAntiAlias = true
            textAlign = Paint.Align.CENTER
        }
        canvas.drawText(description, (pageWidth / 2).toFloat(), 290f, descPaint)

        if (isWatermarked) {
            onProgressUpdate("Applying Center Watermark...")
            val wmPaint = Paint().apply {
                color = Color.parseColor("#25000000")
                this.textSize = 26f
                typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
                isAntiAlias = true
            }
            canvas.save()
            canvas.rotate(-35f, (pageWidth / 2).toFloat(), (pageHeight / 2).toFloat())
            val text = watermarkText
            val textWidth = wmPaint.measureText(text)
            canvas.drawText(text, (pageWidth / 2 - textWidth / 2), (pageHeight / 2).toFloat(), wmPaint)
            canvas.restore()
        }

        // Universal Footer
        drawUniversalFooter(canvas, pageWidth, pageHeight)

        document.finishPage(page)

        onProgressUpdate("Saving to Downloads...")
        delay(250)

        val cleanTitle = toolTitle.replace(" ", "_").replace(Regex("[^a-zA-Z0-9_]"), "")
        val suffix = if (isWatermarked) "_Free_Watermark" else "_Clean_HD"
        val fileName = "AkashHub_${cleanTitle}$suffix.pdf"

        return savePdfDocument(context, document, fileName)
    }

    private fun savePdfDocument(context: Context, document: PdfDocument, fileName: String): File? {
        return try {
            val targetDir = context.getExternalFilesDir(Environment.DIRECTORY_DOCUMENTS) ?: context.filesDir
            if (!targetDir.exists()) {
                targetDir.mkdirs()
            }
            val targetFile = File(targetDir, fileName)
            val outputStream = FileOutputStream(targetFile)
            document.writeTo(outputStream)
            document.close()
            outputStream.flush()
            outputStream.close()
            targetFile
        } catch (e: Exception) {
            e.printStackTrace()
            try {
                document.close()
            } catch (_: Exception) {}
            null
        }
    }

    /**
     * Open or Share the saved PDF file with external viewer / WhatsApp
     */
    fun openOrSharePdfFile(context: Context, file: File, title: String = "Open Document") {
        try {
            val uri: Uri = FileProvider.getUriForFile(
                context,
                "${context.packageName}.fileprovider",
                file
            )

            val viewIntent = Intent(Intent.ACTION_VIEW).apply {
                setDataAndType(uri, "application/pdf")
                addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            }

            val chooser = Intent.createChooser(viewIntent, title).apply {
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            }
            context.startActivity(chooser)
        } catch (e: Exception) {
            e.printStackTrace()
            Toast.makeText(
                context,
                "✅ File saved at: ${file.name}\n(Available in Documents)",
                Toast.LENGTH_LONG
            ).show()
        }
    }
}
