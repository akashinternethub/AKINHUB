package com.example.utils

import android.content.Context
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Rect
import android.graphics.RectF
import android.graphics.Typeface
import android.graphics.pdf.PdfDocument
import android.net.Uri
import android.os.Environment
import android.widget.Toast
import androidx.core.content.FileProvider
import java.io.File
import java.io.FileOutputStream
import kotlinx.coroutines.delay

object DocumentExportHelper {

    /**
     * Helper to safely load and scale Bitmap from Uri
     */
    private fun loadBitmapFromUri(context: Context, uri: Uri?, targetWidth: Int = 300, targetHeight: Int = 360): Bitmap? {
        if (uri == null) return null
        return try {
            val inputStream = context.contentResolver.openInputStream(uri)
            val original = android.graphics.BitmapFactory.decodeStream(inputStream)
            inputStream?.close()
            if (original != null) {
                Bitmap.createScaledBitmap(original, targetWidth, targetHeight, true)
            } else null
        } catch (e: Exception) {
            null
        }
    }

    /**
     * Generate and save Resume / CV PDF with optional candidate photo
     */
    suspend fun generateAndSaveResumePdf(
        context: Context,
        fullName: String,
        jobRole: String,
        phone: String,
        email: String,
        address: String,
        careerObjective: String,
        educationDegree: String,
        educationHs: String,
        educationHslc: String,
        technicalSkills: String,
        experienceText: String,
        languagesKnown: String,
        photoUri: Uri? = null,
        isWatermarked: Boolean,
        watermarkText: String = "Downloaded From Akash Internet Hub",
        onProgressUpdate: (String) -> Unit
    ): File? {
        onProgressUpdate("Preparing Vector Resume Layout...")
        delay(400)

        val pageWidth = 595 // A4 standard pt at 72dpi
        val pageHeight = 842
        val document = PdfDocument()
        val pageInfo = PdfDocument.PageInfo.Builder(pageWidth, pageHeight, 1).create()
        val page = document.startPage(pageInfo)
        val canvas = page.canvas

        onProgressUpdate("Rendering Professional Typography & Styles...")
        delay(400)

        // Background
        val bgPaint = Paint().apply { color = Color.WHITE }
        canvas.drawRect(0f, 0f, pageWidth.toFloat(), pageHeight.toFloat(), bgPaint)

        // Header Background Banner
        val headerPaint = Paint().apply { color = Color.parseColor("#0F2B48") } // Navy
        canvas.drawRect(0f, 0f, pageWidth.toFloat(), 110f, headerPaint)

        // Header Accent Gold Strip
        val goldPaint = Paint().apply { color = Color.parseColor("#F59E0B") }
        canvas.drawRect(0f, 110f, pageWidth.toFloat(), 115f, goldPaint)

        // Draw Candidate Photo (Top-Right of Header)
        val photoWidth = 72f
        val photoHeight = 86f
        val photoLeft = (pageWidth - 30f - photoWidth)
        val photoTop = 12f
        val photoRight = photoLeft + photoWidth
        val photoBottom = photoTop + photoHeight
        val photoDstRect = RectF(photoLeft, photoTop, photoRight, photoBottom)

        val candidateBitmap = loadBitmapFromUri(context, photoUri, 200, 240)
        if (candidateBitmap != null) {
            val srcRect = Rect(0, 0, candidateBitmap.width, candidateBitmap.height)
            canvas.drawBitmap(candidateBitmap, srcRect, photoDstRect, null)
            val borderPaint = Paint().apply {
                color = Color.WHITE
                style = Paint.Style.STROKE
                strokeWidth = 2f
            }
            canvas.drawRect(photoDstRect, borderPaint)
        } else {
            val boxPaint = Paint().apply {
                color = Color.parseColor("#1E3A5F")
                style = Paint.Style.FILL
            }
            val borderPaint = Paint().apply {
                color = Color.parseColor("#F59E0B")
                style = Paint.Style.STROKE
                strokeWidth = 1f
            }
            canvas.drawRect(photoDstRect, boxPaint)
            canvas.drawRect(photoDstRect, borderPaint)

            val txtPaint = Paint().apply {
                color = Color.parseColor("#F59E0B")
                textSize = 7.5f
                typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
                textAlign = Paint.Align.CENTER
                isAntiAlias = true
            }
            canvas.drawText("PASSPORT", photoLeft + photoWidth / 2, photoTop + photoHeight / 2 - 2f, txtPaint)
            canvas.drawText("PHOTO", photoLeft + photoWidth / 2, photoTop + photoHeight / 2 + 8f, txtPaint)
        }

        // Name & Role Text
        val titlePaint = Paint().apply {
            color = Color.WHITE
            textSize = 21f
            typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
            isAntiAlias = true
        }
        canvas.drawText(fullName.ifBlank { "Akash Internet Hub" }, 30f, 42f, titlePaint)

        val rolePaint = Paint().apply {
            color = Color.parseColor("#F59E0B")
            textSize = 12f
            typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
            isAntiAlias = true
        }
        canvas.drawText(jobRole.ifBlank { "Computer Operator & Online Services Associate" }, 30f, 64f, rolePaint)

        val contactPaint = Paint().apply {
            color = Color.parseColor("#E0F2FE")
            textSize = 9f
            isAntiAlias = true
        }
        val contactLine = "📞 $phone   |   ✉️ $email"
        canvas.drawText(contactLine, 30f, 84f, contactPaint)
        canvas.drawText("📍 $address", 30f, 98f, contactPaint)

        var currentY = 140f

        // Helper to draw section header
        fun drawSection(title: String) {
            val secTitlePaint = Paint().apply {
                color = Color.parseColor("#0F2B48")
                textSize = 13f
                typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
                isAntiAlias = true
            }
            canvas.drawText(title.uppercase(), 30f, currentY, secTitlePaint)

            val linePaint = Paint().apply {
                color = Color.parseColor("#CBD5E1")
                strokeWidth = 1.5f
            }
            canvas.drawLine(30f, currentY + 4f, (pageWidth - 30).toFloat(), currentY + 4f, linePaint)
            currentY += 20f
        }

        // Helper to draw body text with line wrap
        fun drawParagraph(text: String, indent: Float = 30f, isBold: Boolean = false, textSize: Float = 9.5f) {
            val pPaint = Paint().apply {
                color = Color.parseColor("#334155")
                this.textSize = textSize
                typeface = if (isBold) Typeface.create(Typeface.DEFAULT, Typeface.BOLD) else Typeface.DEFAULT
                isAntiAlias = true
            }
            val maxLineWidth = (pageWidth - 60).toFloat()
            val words = text.split(" ")
            var currentLine = ""
            for (word in words) {
                val testLine = if (currentLine.isEmpty()) word else "$currentLine $word"
                if (pPaint.measureText(testLine) < maxLineWidth) {
                    currentLine = testLine
                } else {
                    canvas.drawText(currentLine, indent, currentY, pPaint)
                    currentY += 14f
                    currentLine = word
                }
            }
            if (currentLine.isNotEmpty()) {
                canvas.drawText(currentLine, indent, currentY, pPaint)
                currentY += 14f
            }
            currentY += 6f
        }

        // 1. Career Objective
        drawSection("Career Objective")
        drawParagraph(careerObjective)

        // 2. Education
        drawSection("Educational Qualifications")
        drawParagraph("• $educationDegree", isBold = true)
        drawParagraph("• $educationHs")
        drawParagraph("• $educationHslc")

        // 3. Technical Skills
        drawSection("Technical Skills & Computer Proficiency")
        drawParagraph(technicalSkills)

        // 4. Work Experience
        drawSection("Work Experience & Practical Knowledge")
        drawParagraph(experienceText)

        // 5. Personal Details & Languages
        drawSection("Personal Details")
        drawParagraph("• Languages Known: $languagesKnown")
        drawParagraph("• Permanent Address: $address")
        drawParagraph("• Declaration: I hereby declare that all the information mentioned above is true and correct to the best of my knowledge.")

        // Watermark if requested
        if (isWatermarked) {
            onProgressUpdate("Applying Center Watermark...")
            val wmPaint = Paint().apply {
                color = Color.parseColor("#22000000") // 13% opacity black
                this.textSize = 28f
                typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
                isAntiAlias = true
            }
            canvas.save()
            canvas.rotate(-35f, (pageWidth / 2).toFloat(), (pageHeight / 2).toFloat())
            val text = watermarkText
            val textWidth = wmPaint.measureText(text)
            canvas.drawText(text, (pageWidth / 2 - textWidth / 2), (pageHeight / 2).toFloat(), wmPaint)
            canvas.restore()
        }

        // Footer Stamp
        val footerPaint = Paint().apply {
            color = Color.parseColor("#94A3B8")
            this.textSize = 8f
            isAntiAlias = true
        }
        val footerText = if (isWatermarked) {
            "Generated via Akash Internet Hub Cyber Portal • Free Preview Edition"
        } else {
            "Verified High-Resolution CV • Akash Internet Hub (Dhubri, Assam)"
        }
        canvas.drawText(footerText, 30f, (pageHeight - 20).toFloat(), footerPaint)

        document.finishPage(page)

        onProgressUpdate("Writing PDF Document to Storage...")
        delay(300)

        val cleanName = fullName.replace(" ", "_").replace(Regex("[^a-zA-Z0-9_]"), "")
        val suffix = if (isWatermarked) "_Free_Watermark" else "_Pro_HD"
        val fileName = "Resume_${cleanName.ifBlank { "Akash_Hub" }}$suffix.pdf"

        return savePdfDocument(context, document, fileName)
    }

    /**
     * Generate and save Marriage Bio Data PDF with optional candidate photo
     */
    suspend fun generateAndSaveBioDataPdf(
        context: Context,
        fullName: String,
        dob: String,
        birthTime: String,
        birthPlace: String,
        height: String,
        complexion: String,
        religionCaste: String,
        gotraRashi: String,
        qualification: String,
        occupation: String,
        annualIncome: String,
        fatherName: String,
        motherName: String,
        siblings: String,
        permanentAddress: String,
        contactNumber: String,
        photoUri: Uri? = null,
        isWatermarked: Boolean,
        watermarkText: String = "Downloaded From Akash Internet Hub",
        onProgressUpdate: (String) -> Unit
    ): File? {
        onProgressUpdate("Preparing Marriage Bio Data Template...")
        delay(400)

        val pageWidth = 595
        val pageHeight = 842
        val document = PdfDocument()
        val pageInfo = PdfDocument.PageInfo.Builder(pageWidth, pageHeight, 1).create()
        val page = document.startPage(pageInfo)
        val canvas = page.canvas

        onProgressUpdate("Rendering Decorative Borders & Details...")
        delay(400)

        // Background Warm Ivory
        val bgPaint = Paint().apply { color = Color.parseColor("#FFFDF8") }
        canvas.drawRect(0f, 0f, pageWidth.toFloat(), pageHeight.toFloat(), bgPaint)

        // Ornamental Maroon Outer Border
        val borderPaint = Paint().apply {
            color = Color.parseColor("#991B1B") // Rich Maroon
            style = Paint.Style.STROKE
            strokeWidth = 3f
        }
        canvas.drawRect(20f, 20f, (pageWidth - 20).toFloat(), (pageHeight - 20).toFloat(), borderPaint)

        // Inner Gold Border
        val goldBorderPaint = Paint().apply {
            color = Color.parseColor("#D97706") // Rich Gold
            style = Paint.Style.STROKE
            strokeWidth = 1.2f
        }
        canvas.drawRect(25f, 25f, (pageWidth - 25).toFloat(), (pageHeight - 25).toFloat(), goldBorderPaint)

        // Draw Candidate Photo with Golden Frame (Top-Right)
        val photoWidth = 82f
        val photoHeight = 98f
        val photoLeft = (pageWidth - 36f - photoWidth)
        val photoTop = 36f
        val photoRight = photoLeft + photoWidth
        val photoBottom = photoTop + photoHeight
        val photoDstRect = RectF(photoLeft, photoTop, photoRight, photoBottom)

        val candidateBitmap = loadBitmapFromUri(context, photoUri, 220, 260)
        if (candidateBitmap != null) {
            val srcRect = Rect(0, 0, candidateBitmap.width, candidateBitmap.height)
            canvas.drawBitmap(candidateBitmap, srcRect, photoDstRect, null)
        } else {
            val bgBoxPaint = Paint().apply { color = Color.parseColor("#FEF3C7") }
            canvas.drawRect(photoDstRect, bgBoxPaint)
            val textPaint = Paint().apply {
                color = Color.parseColor("#B45309")
                textSize = 7.5f
                typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
                textAlign = Paint.Align.CENTER
                isAntiAlias = true
            }
            canvas.drawText("CANDIDATE", photoLeft + photoWidth / 2, photoTop + photoHeight / 2 - 2f, textPaint)
            canvas.drawText("PHOTO", photoLeft + photoWidth / 2, photoTop + photoHeight / 2 + 8f, textPaint)
        }

        // Golden photo frame stroke
        val frameStrokePaint = Paint().apply {
            color = Color.parseColor("#D97706")
            style = Paint.Style.STROKE
            strokeWidth = 2f
        }
        canvas.drawRect(photoDstRect, frameStrokePaint)

        // Clean Header (English Standard)
        val headerSubPaint = Paint().apply {
            color = Color.parseColor("#991B1B")
            textSize = 10.5f
            typeface = Typeface.create(Typeface.SERIF, Typeface.BOLD)
            isAntiAlias = true
            textAlign = Paint.Align.CENTER
            letterSpacing = 0.12f
        }
        canvas.drawText("✦ CURRICULUM VITAE ✦", (pageWidth / 2 - 20).toFloat(), 52f, headerSubPaint)

        val titlePaint = Paint().apply {
            color = Color.parseColor("#B45309")
            textSize = 21f
            typeface = Typeface.create(Typeface.SERIF, Typeface.BOLD)
            isAntiAlias = true
            textAlign = Paint.Align.CENTER
            letterSpacing = 0.08f
        }
        canvas.drawText("MARRIAGE BIODATA", (pageWidth / 2 - 20).toFloat(), 78f, titlePaint)

        var currentY = 110f

        fun drawCategoryHeader(title: String) {
            val catBgPaint = Paint().apply { color = Color.parseColor("#FEF3C7") }
            canvas.drawRoundRect(35f, currentY - 14f, (pageWidth - 35).toFloat(), currentY + 6f, 6f, 6f, catBgPaint)

            val catTextPaint = Paint().apply {
                color = Color.parseColor("#92400E")
                textSize = 11.5f
                typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
                isAntiAlias = true
            }
            canvas.drawText("✦ $title", 45f, currentY, catTextPaint)
            currentY += 22f
        }

        fun drawField(label: String, value: String) {
            val lblPaint = Paint().apply {
                color = Color.parseColor("#78350F")
                textSize = 10f
                typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
                isAntiAlias = true
            }
            val valPaint = Paint().apply {
                color = Color.parseColor("#1E293B")
                textSize = 10f
                isAntiAlias = true
            }
            canvas.drawText("$label :", 45f, currentY, lblPaint)
            canvas.drawText(value, 180f, currentY, valPaint)
            currentY += 17f
        }

        // 1. Personal
        drawCategoryHeader("PERSONAL DETAILS")
        drawField("Full Name", fullName.ifBlank { "Akash Internet Hub" })
        drawField("Date of Birth", dob)
        drawField("Time & Place", "$birthTime • $birthPlace")
        drawField("Height & Complexion", "$height • $complexion")
        drawField("Religion / Caste", religionCaste)
        drawField("Gotra / Rashi", gotraRashi)

        currentY += 6f
        // 2. Education & Career
        drawCategoryHeader("EDUCATION & OCCUPATION")
        drawField("Highest Degree", qualification)
        drawField("Current Occupation", occupation)
        drawField("Annual Income", annualIncome)

        currentY += 6f
        // 3. Family Details
        drawCategoryHeader("FAMILY BACKGROUND")
        drawField("Father's Name", fatherName)
        drawField("Mother's Name", motherName)
        drawField("Siblings Details", siblings)
        drawField("Native Address", permanentAddress)

        currentY += 6f
        // 4. Contact
        drawCategoryHeader("CONTACT INFORMATION")
        drawField("Mobile Number", contactNumber)
        drawField("Alternate / WhatsApp", "+91 7002134700")

        // Watermark if free
        if (isWatermarked) {
            onProgressUpdate("Applying Watermark Stamp...")
            val wmPaint = Paint().apply {
                color = Color.parseColor("#22991B1B")
                this.textSize = 26f
                typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
                isAntiAlias = true
            }
            canvas.save()
            canvas.rotate(-35f, (pageWidth / 2).toFloat(), (pageHeight / 2).toFloat())
            val text = watermarkText
            val textWidth = wmPaint.measureText(text)
            canvas.drawText(text, (pageWidth / 2 - textWidth / 2), (pageHeight / 2).toFloat(), wmPaint)
            canvas.restore()
        }

        document.finishPage(page)

        onProgressUpdate("Writing Marriage Bio Data to Storage...")
        delay(300)

        val cleanName = fullName.replace(" ", "_").replace(Regex("[^a-zA-Z0-9_]"), "")
        val suffix = if (isWatermarked) "_Free_Watermark" else "_Pro_HD"
        val fileName = "Marriage_BioData_${cleanName.ifBlank { "Akash_Hub" }}$suffix.pdf"

        return savePdfDocument(context, document, fileName)
    }

    /**
     * Generate and save Simple Professional Bio Data PDF for Job / Employment
     */
    suspend fun generateAndSaveSimpleJobBioDataPdf(
        context: Context,
        fullName: String,
        fatherName: String,
        motherName: String,
        dob: String,
        gender: String,
        maritalStatus: String,
        nationality: String,
        religionCategory: String,
        contactNumber: String,
        emailAddress: String,
        presentAddress: String,
        permanentAddress: String,
        careerObjective: String,
        qualification: String,
        technicalSkills: String,
        workExperience: String,
        languagesKnown: String,
        photoUri: Uri? = null,
        isWatermarked: Boolean,
        watermarkText: String = "Downloaded From Akash Internet Hub",
        onProgressUpdate: (String) -> Unit
    ): File? {
        onProgressUpdate("Preparing Job Bio Data Template...")
        delay(400)

        val pageWidth = 595
        val pageHeight = 842
        val document = PdfDocument()
        val pageInfo = PdfDocument.PageInfo.Builder(pageWidth, pageHeight, 1).create()
        val page = document.startPage(pageInfo)
        val canvas = page.canvas

        onProgressUpdate("Rendering Clean Formal Layout...")
        delay(400)

        // Background Clean White
        val bgPaint = Paint().apply { color = Color.WHITE }
        canvas.drawRect(0f, 0f, pageWidth.toFloat(), pageHeight.toFloat(), bgPaint)

        // Outer Clean Border (Navy / Charcoal)
        val borderPaint = Paint().apply {
            color = Color.parseColor("#1E3A8A")
            style = Paint.Style.STROKE
            strokeWidth = 2f
        }
        canvas.drawRect(24f, 24f, (pageWidth - 24).toFloat(), (pageHeight - 24).toFloat(), borderPaint)

        // Header Title Box
        val headerBoxPaint = Paint().apply { color = Color.parseColor("#1E3A8A") }
        canvas.drawRect(24f, 24f, (pageWidth - 24).toFloat(), 64f, headerBoxPaint)

        val headerTextPaint = Paint().apply {
            color = Color.WHITE
            textSize = 16f
            typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
            isAntiAlias = true
            textAlign = Paint.Align.CENTER
            letterSpacing = 0.1f
        }
        canvas.drawText("BIO-DATA FOR EMPLOYMENT", (pageWidth / 2).toFloat(), 48f, headerTextPaint)

        // Candidate Photo (Top-Right)
        val photoWidth = 75f
        val photoHeight = 90f
        val photoLeft = (pageWidth - 36f - photoWidth)
        val photoTop = 74f
        val photoRight = photoLeft + photoWidth
        val photoBottom = photoTop + photoHeight
        val photoDstRect = RectF(photoLeft, photoTop, photoRight, photoBottom)

        val candidateBitmap = loadBitmapFromUri(context, photoUri, 200, 240)
        if (candidateBitmap != null) {
            val srcRect = Rect(0, 0, candidateBitmap.width, candidateBitmap.height)
            canvas.drawBitmap(candidateBitmap, srcRect, photoDstRect, null)
            val photoBorderPaint = Paint().apply {
                color = Color.parseColor("#1E3A8A")
                style = Paint.Style.STROKE
                strokeWidth = 1.5f
            }
            canvas.drawRect(photoDstRect, photoBorderPaint)
        } else {
            val bgBoxPaint = Paint().apply { color = Color.parseColor("#F1F5F9") }
            canvas.drawRect(photoDstRect, bgBoxPaint)
            val textPaint = Paint().apply {
                color = Color.parseColor("#64748B")
                textSize = 7.5f
                typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
                textAlign = Paint.Align.CENTER
                isAntiAlias = true
            }
            canvas.drawText("AFFIX", photoLeft + photoWidth / 2, photoTop + photoHeight / 2 - 2f, textPaint)
            canvas.drawText("PHOTO", photoLeft + photoWidth / 2, photoTop + photoHeight / 2 + 8f, textPaint)
            val photoBorderPaint = Paint().apply {
                color = Color.parseColor("#94A3B8")
                style = Paint.Style.STROKE
                strokeWidth = 1f
            }
            canvas.drawRect(photoDstRect, photoBorderPaint)
        }

        var currentY = 82f

        fun drawSectionHeader(title: String) {
            val barPaint = Paint().apply { color = Color.parseColor("#E0E7FF") }
            canvas.drawRect(34f, currentY - 12f, (pageWidth - 34).toFloat(), currentY + 4f, barPaint)

            val textPaint = Paint().apply {
                color = Color.parseColor("#1E3A8A")
                textSize = 10.5f
                typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
                isAntiAlias = true
            }
            canvas.drawText(title, 40f, currentY, textPaint)
            currentY += 18f
        }

        fun drawFieldLine(label: String, value: String) {
            val lblPaint = Paint().apply {
                color = Color.parseColor("#334155")
                textSize = 9.5f
                typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
                isAntiAlias = true
            }
            val valPaint = Paint().apply {
                color = Color.parseColor("#0F172A")
                textSize = 9.5f
                isAntiAlias = true
            }
            canvas.drawText("$label :", 40f, currentY, lblPaint)
            canvas.drawText(value, 175f, currentY, valPaint)
            currentY += 15.5f
        }

        // Section 1: Personal Details
        drawSectionHeader("1. PERSONAL DETAILS")
        drawFieldLine("Name of Candidate", fullName.ifBlank { "Akash Internet Hub" })
        drawFieldLine("Father's Name", fatherName)
        drawFieldLine("Mother's Name", motherName)
        drawFieldLine("Date of Birth", dob)
        drawFieldLine("Gender / Marital Status", "$gender / $maritalStatus")
        drawFieldLine("Nationality / Category", "$nationality / $religionCategory")

        currentY += 4f
        // Section 2: Contact Details
        drawSectionHeader("2. CONTACT & ADDRESS")
        drawFieldLine("Mobile Number", contactNumber)
        drawFieldLine("Email Address", emailAddress)
        drawFieldLine("Present Address", presentAddress)
        drawFieldLine("Permanent Address", permanentAddress)

        currentY += 4f
        // Section 3: Career Objective
        drawSectionHeader("3. CAREER OBJECTIVE")
        val objPaint = Paint().apply {
            color = Color.parseColor("#334155")
            textSize = 9f
            isAntiAlias = true
        }
        val objLines = if (careerObjective.length > 70) {
            val mid = careerObjective.indexOf(" ", 60).let { if (it == -1) 60 else it }
            listOf(careerObjective.substring(0, mid), careerObjective.substring(mid).trim())
        } else {
            listOf(careerObjective)
        }
        objLines.forEach { l ->
            canvas.drawText(l, 40f, currentY, objPaint)
            currentY += 13f
        }

        currentY += 4f
        // Section 4: Educational Qualifications
        drawSectionHeader("4. ACADEMIC QUALIFICATION")
        drawFieldLine("Educational Degree", qualification)

        currentY += 4f
        // Section 5: Technical Skills & Experience
        drawSectionHeader("5. TECHNICAL SKILLS & EXPERIENCE")
        drawFieldLine("Technical / Computer Skills", technicalSkills)
        drawFieldLine("Working Experience", workExperience)
        drawFieldLine("Languages Known", languagesKnown)

        currentY += 6f
        // Section 6: Declaration
        drawSectionHeader("6. DECLARATION")
        val decPaint = Paint().apply {
            color = Color.parseColor("#475569")
            textSize = 8.5f
            isAntiAlias = true
        }
        canvas.drawText("I hereby declare that all the information furnished above is true and correct to the best of my knowledge.", 40f, currentY, decPaint)
        currentY += 30f

        // Date & Signature
        val signPaint = Paint().apply {
            color = Color.parseColor("#1E293B")
            textSize = 9f
            typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
            isAntiAlias = true
        }
        canvas.drawText("Date: ___/___/2026", 40f, currentY, signPaint)
        canvas.drawText("Place: Dhubri, Assam", 40f, currentY + 14f, signPaint)

        canvas.drawText("(Signature of Candidate)", (pageWidth - 180).toFloat(), currentY + 14f, signPaint)

        // Watermark if free
        if (isWatermarked) {
            onProgressUpdate("Applying Watermark Stamp...")
            val wmPaint = Paint().apply {
                color = Color.parseColor("#221E3A8A")
                this.textSize = 26f
                typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
                isAntiAlias = true
            }
            canvas.save()
            canvas.rotate(-35f, (pageWidth / 2).toFloat(), (pageHeight / 2).toFloat())
            val text = watermarkText
            val textWidth = wmPaint.measureText(text)
            canvas.drawText(text, (pageWidth / 2 - textWidth / 2), (pageHeight / 2).toFloat(), wmPaint)
            canvas.restore()
        }

        document.finishPage(page)

        onProgressUpdate("Writing Job Bio Data to Storage...")
        delay(300)

        val cleanName = fullName.replace(" ", "_").replace(Regex("[^a-zA-Z0-9_]"), "")
        val suffix = if (isWatermarked) "_Free_Watermark" else "_Pro_HD"
        val fileName = "Job_BioData_${cleanName.ifBlank { "Akash_Hub" }}$suffix.pdf"

        return savePdfDocument(context, document, fileName)
    }

    /**
     * Generate and save generic Image or PDF Document for Photo Studio / ID card merger / converters
     */
    suspend fun generateAndSaveGenericToolPdf(
        context: Context,
        toolTitle: String,
        description: String,
        isWatermarked: Boolean,
        watermarkText: String = "Downloaded From Akash Internet Hub",
        onProgressUpdate: (String) -> Unit
    ): File? {
        onProgressUpdate("Generating High Definition Document...")
        delay(400)

        val pageWidth = 595
        val pageHeight = 842
        val document = PdfDocument()
        val pageInfo = PdfDocument.PageInfo.Builder(pageWidth, pageHeight, 1).create()
        val page = document.startPage(pageInfo)
        val canvas = page.canvas

        onProgressUpdate("Rendering Document Graphics & 300 DPI Canvas...")
        delay(400)

        // Background
        val bgPaint = Paint().apply { color = Color.WHITE }
        canvas.drawRect(0f, 0f, pageWidth.toFloat(), pageHeight.toFloat(), bgPaint)

        // Header
        val headPaint = Paint().apply { color = Color.parseColor("#0F2B48") }
        canvas.drawRect(0f, 0f, pageWidth.toFloat(), 90f, headPaint)

        val titlePaint = Paint().apply {
            color = Color.WHITE
            textSize = 18f
            typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
            isAntiAlias = true
        }
        canvas.drawText("AKASH INTERNET HUB • $toolTitle", 30f, 42f, titlePaint)

        val subPaint = Paint().apply {
            color = Color.parseColor("#F59E0B")
            textSize = 10f
            isAntiAlias = true
        }
        canvas.drawText("Common Services Center • Near Saba Petrol Pump, Geramari, Dhubri", 30f, 65f, subPaint)

        // Cut Guideline Box
        val boxBorder = Paint().apply {
            color = Color.parseColor("#DC2626")
            style = Paint.Style.STROKE
            strokeWidth = 1.5f
        }
        canvas.drawRoundRect(30f, 120f, (pageWidth - 30).toFloat(), 480f, 8f, 8f, boxBorder)

        val labelPaint = Paint().apply {
            color = Color.parseColor("#1E293B")
            textSize = 12f
            typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
            isAntiAlias = true
            textAlign = Paint.Align.CENTER
        }
        canvas.drawText("READY FOR HIGH-PRECISION LASER PRINT / DIGITAL SUBMISSION", (pageWidth / 2).toFloat(), 280f, labelPaint)

        val descPaint = Paint().apply {
            color = Color.parseColor("#64748B")
            textSize = 10f
            isAntiAlias = true
            textAlign = Paint.Align.CENTER
        }
        canvas.drawText(description, (pageWidth / 2).toFloat(), 310f, descPaint)

        if (isWatermarked) {
            onProgressUpdate("Applying Center Watermark...")
            val wmPaint = Paint().apply {
                color = Color.parseColor("#25000000")
                this.textSize = 26f
                typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
                isAntiAlias = true
            }
            canvas.save()
            canvas.rotate(-35f, (pageWidth / 2).toFloat(), (pageHeight / 2).toFloat())
            val text = watermarkText
            val textWidth = wmPaint.measureText(text)
            canvas.drawText(text, (pageWidth / 2 - textWidth / 2), (pageHeight / 2).toFloat(), wmPaint)
            canvas.restore()
        }

        document.finishPage(page)

        onProgressUpdate("Saving to Downloads...")
        delay(300)

        val cleanTitle = toolTitle.replace(" ", "_").replace(Regex("[^a-zA-Z0-9_]"), "")
        val suffix = if (isWatermarked) "_Free_Watermark" else "_Clean_HD"
        val fileName = "AkashHub_${cleanTitle}$suffix.pdf"

        return savePdfDocument(context, document, fileName)
    }

    private fun savePdfDocument(context: Context, document: PdfDocument, fileName: String): File? {
        return try {
            // Save to external files dir or cache dir
            val targetDir = context.getExternalFilesDir(Environment.DIRECTORY_DOCUMENTS) ?: context.filesDir
            if (!targetDir.exists()) {
                targetDir.mkdirs()
            }
            val targetFile = File(targetDir, fileName)
            val outputStream = FileOutputStream(targetFile)
            document.writeTo(outputStream)
            document.close()
            outputStream.flush()
            outputStream.close()
            targetFile
        } catch (e: Exception) {
            e.printStackTrace()
            try {
                document.close()
            } catch (_: Exception) {}
            null
        }
    }

    /**
     * Open or Share the saved PDF file with external viewer / WhatsApp
     */
    fun openOrSharePdfFile(context: Context, file: File, title: String = "Open Document") {
        try {
            val uri: Uri = FileProvider.getUriForFile(
                context,
                "${context.packageName}.fileprovider",
                file
            )

            val viewIntent = Intent(Intent.ACTION_VIEW).apply {
                setDataAndType(uri, "application/pdf")
                addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            }

            val chooser = Intent.createChooser(viewIntent, title).apply {
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            }
            context.startActivity(chooser)
        } catch (e: Exception) {
            e.printStackTrace()
            Toast.makeText(
                context,
                "✅ File saved at: ${file.name}\n(Available in Downloads)",
                Toast.LENGTH_LONG
            ).show()
        }
    }
}
