package com.example.utils

import android.app.Activity
import android.content.Context
import android.content.ContextWrapper
import android.content.Intent
import android.net.Uri
import android.util.Log
import androidx.browser.customtabs.CustomTabsIntent

object MonetagHelper {
    private const val TAG = "MonetagHelper"
    const val MONETAG_DIRECT_LINK = "https://omg10.com/4/11642068"

    /**
     * Opens the Monetag direct link via Chrome Custom Tabs with standard browser fallback.
     * Guaranteed to execute asynchronously and non-blockingly so primary user actions proceed uninterrupted.
     */
    fun openMonetagAd(context: Context, url: String = MONETAG_DIRECT_LINK) {
        try {
            val customTabsIntent = CustomTabsIntent.Builder()
                .setShowTitle(true)
                .build()
            customTabsIntent.launchUrl(context, Uri.parse(url))
        } catch (e: Exception) {
            Log.w(TAG, "CustomTabs failed, falling back to standard intent", e)
            try {
                val intent = Intent(Intent.ACTION_VIEW, Uri.parse(url)).apply {
                    addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                }
                context.startActivity(intent)
            } catch (err: Exception) {
                Log.e(TAG, "Browser fallback failed", err)
            }
        }
    }
}

/**
 * Extension function to find the host Activity from any Context
 */
fun Context.findActivity(): Activity? {
    var currentContext = this
    while (currentContext is ContextWrapper) {
        if (currentContext is Activity) {
            return currentContext
        }
        currentContext = currentContext.baseContext
    }
    return null
}
