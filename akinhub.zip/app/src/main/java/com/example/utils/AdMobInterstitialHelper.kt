package com.example.utils

import android.app.Activity
import android.content.Context
import android.content.ContextWrapper
import android.util.Log
import com.google.android.gms.ads.AdError
import com.google.android.gms.ads.AdRequest
import com.google.android.gms.ads.FullScreenContentCallback
import com.google.android.gms.ads.LoadAdError
import com.google.android.gms.ads.interstitial.InterstitialAd
import com.google.android.gms.ads.interstitial.InterstitialAdLoadCallback

/**
 * Live Google AdMob Interstitial Ad Unit ID for Akash Internet Hub
 */
const val ADMOB_INTERSTITIAL_AD_UNIT_ID = "ca-app-pub-8605802472900242/6683643592"

object AdMobInterstitialHelper {
    private const val TAG = "AdMobInterstitial"
    private var interstitialAd: InterstitialAd? = null
    private var isLoading = false

    /**
     * Preloads an Interstitial Ad into memory for instant display on demand.
     */
    fun loadInterstitialAd(context: Context, adUnitId: String = ADMOB_INTERSTITIAL_AD_UNIT_ID) {
        if (interstitialAd != null || isLoading) {
            return
        }

        isLoading = true
        val adRequest = AdRequest.Builder().build()

        InterstitialAd.load(
            context.applicationContext,
            adUnitId,
            adRequest,
            object : InterstitialAdLoadCallback() {
                override fun onAdLoaded(ad: InterstitialAd) {
                    interstitialAd = ad
                    isLoading = false
                    Log.d(TAG, "AdMob Interstitial Ad Loaded Successfully.")
                }

                override fun onAdFailedToLoad(loadAdError: LoadAdError) {
                    interstitialAd = null
                    isLoading = false
                    Log.w(TAG, "AdMob Interstitial failed to load: ${loadAdError.message} (Code: ${loadAdError.code})")
                }
            }
        )
    }

    /**
     * Shows the loaded Interstitial Ad.
     * When the ad is dismissed or if no ad is ready, the [onDismissedOrFailed] action is
     * executed immediately so that downloads or AI generation calls proceed seamlessly.
     */
    fun showInterstitialAd(
        activity: Activity?,
        onDismissedOrFailed: () -> Unit
    ) {
        val currentAd = interstitialAd
        if (activity != null && currentAd != null) {
            currentAd.fullScreenContentCallback = object : FullScreenContentCallback() {
                override fun onAdDismissedFullScreenContent() {
                    Log.d(TAG, "AdMob Interstitial Dismissed by user.")
                    interstitialAd = null
                    // Preload the next ad for future actions
                    loadInterstitialAd(activity)
                    // Resume the user's intended action
                    onDismissedOrFailed()
                }

                override fun onAdFailedToShowFullScreenContent(adError: AdError) {
                    Log.e(TAG, "AdMob Interstitial failed to show: ${adError.message}")
                    interstitialAd = null
                    loadInterstitialAd(activity)
                    onDismissedOrFailed()
                }

                override fun onAdShowedFullScreenContent() {
                    Log.d(TAG, "AdMob Interstitial is now showing.")
                }
            }
            currentAd.show(activity)
        } else {
            Log.d(TAG, "Interstitial ad not ready or activity null. Proceeding directly.")
            if (activity != null) {
                loadInterstitialAd(activity)
            }
            onDismissedOrFailed()
        }
    }
}

/**
 * Extension to find the Host Activity from any Compose Context.
 */
fun Context.findActivity(): Activity? {
    var currentContext = this
    while (currentContext is ContextWrapper) {
        if (currentContext is Activity) {
            return currentContext
        }
        currentContext = currentContext.baseContext
    }
    return null
}
